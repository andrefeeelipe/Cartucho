"""Gera todos os ícones do Cartucho a partir do desenho do Claude Design (grade 100 × 100)."""
import os, subprocess, sys
from PIL import Image

SYMBOL = '''<path d="M24 16 H76 Q83 16 83 23 V33 L77 40 V82 Q77 85 74 85 H26 Q23 85 23 82 V40 L17 33 V23 Q17 16 24 16 Z" fill="#D2D2DB"/>
<rect x="24" y="20" width="2.4" height="8" rx="1.2" fill="#A9A9B8"/><rect x="29" y="20" width="2.4" height="8" rx="1.2" fill="#A9A9B8"/>
<rect x="69.6" y="20" width="2.4" height="8" rx="1.2" fill="#A9A9B8"/><rect x="74.6" y="20" width="2.4" height="8" rx="1.2" fill="#A9A9B8"/>
<rect x="30" y="38" width="40" height="38" rx="4" fill="#2B2B33"/>
<circle cx="50" cy="49.8" r="3.6" fill="#2A5DB8"/><circle cx="57.2" cy="57" r="3.6" fill="#D3262F"/>
<circle cx="50" cy="64.2" r="3.6" fill="#F0BE1E"/><circle cx="42.8" cy="57" r="3.6" fill="#23965A"/>'''
PURPLE = "#4F43AE"

def icon_svg(rx):  # rx em % do lado (22 = padrão, 12 = Windows, 0 = quadrado inteiro, 50 = redondo)
    bg = f'<circle cx="50" cy="50" r="50" fill="{PURPLE}"/>' if rx == 50 else f'<rect width="100" height="100" rx="{rx}" fill="{PURPLE}"/>'
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">{bg}{SYMBOL}</svg>'

def symbol_svg():
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="15 14 70 73">{SYMBOL}</svg>'

def adaptive_fg_svg():
    # 108 × 108: a parte visível do ícone adaptável tem 72, que equivale ao quadrado de 100 do desenho.
    s = 0.72
    tx = 54 - 50 * s
    ty = 54 - 50 * s
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108"><g transform="translate({tx:.3f} {ty:.3f}) scale({s:.5f})">{SYMBOL}</g></svg>'

def render(svg, size, out, w=None):
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    tmp = out + ".svg"
    open(tmp, "w").write(svg)
    args = ["rsvg-convert", "-w", str(w or size), "-h", str(size), tmp, "-o", out]
    subprocess.check_call(args)
    os.remove(tmp)

ROOT = sys.argv[1]   # /home/claude/cartucho
SITE = sys.argv[2]   # /home/claude/cartucho-repo
open(os.path.join(ROOT, "brand/cartucho-icone.svg"), "w").write(icon_svg(22))
open(os.path.join(ROOT, "brand/cartucho-simbolo.svg"), "w").write(symbol_svg())

res = os.path.join(ROOT, "app/src/main/res")
for d, px in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
    render(icon_svg(22), px, f"{res}/mipmap-{d}/ic_launcher.png")
    render(icon_svg(50), px, f"{res}/mipmap-{d}/ic_launcher_round.png")
    render(adaptive_fg_svg(), px * 108 // 48, f"{res}/mipmap-{d}/ic_launcher_foreground.png")
render(icon_svg(0), 512, f"{res}/drawable-nodpi/brand_icon.png")

a = os.path.join(ROOT, "desktop/assets")
render(icon_svg(0), 512, f"{a}/brand_icon.png")
render(icon_svg(22), 512, f"{a}/cartucho.png")
render(icon_svg(0), 1024, f"{a}/ios-icon.png")
Image.open(f"{a}/ios-icon.png").convert("RGB").save(f"{a}/ios-icon.png")  # iPhone: sem transparência
render(icon_svg(22), 256, f"{a}/cartucho-256.png")  # Linux
render(symbol_svg(), 512, f"{a}/simbolo.png", w=round(512 * 70 / 73))
# Windows: cantos curtos, vários tamanhos num .ico só.
render(icon_svg(12), 256, "/tmp/ico256.png")
Image.open("/tmp/ico256.png").save(f"{a}/cartucho.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])

site = os.path.join(SITE, "site")
render(icon_svg(22), 64, f"{site}/favicon.png")
for n in (180, 192, 512):
    render(icon_svg(0 if n == 180 else 22), n, f"{site}/jogar/icon-{n}.png")
render(icon_svg(22), 512, f"{SITE}/docs/cartucho.png")
print("ok")
