# Ponte JNI: nomes de classe e métodos são usados pelo código nativo.
-keep class app.cartucho.emu.NativeBridge { *; }
-keepclasseswithmembernames class * { native <methods>; }

# Google Sign-In / Play Services
-keep class com.google.android.gms.auth.** { *; }
-dontwarn com.google.android.gms.**

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# security-crypto (Tink)
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**

# Compactados
-keep class org.apache.commons.compress.** { *; }
-keep class org.tukaani.xz.** { *; }
-keep class com.github.junrar.** { *; }
-dontwarn org.apache.commons.compress.**
-dontwarn com.github.luben.zstd.**
-dontwarn org.brotli.dec.**
-dontwarn org.objectweb.asm.**
-dontwarn org.osgi.**
-dontwarn org.slf4j.**
-dontwarn java.nio.file.**
-dontwarn javax.annotation.**
-dontwarn org.apache.commons.io.**
-dontwarn org.apache.commons.lang3.**
