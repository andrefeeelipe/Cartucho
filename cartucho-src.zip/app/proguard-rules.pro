# Ponte JNI: nomes de classe e métodos são usados pelo código nativo.
-keep class app.cartucho.emu.NativeBridge { *; }
-keepclasseswithmembernames class * { native <methods>; }

# Google Sign-In / Play Services
-keep class com.google.android.gms.auth.** { *; }
-dontwarn com.google.android.gms.**

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# security-crypto (Tink)
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
