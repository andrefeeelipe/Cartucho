package app.cartucho.data

import android.app.Application
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

/** Gera os 6 cards (zerado e jogando, nos 3 formatos) em PNG para conferir com os modelos. */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [34], application = Application::class)
class GameCardPreviewTest {
    private fun sample(finished: Boolean) = CardData(
        title = if (finished) "Mega Man X" else "Chrono Trigger",
        console = "SNES",
        finished = finished,
        platinum = false,
        rating = if (finished) 8 else 10,
        seconds = if (finished) 12 * 3600L + 34 * 60 else 6 * 3600L + 10 * 60,
        player = "@exemplo",
        date = if (finished) 1793847600000L else 1793588400000L,
        comment = if (finished) "A primeira fase na rodovia continua perfeita. Joguei de novo só pela trilha."
        else "Cada era tem uma trilha melhor que a outra. Sem pressa nenhuma de terminar.",
        level = 754,
        achievementsTotal = if (finished) 10 else 21,
        achievementsUnlocked = if (finished) 9 else 14,
        highlights = if (finished) listOf("Primeiro chefe derrotado" to 5, "Todos os upgrades" to 10, "Sem tomar dano" to 25, "Fim de jogo" to 50)
        else listOf("Primeira viagem no tempo" to 5, "Técnica dupla" to 10, "Feira do milênio" to 10, "Portal aberto" to 25),
        coverFile = null,
    )

    @Test
    fun renderAll() {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val out = File("build/card-previews").apply { mkdirs() }
        for (finished in listOf(true, false)) for (format in CardFormat.values()) {
            val bmp = GameCard.renderCard(context, sample(finished), format)
            val name = (if (finished) "zerado" else "jogando") + "-" + format.name.lowercase() + ".png"
            File(out, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        // Sem conquistas nem comentário (o caso de quem não usa RetroAchievements).
        val bare = sample(false).copy(achievementsTotal = 0, achievementsUnlocked = 0, highlights = emptyList(), comment = "", rating = 0)
        for (format in CardFormat.values()) {
            val bmp = GameCard.renderCard(context, bare, format)
            File(out, "simples-" + format.name.lowercase() + ".png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
    }
}
