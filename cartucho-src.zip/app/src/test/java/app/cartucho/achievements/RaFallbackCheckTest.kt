package app.cartucho.achievements

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/** Confere, com a internet do CI, se a busca pelo nome acha jogos traduzidos no RetroAchievements. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = Application::class)
class RaFallbackCheckTest {
    @Test
    fun lookup() {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val cases = listOf(
            18 to listOf("Digimon World - Dawn (USA) (PT-BR)", "Digimon World - Dawn", "Digimon World Dawn (Traduzido).nds"),
            3 to listOf("Chrono Trigger (Traduzido)", "Chrono Trigger [T-Por]"),
            5 to listOf("Pokemon - Edicao Vermelho Fogo", "Pokemon - FireRed Version (USA) [T-Br]"),
        )
        val out = StringBuilder()
        for ((console, names) in cases) {
            val r = runCatching { RaFallback.findGameId(context, console, names, "Cartucho/1.0 (CI)") }
            out.append("console $console ${names.first()} -> ${r.getOrNull() ?: r.exceptionOrNull()}\n")
        }
        File("build/card-previews").mkdirs()
        File("build/card-previews/ra-check.txt").writeText(out.toString())
        println(out)
    }
}
