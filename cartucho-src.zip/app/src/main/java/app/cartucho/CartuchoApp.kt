package app.cartucho

import app.cartucho.data.Translations
import app.cartucho.data.Covers
import app.cartucho.data.CollectionStore

import android.app.Application
import app.cartucho.data.DeviceProfile
import app.cartucho.data.GameDetector
import app.cartucho.data.GameLibrary
import app.cartucho.data.Prefs
import app.cartucho.data.SecureStore
import java.io.File

class CartuchoApp : Application() {
    lateinit var prefs: Prefs
        private set
    lateinit var library: GameLibrary
        private set
    lateinit var device: DeviceProfile
        private set
    lateinit var secure: SecureStore
        private set
    lateinit var detector: GameDetector
        private set
    lateinit var covers: Covers
        private set
    val collection: CollectionStore by lazy { CollectionStore(this) }
    /** Catálogo de traduções PT-BR (carregado sob demanda, em segundo plano). */
    val translations: Translations by lazy { Translations(this).also { it.load() } }
    /** Mural dos amigos (reações e comentários). */
    val mural: app.cartucho.social.Mural by lazy { app.cartucho.social.Mural(this) }
    /** Loja de jogos gratuitos (homebrew). */
    val store: app.cartucho.data.Store by lazy { app.cartucho.data.Store(this).also { it.load() } }
    /** Perfil do jogador (nome e foto). */
    val profile: app.cartucho.data.Profile by lazy { app.cartucho.data.Profile(this) }
    /** Reconhece os jogos pelo conteúdo (nome oficial e capa certa). */
    val identifier: app.cartucho.data.GameIdentifier by lazy {
        app.cartucho.data.GameIdentifier(this).also { id ->
            val scanner = app.cartucho.data.GameScanner(this, detector)
            id.siblingUri = { g, name ->
                val uri = android.net.Uri.parse(g.uri)
                val tree = g.treeUri?.let { android.net.Uri.parse(it) }
                val parent = g.parentDocId
                when {
                    uri.scheme == "file" -> uri.path?.let { java.io.File(java.io.File(it).parentFile, name) }?.takeIf { it.exists() }?.let { android.net.Uri.fromFile(it) }
                    tree != null && parent != null -> runCatching {
                        scanner.listChildren(tree, parent).firstOrNull { it.name.equals(name, true) }
                            ?.let { android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, it.docId) }
                    }.getOrNull()
                    else -> null
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        CrashReport.install(this)
        prefs = Prefs(this)
        library = GameLibrary(this)
        device = DeviceProfile(this)
        secure = SecureStore(this)
        detector = GameDetector(this)
        covers = Covers(this)
        // Fora da thread principal para não atrasar a abertura do app nem do jogo.
        Thread { copyBundledSystemFiles() }.start()
    }

    /** Copia arquivos de sistema embutidos no APK (ex.: fontes do PPSSPP) na primeira execução. */
    private fun copyBundledSystemFiles() {
        val marker = File(filesDir, "system/.bundled-v3")
        if (!marker.exists()) runCatching {
            copyAssetDir("system", File(filesDir, "system"))
            marker.parentFile?.mkdirs()
            marker.writeText("ok")
        }
        registerBuiltInGames()
    }

    /** Jogos gratuitos que já vêm com o app (os dados chegam junto com o emulador). */
    private fun registerBuiltInGames() {
        val builtIn = listOf(
            Triple("cavestory", "Cave Story", File(filesDir, "system/nxengine/Doukutsu.exe")),
        )
        for ((systemId, title, file) in builtIn) {
            if (!file.exists()) continue
            val uri = android.net.Uri.fromFile(file).toString()
            val id = app.cartucho.data.GameLibrary.idFor(uri)
            if (library.find(id) != null) continue
            library.upsert(
                app.cartucho.data.Game(
                    id = id, title = title, fileName = file.name, uri = uri, systemId = systemId,
                    size = file.length(), addedAt = System.currentTimeMillis(), folderPath = "Inclusos",
                ),
            )
        }
    }

    private fun copyAssetDir(path: String, dest: File) {
        val children = assets.list(path) ?: return
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { input -> dest.outputStream().use { input.copyTo(it) } }
            return
        }
        dest.mkdirs()
        children.forEach { copyAssetDir("$path/$it", File(dest, it)) }
    }

    companion object {
        lateinit var instance: CartuchoApp
            private set
    }
}
