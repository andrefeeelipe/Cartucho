package app.cartucho

import app.cartucho.data.Covers
import app.cartucho.data.CollectionStore

import android.app.Application
import app.cartucho.data.DeviceProfile
import app.cartucho.data.GameDetector
import app.cartucho.data.GameLibrary
import app.cartucho.data.Prefs
import app.cartucho.data.SecureStore
import java.io.File

class CartuchoApp : Application() {
    lateinit var prefs: Prefs
        private set
    lateinit var library: GameLibrary
        private set
    lateinit var device: DeviceProfile
        private set
    lateinit var secure: SecureStore
        private set
    lateinit var detector: GameDetector
        private set
    lateinit var covers: Covers
        private set
    val collection: CollectionStore by lazy { CollectionStore(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        library = GameLibrary(this)
        device = DeviceProfile(this)
        secure = SecureStore(this)
        detector = GameDetector(this)
        covers = Covers(this)
        // Fora da thread principal para não atrasar a abertura do app nem do jogo.
        Thread { copyBundledSystemFiles() }.start()
    }

    /** Copia arquivos de sistema embutidos no APK (ex.: fontes do PPSSPP) na primeira execução. */
    private fun copyBundledSystemFiles() {
        val marker = File(filesDir, "system/.bundled-v1")
        if (marker.exists()) return
        runCatching {
            copyAssetDir("system", File(filesDir, "system"))
            marker.parentFile?.mkdirs()
            marker.writeText("ok")
        }
    }

    private fun copyAssetDir(path: String, dest: File) {
        val children = assets.list(path) ?: return
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { input -> dest.outputStream().use { input.copyTo(it) } }
            return
        }
        dest.mkdirs()
        children.forEach { copyAssetDir("$path/$it", File(dest, it)) }
    }

    companion object {
        lateinit var instance: CartuchoApp
            private set
    }
}
