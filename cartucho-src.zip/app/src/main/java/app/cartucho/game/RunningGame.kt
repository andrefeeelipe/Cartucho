package app.cartucho.game

import android.app.ActivityManager
import android.content.Context
import java.io.File

/**
 * Marca "tem um jogo aberto" enquanto o jogo roda. Se a marca continua lá e o processo do jogo não existe
 * mais, o jogo fechou sozinho (erro do emulador ou o Android sem memória): a biblioteca oferece continuar
 * do último ponto de retomada.
 */
object RunningGame {
    private const val FILE = "jogo-aberto.txt"

    fun mark(context: Context, gameId: String, autoFile: File) {
        runCatching { File(context.filesDir, FILE).writeText(gameId + "\n" + autoFile.absolutePath) }
    }

    fun clear(context: Context) {
        runCatching { File(context.filesDir, FILE).delete() }
    }

    data class Ended(val gameId: String, val autoFile: File?)

    /** Jogo que fechou sozinho desde a última vez (e já apaga a marca). */
    fun endedAbruptly(context: Context): Ended? {
        val f = File(context.filesDir, FILE)
        if (!f.exists()) return null
        val am = context.getSystemService(ActivityManager::class.java)
        val gameAlive = am?.runningAppProcesses?.any { it.processName == context.packageName + ":game" } == true
        if (gameAlive) return null
        val lines = runCatching { f.readLines() }.getOrDefault(emptyList())
        f.delete()
        val id = lines.getOrNull(0)?.takeIf { it.isNotBlank() } ?: return null
        val auto = lines.getOrNull(1)?.let { File(it) }?.takeIf { it.exists() && it.length() > 0 }
        return Ended(id, auto)
    }
}
