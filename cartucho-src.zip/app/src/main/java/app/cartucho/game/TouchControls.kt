package app.cartucho.game

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import app.cartucho.data.PadLayout
import app.cartucho.emu.RetroPad
import app.cartucho.ui.theme.Type
import kotlin.math.atan2
import kotlin.math.hypot

/** Agrega o estado de todos os botões da tela em uma única máscara. */
class TouchPadState(private val onChange: (Int) -> Unit) {
    private var mask = 0
    fun set(bit: Int, pressed: Boolean) {
        val next = if (pressed) mask or (1 shl bit) else mask and (1 shl bit).inv()
        if (next != mask) {
            mask = next
            onChange(mask)
        }
    }

    fun setDirections(up: Boolean, down: Boolean, left: Boolean, right: Boolean) {
        var next = mask and ((1 shl RetroPad.UP) or (1 shl RetroPad.DOWN) or (1 shl RetroPad.LEFT) or (1 shl RetroPad.RIGHT)).inv()
        if (up) next = next or (1 shl RetroPad.UP)
        if (down) next = next or (1 shl RetroPad.DOWN)
        if (left) next = next or (1 shl RetroPad.LEFT)
        if (right) next = next or (1 shl RetroPad.RIGHT)
        if (next != mask) {
            mask = next
            onChange(mask)
        }
    }
}

private data class Face(val label: String, val id: Int)

private fun facesFor(layout: PadLayout): List<Face> = when (layout) {
    PadLayout.TWO_BUTTONS -> listOf(Face("B", RetroPad.B), Face("A", RetroPad.A))
    PadLayout.GBA -> listOf(Face("B", RetroPad.B), Face("A", RetroPad.A))
    PadLayout.SNES, PadLayout.DS, PadLayout.DREAMCAST -> listOf(Face("Y", RetroPad.Y), Face("X", RetroPad.X), Face("B", RetroPad.B), Face("A", RetroPad.A))
    PadLayout.GENESIS -> listOf(Face("A", RetroPad.Y), Face("B", RetroPad.B), Face("C", RetroPad.A))
    PadLayout.SATURN -> listOf(Face("A", RetroPad.Y), Face("B", RetroPad.B), Face("C", RetroPad.A))
    PadLayout.ARCADE -> listOf(Face("3", RetroPad.Y), Face("4", RetroPad.X), Face("1", RetroPad.B), Face("2", RetroPad.A))
    PadLayout.N64 -> listOf(Face("B", RetroPad.Y), Face("A", RetroPad.B))
    PadLayout.PLAYSTATION, PadLayout.PSP -> listOf(Face("□", RetroPad.Y), Face("△", RetroPad.X), Face("✕", RetroPad.B), Face("○", RetroPad.A))
}

private fun shouldersFor(layout: PadLayout): Pair<List<Face>, List<Face>> = when (layout) {
    PadLayout.TWO_BUTTONS, PadLayout.GENESIS, PadLayout.ARCADE -> emptyList<Face>() to emptyList()
    PadLayout.GBA, PadLayout.SNES, PadLayout.DS, PadLayout.PSP -> listOf(Face("L", RetroPad.L)) to listOf(Face("R", RetroPad.R))
    PadLayout.SATURN -> listOf(Face("L", RetroPad.L2)) to listOf(Face("R", RetroPad.R2))
    PadLayout.N64 -> listOf(Face("Z", RetroPad.L2), Face("L", RetroPad.L)) to listOf(Face("R", RetroPad.R))
    PadLayout.DREAMCAST -> listOf(Face("LT", RetroPad.L2)) to listOf(Face("RT", RetroPad.R2))
    PadLayout.PLAYSTATION -> listOf(Face("L2", RetroPad.L2), Face("L1", RetroPad.L)) to listOf(Face("R2", RetroPad.R2), Face("R1", RetroPad.R))
}

private fun extraRowFor(layout: PadLayout): List<Face> = when (layout) {
    PadLayout.GENESIS -> listOf(Face("X", RetroPad.L), Face("Y", RetroPad.X), Face("Z", RetroPad.R))
    PadLayout.SATURN -> listOf(Face("X", RetroPad.L), Face("Y", RetroPad.X), Face("Z", RetroPad.R))
    PadLayout.ARCADE -> listOf(Face("5", RetroPad.L), Face("6", RetroPad.R))
    else -> emptyList()
}

private fun hasStick(layout: PadLayout, systemId: String): Boolean =
    layout == PadLayout.N64 || layout == PadLayout.PSP || layout == PadLayout.DREAMCAST || systemId == "ps2"

private fun hasSelect(layout: PadLayout): Boolean = layout !in setOf(PadLayout.N64, PadLayout.DREAMCAST, PadLayout.SATURN)

@Composable
fun TouchControls(
    layout: PadLayout,
    systemId: String,
    opacity: Float,
    scale: Float,
    vibration: Boolean,
    onButtons: (Int) -> Unit,
    onAnalog: (stick: Int, x: Float, y: Float) -> Unit,
    onMenu: () -> Unit,
    layoutStore: TouchLayoutStore,
    editing: Boolean = false,
) {
    val view = LocalView.current
    val haptic: () -> Unit = { if (vibration) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
    val state = remember { TouchPadState(onButtons) }
    val faces = facesFor(layout)
    val (leftShoulders, rightShoulders) = shouldersFor(layout)
    val extra = extraRowFor(layout)
    val stick = hasStick(layout, systemId)
    val unit = 60.dp * scale

    BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).alpha(opacity)) {
        val landscape = maxWidth > maxHeight
        val controlsTop = if (landscape) 0.dp else maxHeight * 0.52f

        // Ombros
        if (leftShoulders.isNotEmpty()) Editable("shoulderL", layoutStore, editing, Modifier.align(Alignment.TopStart).padding(start = 16.dp, top = controlsTop + 12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                leftShoulders.forEach { f -> PadButton(f.label, unit * 1.2f, unit * 0.62f, RoundedCornerShape(12.dp)) { p -> state.set(f.id, p); if (p) haptic() } }
            }
        }
        if (rightShoulders.isNotEmpty()) Editable("shoulderR", layoutStore, editing, Modifier.align(Alignment.TopEnd).padding(end = 16.dp, top = controlsTop + 12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rightShoulders.reversed().forEach { f -> PadButton(f.label, unit * 1.2f, unit * 0.62f, RoundedCornerShape(12.dp)) { p -> state.set(f.id, p); if (p) haptic() } }
            }
        }

        // Esquerda: direcional (+ analógico)
        Editable("left", layoutStore, editing, Modifier.align(Alignment.BottomStart).padding(start = 20.dp, bottom = 24.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (stick) {
                AnalogStick(unit * 2.1f) { x, y -> onAnalog(0, x, y) }
                Spacer(Modifier.height(12.dp))
                DPad(unit * 1.9f, state, haptic)
            } else {
                DPad(unit * 2.5f, state, haptic)
            }
        }
        }

        // Direita: botões de ação
        Editable("right", layoutStore, editing, Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 24.dp)) {
        Column(horizontalAlignment = Alignment.End) {
            if (layout == PadLayout.N64) {
                CButtons(unit * 1.9f, haptic) { x, y -> onAnalog(1, x, y) }
                Spacer(Modifier.height(12.dp))
            }
            if (extra.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    extra.forEach { f -> PadButton(f.label, unit * 0.82f, unit * 0.82f, CircleShape) { p -> state.set(f.id, p); if (p) haptic() } }
                }
                Spacer(Modifier.height(10.dp))
            }
            FaceCluster(faces, unit) { id, p -> state.set(id, p); if (p) haptic() }
        }
        }

        // Centro: select / start / menu
        Editable("center", layoutStore, editing, Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (hasSelect(layout)) {
                PadButton(if (layout == PadLayout.ARCADE) "Ficha" else "Select", unit * 1.15f, unit * 0.46f, RoundedCornerShape(999.dp)) { p -> state.set(RetroPad.SELECT, p) }
            }
            PadButton("Start", unit * 1.15f, unit * 0.46f, RoundedCornerShape(999.dp)) { p -> state.set(RetroPad.START, p) }
        }
        }
        if (!editing) Editable("menu", layoutStore, false, Modifier.align(Alignment.TopCenter).padding(top = controlsTop + 8.dp)) {
            PadButton("Menu", unit * 1.1f, unit * 0.46f, RoundedCornerShape(999.dp)) { p -> if (!p) onMenu() }
        }
    }
}

@Composable
private fun FaceCluster(faces: List<Face>, unit: Dp, onPress: (Int, Boolean) -> Unit) {
    val size = unit * 0.95f
    when (faces.size) {
        2 -> Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Bottom) {
            PadButton(faces[0].label, size, size, CircleShape, Modifier.offset(y = 10.dp)) { onPress(faces[0].id, it) }
            PadButton(faces[1].label, size, size, CircleShape, Modifier.offset(y = (-14).dp)) { onPress(faces[1].id, it) }
        }
        3 -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            faces.forEach { f -> PadButton(f.label, size, size, CircleShape) { onPress(f.id, it) } }
        }
        else -> Box(Modifier.size(size * 3f)) {
            // Losango: [0]=esquerda, [1]=cima, [2]=baixo, [3]=direita
            PadButton(faces[0].label, size, size, CircleShape, Modifier.align(Alignment.CenterStart)) { onPress(faces[0].id, it) }
            PadButton(faces[1].label, size, size, CircleShape, Modifier.align(Alignment.TopCenter)) { onPress(faces[1].id, it) }
            PadButton(faces[2].label, size, size, CircleShape, Modifier.align(Alignment.BottomCenter)) { onPress(faces[2].id, it) }
            PadButton(faces[3].label, size, size, CircleShape, Modifier.align(Alignment.CenterEnd)) { onPress(faces[3].id, it) }
        }
    }
}

@Composable
private fun PadButton(
    label: String,
    width: Dp,
    height: Dp,
    shape: androidx.compose.ui.graphics.Shape,
    modifier: Modifier = Modifier,
    onPress: (Boolean) -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    Box(
        modifier = modifier
            .size(width, height)
            .clip(shape)
            .background(if (pressed) Color.White.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.16f))
            .border(1.dp, Color.White.copy(alpha = 0.35f), shape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    onPress(true)
                    do {
                        val event = awaitPointerEvent()
                        event.changes.forEach(PointerInputChange::consume)
                    } while (event.changes.any { it.pressed })
                    pressed = false
                    onPress(false)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = Type.label, color = Color.White)
    }
}

@Composable
private fun DPad(size: Dp, state: TouchPadState, haptic: () -> Unit) {
    var dir by remember { mutableStateOf(IntOffset.Zero) }
    Box(
        Modifier
            .size(size)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    fun update(pos: Offset) {
                        val cx = this.size.width / 2f
                        val cy = this.size.height / 2f
                        val dx = pos.x - cx
                        val dy = pos.y - cy
                        val dead = this.size.width * 0.14f
                        var nx = 0
                        var ny = 0
                        if (hypot(dx, dy) > dead) {
                            val angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble()))
                            // 8 direções em setores de 45 graus
                            if (angle > -67.5 && angle < 67.5) nx = 1
                            if (angle > 112.5 || angle < -112.5) nx = -1
                            if (angle > 22.5 && angle < 157.5) ny = 1
                            if (angle < -22.5 && angle > -157.5) ny = -1
                        }
                        val next = IntOffset(nx, ny)
                        if (next != dir) {
                            if (next != IntOffset.Zero) haptic()
                            dir = next
                            state.setDirections(ny < 0, ny > 0, nx < 0, nx > 0)
                        }
                    }
                    update(down.position)
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: event.changes.first()
                        if (change.pressed) update(change.position)
                        event.changes.forEach(PointerInputChange::consume)
                    } while (event.changes.any { it.pressed })
                    dir = IntOffset.Zero
                    state.setDirections(false, false, false, false)
                }
            },
    ) {
        val arm = size / 3f
        val base = Color.White.copy(alpha = 0.16f)
        val active = Color.White.copy(alpha = 0.55f)
        val shape = RoundedCornerShape(10.dp)
        Box(Modifier.align(Alignment.TopCenter).size(arm, arm * 1.15f).clip(shape).background(if (dir.y < 0) active else base).border(1.dp, Color.White.copy(alpha = 0.35f), shape))
        Box(Modifier.align(Alignment.BottomCenter).size(arm, arm * 1.15f).clip(shape).background(if (dir.y > 0) active else base).border(1.dp, Color.White.copy(alpha = 0.35f), shape))
        Box(Modifier.align(Alignment.CenterStart).size(arm * 1.15f, arm).clip(shape).background(if (dir.x < 0) active else base).border(1.dp, Color.White.copy(alpha = 0.35f), shape))
        Box(Modifier.align(Alignment.CenterEnd).size(arm * 1.15f, arm).clip(shape).background(if (dir.x > 0) active else base).border(1.dp, Color.White.copy(alpha = 0.35f), shape))
    }
}

@Composable
private fun AnalogStick(size: Dp, onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.10f))
            .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val radius = this.size.width / 2f
                    val center = Offset(radius, this.size.height / 2f)
                    fun update(pos: Offset) {
                        var d = pos - center
                        val len = d.getDistance()
                        val max = radius * 0.72f
                        if (len > max) d = d * (max / len)
                        knob = d
                        onMove((d.x / max).coerceIn(-1f, 1f), (d.y / max).coerceIn(-1f, 1f))
                    }
                    update(down.position)
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: event.changes.first()
                        if (change.pressed) update(change.position)
                        event.changes.forEach(PointerInputChange::consume)
                    } while (event.changes.any { it.pressed })
                    knob = Offset.Zero
                    onMove(0f, 0f)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color.White.copy(alpha = 0.5f), radius = this.size.minDimension * 0.2f, center = this.center + knob)
        }
    }
}

/** Botões C do N64, enviados como analógico direito (padrão do Mupen64Plus-Next). */
@Composable
private fun CButtons(size: Dp, haptic: () -> Unit, onAxis: (Float, Float) -> Unit) {
    val b = size / 3f
    var x by remember { mutableStateOf(0f) }
    var y by remember { mutableStateOf(0f) }
    fun push() = onAxis(x, y)
    Box(Modifier.size(size)) {
        PadButton("C↑", b, b, CircleShape, Modifier.align(Alignment.TopCenter)) { p -> y = if (p) -1f else 0f; if (p) haptic(); push() }
        PadButton("C↓", b, b, CircleShape, Modifier.align(Alignment.BottomCenter)) { p -> y = if (p) 1f else 0f; if (p) haptic(); push() }
        PadButton("C←", b, b, CircleShape, Modifier.align(Alignment.CenterStart)) { p -> x = if (p) -1f else 0f; if (p) haptic(); push() }
        PadButton("C→", b, b, CircleShape, Modifier.align(Alignment.CenterEnd)) { p -> x = if (p) 1f else 0f; if (p) haptic(); push() }
    }
}
