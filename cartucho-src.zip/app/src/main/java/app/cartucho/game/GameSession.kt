package app.cartucho.game

import app.cartucho.data.Ps2Engine
import app.cartucho.data.DsLayout
import app.cartucho.data.CollectionStore

import android.graphics.Bitmap
import android.opengl.GLSurfaceView
import app.cartucho.CartuchoApp
import app.cartucho.achievements.RetroAchievements
import app.cartucho.data.AspectMode
import app.cartucho.data.BiosCatalog
import app.cartucho.data.Frameskip
import app.cartucho.data.Game
import app.cartucho.data.GameResolver
import app.cartucho.data.GameSystem
import app.cartucho.data.Settings
import app.cartucho.emu.AudioPlayer
import app.cartucho.emu.GamepadInput
import app.cartucho.emu.NativeBridge
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

data class SlotInfo(val slot: Int, val exists: Boolean, val modified: Long, val thumbnail: File?)

/** Tudo que acontece enquanto um jogo está aberto (vive no processo :game). */
class GameSession(
    val app: CartuchoApp,
    val game: Game,
    val system: GameSystem,
    val glesMajor: Int,
) {
    val input = GamepadInput(app)
    val renderer = EmulatorRenderer(this)
    var view: GLSurfaceView? = null
    private var prepared: GameResolver.Prepared? = null
    private var audio: AudioPlayer? = null
    /** Cópia do áudio para a sala online (amostras estéreo intercaladas, taxa do core). */
    @Volatile var audioTap: ((ShortArray, Int, Int) -> Unit)? = null
    @Volatile var audioTargetFrames = 0
        private set

    private val baseName = game.fileName.substringBeforeLast('.').replace(Regex("""[\\/:*?"<>|]"""), "_")
    val saveDir: File = File(app.filesDir, "saves/${system.id}").apply { mkdirs() }
    val sramFile: File = File(saveDir, "$baseName.srm")
    val stateDir: File = File(app.filesDir, "states/${system.id}/$baseName").apply { mkdirs() }

    private val _fps = MutableStateFlow(0.0)
    val fps: StateFlow<Double> = _fps.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()
    private val _paused = MutableStateFlow(false)
    val paused: StateFlow<Boolean> = _paused.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    var onExitRequestedByCore: (() -> Unit)? = null

    /** Prepara o arquivo (fora da thread de UI). Retorna mensagem de erro ou nulo. */
    fun prepareFiles(): String? {
        val missing = BiosCatalog.missingRequired(app, system.id)
        if (missing.isNotEmpty()) {
            return "Este sistema precisa da BIOS ${missing.joinToString { it.fileName }}. Adicione em Ajustes > BIOS."
        }
        return try {
            prepared = GameResolver(app, app.detector).prepare(game, system) { msg -> _message.value = msg }
            // Com o jogo pronto (extraído, partes juntadas), dá para reconhecer o que antes não dava.
            prepared?.path?.let { p -> runCatching { app.identifier.identifyPrepared(app.library, app.covers, game, java.io.File(p), app.prefs.current.coverDownload) } }
            _message.value = null
            null
        } catch (e: Throwable) {
            e.message ?: "Não foi possível abrir o arquivo do jogo."
        }
    }

    /**
     * Emulador usado de fato. No PS2, o ARMSX2 (bem mais rápido) entra quando há BIOS do console;
     * sem BIOS, fica o Play!, que não precisa dela. Dá para escolher no menu do jogo.
     */
    val coreId: String by lazy {
        if (system.id != "ps2") return@lazy system.coreId
        val hasBios = File(BiosCatalog.systemDir(app), "pcsx2/bios").listFiles()?.any { it.isFile && it.length() > 1_000_000 } == true
        when (app.prefs.current.ps2Engine) {
            Ps2Engine.PLAY -> system.coreId
            Ps2Engine.ARMSX2 -> if (app.device.coreAvailable("armsx2")) "armsx2" else system.coreId
            Ps2Engine.AUTO -> if (hasBios && app.device.coreAvailable("armsx2")) "armsx2" else system.coreId
        }
    }

    /** Chamado pelo renderer na thread do GL. */
    fun loadOnGlThread(): Boolean {
        val path = prepared?.path ?: run { _error.value = "Arquivo do jogo indisponível."; return false }
        val s = app.prefs.current
        val corePath = app.device.corePath(coreId)
        if (!File(corePath).exists()) {
            _error.value = "O emulador de ${system.name} não está disponível neste aparelho."
            return false
        }
        if (!NativeBridge.loadCore(corePath, BiosCatalog.systemDir(app).absolutePath, saveDir.absolutePath)) {
            _error.value = "Não foi possível iniciar o emulador de ${system.name}."
            return false
        }
        applyCoreDefaults()
        NativeBridge.setPerformance(s.resolution, if (s.frameskip == Frameskip.AUTO) 0 else 1)
        if (!NativeBridge.loadGame(path)) {
            val detail = NativeBridge.getLastError().orEmpty()
            val size = File(path).let { f -> runCatching { f.length() }.getOrDefault(0L) }
            _error.value = buildString {
                append("O emulador de ${system.name} não conseguiu abrir ${game.fileName}.")
                append(" Se o jogo for de outro sistema, segure o jogo na biblioteca e use \"Mudar sistema\".")
                if (detail.isNotEmpty()) append("\n\nDetalhe técnico: ").append(detail)
                append("\n(").append(size / 1024).append(" KB lidos)")
            }
            return false
        }
        if (sramFile.exists()) NativeBridge.loadSram(sramFile.absolutePath)
        applyVideo(s)
        renderer.audioSync = s.audioSync
        _loaded.value = true
        if (!_paused.value) activeSince = System.currentTimeMillis()
        if (system.raConsoleId > 0) RetroAchievements.get().startForGame(system.raConsoleId, path)
        return true
    }

    /** Celular deitado agora (o modo automático do DS/3DS usa as telas lado a lado). */
    @Volatile var landscape = false
    private var appliedLayout = ""

    /** Valor da opção do core para a disposição das telas do DS/3DS. */
    private fun screenLayoutValue(): String {
        val choice = app.prefs.current.dsLayout.let { if (it == DsLayout.AUTO) (if (landscape) DsLayout.SIDE else DsLayout.STACKED) else it }
        return when (coreId) {
            "citra" -> when (choice) {
                DsLayout.SIDE -> "Side by Side"
                DsLayout.BIG_TOP -> "Large Screen, Small Screen"
                else -> "Default Top-Bottom Screen"
            }
            else -> when (choice) {
                DsLayout.SIDE -> "Left/Right"
                DsLayout.BIG_TOP -> "Hybrid Top"
                else -> "Top/Bottom"
            }
        }
    }

    /** Tem duas telas (DS/3DS): o menu mostra a troca de disposição. */
    val hasTwoScreens: Boolean get() = coreId == "melonds" || coreId == "citra"

    /** Reaplica a disposição das telas (girou o celular ou mudou a escolha no menu). */
    fun applyScreenLayout(isLandscape: Boolean) {
        landscape = isLandscape
        if (!hasTwoScreens) return
        val value = screenLayoutValue()
        if (value == appliedLayout) return
        appliedLayout = value
        val key = if (coreId == "citra") "citra_layout_option" else "melonds_screen_layout"
        renderer.post { NativeBridge.setOption(key, value) }
    }

    /** Ajustes por core que deixam a experiência mais previsível no celular. */
    private fun applyCoreDefaults() {
        when (coreId) {
            "pcsx_rearmed" -> NativeBridge.setOption("pcsx_rearmed_bios", "auto")
            "flycast" -> NativeBridge.setOption("flycast_hle_bios", "enabled")
            "melonds" -> {
                NativeBridge.setOption("melonds_boot_directly", "enabled")
                // Disposição das telas conforme a escolha e a posição do celular; toque do dedo direto na tela de baixo.
                NativeBridge.setOption("melonds_screen_layout", screenLayoutValue().also { appliedLayout = it })
                NativeBridge.setOption("melonds_screen_gap", "0")
                NativeBridge.setOption("melonds_touch_mode", "Touch")
            }
            "citra" -> {
                NativeBridge.setOption("citra_layout_option", screenLayoutValue().also { appliedLayout = it })
                NativeBridge.setOption("citra_touch_touchscreen", "enabled")
                NativeBridge.setOption("citra_mouse_touchscreen", "disabled")
                NativeBridge.setOption("citra_use_hw_shader_cache", "enabled")
            }
            "genesis_plus_gx" -> if (system.id == "megadrive") NativeBridge.setOption("genesis_plus_gx_system_hw", "auto")
        }
    }

    fun onAudioFormat(sampleRate: Int) {
        audio?.release()
        val s = app.prefs.current
        audio = AudioPlayer(sampleRate, s.latency).also {
            it.tap = { buf, n -> audioTap?.invoke(buf, n, sampleRate) }
            it.setVolume(s.volume, s.muted)
            audioTargetFrames = it.targetBufferedFrames
            if (_paused.value) it.pause()
        }
    }

    fun onFps(value: Double) {
        _fps.value = value
    }

    fun requestExitFromCore() {
        onExitRequestedByCore?.invoke()
    }

    fun applyVideo(s: Settings) {
        val aspect = when (s.aspect) {
            AspectMode.ORIGINAL -> 0
            AspectMode.FOUR_THREE -> 1
            AspectMode.WIDE -> 2
            AspectMode.STRETCH -> 3
        }
        NativeBridge.setVideoOptions(aspect, s.integerScale, s.smoothFilter, s.crt)
    }

    fun applySettings(s: Settings) {
        audio?.setVolume(s.volume, s.muted)
        renderer.audioSync = s.audioSync
        input.menuComboEnabled = s.menuCombo
        renderer.post {
            applyVideo(s)
            NativeBridge.setPerformance(s.resolution, if (s.frameskip == Frameskip.AUTO) 0 else 1)
        }
        view?.requestRender()
    }

    // Tempo de jogo: conta só enquanto o jogo está rodando (sem menu, sem app em segundo plano).
    @Volatile private var activeSince = 0L

    private fun flushPlaytime() {
        val since = activeSince
        if (since > 0L) {
            CollectionStore.appendSession(app, game.id, since, (System.currentTimeMillis() - since) / 1000)
            activeSince = 0L
        }
    }

    fun setPaused(value: Boolean) {
        if (value) flushPlaytime() else if (_loaded.value && activeSince == 0L) activeSince = System.currentTimeMillis()
        _paused.value = value
        renderer.paused = value
        if (value) {
            audio?.pause()
            input.releaseAll()
            view?.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        } else {
            audio?.resume()
            view?.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
    }

    fun setFastForward(multiplier: Int) {
        renderer.speed = multiplier
        renderer.post { NativeBridge.setFastForward(multiplier > 1) }
    }

    fun saveSramNow() {
        NativeBridge.saveSram(sramFile.absolutePath)
    }

    fun slots(): List<SlotInfo> = (1..3).map { slot ->
        val f = File(stateDir, "slot$slot.state")
        val thumb = File(stateDir, "slot$slot.png")
        SlotInfo(slot, f.exists(), if (f.exists()) f.lastModified() else 0L, thumb.takeIf { it.exists() })
    }

    fun saveState(slot: Int, done: (Boolean) -> Unit) {
        val f = File(stateDir, "slot$slot.state")
        val thumb = File(stateDir, "slot$slot.png")
        renderer.post {
            val ok = NativeBridge.saveState(f.absolutePath)
            renderer.pendingCapture = { pixels ->
                if (ok && pixels != null && pixels.size > 2) {
                    runCatching {
                        val w = pixels[0]
                        val h = pixels[1]
                        val bmp = Bitmap.createBitmap(pixels, 2, w, w, h, Bitmap.Config.ARGB_8888)
                        thumb.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
                    }
                }
                done(ok)
            }
        }
        view?.requestRender()
    }

    fun loadState(slot: Int, done: (Boolean) -> Unit) {
        val f = File(stateDir, "slot$slot.state")
        renderer.post {
            val ok = f.exists() && NativeBridge.loadState(f.absolutePath)
            done(ok)
        }
        view?.requestRender()
    }

    fun reset() {
        renderer.post { NativeBridge.reset() }
        view?.requestRender()
    }

    fun showMessage(text: String?) {
        _message.value = text
    }

    /** Executa algo na thread do GL e espera (com limite), usado ao pausar e ao sair. */
    fun runOnGlAndWait(timeoutMs: Long, block: () -> Unit) {
        val v = view ?: return
        val latch = CountDownLatch(1)
        renderer.post {
            runCatching(block)
            latch.countDown()
        }
        v.requestRender()
        latch.await(timeoutMs, TimeUnit.MILLISECONDS)
    }

    fun shutdown() {
        flushPlaytime()
        runOnGlAndWait(3000) {
            if (_loaded.value) NativeBridge.saveSram(sramFile.absolutePath)
            NativeBridge.unloadGame()
        }
        audio?.release()
        audio = null
        prepared?.close()
    }
}
