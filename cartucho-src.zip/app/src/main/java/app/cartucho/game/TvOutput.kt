package app.cartucho.game

import android.app.Activity
import android.app.Presentation
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import androidx.compose.runtime.mutableStateOf
import app.cartucho.emu.NativeBridge

/** Onde o jogo aparece. */
enum class TvMode { PHONE, MIRROR, TV_ONLY }

/**
 * Saída para TV. O Android expõe a TV como uma "segunda tela" quando ela está ligada por
 * espelhamento sem fio (Smart View/Miracast) ou por cabo (HDMI/USB-C). Nesse caso o jogo é
 * desenhado direto nela em tela cheia, usando o mesmo contexto OpenGL do jogo:
 * - PHONE: só no celular (o conteúdo do jogo fica protegido do espelhamento);
 * - MIRROR: no celular e na TV;
 * - TV_ONLY: só na TV, e o celular vira o controle.
 * Pelo Chromecast (Google Home), o Android espelha a tela inteira do celular: "duplicar" funciona sempre.
 */
class TvOutput(private val activity: Activity, private val renderer: EmulatorRenderer) {
    val mode = mutableStateOf(TvMode.PHONE)
    /** Existe uma TV/segunda tela disponível agora. */
    val tvAvailable = mutableStateOf(false)
    val tvName = mutableStateOf("")

    private val dm = activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val main = Handler(Looper.getMainLooper())
    private var presentation: GamePresentation? = null

    private val listener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = refresh()
        override fun onDisplayRemoved(displayId: Int) = refresh()
        override fun onDisplayChanged(displayId: Int) = refresh()
    }

    fun start() {
        dm.registerDisplayListener(listener, main)
        refresh()
    }

    fun stop() {
        dm.unregisterDisplayListener(listener)
        dismiss()
    }

    fun setMode(m: TvMode) {
        mode.value = m
        refresh()
    }

    /** Abre a tela de transmissão do Android (Smart View, Transmitir, Google Home…). */
    fun openSystemCast() {
        val intents = listOf(
            Intent(Settings.ACTION_CAST_SETTINGS),
            Intent("android.settings.WIFI_DISPLAY_SETTINGS"),
            Intent(Settings.ACTION_DISPLAY_SETTINGS),
        )
        for (i in intents) {
            if (runCatching { activity.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return
        }
    }

    private fun externalDisplay(): Display? =
        dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull { it.isValid }

    private fun refresh() {
        val display = externalDisplay()
        tvAvailable.value = display != null
        tvName.value = display?.name.orEmpty()
        // Só no celular: com uma TV espelhando, o jogo não aparece nela.
        if (mode.value == TvMode.PHONE && display != null) {
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        renderer.drawOnPhone = !(mode.value == TvMode.TV_ONLY && display != null)
        val wantTv = display != null && mode.value != TvMode.PHONE
        if (!wantTv) {
            dismiss()
            return
        }
        if (presentation?.display?.displayId == display!!.displayId) return
        dismiss()
        val p = GamePresentation(activity, display, renderer)
        presentation = runCatching { p.show(); p }.getOrNull()
    }

    private fun dismiss() {
        presentation?.let { runCatching { it.dismiss() } }
        presentation = null
        renderer.detachTv()
    }
}

/** A janela na TV: uma superfície em tela cheia onde o renderizador do jogo desenha. */
private class GamePresentation(context: Context, display: Display, private val renderer: EmulatorRenderer) :
    Presentation(context, display) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val view = SurfaceView(context)
        view.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {}
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                renderer.attachTv(holder.surface, width, height)
            }
            override fun surfaceDestroyed(holder: SurfaceHolder) {
                renderer.detachTv()
            }
        })
        setContentView(view)
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}

/**
 * Superfície EGL da TV, criada com o mesmo display/configuração/contexto do jogo
 * (assim a textura do quadro é a mesma). Usada só na thread de renderização.
 */
class TvSurface {
    private var surface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var intervalSet = false
    var width = 0
    var height = 0

    val ready: Boolean get() = surface != EGL14.EGL_NO_SURFACE

    fun create(window: Any, w: Int, h: Int): Boolean {
        release()
        val dpy = EGL14.eglGetCurrentDisplay()
        val ctx = EGL14.eglGetCurrentContext()
        if (dpy == EGL14.EGL_NO_DISPLAY || ctx == EGL14.EGL_NO_CONTEXT) return false
        val config = configOf(dpy, ctx) ?: return false
        val s = EGL14.eglCreateWindowSurface(dpy, config, window, intArrayOf(EGL14.EGL_NONE), 0)
        if (s == null || s == EGL14.EGL_NO_SURFACE) return false
        display = dpy
        surface = s
        intervalSet = false
        width = w
        height = h
        return true
    }

    /** Desenha o quadro na TV e volta para a superfície do celular. */
    fun draw() {
        if (!ready) return
        val ctx = EGL14.eglGetCurrentContext()
        val draw = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW)
        val read = EGL14.eglGetCurrentSurface(EGL14.EGL_READ)
        if (!EGL14.eglMakeCurrent(display, surface, surface, ctx)) return
        // A TV (sem fio ou cabo) não segura o laço do jogo: troca de quadro sem esperar o vsync dela.
        if (!intervalSet) {
            EGL14.eglSwapInterval(display, 0)
            intervalSet = true
        }
        NativeBridge.renderTo(width, height)
        EGL14.eglSwapBuffers(display, surface)
        EGL14.eglMakeCurrent(display, draw, read, ctx)
    }

    fun release() {
        if (surface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface)
        surface = EGL14.EGL_NO_SURFACE
    }

    private fun configOf(dpy: EGLDisplay, ctx: EGLContext): EGLConfig? {
        val id = IntArray(1)
        EGL14.eglQueryContext(dpy, ctx, EGL14.EGL_CONFIG_ID, id, 0)
        val configs = arrayOfNulls<EGLConfig>(1)
        val count = IntArray(1)
        EGL14.eglChooseConfig(dpy, intArrayOf(EGL14.EGL_CONFIG_ID, id[0], EGL14.EGL_NONE), 0, configs, 0, 1, count, 0)
        return if (count[0] > 0) configs[0] else null
    }
}
