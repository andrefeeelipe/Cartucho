package app.cartucho.game

import android.content.Context
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.offset
import kotlin.math.roundToInt

/** Posição (deslocamento em px) e escala de um grupo de botões da tela. */
data class GroupLayout(val dx: Float = 0f, val dy: Float = 0f, val scale: Float = 1f)

/**
 * Layout personalizado dos controles na tela, salvo por tipo de controle (SNES, PlayStation...)
 * e por orientação, já que retrato e paisagem têm espaços bem diferentes.
 */
class TouchLayoutStore(context: Context, private val key: String) {
    private val sp = context.getSharedPreferences("cartucho_touch_layout", Context.MODE_PRIVATE)
    private val groups = mutableStateMapOf<String, GroupLayout>()
    var selected by mutableStateOf<String?>(null)

    init {
        sp.all.forEach { (k, v) ->
            if (k.startsWith("$key/") && v is String) {
                val parts = v.split(',').mapNotNull { it.toFloatOrNull() }
                if (parts.size == 3) groups[k.removePrefix("$key/")] = GroupLayout(parts[0], parts[1], parts[2])
            }
        }
    }

    fun get(id: String): GroupLayout = groups[id] ?: GroupLayout()

    fun move(id: String, dx: Float, dy: Float) {
        val g = get(id)
        groups[id] = g.copy(dx = g.dx + dx, dy = g.dy + dy)
    }

    fun setScale(id: String, scale: Float) {
        groups[id] = get(id).copy(scale = scale.coerceIn(0.6f, 1.8f))
    }

    fun save() {
        val e = sp.edit()
        groups.forEach { (id, g) -> e.putString("$key/$id", "${g.dx},${g.dy},${g.scale}") }
        e.apply()
    }

    fun reset() {
        val e = sp.edit()
        groups.keys.forEach { e.remove("$key/$it") }
        e.apply()
        groups.clear()
        selected = null
    }
}

/**
 * Envolve um grupo de botões: aplica a posição/escala salvas e, no modo de edição,
 * troca o toque nos botões por arrastar e selecionar.
 */
@Composable
fun Editable(
    id: String,
    store: TouchLayoutStore,
    editing: Boolean,
    modifier: Modifier,
    content: @Composable () -> Unit,
) {
    val g = store.get(id)
    Box(
        modifier
            .offset { IntOffset(g.dx.roundToInt(), g.dy.roundToInt()) }
            .graphicsLayer {
                scaleX = g.scale
                scaleY = g.scale
            },
    ) {
        content()
        if (editing) {
            val isSelected = store.selected == id
            Box(
                Modifier
                    .matchParentSize()
                    .border(if (isSelected) 2.dp else 1.dp, if (isSelected) Color.White else Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .pointerInput(id) { detectTapGestures { store.selected = id } }
                    .pointerInput(id + "drag") {
                        detectDragGestures(
                            onDragStart = { store.selected = id },
                            onDragEnd = { store.save() },
                        ) { change, drag ->
                            change.consume()
                            // O arrasto chega na escala do grupo; corrige para seguir o dedo 1:1.
                            val s = store.get(id).scale
                            store.move(id, drag.x * s, drag.y * s)
                        }
                    },
            )
        }
    }
}
