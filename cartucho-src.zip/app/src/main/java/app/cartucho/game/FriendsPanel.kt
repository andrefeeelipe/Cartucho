package app.cartucho.game

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.net.RemotePadServer
import app.cartucho.net.RoomHost
import app.cartucho.net.Signaling
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SegmentedRow
import app.cartucho.ui.theme.Cartucho
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** QR code em bitmap (preto no branco, com margem). */
fun qrBitmap(text: String, size: Int = 512): Bitmap {
    val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1))
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    for (y in 0 until size) for (x in 0 until size) bmp.setPixel(x, y, if (matrix[x, y]) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())
    return bmp
}

@Composable
private fun QrImage(text: String, modifier: Modifier = Modifier) {
    val bmp = remember(text) { qrBitmap(text) }
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).padding(10.dp)) {
        Image(bmp.asImageBitmap(), contentDescription = "QR code", modifier = Modifier.size(200.dp))
    }
}

/**
 * Menu do jogo > Jogar com amigos. Ao abrir, a sala já é criada:
 * - um QR só: quem tem o Cartucho entra na sala; quem não tem joga pelo navegador (mesmo Wi-Fi);
 * - convite por WhatsApp, código ou amigos do RetroAchievements para quem está longe.
 */
@Composable
fun FriendsPanel(app: CartuchoApp, pad: RemotePadServer, room: RoomHost) {
    val c = Cartucho.colors
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { pad.start() }
        room.start()
    }
    val code by room.code
    val status by room.status
    val roomError by room.error
    val starting by room.starting
    val lan by pad.url
    val lanError by pad.error
    LaunchedEffect(code) { pad.roomCode = code }

    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Com sala: o QR é o convite da página do Cartucho (funciona em qualquer rede e abre o app);
        // a página também leva ao controle pelo navegador quando o amigo está no mesmo Wi-Fi.
        val qr = when {
            code != null -> Signaling.inviteLink(code!!) + (lan?.let { "&lan=" + it.removePrefix("http://").trimEnd('/') } ?: "")
            lan != null -> lan
            else -> null
        }
        if (qr != null) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                QrImage(qr)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Leia o QR para jogar junto", style = Cartucho.type.headline, color = c.text)
                    Text(
                        when {
                            code != null -> "Quem tem o Cartucho entra na sala de qualquer lugar, até pelos dados móveis. Quem não tem joga pelo navegador, no mesmo Wi-Fi (ou no roteador do seu celular)."
                            else -> "Abre no navegador e vira o controle, no mesmo Wi-Fi (ou no roteador do seu celular)."
                        },
                        style = Cartucho.type.caption,
                        color = c.textSecondary,
                    )
                    if (code != null) {
                        Text("Código da sala", style = Cartucho.type.caption, color = c.textSecondary)
                        Text(code ?: "", style = Cartucho.type.title, color = c.text)
                    }
                }
            }
        } else if (starting) {
            Text("Criando a sala…", style = Cartucho.type.body, color = c.textSecondary)
        }
        if (status.isNotEmpty()) Text(status, style = Cartucho.type.caption, color = c.textSecondary)
        if (roomError != null) {
            Text(roomError ?: "", style = Cartucho.type.body, color = c.danger)
            SecondaryButton("Tentar criar a sala de novo", { room.start() }, Modifier.fillMaxWidth())
        }
        if (lanError != null && code == null) Text(lanError ?: "", style = Cartucho.type.caption, color = c.textSecondary)

        if (code != null) {
            val link = Signaling.inviteLink(code!!)
            val inviteText = "Bora jogar comigo no Cartucho! Entra na sala: $link (código $code)"
            PrimaryButton("Convidar pelo WhatsApp", { shareInvite(context, inviteText, whatsapp = true) }, Modifier.fillMaxWidth(), icon = R.drawable.ic_share)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Copiar convite", { copy(context, inviteText) }, Modifier.weight(1f))
                SecondaryButton("Outros apps", { shareInvite(context, inviteText, whatsapp = false) }, Modifier.weight(1f))
            }
            PlayersList(
                room.guests.map { Triple("s:" + it.id, it.name + if (it.connected) " · no app" else " (conectando…)", it.port) } +
                    pad.players.map { Triple("n:" + it.id, it.name + " · navegador", it.port) },
                onPort = { id, p -> if (id.startsWith("s:")) room.setPort(id.drop(2), p) else pad.setPort(id.drop(2).toInt(), p) },
                onKick = { id -> if (id.startsWith("s:")) room.kick(id.drop(2)) },
            )
            SecondaryButton("Fechar a sala", { room.stop(); pad.stop() }, Modifier.fillMaxWidth())
        } else if (lan != null) {
            PlayersList(
                pad.players.map { Triple(it.id.toString(), it.name + " · navegador", it.port) },
                onPort = { id, p -> pad.setPort(id.toInt(), p) },
                onKick = null,
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PlayersList(players: List<Triple<String, String, Int>>, onPort: (String, Int) -> Unit, onKick: ((String) -> Unit)?) {
    val c = Cartucho.colors
    ListGroup {
        Row(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Jogador 1", style = Cartucho.type.body, color = c.text, modifier = Modifier.weight(1f))
            Text("Você", style = Cartucho.type.body, color = c.textSecondary)
        }
        if (players.isEmpty()) {
            Divider()
            Text("Ninguém entrou ainda.", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(16.dp))
        }
        players.forEach { (id, name, port) ->
            Divider()
            SegmentedRow(name, listOf("1", "2", "3", "4"), port, { onPort(id, it) }, subtitle = "Jogador ${port + 1}")
            if (onKick != null && id.startsWith("s:")) {
                Text(
                    "Remover da sala",
                    style = Cartucho.type.caption,
                    color = c.danger,
                    modifier = Modifier.clickable { onKick(id) }.padding(start = 16.dp, bottom = 12.dp, top = 2.dp),
                )
            }
        }
    }
}
