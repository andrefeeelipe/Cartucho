package app.cartucho.game

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.achievements.RaWeb
import app.cartucho.net.RemotePadServer
import app.cartucho.net.RoomHost
import app.cartucho.net.Signaling
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SegmentedRow
import app.cartucho.ui.theme.Cartucho
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** QR code em bitmap (preto no branco, com margem). */
fun qrBitmap(text: String, size: Int = 512): Bitmap {
    val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1))
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    for (y in 0 until size) for (x in 0 until size) bmp.setPixel(x, y, if (matrix[x, y]) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())
    return bmp
}

@Composable
private fun QrImage(text: String, modifier: Modifier = Modifier) {
    val bmp = remember(text) { qrBitmap(text) }
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).padding(10.dp)) {
        Image(bmp.asImageBitmap(), contentDescription = "QR code", modifier = Modifier.size(200.dp))
    }
}

/**
 * Menu do jogo > Jogar com amigos:
 * - Controle pelo navegador: QR na mesma rede Wi-Fi (sem instalar nada), jogadores 2 a 4;
 * - Sala online: amigos com o Cartucho assistem pela internet e controlam 1 a 4.
 */
@Composable
fun FriendsPanel(app: CartuchoApp, pad: RemotePadServer, room: RoomHost) {
    val c = Cartucho.colors
    val context = LocalContext.current
    var tab by remember { mutableStateOf(if (room.running) 1 else 0) }
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ListGroup {
            SegmentedRow("Como os amigos entram", listOf("Navegador (QR)", "Sala online"), tab, { tab = it })
        }
        if (tab == 0) {
            LaunchedEffect(Unit) { withContext(Dispatchers.IO) { pad.start() } }
            val url by pad.url
            val err by pad.error
            if (err != null) {
                Text(err ?: "", style = Cartucho.type.body, color = c.textSecondary)
                SecondaryButton("Tentar de novo", { pad.stop(); pad.start() }, Modifier.fillMaxWidth())
            } else if (url != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    QrImage(url!!)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Aponte a câmera para o QR", style = Cartucho.type.headline, color = c.text)
                        Text(
                            "Os amigos precisam estar no mesmo Wi-Fi que você (ou no roteador do seu celular). Abre no navegador e vira o controle na hora.",
                            style = Cartucho.type.caption,
                            color = c.textSecondary,
                        )
                        Text(url ?: "", style = Cartucho.type.mono, color = c.accent)
                    }
                }
                PlayersList(
                    pad.players.map { Triple(it.id.toString(), it.name, it.port) },
                    onPort = { id, p -> pad.setPort(id.toInt(), p) },
                    onKick = null,
                )
            }
        } else {
            val code by room.code
            val status by room.status
            if (code == null) {
                Text(
                    "Crie uma sala e mande o convite. Quem tem o Cartucho entra pelo link ou pelo código, assiste ao jogo em tempo real e vira o jogador 1, 2, 3 ou 4. O jogo roda só no seu celular.",
                    style = Cartucho.type.body,
                    color = c.textSecondary,
                )
                PrimaryButton("Criar sala", { room.start() }, Modifier.fillMaxWidth(), icon = R.drawable.ic_broadcast)
            } else {
                val link = Signaling.inviteLink(code!!)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    QrImage(link)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Código da sala", style = Cartucho.type.caption, color = c.textSecondary)
                        Text(code ?: "", style = Cartucho.type.title, color = c.text)
                        if (status.isNotEmpty()) Text(status, style = Cartucho.type.caption, color = c.textSecondary)
                    }
                }
                val inviteText = "Bora jogar comigo no Cartucho! Entra na sala: $link (código $code)"
                PrimaryButton("Convidar pelo WhatsApp", { shareInvite(context, inviteText, whatsapp = true) }, Modifier.fillMaxWidth(), icon = R.drawable.ic_share)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Copiar convite", { copy(context, inviteText) }, Modifier.weight(1f))
                    SecondaryButton("Outros apps", { shareInvite(context, inviteText, whatsapp = false) }, Modifier.weight(1f))
                }
                PlayersList(
                    room.guests.map { Triple(it.id, it.name + if (it.connected) "" else " (conectando…)", it.port) },
                    onPort = { id, p -> room.setPort(id, p) },
                    onKick = { id -> room.kick(id) },
                )
                RaFriends(app, inviteText)
                SecondaryButton("Fechar a sala", { room.stop() }, Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PlayersList(players: List<Triple<String, String, Int>>, onPort: (String, Int) -> Unit, onKick: ((String) -> Unit)?) {
    val c = Cartucho.colors
    ListGroup {
        Row(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Jogador 1", style = Cartucho.type.body, color = c.text, modifier = Modifier.weight(1f))
            Text("Você", style = Cartucho.type.body, color = c.textSecondary)
        }
        if (players.isEmpty()) {
            Divider()
            Text("Ninguém entrou ainda.", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(16.dp))
        }
        players.forEach { (id, name, port) ->
            Divider()
            SegmentedRow(name, listOf("1", "2", "3", "4"), port, { onPort(id, it) }, subtitle = "Jogador ${port + 1}")
            if (onKick != null) {
                Text(
                    "Remover da sala",
                    style = Cartucho.type.caption,
                    color = c.danger,
                    modifier = Modifier.clickable { onKick(id) }.padding(start = 16.dp, bottom = 12.dp, top = 2.dp),
                )
            }
        }
    }
}

/** Amigos do RetroAchievements: abre a conversa com o convite já copiado. */
@Composable
private fun RaFriends(app: CartuchoApp, inviteText: String) {
    val c = Cartucho.colors
    val context = LocalContext.current
    val user = app.prefs.current.raUser
    val key = app.secure.raWebKey
    if (user.isEmpty() || key.isEmpty()) return
    var friends by remember { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(user) {
        friends = withContext(Dispatchers.IO) { runCatching { RaWeb(user, key).following().map { it.user } }.getOrNull() }
    }
    val list = friends ?: return
    if (list.isEmpty()) return
    Text("Amigos do RetroAchievements", style = Cartucho.type.caption, color = c.textSecondary)
    ListGroup {
        list.take(12).forEachIndexed { i, name ->
            if (i > 0) Divider()
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(name, style = Cartucho.type.body, color = c.text, modifier = Modifier.weight(1f))
                SecondaryButton("Convidar", {
                    copy(context, inviteText)
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://retroachievements.org/messages/create?to=${Uri.encode(name)}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                })
            }
        }
    }
    Text("O convite fica copiado: é só colar na mensagem.", style = Cartucho.type.caption, color = c.textSecondary)
}

private fun copy(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Convite", text))
}

private fun shareInvite(context: Context, text: String, whatsapp: Boolean) {
    val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    if (whatsapp) {
        val wa = Intent(intent).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (runCatching { context.startActivity(wa) }.isSuccess) return
    }
    context.startActivity(Intent.createChooser(intent, "Convidar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
