package app.cartucho.game

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.cartucho.CartuchoApp
import app.cartucho.R
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import app.cartucho.net.LocalHotspot
import app.cartucho.net.RemotePadServer
import app.cartucho.net.RoomHost
import app.cartucho.net.Signaling
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SegmentedRow
import app.cartucho.ui.theme.Cartucho
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** QR code em bitmap (preto no branco, com margem). */
fun qrBitmap(text: String, size: Int = 512): Bitmap {
    val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1))
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    for (y in 0 until size) for (x in 0 until size) bmp.setPixel(x, y, if (matrix[x, y]) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())
    return bmp
}

@Composable
private fun QrImage(text: String, modifier: Modifier = Modifier, size: Int = 200) {
    val bmp = remember(text) { qrBitmap(text) }
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).padding(10.dp)) {
        Image(bmp.asImageBitmap(), contentDescription = "QR code", modifier = Modifier.size(size.dp))
    }
}

/**
 * Menu do jogo > Jogar com amigos (até 4 jogadores), de dois jeitos:
 * - Aqui perto: o celular cria o Wi-Fi do Cartucho (ou usa o Wi-Fi em que todos estão); os amigos
 *   leem o QR, entram na rede e jogam pelo navegador, sem instalar nada e sem internet.
 *   Controles Bluetooth/USB ligados no celular também viram jogadores 2 a 4.
 * - De longe: sala online com convite por QR, WhatsApp ou código (cada um na sua internet).
 */
@Composable
fun FriendsPanel(app: CartuchoApp, pad: RemotePadServer, room: RoomHost, hotspot: LocalHotspot) {
    val c = Cartucho.colors
    val context = LocalContext.current
    var mode by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { pad.start() }
        room.start()
    }
    val code by room.code
    val status by room.status
    val roomError by room.error
    val starting by room.starting
    val lan by pad.url
    val lanError by pad.error
    val ssid by hotspot.ssid
    val hotspotError by hotspot.error
    val hotspotStarting by hotspot.starting
    LaunchedEffect(code) { pad.roomCode = code }

    val startHotspot = {
        hotspot.start {
            pad.preferHotspot = true
            pad.refreshUrl()
        }
    }
    val permissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted.values.all { it }) startHotspot()
        else hotspot.error.value = "Sem a permissão de aparelhos por perto o Android não deixa criar o Wi-Fi do Cartucho."
    }
    fun askAndStart() {
        val needed = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startHotspot() else permissions.launch(missing.toTypedArray())
    }

    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ListGroup { SegmentedRow("", listOf("Aqui perto", "De longe"), mode, { mode = it }) }

        if (mode == 0) {
            if (ssid == null) {
                Text(
                    "Todos no mesmo lugar, até 4 jogadores. O Cartucho cria uma rede Wi-Fi só para o jogo, sem internet e sem depender do roteador. " +
                        "Os amigos leem dois QR, um para entrar na rede e outro para abrir o controle, e jogam pelo navegador, sem instalar nada.",
                    style = Cartucho.type.body,
                    color = c.textSecondary,
                )
                PrimaryButton(
                    if (hotspotStarting) "Criando o Wi-Fi…" else "Criar o Wi-Fi do Cartucho",
                    { askAndStart() },
                    Modifier.fillMaxWidth(),
                    icon = R.drawable.ic_broadcast,
                    enabled = !hotspotStarting,
                )
                if (hotspotError != null) Text(hotspotError ?: "", style = Cartucho.type.body, color = c.danger)
                // Alternativa: todos já no mesmo Wi-Fi.
                if (lan != null) {
                    Divider()
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        QrImage(lan!!, size = 140)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Já estão todos no mesmo Wi-Fi?", style = Cartucho.type.headline, color = c.text)
                            Text("Leiam este QR para abrir o controle. Se não abrir, o roteador bloqueia aparelhos entre si: use o Wi-Fi do Cartucho.", style = Cartucho.type.caption, color = c.textSecondary)
                        }
                    }
                } else if (lanError != null) {
                    Text(lanError ?: "", style = Cartucho.type.caption, color = c.textSecondary)
                }
            } else {
                Text("1. Entrar no Wi-Fi do Cartucho", style = Cartucho.type.headline, color = c.text)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    hotspot.wifiQr()?.let { QrImage(it, size = 150) }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Leia com a câmera e toque em Conectar.", style = Cartucho.type.caption, color = c.textSecondary)
                        Text("Rede", style = Cartucho.type.caption, color = c.textSecondary)
                        Text(ssid ?: "", style = Cartucho.type.body, color = c.text)
                        if (!hotspot.password.value.isNullOrEmpty()) {
                            Text("Senha", style = Cartucho.type.caption, color = c.textSecondary)
                            Text(hotspot.password.value ?: "", style = Cartucho.type.body, color = c.text)
                        }
                    }
                }
                Text("2. Abrir o controle", style = Cartucho.type.headline, color = c.text)
                if (lan != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        QrImage(lan!!, size = 150)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Depois de entrar na rede, leia este QR. Se o celular avisar que a rede não tem internet, escolha manter a conexão.", style = Cartucho.type.caption, color = c.textSecondary)
                            Text(lan!!.removePrefix("http://").trimEnd('/'), style = Cartucho.type.body, color = c.text)
                        }
                    }
                } else {
                    Text("Preparando o controle…", style = Cartucho.type.caption, color = c.textSecondary)
                }
                PlayersList(
                    pad.players.map { Triple("n:" + it.id, it.name + " · navegador", it.port) },
                    onPort = { id, p -> pad.setPort(id.drop(2).toInt(), p) },
                    onKick = null,
                )
                SecondaryButton("Desligar o Wi-Fi do Cartucho", {
                    hotspot.stop()
                    pad.preferHotspot = false
                    pad.refreshUrl()
                }, Modifier.fillMaxWidth())
            }
            Text(
                "Controles Bluetooth ou USB ligados no celular também entram como jogadores 2, 3 e 4.",
                style = Cartucho.type.caption,
                color = c.textSecondary,
            )
        } else {
            // Com sala: o QR é o convite da página do Cartucho (funciona em qualquer rede e abre o app);
            // a página também leva ao controle pelo navegador quando o amigo está no mesmo Wi-Fi.
            val qr = code?.let { Signaling.inviteLink(it) + (lan?.let { l -> "&lan=" + l.removePrefix("http://").trimEnd('/') } ?: "") }
            if (qr != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    QrImage(qr)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Convite para quem está longe", style = Cartucho.type.headline, color = c.text)
                        Text(
                            if (RoomHost.relayReady) "Quem tem o Cartucho entra na sala de qualquer internet: Wi-Fi ou dados móveis."
                            else "Quem tem o Cartucho entra na sala. Funciona quando ao menos um de vocês está num Wi-Fi.",
                            style = Cartucho.type.caption,
                            color = c.textSecondary,
                        )
                        Text("Código da sala", style = Cartucho.type.caption, color = c.textSecondary)
                        Text(code ?: "", style = Cartucho.type.title, color = c.text)
                    }
                }
            } else if (starting) {
                Text("Criando a sala…", style = Cartucho.type.body, color = c.textSecondary)
            }
            if (status.isNotEmpty()) Text(status, style = Cartucho.type.caption, color = c.textSecondary)
            if (roomError != null) {
                Text(roomError ?: "", style = Cartucho.type.body, color = c.danger)
                SecondaryButton("Tentar criar a sala de novo", { room.start() }, Modifier.fillMaxWidth())
            }
            if (code != null) {
                val link = Signaling.inviteLink(code!!)
                val inviteText = "Bora jogar comigo no Cartucho! Entra na sala: $link (código $code)"
                PrimaryButton("Convidar pelo WhatsApp", { shareInvite(context, inviteText, whatsapp = true) }, Modifier.fillMaxWidth(), icon = R.drawable.ic_share)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Copiar convite", { copy(context, inviteText) }, Modifier.weight(1f))
                    SecondaryButton("Outros apps", { shareInvite(context, inviteText, whatsapp = false) }, Modifier.weight(1f))
                }
                PlayersList(
                    room.guests.map { Triple("s:" + it.id, it.name + if (it.connected) " · no app" else " (conectando…)", it.port) } +
                        pad.players.map { Triple("n:" + it.id, it.name + " · navegador", it.port) },
                    onPort = { id, p -> if (id.startsWith("s:")) room.setPort(id.drop(2), p) else pad.setPort(id.drop(2).toInt(), p) },
                    onKick = { id -> if (id.startsWith("s:")) room.kick(id.drop(2)) },
                )
                SecondaryButton("Fechar a sala", { room.stop() }, Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PlayersList(players: List<Triple<String, String, Int>>, onPort: (String, Int) -> Unit, onKick: ((String) -> Unit)?) {
    val c = Cartucho.colors
    ListGroup {
        Row(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Jogador 1", style = Cartucho.type.body, color = c.text, modifier = Modifier.weight(1f))
            Text("Você", style = Cartucho.type.body, color = c.textSecondary)
        }
        if (players.isEmpty()) {
            Divider()
            Text("Ninguém entrou ainda.", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(16.dp))
        }
        players.forEach { (id, name, port) ->
            Divider()
            SegmentedRow(name, listOf("1", "2", "3", "4"), port, { onPort(id, it) }, subtitle = "Jogador ${port + 1}")
            if (onKick != null && id.startsWith("s:")) {
                Text(
                    "Remover da sala",
                    style = Cartucho.type.caption,
                    color = c.danger,
                    modifier = Modifier.clickable { onKick(id) }.padding(start = 16.dp, bottom = 12.dp, top = 2.dp),
                )
            }
        }
    }
}
private fun copy(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Convite", text))
}

private fun shareInvite(context: Context, text: String, whatsapp: Boolean) {
    val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    if (whatsapp) {
        val wa = Intent(intent).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (runCatching { context.startActivity(wa) }.isSuccess) return
    }
    context.startActivity(Intent.createChooser(intent, "Convidar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
