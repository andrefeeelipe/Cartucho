package app.cartucho.game

import android.content.Context

/**
 * "Modo exato" por jogo: quando o vigia vê um erro de imagem (tela toda branca com o jogo rodando),
 * o jogo passa a abrir com o emulador no modo mais preciso, mesmo que um pouco mais lento.
 */
object SafeMode {
    private const val PREFS = "modo_exato"

    fun isOn(context: Context, gameId: String): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(gameId, false)

    fun turnOn(context: Context, gameId: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(gameId, true).apply()
    }

    fun turnOff(context: Context, gameId: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(gameId).apply()
    }
}
