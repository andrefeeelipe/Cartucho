package app.cartucho.game

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.hardware.input.InputManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import app.cartucho.CartuchoApp
import app.cartucho.achievements.RaToast
import app.cartucho.achievements.RetroAchievements
import app.cartucho.data.ControlMode
import app.cartucho.data.OrientationMode
import app.cartucho.data.Systems
import app.cartucho.data.ThemeMode
import app.cartucho.emu.Gamepads
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.pressable
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.CartuchoTheme
import app.cartucho.ui.theme.Motion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameActivity : ComponentActivity(), InputManager.InputDeviceListener {
    companion object {
        const val EXTRA_GAME_ID = "gameId"
    }

    private lateinit var app: CartuchoApp
    private lateinit var session: GameSession
    private lateinit var root: FrameLayout
    private var glView: GLSurfaceView? = null
    private var exiting = false

    private val menuOpen = mutableStateOf(false)
    private val gamepadConnected = mutableStateOf(false)
    private val toast = mutableStateOf<RaToast?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as CartuchoApp
        val game = intent.getStringExtra(EXTRA_GAME_ID)?.let { app.library.find(it) }
        val system = game?.let { Systems.get(it.systemId) }
        if (game == null || system == null) {
            finish()
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()
        applyOrientation(app.prefs.current.orientation)

        session = GameSession(app, game, system, if (app.device.glesMajor >= 3) 3 else 2)
        session.input.menuComboEnabled = app.prefs.current.menuCombo
        session.input.onMenuRequested = { runOnUiThread { toggleMenu() } }
        session.onExitRequestedByCore = { runOnUiThread { exitGame() } }

        root = FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }
        val overlay = ComposeView(this).apply { setContent { Overlay() } }
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        gamepadConnected.value = Gamepads.connected().isNotEmpty()
        (getSystemService(Context.INPUT_SERVICE) as InputManager).registerInputDeviceListener(this, Handler(Looper.getMainLooper()))

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                toggleMenu()
            }
        })

        lifecycleScope.launch {
            val error = withContext(Dispatchers.IO) { session.prepareFiles() }
            if (error != null) {
                session.showMessage(error)
                showFatal(error)
            } else {
                createGlView()
            }
        }

        lifecycleScope.launch {
            app.prefs.settings.collect { s ->
                if (::session.isInitialized) session.applySettings(s)
                applyOrientation(s.orientation)
                updateGlLayout()
            }
        }

        lifecycleScope.launch {
            RetroAchievements.get().toasts.collect { t -> showToast(t) }
        }
    }

    private val fatal = mutableStateOf<String?>(null)

    private fun showFatal(message: String) {
        fatal.value = message
    }

    private fun showToast(t: RaToast) {
        toast.value = t
    }

    private fun createGlView() {
        val view = GLSurfaceView(this).apply {
            setEGLContextClientVersion(session.glesMajor)
            preserveEGLContextOnPause = true
            setRenderer(session.renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            isFocusable = false
        }
        glView = view
        session.view = view
        root.addView(view, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        updateGlLayout()
        lifecycleScope.launch {
            session.error.collect { e -> if (e != null) showFatal(e) }
        }
    }

    /** No modo retrato com controles na tela, o jogo ocupa a metade de cima. */
    /** Mostra os botões na tela conforme a escolha em Ajustes > Controles > Jogar com. */
    private fun touchVisible(mode: ControlMode = app.prefs.current.controlMode): Boolean = when (mode) {
        ControlMode.TOUCH -> true
        ControlMode.GAMEPAD -> false
        ControlMode.AUTO -> !gamepadConnected.value
    }

    private fun updateGlLayout() {
        val view = glView ?: return
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val touchVisible = touchVisible()
        val params = view.layoutParams as? FrameLayout.LayoutParams ?: return
        if (portrait && touchVisible) {
            params.height = (resources.displayMetrics.heightPixels * 0.52f).toInt()
            params.gravity = Gravity.TOP
        } else {
            params.height = ViewGroup.LayoutParams.MATCH_PARENT
            params.gravity = Gravity.CENTER
        }
        view.layoutParams = params
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateGlLayout()
        hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun applyOrientation(mode: OrientationMode) {
        requestedOrientation = when (mode) {
            OrientationMode.AUTO -> ActivityInfo.SCREEN_ORIENTATION_FULL_USER
            OrientationMode.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
            OrientationMode.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
        }
    }

    private fun toggleMenu() {
        if (exiting) return
        setMenu(!menuOpen.value)
    }

    private fun setMenu(open: Boolean) {
        menuOpen.value = open
        if (::session.isInitialized) session.setPaused(open)
    }

    private fun exitGame() {
        if (exiting) return
        exiting = true
        menuOpen.value = false
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { session.shutdown() }
            finish()
            // O core fica com estado global; encerrar o processo garante um começo limpo no próximo jogo.
            Handler(Looper.getMainLooper()).postDelayed({ Process.killProcess(Process.myPid()) }, 400)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!::session.isInitialized) return super.dispatchKeyEvent(event)
        if (menuOpen.value) {
            val mapped = when (event.keyCode) {
                KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER
                KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK
                KeyEvent.KEYCODE_BUTTON_MODE, KeyEvent.KEYCODE_BUTTON_START -> {
                    if (event.action == KeyEvent.ACTION_UP) setMenu(false)
                    return true
                }
                else -> null
            }
            if (mapped != null) {
                return super.dispatchKeyEvent(KeyEvent(event.downTime, event.eventTime, event.action, mapped, event.repeatCount, event.metaState, event.deviceId, event.scanCode, event.flags, event.source))
            }
            return super.dispatchKeyEvent(event)
        }
        if (session.input.handleKey(event)) {
            if (gamepadConnected.value.not()) {
                gamepadConnected.value = true
                updateGlLayout()
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (::session.isInitialized && !menuOpen.value && session.input.handleMotion(event)) return true
        return super.dispatchGenericMotionEvent(event)
    }

    override fun onInputDeviceAdded(deviceId: Int) {
        gamepadConnected.value = Gamepads.connected().isNotEmpty()
        updateGlLayout()
        if (Gamepads.isGamepad(android.view.InputDevice.getDevice(deviceId))) {
            showToast(RaToast("Controle conectado", android.view.InputDevice.getDevice(deviceId)?.name ?: ""))
        }
    }

    override fun onInputDeviceRemoved(deviceId: Int) {
        if (!::session.isInitialized) return
        val port = session.input.deviceRemoved(deviceId)
        gamepadConnected.value = Gamepads.connected().isNotEmpty()
        updateGlLayout()
        if (port != null) {
            showToast(RaToast("Controle desconectado", "Jogador ${port + 1}"))
            if (port == 0 && !menuOpen.value) setMenu(true)
        }
    }

    override fun onInputDeviceChanged(deviceId: Int) {}

    override fun onPause() {
        super.onPause()
        if (!::session.isInitialized || exiting) return
        session.setPaused(true)
        session.runOnGlAndWait(800) { session.saveSramNow() }
        glView?.onPause()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        if (!::session.isInitialized) return
        glView?.onResume()
        if (!menuOpen.value) session.setPaused(false)
    }

    override fun onDestroy() {
        runCatching { (getSystemService(Context.INPUT_SERVICE) as InputManager).unregisterInputDeviceListener(this) }
        super.onDestroy()
        if (!exiting && isFinishing && ::session.isInitialized) {
            session.shutdown()
            Process.killProcess(Process.myPid())
        }
    }

    @Composable
    private fun Overlay() {
        CartuchoTheme(ThemeMode.DARK) {
            val s by app.prefs.settings.collectAsState()
            val c = Cartucho.colors
            val loaded by session.loaded.collectAsState()
            val fps by session.fps.collectAsState()
            val fatalMessage = fatal.value
            val currentToast = toast.value

            LaunchedEffect(currentToast) {
                if (currentToast != null) {
                    delay(2600)
                    toast.value = null
                }
            }

            Box(Modifier.fillMaxSize()) {
                if (fatalMessage != null) {
                    Column(
                        Modifier.align(Alignment.Center).widthIn(max = 420.dp).padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text("Não deu para abrir o jogo", style = Cartucho.type.title, color = c.text, textAlign = TextAlign.Center)
                        Text(fatalMessage, style = Cartucho.type.body, color = c.textSecondary, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(8.dp))
                        PrimaryButton("Voltar à biblioteca", { exitGame() }, Modifier.fillMaxWidth())
                    }
                } else {
                    GameLayer(s, loaded, fps, currentToast)
                }
            }
        }
    }

    @Composable
    private fun androidx.compose.foundation.layout.BoxScope.GameLayer(
        s: app.cartucho.data.Settings,
        loaded: Boolean,
        fps: Double,
        currentToast: RaToast?,
    ) {
                val c = Cartucho.colors
                if (!loaded) {
                    val status by session.message.collectAsState()
                    Text(status ?: "Abrindo…", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.align(Alignment.Center))
                }

                if (loaded && touchVisible(s.controlMode) && !menuOpen.value) {
                    TouchControls(
                        layout = session.system.layout,
                        systemId = session.system.id,
                        opacity = s.touchOpacity,
                        scale = s.touchScale,
                        vibration = s.vibration,
                        onButtons = { session.input.setTouchButtons(it) },
                        onAnalog = { stick, x, y -> session.input.setTouchAnalog(stick, x, y) },
                        onMenu = { toggleMenu() },
                    )
                }

                if (loaded && !touchVisible(s.controlMode) && !menuOpen.value) {
                    androidx.compose.foundation.layout.Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .windowInsetsPadding(WindowInsets.safeDrawing)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color.Black.copy(alpha = 0.35f))
                            .pressable(shape = RoundedCornerShape(999.dp)) { toggleMenu() }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    ) {
                        Text(if (gamepadConnected.value) "Menu" else "Menu · conecte um controle", style = Cartucho.type.caption, color = Color.White)
                    }
                }

                if (s.showFps && loaded) {
                    Text(
                        "%.0f FPS".format(fps),
                        style = Cartucho.type.mono,
                        color = Color.White,
                        modifier = Modifier
                            .windowInsetsPadding(WindowInsets.safeDrawing)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.5f))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                    )
                }

                AnimatedVisibility(
                    visible = currentToast != null,
                    enter = slideInVertically(Motion.standard()) { -it } + fadeIn(Motion.fade()),
                    exit = slideOutVertically(Motion.standard()) { -it } + fadeOut(Motion.fade()),
                    modifier = Modifier.align(Alignment.TopCenter).windowInsetsPadding(WindowInsets.safeDrawing).padding(top = 12.dp),
                ) {
                    Column(
                        Modifier
                            .widthIn(max = 420.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(c.surface)
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                    ) {
                        Text(currentToast?.title ?: "", style = Cartucho.type.label, color = c.text)
                        if (!currentToast?.subtitle.isNullOrEmpty()) {
                            Text(currentToast?.subtitle ?: "", style = Cartucho.type.caption, color = c.textSecondary)
                        }
                    }
                }

                InGameMenu(
                    session = session,
                    visible = menuOpen.value,
                    onResume = { setMenu(false) },
                    onExit = { exitGame() },
                    onMessage = { msg -> runOnUiThread { showToast(RaToast(msg, "")) } },
                )
    }
}
