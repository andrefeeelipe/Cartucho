package app.cartucho.game

import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import app.cartucho.data.Ps2Engine
import app.cartucho.data.OrientationMode
import app.cartucho.data.DsLayout
import app.cartucho.data.GameCard
import app.cartucho.emu.Gamepads
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.cartucho.R
import app.cartucho.achievements.Achievement
import app.cartucho.achievements.RetroAchievements
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.CIcon
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.IconButton
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.SheetAction
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SegmentedRow
import app.cartucho.ui.components.pressable
import app.cartucho.ui.screens.AudioGroup
import app.cartucho.ui.screens.TouchGroup
import app.cartucho.ui.screens.VideoGroup
import app.cartucho.ui.screens.formatDate
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.Motion

private enum class Panel { MAIN, SAVE, LOAD, CONTROLS, AUDIO, VIDEO, ACHIEVEMENTS, TV, FRIENDS, SCREENS, ROTATION }

@Composable
fun InGameMenu(
    session: GameSession,
    visible: Boolean,
    onResume: () -> Unit,
    onExit: () -> Unit,
    onMessage: (String) -> Unit,
    onEditTouch: () -> Unit = {},
    onRemapController: (android.view.InputDevice) -> Unit = {},
    tv: TvOutput? = null,
    friends: @Composable () -> Unit = {},
) {
    val app = session.app
    val shareScope = rememberCoroutineScope()
    val c = Cartucho.colors
    val s by app.prefs.settings.collectAsState()
    var panel by remember { mutableStateOf(Panel.MAIN) }
    var speed by remember { mutableIntStateOf(1) }
    var slotsVersion by remember { mutableIntStateOf(0) }
    val hardcore = s.raEnabled && s.raHardcore
    val raState by RetroAchievements.get().state.collectAsState()

    LaunchedEffect(visible) { if (visible) panel = Panel.MAIN }

    BottomSheet(visible = visible, onDismiss = onResume) {
        AnimatedContent(
            targetState = panel,
            transitionSpec = { fadeIn(Motion.fade()) togetherWith fadeOut(Motion.fade()) },
            label = "panel",
        ) { p ->
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                when (p) {
                    Panel.MAIN -> {
                        Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                            Text(session.game.title, style = Cartucho.type.title, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(session.system.name, style = Cartucho.type.caption, color = c.textSecondary)
                        }
                        Spacer(Modifier.height(6.dp))
                        SheetAction("Continuar", R.drawable.ic_play, onResume)
                        SheetAction("Salvar estado", R.drawable.ic_save, { panel = Panel.SAVE })
                        SheetAction(
                            "Carregar estado", R.drawable.ic_load, { panel = Panel.LOAD },
                            enabled = !hardcore,
                            subtitle = if (hardcore) "Indisponível no modo hardcore" else null,
                        )
                        SheetAction(
                            "Avanço rápido: ${speed}x", R.drawable.ic_fast_forward, {
                                speed = when (speed) { 1 -> 2; 2 -> 4; else -> 1 }
                                session.setFastForward(speed)
                            },
                            enabled = !hardcore,
                        )
                        SheetAction("Compartilhar card", R.drawable.ic_cloud_up, {
                            shareScope.launch { if (!GameCard.shareGame(app, session.game)) onMessage("Não foi possível gerar o card.") }
                        }, subtitle = "Mostre o que você está jogando")
                        SheetAction("Transmitir para TV", R.drawable.ic_tv, { panel = Panel.TV }, subtitle = when (tv?.mode?.value) {
                            TvMode.MIRROR -> "Duplicando"
                            TvMode.TV_ONLY -> "Só na TV"
                            else -> "Desligado"
                        })
                        SheetAction("Jogar com amigos", R.drawable.ic_users, { panel = Panel.FRIENDS }, subtitle = "Controle pelo navegador (QR) ou sala online")
                        if (session.hasTwoScreens) {
                            SheetAction("Telas", R.drawable.ic_video, { panel = Panel.SCREENS }, subtitle = s.dsLayout.label)
                        }
                        if (session.system.id == "ps2") {
                            SheetAction("Emulador do PS2", R.drawable.ic_controller, {
                                val next = Ps2Engine.values()[(s.ps2Engine.ordinal + 1) % Ps2Engine.values().size]
                                app.prefs.update { it.copy(ps2Engine = next) }
                                onMessage("${next.label}: vale na próxima vez que abrir o jogo")
                            }, subtitle = s.ps2Engine.label + if (session.coreId == "armsx2") " · usando ARMSX2" else " · usando Play!")
                        }
                        SheetAction("Girar a tela", R.drawable.ic_sync, { panel = Panel.ROTATION }, subtitle = when (s.orientation) {
                            OrientationMode.AUTO -> "Gira junto com o celular"
                            OrientationMode.PORTRAIT -> "Travada em pé"
                            OrientationMode.LANDSCAPE -> "Travada deitada"
                        })
                        SheetAction("Controles", R.drawable.ic_controller, { panel = Panel.CONTROLS })
                        SheetAction("Áudio", R.drawable.ic_audio, { panel = Panel.AUDIO })
                        SheetAction("Vídeo", R.drawable.ic_video, { panel = Panel.VIDEO })
                        if (s.raEnabled) {
                            SheetAction(
                                "Conquistas", R.drawable.ic_trophy, { panel = Panel.ACHIEVEMENTS },
                                subtitle = if (raState.total > 0) "${raState.unlocked} de ${raState.total}" else raState.gameTitle,
                            )
                        }
                        SheetAction("Reiniciar jogo", R.drawable.ic_reset, {
                            session.reset()
                            onResume()
                        })
                        SheetAction("Sair do jogo", R.drawable.ic_exit, onExit, danger = true, subtitle = "O save do jogo é guardado automaticamente")
                    }
                    Panel.SAVE, Panel.LOAD -> SlotPanel(
                        session = session,
                        saving = p == Panel.SAVE,
                        version = slotsVersion,
                        onBack = { panel = Panel.MAIN },
                        onPick = { slot ->
                            if (p == Panel.SAVE) {
                                session.saveState(slot) { ok ->
                                    slotsVersion++
                                    onMessage(if (ok) "Estado salvo no espaço $slot" else "Este emulador não conseguiu salvar o estado")
                                }
                                onResume()
                            } else {
                                session.loadState(slot) { ok ->
                                    onMessage(if (ok) "Estado $slot carregado" else "Não foi possível carregar o estado")
                                }
                                onResume()
                            }
                        },
                    )
                    Panel.CONTROLS -> SubPanel("Controles", { panel = Panel.MAIN }) {
                        // Controles físicos conectados: mapear sem sair do jogo.
                        Gamepads.connected().forEachIndexed { i, d ->
                            SheetAction(
                                "Mapear ${d.name}",
                                R.drawable.ic_controller,
                                { onRemapController(d) },
                                subtitle = "Jogador ${i + 1} · escolha o botão do controle para cada botão do jogo",
                            )
                        }
                        SheetAction("Editar botões na tela", R.drawable.ic_touch, onEditTouch, subtitle = "Arraste e mude o tamanho de cada grupo")
                        TouchGroup(app)
                    }
                    Panel.TV -> SubPanel("Transmitir para TV", { panel = Panel.MAIN }) { if (tv != null) TvPanel(tv) }
                    Panel.FRIENDS -> SubPanel("Jogar com amigos", { panel = Panel.MAIN }) { friends() }
                    Panel.AUDIO -> SubPanel("Áudio", { panel = Panel.MAIN }) { AudioGroup(app) }
                    Panel.VIDEO -> SubPanel("Vídeo", { panel = Panel.MAIN }) { VideoGroup(app) }
                    Panel.ACHIEVEMENTS -> SubPanel("Conquistas", { panel = Panel.MAIN }) { AchievementList() }
                    Panel.SCREENS -> SubPanel("Telas", { panel = Panel.MAIN }) {
                        Text(
                            "Como as duas telas aparecem. No automático, deitado fica lado a lado (a de cima à esquerda) e em pé uma em cima da outra.",
                            style = Cartucho.type.caption,
                            color = c.textSecondary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
                        )
                        DsLayout.values().forEach { layout ->
                            SheetAction(
                                layout.label,
                                if (s.dsLayout == layout) R.drawable.ic_check else R.drawable.ic_video,
                                { app.prefs.update { it.copy(dsLayout = layout) } },
                            )
                        }
                    }
                    Panel.ROTATION -> SubPanel("Girar a tela", { panel = Panel.MAIN }) {
                        Text(
                            "Trave a tela para ela não girar enquanto você mexe o celular, mesmo com o giro automático ligado.",
                            style = Cartucho.type.caption,
                            color = c.textSecondary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
                        )
                        listOf(
                            OrientationMode.AUTO to "Girar junto com o celular",
                            OrientationMode.PORTRAIT to "Travar em pé (vertical)",
                            OrientationMode.LANDSCAPE to "Travar deitado (horizontal)",
                        ).forEach { (mode, label) ->
                            SheetAction(
                                label,
                                if (s.orientation == mode) R.drawable.ic_check else R.drawable.ic_sync,
                                { app.prefs.update { it.copy(orientation = mode) } },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubPanel(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    val c = Cartucho.colors
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(R.drawable.ic_back, "Voltar", onBack)
            Text(title, style = Cartucho.type.title, color = c.text)
        }
        Spacer(Modifier.height(8.dp))
        content()
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SlotPanel(session: GameSession, saving: Boolean, version: Int, onBack: () -> Unit, onPick: (Int) -> Unit) {
    val c = Cartucho.colors
    val slots = remember(version) { session.slots() }
    SubPanel(if (saving) "Salvar em" else "Carregar de", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            slots.forEach { slot ->
                val enabled = saving || slot.exists
                Column(
                    Modifier
                        .weight(1f)
                        .pressable(enabled = enabled, shape = RoundedCornerShape(10.dp)) { onPick(slot.slot) }
                        .border(1.dp, c.border, RoundedCornerShape(10.dp))
                        .padding(8.dp),
                ) {
                    val bitmap = remember(slot.thumbnail, version) {
                        slot.thumbnail?.let { f -> runCatching { BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() }.getOrNull() }
                    }
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(4f / 3f).clip(RoundedCornerShape(6.dp)).background(c.surfaceRaised),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (bitmap != null) {
                            Image(bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth())
                        } else {
                            CIcon(R.drawable.ic_save, tint = c.textSecondary, size = 20.dp)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Espaço ${slot.slot}", style = Cartucho.type.label, color = if (enabled) c.text else c.textSecondary)
                    Text(if (slot.exists) formatDate(slot.modified) else "Vazio", style = Cartucho.type.caption, color = c.textSecondary, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun AchievementList() {
    val c = Cartucho.colors
    val list = remember { mutableStateOf<List<Achievement>>(emptyList()) }
    LaunchedEffect(Unit) { list.value = RetroAchievements.get().achievements() }
    ListGroup {
        if (list.value.isEmpty()) {
            Text(
                "Nenhuma conquista para mostrar. O jogo pode não ter conquistas ou ainda estar sendo identificado.",
                style = Cartucho.type.body,
                color = c.textSecondary,
                modifier = Modifier.padding(16.dp),
            )
        }
        list.value.forEachIndexed { i, a ->
            if (i > 0) Divider()
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                CIcon(if (a.unlocked) R.drawable.ic_check else R.drawable.ic_lock, tint = if (a.unlocked) c.success else c.textSecondary, size = 18.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.title, style = Cartucho.type.body, color = c.text)
                    Text(a.description, style = Cartucho.type.caption, color = c.textSecondary)
                    if (a.progress.isNotEmpty() && !a.unlocked) Text(a.progress, style = Cartucho.type.mono, color = c.textSecondary)
                }
                Text("${a.points}", style = Cartucho.type.mono, color = c.textSecondary)
            }
        }
    }
}


@Composable
private fun TvPanel(tv: TvOutput) {
    val c = Cartucho.colors
    val mode by tv.mode
    val available by tv.tvAvailable
    val name by tv.tvName
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ListGroup {
            SegmentedRow(
                "Onde o jogo aparece",
                listOf("Só celular", "Duplicar", "Só TV"),
                mode.ordinal,
                { tv.setMode(TvMode.values()[it]) },
                subtitle = when (mode) {
                    TvMode.PHONE -> "A TV não mostra o jogo."
                    TvMode.MIRROR -> "O jogo aparece no celular e na TV."
                    TvMode.TV_ONLY -> "O jogo aparece só na TV; o celular vira o controle."
                },
            )
        }
        Text(
            if (available) "Conectado: $name" else "Nenhuma TV conectada. Use a transmissão do Android (Smart View, Transmitir tela ou Google Home) ou um cabo HDMI.",
            style = Cartucho.type.caption,
            color = if (available) c.accent else c.textSecondary,
        )
        if (mode == TvMode.TV_ONLY && !available) {
            Text(
                "\"Só TV\" precisa que a TV apareça como segunda tela: espelhamento sem fio (Smart View/Miracast) ou cabo. Pelo Chromecast, use \"Duplicar\".",
                style = Cartucho.type.caption,
                color = c.textSecondary,
            )
        }
        SecondaryButton("Conectar a uma TV", { tv.openSystemCast() }, Modifier.fillMaxWidth(), icon = R.drawable.ic_tv)
        Spacer(Modifier.height(8.dp))
    }
}
