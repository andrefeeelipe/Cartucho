package app.cartucho.game

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import app.cartucho.emu.NativeBridge
import java.util.concurrent.ConcurrentLinkedQueue
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Laço principal da emulação, rodando na thread do GLSurfaceView.
 * O ritmo segue o relógio (fps do core), não a taxa da tela — assim telas de 90/120 Hz
 * não aceleram o jogo. Com "sincronizar áudio", o ritmo é corrigido pelo nível do buffer de som.
 */
class EmulatorRenderer(private val session: GameSession) : GLSurfaceView.Renderer {
    private val commands = ConcurrentLinkedQueue<() -> Unit>()
    @Volatile var paused = false
    @Volatile var speed = 1
    @Volatile var audioSync = true
    @Volatile var pendingCapture: ((IntArray?) -> Unit)? = null
    /** Falso no modo "só TV": o celular fica preto (só os controles por cima). */
    @Volatile var drawOnPhone = true
    private val tv = TvSurface()
    /** Ganchos chamados a cada quadro desenhado (transmissão da sala online). */
    @Volatile var frameListener: (() -> Unit)? = null

    fun attachTv(window: Any, width: Int, height: Int) = post { tv.create(window, width, height) }
    fun detachTv() = post { tv.release() }

    private var loaded = false
    private var failed = false
    private var lastNanos = 0L
    private var accumulator = 0.0
    private var frameTime = 1.0 / 60.0
    private var sampleRate = 48000
    private var framesThisSecond = 0
    private var secondStart = 0L
    private var frameCounter = 0L
    private var lastSramSave = 0L

    fun post(command: () -> Unit) {
        commands.add(command)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        NativeBridge.setGlesVersion(session.glesMajor)
        NativeBridge.onSurfaceCreated()
        if (!loaded && !failed) {
            loaded = session.loadOnGlThread()
            failed = !loaded
            if (loaded) readAvInfo(force = true)
        }
        lastNanos = System.nanoTime()
        secondStart = lastNanos
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        NativeBridge.onSurfaceChanged(width, height)
    }

    private fun readAvInfo(force: Boolean) {
        val av = NativeBridge.getAvInfo()
        val changed = av.size >= 6 && av[5] > 0.5
        if (!force && !changed) return
        val fps = av[0]
        frameTime = if (fps in 10.0..240.0) 1.0 / fps else 1.0 / 60.0
        val rate = av[1].toInt()
        if (rate in 8000..192000 && (force || rate != sampleRate)) {
            sampleRate = rate
            session.onAudioFormat(rate)
        }
    }

    override fun onDrawFrame(gl: GL10?) {
        while (true) {
            val cmd = commands.poll() ?: break
            runCatching { cmd() }
        }
        if (!loaded) {
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            return
        }
        if (NativeBridge.consumeShutdownRequest()) session.requestExitFromCore()

        val now = System.nanoTime()
        val dt = ((now - lastNanos) / 1e9).coerceIn(0.0, 0.25)
        lastNanos = now

        if (!paused) {
            accumulator += dt * speed
            if (audioSync && speed == 1) {
                val target = session.audioTargetFrames
                if (target > 0) {
                    val buffered = NativeBridge.audioBufferedFrames()
                    if (buffered > target * 2) accumulator -= frameTime * 0.25
                    else if (buffered < target / 2) accumulator += frameTime * 0.25
                }
            }
            val maxRuns = if (speed > 1) speed + 1 else 3
            var runs = 0
            while (accumulator >= frameTime && runs < maxRuns) {
                NativeBridge.runFrame(speed > 1 && runs > 0)
                runs++
                accumulator -= frameTime
                framesThisSecond++
            }
            if (runs == maxRuns) accumulator = 0.0
            if (accumulator < -frameTime) accumulator = -frameTime

            frameCounter++
            if (frameCounter % 30L == 0L) readAvInfo(force = false)
            if (now - lastSramSave > 30_000_000_000L) {
                lastSramSave = now
                session.saveSramNow()
            }
        }

        if (drawOnPhone) NativeBridge.render() else NativeBridge.clearScreen()
        tv.draw()
        frameListener?.invoke()

        pendingCapture?.let { cb ->
            pendingCapture = null
            cb(NativeBridge.captureFrame(320))
        }

        if (now - secondStart >= 1_000_000_000L) {
            session.onFps(framesThisSecond * 1e9 / (now - secondStart))
            framesThisSecond = 0
            secondStart = now
        }
    }
}
