package app.cartucho.net

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import app.cartucho.emu.NativeBridge
import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.JavaI420Buffer
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.VideoFrame
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap

/**
 * Sala online, lado de quem criou: o jogo roda só aqui e é transmitido (vídeo + áudio) para os
 * amigos que têm o Cartucho; cada amigo vira o jogador 1, 2, 3 ou 4.
 * Conexão direta entre os celulares (WebRTC); o ntfy.sh só serve para eles se encontrarem.
 */
class RoomHost(
    private val context: Context,
    private val layoutName: String,
    private val systemId: String,
    private val gameTitle: String,
    private val onButtons: (port: Int, mask: Int) -> Unit,
    private val onAnalog: (port: Int, stick: Int, x: Float, y: Float) -> Unit,
) {
    data class Guest(val id: String, val name: String, val port: Int, val connected: Boolean)

    val code = mutableStateOf<String?>(null)
    val guests = mutableStateListOf<Guest>()
    val status = mutableStateOf("")
    val error = mutableStateOf<String?>(null)
    val starting = mutableStateOf(false)
    /** Jogadores já ocupados por quem está no controle pelo navegador. */
    @Volatile var takenPorts: () -> Set<Int> = { emptySet() }
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    private var signaling: Signaling? = null
    private var factory: PeerConnectionFactory? = null
    private var eglBase: EglBase? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private val peers = ConcurrentHashMap<String, Peer>()
    private var frameCount = 0L
    private var rgba: ByteBuffer? = null
    private var streamW = 0
    private var streamH = 0

    private inner class Peer(val id: String, val pc: PeerConnection) {
        var input: DataChannel? = null
        var audio: DataChannel? = null
        val offerSent = java.util.concurrent.atomic.AtomicBoolean(false)
    }

    val running: Boolean get() = code.value != null

    /** Cria a sala em segundo plano; erros aparecem em [error] em vez de travar o jogo. */
    fun start() {
        if (running || starting.value) return
        starting.value = true
        error.value = null
        status.value = "Criando a sala…"
        // Se o app fechou na última tentativa, tenta de outro jeito (sem aceleração de vídeo).
        val marker = java.io.File(context.filesDir, "sala-iniciando")
        val modes = context.getSharedPreferences("cartucho_sala", Context.MODE_PRIVATE)
        val crashedWith = if (marker.exists()) marker.readText() else ""
        var mode = modes.getString("modo", "hw") ?: "hw"
        if (crashedWith == "hw") mode = "sw"
        if (crashedWith == "sw") {
            marker.delete()
            starting.value = false
            status.value = ""
            error.value = "Da última vez o jogo fechou ao abrir a sala online neste celular. Ao voltar para a biblioteca, o app mostra os detalhes do erro: me mande um print. O QR ainda funciona para quem joga pelo navegador."
            modes.edit().putString("modo", "hw").apply()
            return
        }
        runCatching { marker.writeText(mode) }
        Thread({
            val result = runCatching {
                step("iniciando WebRTC ($mode)")
                initWebRtc(context)
                step("criando fábrica")
                val f = if (mode == "hw") {
                    val egl = EglBase.create()
                    eglBase = egl
                    step("EGL ok")
                    PeerConnectionFactory.builder()
                        .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
                        .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
                        .createPeerConnectionFactory()
                } else {
                    PeerConnectionFactory.builder()
                        .setVideoEncoderFactory(org.webrtc.SoftwareVideoEncoderFactory())
                        .setVideoDecoderFactory(org.webrtc.SoftwareVideoDecoderFactory())
                        .createPeerConnectionFactory()
                }
                factory = f
                step("fábrica ok, criando vídeo")
                val source = f.createVideoSource(false)
                videoSource = source
                source.capturerObserver.onCapturerStarted(true)
                videoTrack = f.createVideoTrack("game", source)
                step("vídeo ok")
            }
            main.post {
                starting.value = false
                result.onSuccess {
                    step("sala pronta")
                    modes.edit().putString("modo", mode).apply()
                    // Passou dos primeiros segundos sem fechar: este jeito funciona aqui.
                    main.postDelayed({ marker.delete() }, 6000)
                    val c = Signaling.newCode()
                    code.value = c
                    status.value = "Conectando ao servidor de encontro…"
                    val sig = Signaling(c, onState = { ok ->
                        main.post {
                            if (code.value == null) return@post
                            if (ok) { if (guests.isEmpty()) status.value = "Sala aberta. Esperando os amigos entrarem…" }
                            else status.value = "Sem internet no momento: os amigos de fora não conseguem entrar. Tentando de novo…"
                        }
                    }) { msg -> main.post { onSignal(msg) } }
                    signaling = sig
                    sig.start()
                }.onFailure { e ->
                    marker.delete()
                    logError(e)
                    status.value = ""
                    error.value = "Não foi possível criar a sala neste celular (${e.javaClass.simpleName}${e.message?.let { ": $it" } ?: ""})."
                    runCatching { factory?.dispose() }
                    runCatching { eglBase?.release() }
                    factory = null; eglBase = null; videoSource = null; videoTrack = null
                }
            }
        }, "room-start").start()
    }

    /** Marca cada etapa no log do Android: se o app fechar, o relatório mostra onde parou. */
    private fun step(text: String) {
        android.util.Log.w("CartuchoSala", text)
    }

    private fun logError(e: Throwable) {
        runCatching {
            java.io.File(context.filesDir, "sala-erro.txt").writeText(android.util.Log.getStackTraceString(e))
        }
    }

    fun stop() {
        runCatching { java.io.File(context.filesDir, "sala-iniciando").delete() }
        signaling?.stop()
        signaling = null
        for (p in peers.values) runCatching { p.pc.close() }
        peers.clear()
        for (g in guests.toList()) { onButtons(g.port, 0); onAnalog(g.port, 0, 0f, 0f) }
        guests.clear()
        runCatching { videoSource?.capturerObserver?.onCapturerStopped() }
        runCatching { videoTrack?.dispose() }
        runCatching { videoSource?.dispose() }
        runCatching { factory?.dispose() }
        runCatching { eglBase?.release() }
        videoTrack = null; videoSource = null; factory = null; eglBase = null
        code.value = null
        status.value = ""
    }

    /** Passa um amigo para outro jogador (0 = jogador 1). */
    fun setPort(id: String, port: Int) {
        val i = guests.indexOfFirst { it.id == id }
        if (i < 0) return
        onButtons(guests[i].port, 0)
        guests[i] = guests[i].copy(port = port)
        peers[id]?.input?.let { sendText(it, "P $port") }
    }

    fun kick(id: String) {
        peers.remove(id)?.let { runCatching { it.pc.close() } }
        guests.firstOrNull { it.id == id }?.let { onButtons(it.port, 0) }
        guests.removeAll { it.id == id }
    }

    /** Chamado a cada quadro desenhado (thread do OpenGL): envia ~30 quadros/s para quem estiver conectado. */
    fun onFrame() {
        val source = videoSource ?: return
        if (peers.isEmpty()) return
        frameCount++
        if (frameCount % 2L != 0L) return
        if (streamW == 0 || frameCount % 120L == 0L) {
            val aspect = NativeBridge.frameAspect().coerceIn(0.5f, 2.5f)
            val h = 480
            var w = ((h * aspect).toInt() / 2) * 2
            if (w > 864) w = 864
            if (w != streamW || h != streamH) {
                streamW = w
                streamH = h
                rgba = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
            }
        }
        val buf = rgba ?: return
        if (!NativeBridge.captureStream(streamW, streamH, buf)) return
        val i420 = JavaI420Buffer.allocate(streamW, streamH)
        NativeBridge.rgbaToI420(buf, streamW, streamH, i420.dataY, i420.strideY, i420.dataU, i420.strideU, i420.dataV, i420.strideV)
        val frame = VideoFrame(i420, 0, System.nanoTime())
        source.capturerObserver.onFrameCaptured(frame)
        frame.release()
    }

    // Áudio: mono, 24 kHz, 16 bits, em pacotes de ~20 ms pelo canal "audio" (sem retransmissão).
    private var audioAcc = 0.0
    private val audioOut = ShortArray(480)
    private var audioOutN = 0

    fun onAudio(samples: ShortArray, count: Int, sampleRate: Int) {
        if (peers.isEmpty()) return
        val step = sampleRate / 24000.0
        var i = 0
        while (i + 1 < count) {
            audioAcc += 1.0
            if (audioAcc >= step) {
                audioAcc -= step
                audioOut[audioOutN++] = ((samples[i] + samples[i + 1]) / 2).toShort()
                if (audioOutN == audioOut.size) {
                    val bb = ByteBuffer.allocate(audioOutN * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (k in 0 until audioOutN) bb.putShort(audioOut[k])
                    bb.flip()
                    for (p in peers.values) {
                        val ch = p.audio ?: continue
                        if (ch.state() == DataChannel.State.OPEN && ch.bufferedAmount() < 64_000) {
                            ch.send(DataChannel.Buffer(bb.duplicate(), true))
                        }
                    }
                    audioOutN = 0
                }
            }
            i += 2
        }
    }

    private fun onSignal(msg: JSONObject) {
        when (msg.optString("t")) {
            "join" -> {
                val id = msg.optString("id")
                if (id.isEmpty()) return
                // Pediu de novo: a oferta pode ter se perdido no caminho, manda outra vez.
                peers[id]?.let { p ->
                    if (p.pc.iceConnectionState() != PeerConnection.IceConnectionState.CONNECTED) { p.offerSent.set(false); sendOffer(p, id) }
                    return
                }
                if (guests.size >= 3) {
                    signaling?.send(JSONObject().put("t", "full").put("to", id))
                    return
                }
                val used = guests.map { it.port }.toSet() + takenPorts()
                val port = (1..3).firstOrNull { it !in used } ?: 1
                guests.add(Guest(id, msg.optString("name").take(24).ifBlank { "Amigo" }, port, false))
                status.value = ""
                connectGuest(id)
            }
            "answer" -> {
                val id = msg.optString("id")
                val p = peers[id] ?: return
                val sdp = runCatching { Signaling.unpack(msg.optString("sdp")) }.getOrNull() ?: return
                p.pc.setRemoteDescription(SimpleSdp(), SessionDescription(SessionDescription.Type.ANSWER, sdp))
            }
            "leave" -> kick(msg.optString("id"))
        }
    }

    private fun connectGuest(id: String) {
        val f = factory ?: return
        val config = PeerConnection.RTCConfiguration(iceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        lateinit var peer: Peer
        val pc = f.createPeerConnection(config, object : PeerObserver() {
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {
                if (state == PeerConnection.IceGatheringState.COMPLETE) sendOffer(peer, id)
            }

            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                main.post { iceChanged(id, state) }
            }
        }) ?: return
        peer = Peer(id, pc)
        connectRest(peer, id)
    }

    private fun iceChanged(id: String, state: PeerConnection.IceConnectionState) {
                val i = guests.indexOfFirst { it.id == id }
                if (i < 0) return
                when (state) {
                    PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED ->
                        guests[i] = guests[i].copy(connected = true)
                    PeerConnection.IceConnectionState.FAILED ->
                        status.value = "Não foi possível conectar com ${guests[i].name}. A rede de algum dos dois pode estar bloqueando; tentem pelo Wi-Fi."
                    PeerConnection.IceConnectionState.CLOSED, PeerConnection.IceConnectionState.DISCONNECTED -> {
                        onButtons(guests[i].port, 0)
                        guests[i] = guests[i].copy(connected = false)
                    }
                    else -> {}
                }
    }

    private fun connectRest(peer: Peer, id: String) {
        val pc = peer.pc
        peers[id] = peer
        videoTrack?.let { pc.addTransceiver(it, RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.SEND_ONLY, listOf("game"))) }
        val input = pc.createDataChannel("input", DataChannel.Init().apply { ordered = true })
        val audio = pc.createDataChannel("audio", DataChannel.Init().apply { ordered = false; maxRetransmits = 0 })
        peer.input = input
        peer.audio = audio
        input.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previous: Long) {}
            override fun onStateChange() {
                if (input.state() == DataChannel.State.OPEN) {
                    val g = guests.firstOrNull { it.id == id } ?: return
                    sendText(input, "L $layoutName $systemId")
                    sendText(input, "T $gameTitle")
                    sendText(input, "P ${g.port}")
                }
            }
            override fun onMessage(buffer: DataChannel.Buffer) {
                val bytes = ByteArray(buffer.data.remaining())
                buffer.data.get(bytes)
                val text = String(bytes)
                val g = guests.firstOrNull { it.id == id } ?: return
                val parts = text.split(' ')
                when (parts.firstOrNull()) {
                    "B" -> parts.getOrNull(1)?.toIntOrNull()?.let { onButtons(g.port, it) }
                    "A" -> if (parts.size >= 4) onAnalog(g.port, parts[1].toIntOrNull() ?: 0, parts[2].toFloatOrNull() ?: 0f, parts[3].toFloatOrNull() ?: 0f)
                    "R" -> parts.getOrNull(1)?.toIntOrNull()?.takeIf { it in 0..3 }?.let { p -> main.post { setPort(id, p) } }
                }
            }
        })
        val constraints = MediaConstraints()
        pc.createOffer(object : SimpleSdp() {
            override fun onCreateSuccess(desc: SessionDescription) {
                pc.setLocalDescription(object : SimpleSdp() {
                    // Se a rede demorar para listar os caminhos, manda o que já tem depois de 6 s.
                    override fun onSetSuccess() { main.postDelayed({ sendOffer(peer, id) }, 6000) }
                }, desc)
            }
        }, constraints)
    }

    private fun sendOffer(peer: Peer, id: String) {
        if (peer.offerSent.getAndSet(true)) return
        val desc = peer.pc.localDescription ?: run { peer.offerSent.set(false); return }
        signaling?.send(JSONObject().put("t", "offer").put("to", id).put("sdp", Signaling.pack(desc.description)))
    }

    private fun sendText(ch: DataChannel, text: String) {
        if (ch.state() != DataChannel.State.OPEN) return
        ch.send(DataChannel.Buffer(ByteBuffer.wrap(text.toByteArray()), false))
    }

    companion object {
        @Volatile private var webrtcReady = false

        /** O WebRTC só pode ser iniciado uma vez por processo. */
        @Synchronized
        fun initWebRtc(context: Context) {
            if (webrtcReady) return
            PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(context.applicationContext).createInitializationOptions())
            runCatching { org.webrtc.Logging.enableLogToDebugOutput(org.webrtc.Logging.Severity.LS_WARNING) }
            webrtcReady = true
        }

        /**
         * Caminhos para as duas pontas se acharem:
         * - STUN (Google e Cloudflare): basta quando ao menos um lado está num Wi-Fi comum;
         * - TURN do Open Relay (gratuito, metered.ca): retransmite o jogo quando os dois estão em
         *   dados móveis (as operadoras escondem os celulares atrás de um mesmo endereço e a
         *   conexão direta não passa). Senhas temporárias geradas aqui, no padrão "REST" do coturn.
         */
        fun iceServers(): List<PeerConnection.IceServer> {
            val (user, pass) = turnCredentials()
            val turn = listOf(
                "turn:$RELAY:80",
                "turn:$RELAY:80?transport=tcp",
                "turn:$RELAY:443",
                "turns:$RELAY:443?transport=tcp",
            )
            return listOf(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
                PeerConnection.IceServer.builder("stun:stun.cloudflare.com:3478").createIceServer(),
                PeerConnection.IceServer.builder(turn).setUsername(user).setPassword(pass).createIceServer(),
            )
        }

        private const val RELAY = "staticauth.openrelay.metered.ca"
        private const val RELAY_SECRET = "openrelayprojectsecret"  // segredo público do Open Relay

        fun turnCredentials(): Pair<String, String> {
            val user = "${System.currentTimeMillis() / 1000 + 24 * 3600}:cartucho"
            val mac = javax.crypto.Mac.getInstance("HmacSHA1")
            mac.init(javax.crypto.spec.SecretKeySpec(RELAY_SECRET.toByteArray(), "HmacSHA1"))
            val pass = android.util.Base64.encodeToString(mac.doFinal(user.toByteArray()), android.util.Base64.NO_WRAP)
            return user to pass
        }
    }
}

open class SimpleSdp : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}

open class PeerObserver : PeerConnection.Observer {
    override fun onSignalingChange(state: PeerConnection.SignalingState) {}
    override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {}
    override fun onIceConnectionReceivingChange(receiving: Boolean) {}
    override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
    override fun onIceCandidate(candidate: IceCandidate) {}
    override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
    override fun onAddStream(stream: MediaStream) {}
    override fun onRemoveStream(stream: MediaStream) {}
    override fun onDataChannel(channel: DataChannel) {}
    override fun onRenegotiationNeeded() {}
    override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {}
}
