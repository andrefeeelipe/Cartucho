package app.cartucho.net

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf

/**
 * Wi-Fi próprio do Cartucho: o celular de quem cria a sala vira um ponto de acesso local
 * (sem internet, só para jogar). Os amigos entram nele pelo QR e usam o controle pelo navegador.
 * Não depende de roteador nem de dados móveis, e o roteador não consegue bloquear os aparelhos
 * entre si (o "isolamento de clientes" que derruba a sala em muitos Wi-Fi de casa e de bar).
 */
class LocalHotspot(context: Context) {
    private val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val main = Handler(Looper.getMainLooper())
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null

    val ssid = mutableStateOf<String?>(null)
    val password = mutableStateOf<String?>(null)
    val starting = mutableStateOf(false)
    val error = mutableStateOf<String?>(null)
    val active: Boolean get() = ssid.value != null

    /** QR que o Android lê pela câmera e conecta direto na rede. */
    fun wifiQr(): String? {
        val s = ssid.value ?: return null
        val p = password.value.orEmpty()
        fun esc(t: String) = t.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")
        return if (p.isEmpty()) "WIFI:T:nopass;S:${esc(s)};;" else "WIFI:T:WPA;S:${esc(s)};P:${esc(p)};;"
    }

    @SuppressLint("MissingPermission")
    fun start(onReady: () -> Unit) {
        if (active || starting.value) return
        starting.value = true
        error.value = null
        runCatching {
            wifi.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = res
                    if (Build.VERSION.SDK_INT >= 30) {
                        val conf = res.softApConfiguration
                        @Suppress("DEPRECATION")
                        ssid.value = conf.ssid?.trim('"') ?: "Cartucho"
                        password.value = conf.passphrase
                    } else {
                        @Suppress("DEPRECATION")
                        val conf = res.wifiConfiguration
                        @Suppress("DEPRECATION")
                        ssid.value = conf?.SSID?.trim('"') ?: "Cartucho"
                        @Suppress("DEPRECATION")
                        password.value = conf?.preSharedKey
                    }
                    starting.value = false
                    onReady()
                }

                override fun onStopped() {
                    reservation = null
                    ssid.value = null
                    password.value = null
                    starting.value = false
                }

                override fun onFailed(reason: Int) {
                    starting.value = false
                    error.value = when (reason) {
                        ERROR_INCOMPATIBLE_MODE ->
                            "O roteador do celular (ancoragem) está ligado. Desligue-o e tente de novo, ou peça para os amigos entrarem nele e use o QR do controle."
                        ERROR_TETHERING_DISALLOWED -> "Este celular não permite criar rede Wi-Fi (bloqueio da operadora ou do aparelho)."
                        else -> "Não foi possível criar o Wi-Fi do Cartucho. Ligue o Wi-Fi e a localização do celular e tente de novo."
                    }
                }
            }, main)
        }.onFailure {
            starting.value = false
            error.value = if (it is SecurityException) "Permita o acesso a aparelhos por perto (ou à localização) para criar o Wi-Fi do Cartucho."
            else "Não foi possível criar o Wi-Fi do Cartucho (${it.message})."
        }
    }

    fun stop() {
        runCatching { reservation?.close() }
        reservation = null
        ssid.value = null
        password.value = null
        starting.value = false
    }
}
