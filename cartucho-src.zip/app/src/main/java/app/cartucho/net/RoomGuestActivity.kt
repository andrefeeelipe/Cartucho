package app.cartucho.net

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import app.cartucho.data.PadLayout
import app.cartucho.emu.Gamepads
import app.cartucho.emu.RemapStore
import app.cartucho.emu.RetroPad
import app.cartucho.game.TouchControls
import app.cartucho.game.TouchLayoutStore
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.CartuchoTheme
import app.cartucho.data.ThemeMode
import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.MediaConstraints
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RendererCommon
import org.webrtc.RtpTransceiver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Sala online, lado do amigo: entra pelo código ou pelo link do convite, assiste ao jogo
 * transmitido em tempo real e controla o jogador que o anfitrião der (1 a 4).
 * Funciona com a tela de toque ou com um joystick conectado.
 */
class RoomGuestActivity : ComponentActivity() {
    private val state = mutableStateOf("Entrando na sala…")
    private val port = mutableStateOf(-1)
    private val layout = mutableStateOf(PadLayout.SNES)
    private val title = mutableStateOf("")
    private val connected = mutableStateOf(false)

    private val myId = Signaling.newId()
    private var code = ""
    private var signaling: Signaling? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var input: DataChannel? = null
    private val egl: EglBase by lazy { EglBase.create() }
    private var renderer: SurfaceViewRenderer? = null
    private var pendingTrack: VideoTrack? = null
    private var audio: AudioTrack? = null
    private var touchMask = 0
    private var padMask = 0
    private var lastSent = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        code = codeFrom(intent) ?: ""
        setContent {
            CartuchoTheme(ThemeMode.DARK) { Screen() }
        }
        if (code.isEmpty()) {
            state.value = "Código da sala inválido."
            return
        }
        join()
    }

    private fun codeFrom(intent: Intent?): String? {
        intent?.getStringExtra(EXTRA_CODE)?.let { return Signaling.normalizeCode(it) }
        val data: Uri = intent?.data ?: return null
        val raw = data.fragment ?: data.lastPathSegment ?: data.getQueryParameter("c") ?: return null
        return Signaling.normalizeCode(raw)
    }

    private fun join() {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(applicationContext).createInitializationOptions())
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()
        val sig = Signaling(code) { msg -> onSignal(msg) }
        signaling = sig
        sig.start()
        // Avisa o anfitrião (repete algumas vezes até receber a resposta).
        val name = android.os.Build.MODEL.take(24)
        Thread {
            repeat(6) {
                if (pc != null) return@Thread
                sig.send(JSONObject().put("t", "join").put("id", myId).put("name", name))
                Thread.sleep(4000)
            }
            if (pc == null) runOnUiThread { state.value = "Ninguém respondeu. Confira o código e se a sala ainda está aberta." }
        }.apply { isDaemon = true }.start()
    }

    private fun onSignal(msg: JSONObject) {
        when (msg.optString("t")) {
            "full" -> if (msg.optString("to") == myId) runOnUiThread { state.value = "A sala está cheia (4 jogadores)." }
            "offer" -> {
                if (msg.optString("to") != myId || pc != null) return
                val sdp = runCatching { Signaling.unpack(msg.optString("sdp")) }.getOrNull() ?: return
                runOnUiThread { state.value = "Conectando ao jogo…" }
                answer(sdp)
            }
        }
    }

    private fun answer(offer: String) {
        val f = factory ?: return
        val config = PeerConnection.RTCConfiguration(RoomHost.ICE_SERVERS).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        val conn = f.createPeerConnection(config, object : PeerObserver() {
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {
                if (state == PeerConnection.IceGatheringState.COMPLETE) {
                    val desc = pc?.localDescription ?: return
                    signaling?.send(JSONObject().put("t", "answer").put("id", myId).put("sdp", Signaling.pack(desc.description)))
                }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {
                runOnUiThread {
                    when (s) {
                        PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> {
                            connected.value = true
                            state.value = ""
                        }
                        PeerConnection.IceConnectionState.FAILED ->
                            state.value = "Não foi possível conectar. A rede de algum dos dois pode estar bloqueando; tentem pelo Wi-Fi."
                        PeerConnection.IceConnectionState.DISCONNECTED, PeerConnection.IceConnectionState.CLOSED -> {
                            connected.value = false
                            state.value = "A transmissão caiu. O anfitrião pode ter fechado a sala."
                        }
                        else -> {}
                    }
                }
            }

            override fun onDataChannel(channel: DataChannel) {
                if (channel.label() == "input") {
                    input = channel
                    channel.registerObserver(textObserver { text -> onHostText(text) })
                } else if (channel.label() == "audio") {
                    channel.registerObserver(object : DataChannel.Observer {
                        override fun onBufferedAmountChange(previous: Long) {}
                        override fun onStateChange() {}
                        override fun onMessage(buffer: DataChannel.Buffer) = playAudio(buffer.data)
                    })
                }
            }

            override fun onTrack(transceiver: RtpTransceiver) {
                val track = transceiver.receiver.track() as? VideoTrack ?: return
                runOnUiThread {
                    val r = renderer
                    if (r != null) track.addSink(r) else pendingTrack = track
                }
            }
        }) ?: return
        pc = conn
        conn.setRemoteDescription(object : SimpleSdp() {
            override fun onSetSuccess() {
                conn.createAnswer(object : SimpleSdp() {
                    override fun onCreateSuccess(desc: SessionDescription) {
                        conn.setLocalDescription(SimpleSdp(), desc)
                    }
                }, MediaConstraints())
            }
        }, SessionDescription(SessionDescription.Type.OFFER, offer))
    }

    private fun onHostText(text: String) {
        val parts = text.split(' ')
        runOnUiThread {
            when (parts.firstOrNull()) {
                "P" -> port.value = parts.getOrNull(1)?.toIntOrNull() ?: -1
                "L" -> layout.value = runCatching { PadLayout.valueOf(parts.getOrNull(1).orEmpty()) }.getOrDefault(PadLayout.SNES)
                "T" -> title.value = text.removePrefix("T ")
            }
        }
    }

    private fun sendButtons() {
        val m = touchMask or padMask
        if (m == lastSent) return
        lastSent = m
        send("B $m")
    }

    private fun send(text: String) {
        val ch = input ?: return
        if (ch.state() != DataChannel.State.OPEN) return
        ch.send(DataChannel.Buffer(ByteBuffer.wrap(text.toByteArray()), false))
    }

    private fun playAudio(data: ByteBuffer) {
        val track = audio ?: run {
            val minBuf = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            @Suppress("DEPRECATION")
            AudioTrack(AudioManager.STREAM_MUSIC, 24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 24000 / 5 * 2), AudioTrack.MODE_STREAM).also { audio = it; it.play() }
        }
        val bytes = ByteArray(data.remaining())
        data.get(bytes)
        val shorts = ShortArray(bytes.size / 2)
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
        track.write(shorts, 0, shorts.size, AudioTrack.WRITE_NON_BLOCKING)
    }

    // Joystick conectado no celular do amigo.
    private val remaps by lazy { RemapStore(this) }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val device = event.device
        val map = device?.let { remaps.load(Gamepads.descriptorOf(it)) }?.takeIf { it.isNotEmpty() } ?: Gamepads.defaultMap
        val bit = map[event.keyCode] ?: dpadBit(event.keyCode)
        if (bit != null && event.keyCode != KeyEvent.KEYCODE_BACK) {
            padMask = if (event.action == KeyEvent.ACTION_DOWN) padMask or (1 shl bit) else padMask and (1 shl bit).inv()
            sendButtons()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.source and android.view.InputDevice.SOURCE_JOYSTICK != 0) {
            send("A 0 ${event.getAxisValue(MotionEvent.AXIS_X)} ${event.getAxisValue(MotionEvent.AXIS_Y)}")
            send("A 1 ${event.getAxisValue(MotionEvent.AXIS_Z)} ${event.getAxisValue(MotionEvent.AXIS_RZ)}")
            val hx = event.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val dirs = (1 shl RetroPad.UP) or (1 shl RetroPad.DOWN) or (1 shl RetroPad.LEFT) or (1 shl RetroPad.RIGHT)
            var m = padMask and dirs.inv()
            if (hy < -0.5f) m = m or (1 shl RetroPad.UP)
            if (hy > 0.5f) m = m or (1 shl RetroPad.DOWN)
            if (hx < -0.5f) m = m or (1 shl RetroPad.LEFT)
            if (hx > 0.5f) m = m or (1 shl RetroPad.RIGHT)
            padMask = m
            sendButtons()
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    private fun dpadBit(code: Int): Int? = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> RetroPad.UP
        KeyEvent.KEYCODE_DPAD_DOWN -> RetroPad.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> RetroPad.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> RetroPad.RIGHT
        else -> null
    }

    @Composable
    private fun Screen() {
        val c = Cartucho.colors
        val msg by state
        val p by port
        val lay by layout
        val name by title
        val portrait = LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
        val store = remember(portrait) { TouchLayoutStore(this, "sala-" + if (portrait) "retrato" else "paisagem") }
        Box(Modifier.fillMaxSize().background(c.background)) {
            Column(Modifier.fillMaxSize()) {
                AndroidView(
                    factory = { ctx ->
                        SurfaceViewRenderer(ctx).also { r ->
                            r.init(egl.eglBaseContext, null)
                            r.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
                            r.setEnableHardwareScaler(true)
                            renderer = r
                            pendingTrack?.addSink(r)
                            pendingTrack = null
                        }
                    },
                    modifier = Modifier.fillMaxWidth().then(if (portrait) Modifier.fillMaxHeight(0.52f) else Modifier.fillMaxHeight()),
                )
            }
            TouchControls(
                layout = lay,
                systemId = "",
                opacity = 0.85f,
                scale = 1f,
                vibration = true,
                onButtons = { m -> touchMask = m; sendButtons() },
                onAnalog = { stick, x, y -> send("A $stick $x $y") },
                onMenu = { finish() },
                layoutStore = store,
            )
            Column(
                Modifier.align(Alignment.TopCenter).safeDrawingPadding().padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    listOfNotNull(
                        name.takeIf { it.isNotEmpty() },
                        if (p >= 0) "Jogador ${p + 1}" else null,
                        "Sala $code",
                    ).joinToString(" · "),
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                )
                if (msg.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    Text(msg, style = Cartucho.type.body, color = c.text)
                    if (!connected.value && msg.startsWith("N")) {
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PrimaryButton("Tentar de novo", { recreate() })
                            SecondaryButton("Sair", { finish() })
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        signaling?.send(JSONObject().put("t", "leave").put("id", myId))
        signaling?.stop()
        runCatching { pc?.close() }
        runCatching { renderer?.release() }
        runCatching { audio?.release() }
        runCatching { factory?.dispose() }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CODE = "code"

        fun open(context: Context, code: String) {
            context.startActivity(Intent(context, RoomGuestActivity::class.java).putExtra(EXTRA_CODE, code))
        }
    }
}

/** Observador de canal de dados que só se importa com mensagens de texto. */
internal fun textObserver(onText: (String) -> Unit) = object : DataChannel.Observer {
    override fun onBufferedAmountChange(previous: Long) {}
    override fun onStateChange() {}
    override fun onMessage(buffer: DataChannel.Buffer) {
        val bytes = ByteArray(buffer.data.remaining())
        buffer.data.get(bytes)
        onText(String(bytes))
    }
}
