package app.cartucho.net

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.concurrent.thread

/**
 * Amigos do Cartucho, sem servidor próprio e sem conta: cada jogador tem um código pessoal secreto
 * (dois "tópicos" no ntfy.sh, o mesmo serviço gratuito das salas, e uma chave pública).
 *
 * - Caixa de entrada: pedidos de amizade, mensagens e convites. As mensagens vão cifradas (AES-GCM) com uma
 *   chave que só os dois amigos calculam (ECDH P-256): quem não é amigo não consegue ler.
 * - Status: online, offline ou "jogando X". Só quem tem o código sabe onde olhar.
 * - Lista de amigos e conversas ficam só no aparelho. O ntfy guarda as mensagens por 12 horas
 *   (quem estiver sem internet recebe quando voltar, dentro desse prazo).
 *
 * Tudo aqui funciona por arquivo, então o processo do jogo também consegue publicar "jogando X" e mandar convites.
 */
object Friends {
    private const val BASE = "https://ntfy.sh"
    private const val CODE_PREFIX = "CTA1."
    const val LINK_PREFIX = "https://cartucho-emulador.netlify.app/amigo#"
    private const val ONLINE_WINDOW_MS = 15L * 60 * 1000
    private const val HEARTBEAT_MS = 10L * 60 * 1000

    data class Me(val name: String, val inbox: String, val status: String, val pub: String, val priv: String)
    data class Presence(val online: Boolean, val game: String, val system: String, val ts: Long, val watchable: Boolean)
    data class Friend(val name: String, val inbox: String, val status: String, val pub: String, val addedAt: Long, val presence: Presence? = null, val unread: Int = 0)
    data class ChatMsg(val id: String, val fromMe: Boolean, val kind: String, val text: String, val ts: Long, val room: String = "", val game: String = "")
    data class FriendRequest(val name: String, val code: String, val ts: Long)

    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(0, TimeUnit.SECONDS).build()
    private val rnd = SecureRandom()

    private val _friends = MutableStateFlow<List<Friend>>(emptyList())
    val friends: StateFlow<List<Friend>> = _friends.asStateFlow()
    private val _requests = MutableStateFlow<List<FriendRequest>>(emptyList())
    val requests: StateFlow<List<FriendRequest>> = _requests.asStateFlow()
    private val _chatVersion = MutableStateFlow(0)
    /** Muda quando chega ou sai mensagem (a tela de conversa relê o arquivo). */
    val chatVersion: StateFlow<Int> = _chatVersion.asStateFlow()

    @Volatile private var call: Call? = null
    @Volatile private var running = false
    private var heartbeat: Thread? = null
    private val seen = LinkedHashSet<String>()

    // ------------------------------------------------------------------ arquivos

    private fun dir(c: Context) = File(c.filesDir, "amigos").apply { mkdirs() }
    private fun meFile(c: Context) = File(dir(c), "eu.json")
    private fun friendsFile(c: Context) = File(dir(c), "amigos.json")
    private fun requestsFile(c: Context) = File(dir(c), "pedidos.json")
    private fun chatFile(c: Context, inbox: String) = File(dir(c), "conversa-$inbox.json")
    private fun inviteFile(c: Context) = File(dir(c), "convite.json")

    private fun writeAtomic(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        tmp.renameTo(f)
    }

    private fun randomId(n: Int = 20): String {
        val a = "abcdefghijklmnopqrstuvwxyz0123456789"
        return (1..n).map { a[rnd.nextInt(a.length)] }.joinToString("")
    }
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)

    /** Já abriu Amigos alguma vez (tem código)? Sem isso o app não publica nada. */
    fun hasIdentity(c: Context): Boolean = meFile(c).exists()

    /** Quem sou eu (cria na primeira vez). O nome acompanha o perfil do app. */
    @Synchronized
    fun me(c: Context, name: String? = null): Me {
        val f = meFile(c)
        val current = runCatching {
            val o = JSONObject(f.readText())
            Me(o.getString("n"), o.getString("i"), o.getString("s"), o.getString("k"), o.getString("p"))
        }.getOrNull()
        if (current != null) {
            if (name != null && name.isNotBlank() && name != current.name) {
                val upd = current.copy(name = name.take(40))
                saveMe(c, upd)
                return upd
            }
            return current
        }
        val kpg = KeyPairGenerator.getInstance("EC")
        kpg.initialize(ECGenParameterSpec("secp256r1"))
        val kp = kpg.generateKeyPair()
        val m = Me(
            name = (name?.takeIf { it.isNotBlank() } ?: "Jogador").take(40),
            inbox = "cartucho-a-" + randomId(),
            status = "cartucho-s-" + randomId(),
            pub = b64(kp.public.encoded),
            priv = b64(kp.private.encoded),
        )
        saveMe(c, m)
        return m
    }

    private fun saveMe(c: Context, m: Me) = writeAtomic(
        meFile(c),
        JSONObject().put("n", m.name).put("i", m.inbox).put("s", m.status).put("k", m.pub).put("p", m.priv).toString(),
    )

    /** Código para mandar aos amigos (texto ou QR). Contém só dados públicos. */
    fun myCode(c: Context, name: String? = null): String {
        val m = me(c, name)
        val o = JSONObject().put("n", m.name).put("i", m.inbox).put("s", m.status).put("k", m.pub)
        return LINK_PREFIX + CODE_PREFIX + b64(o.toString().toByteArray())
    }

    private fun parseCode(text: String): Friend? {
        val t = text.trim()
        val start = t.indexOf(CODE_PREFIX)
        if (start < 0) return null
        val raw = t.substring(start + CODE_PREFIX.length).takeWhile { it.isLetterOrDigit() || it == '-' || it == '_' }
        return runCatching {
            val o = JSONObject(String(unb64(raw)))
            val inbox = o.getString("i")
            val status = o.getString("s")
            require(inbox.startsWith("cartucho-a-") && status.startsWith("cartucho-s-"))
            Friend(o.optString("n", "Amigo").take(40), inbox, status, o.getString("k"), System.currentTimeMillis())
        }.getOrNull()
    }

    fun loadFriends(c: Context): List<Friend> = runCatching {
        val arr = JSONArray(friendsFile(c).readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val p = o.optJSONObject("pr")?.let { Presence(it.optBoolean("on"), it.optString("g"), it.optString("s"), it.optLong("ts"), it.optBoolean("w")) }
            Friend(o.getString("n"), o.getString("i"), o.getString("s"), o.getString("k"), o.optLong("a"), p, o.optInt("u"))
        }
    }.getOrDefault(emptyList())

    @Synchronized
    private fun saveFriends(c: Context, list: List<Friend>) {
        val arr = JSONArray()
        for (f in list) {
            val o = JSONObject().put("n", f.name).put("i", f.inbox).put("s", f.status).put("k", f.pub).put("a", f.addedAt).put("u", f.unread)
            f.presence?.let { p -> o.put("pr", JSONObject().put("on", p.online).put("g", p.game).put("s", p.system).put("ts", p.ts).put("w", p.watchable)) }
            arr.put(o)
        }
        writeAtomic(friendsFile(c), arr.toString())
        _friends.value = list
    }

    private fun loadRequests(c: Context): List<FriendRequest> = runCatching {
        val arr = JSONArray(requestsFile(c).readText())
        (0 until arr.length()).map { arr.getJSONObject(it) }.map { FriendRequest(it.getString("n"), it.getString("c"), it.optLong("ts")) }
    }.getOrDefault(emptyList())

    private fun saveRequests(c: Context, list: List<FriendRequest>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("n", it.name).put("c", it.code).put("ts", it.ts)) }
        writeAtomic(requestsFile(c), arr.toString())
        _requests.value = list
    }

    fun loadChat(c: Context, inbox: String): List<ChatMsg> = runCatching {
        val arr = JSONArray(chatFile(c, inbox).readText())
        (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            ChatMsg(it.getString("id"), it.optBoolean("me"), it.optString("k", "text"), it.optString("x"), it.optLong("ts"), it.optString("r"), it.optString("g"))
        }
    }.getOrDefault(emptyList())

    @Synchronized
    private fun appendChat(c: Context, inbox: String, m: ChatMsg) {
        val list = loadChat(c, inbox)
        if (list.any { it.id == m.id }) return
        val arr = JSONArray()
        (list + m).takeLast(400).forEach {
            arr.put(JSONObject().put("id", it.id).put("me", it.fromMe).put("k", it.kind).put("x", it.text).put("ts", it.ts).put("r", it.room).put("g", it.game))
        }
        writeAtomic(chatFile(c, inbox), arr.toString())
        _chatVersion.value = _chatVersion.value + 1
    }

    // ------------------------------------------------------------------ criptografia

    private fun pairKey(c: Context, friendPub: String): SecretKeySpec {
        val m = me(c)
        val kf = KeyFactory.getInstance("EC")
        val priv = kf.generatePrivate(PKCS8EncodedKeySpec(unb64(m.priv)))
        val pub = kf.generatePublic(X509EncodedKeySpec(unb64(friendPub)))
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(priv)
        ka.doPhase(pub, true)
        val secret = MessageDigest.getInstance("SHA-256").digest(ka.generateSecret() + "cartucho-amigos-v1".toByteArray())
        return SecretKeySpec(secret, "AES")
    }

    private fun encrypt(c: Context, friendPub: String, plain: String): Pair<String, String> {
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, pairKey(c, friendPub), GCMParameterSpec(128, iv))
        return b64(iv) to b64(cipher.doFinal(plain.toByteArray()))
    }

    private fun decrypt(c: Context, friendPub: String, iv: String, ct: String): String? = runCatching {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, pairKey(c, friendPub), GCMParameterSpec(128, unb64(iv)))
        String(cipher.doFinal(unb64(ct)))
    }.getOrNull()

    // ------------------------------------------------------------------ envio

    private fun publish(topic: String, body: String): Boolean {
        val req = Request.Builder().url("$BASE/$topic").post(body.toRequestBody("text/plain; charset=utf-8".toMediaType())).build()
        return runCatching { http.newCall(req).execute().use { it.isSuccessful } }.getOrDefault(false)
    }

    private fun async(block: () -> Unit) { thread(name = "amigos", isDaemon = true) { runCatching(block) } }

    /** Adiciona pelo código (texto ou link) e manda o pedido de amizade. Retorna o nome, ou null se o código não vale. */
    fun addByCode(c: Context, text: String): String? {
        val f = parseCode(text) ?: return null
        val m = me(c)
        if (f.inbox == m.inbox) return null
        val list = loadFriends(c)
        if (list.none { it.inbox == f.inbox }) saveFriends(c, list + f)
        val myCode = myCode(c)
        async { publish(f.inbox, JSONObject().put("t", "req").put("c", myCode).toString()) }
        restartListening(c)
        return f.name
    }

    /** Aceita um pedido: vira amigo e avisa (cifrado) que aceitou. */
    fun accept(c: Context, r: FriendRequest) {
        val f = parseCode(r.code) ?: return
        val list = loadFriends(c)
        if (list.none { it.inbox == f.inbox }) saveFriends(c, list + f)
        saveRequests(c, loadRequests(c).filter { it.code != r.code })
        sendKind(c, f.inbox, "accept", "")
        restartListening(c)
    }

    fun decline(c: Context, r: FriendRequest) = saveRequests(c, loadRequests(c).filter { it.code != r.code })

    fun remove(c: Context, inbox: String) {
        saveFriends(c, loadFriends(c).filter { it.inbox != inbox })
        chatFile(c, inbox).delete()
        restartListening(c)
    }

    fun sendText(c: Context, inbox: String, text: String) = sendKind(c, inbox, "text", text.take(1000))

    fun sendInvite(c: Context, inbox: String, room: String, game: String) = sendKind(c, inbox, "invite", "", room, game)

    private fun sendKind(c: Context, inbox: String, kind: String, text: String, room: String = "", game: String = "") {
        val f = loadFriends(c).firstOrNull { it.inbox == inbox } ?: return
        val id = randomId(12)
        val now = System.currentTimeMillis()
        if (kind != "accept") appendChat(c, inbox, ChatMsg(id, true, kind, text, now, room, game))
        val m = me(c)
        val payload = JSONObject().put("id", id).put("k", kind).put("x", text).put("r", room).put("g", game).put("ts", now).put("n", m.name).toString()
        async {
            val (iv, ct) = encrypt(c, f.pub, payload)
            publish(f.inbox, JSONObject().put("t", "msg").put("f", m.inbox).put("iv", iv).put("ct", ct).toString())
        }
    }

    /** Status para os amigos: online/offline e o jogo aberto. Chamado pela tela principal e pelo jogo. */
    fun publishStatus(c: Context, online: Boolean, game: String = "", system: String = "", watchable: Boolean = false) {
        if (!meFile(c).exists()) return  // quem nunca abriu Amigos não publica nada
        val m = me(c)
        val body = JSONObject().put("t", "st").put("n", m.name).put("on", online).put("g", game).put("s", system)
            .put("w", watchable).put("ts", System.currentTimeMillis()).toString()
        async { publish(m.status, body) }
    }

    /** Convite pendente: quem cria a sala pela conversa com um amigo recebe o código automático. */
    fun setPendingInvite(c: Context, inbox: String, game: String) =
        writeAtomic(inviteFile(c), JSONObject().put("i", inbox).put("g", game).put("ts", System.currentTimeMillis()).toString())

    /** Chamado pela sala (processo do jogo) quando o código fica pronto. */
    fun deliverPendingInvite(c: Context, room: String) {
        val f = inviteFile(c)
        val o = runCatching { JSONObject(f.readText()) }.getOrNull() ?: return
        f.delete()
        if (System.currentTimeMillis() - o.optLong("ts") > 10 * 60 * 1000) return
        sendInvite(c, o.getString("i"), room, o.optString("g"))
    }

    fun markRead(c: Context, inbox: String) {
        val list = loadFriends(c)
        if (list.any { it.inbox == inbox && it.unread > 0 }) saveFriends(c, list.map { if (it.inbox == inbox) it.copy(unread = 0) else it })
    }

    /** Online de verdade: o último aviso diz online e é recente. */
    fun isOnline(p: Presence?): Boolean = p != null && p.online && System.currentTimeMillis() - p.ts < ONLINE_WINDOW_MS

    // ------------------------------------------------------------------ escuta

    /** Começa a ouvir a caixa de entrada e o status dos amigos (enquanto o app está aberto). */
    @Synchronized
    fun start(c: Context, myName: String) {
        val app = c.applicationContext
        me(app, myName)
        _friends.value = loadFriends(app)
        _requests.value = loadRequests(app)
        if (running) return
        running = true
        publishStatus(app, online = true)
        heartbeat = thread(name = "amigos-status", isDaemon = true) {
            while (running) {
                try { Thread.sleep(HEARTBEAT_MS) } catch (_: InterruptedException) { break }
                if (running) publishStatus(app, online = true)
            }
        }
        listen(app)
    }

    @Synchronized
    fun stop(c: Context, publishOffline: Boolean = true) {
        if (!running) return
        running = false
        heartbeat?.interrupt()
        runCatching { call?.cancel() }
        if (publishOffline) publishStatus(c.applicationContext, online = false)
    }

    private fun restartListening(c: Context) {
        if (!running) return
        runCatching { call?.cancel() }  // o laço reconecta com a lista nova de tópicos
    }

    private fun listen(app: Context) {
        thread(name = "amigos-escuta", isDaemon = true) {
            var backoff = 2000L
            var since = "12h"
            while (running) {
                val topics = (listOf(me(app).inbox) + loadFriends(app).map { it.status }).distinct().joinToString(",")
                val req = Request.Builder().url("$BASE/$topics/json?since=$since").build()
                val c = http.newCall(req)
                call = c
                val ok = runCatching {
                    c.execute().use { resp ->
                        if (!resp.isSuccessful) error("http ${resp.code}")
                        backoff = 2000L
                        val src = resp.body?.source() ?: return@use
                        while (running) {
                            val line = src.readUtf8Line() ?: break
                            val o = runCatching { JSONObject(line) }.getOrNull() ?: continue
                            if (o.optString("event") != "message") continue
                            since = o.optLong("time").toString()
                            val id = o.optString("id")
                            if (!seen.add(id)) continue
                            if (seen.size > 600) seen.remove(seen.first())
                            handle(app, o.optString("topic"), o.optString("message"))
                        }
                    }
                }.isSuccess
                if (!running) break
                if (!ok) {
                    try { Thread.sleep(backoff) } catch (_: InterruptedException) {}
                    backoff = (backoff * 2).coerceAtMost(60_000L)
                }
            }
        }
    }

    private fun handle(app: Context, topic: String, message: String) {
        val o = runCatching { JSONObject(message) }.getOrNull() ?: return
        val m = me(app)
        when {
            topic == m.inbox && o.optString("t") == "req" -> {
                val code = o.optString("c")
                val f = parseCode(code) ?: return
                val friends = loadFriends(app)
                if (friends.any { it.inbox == f.inbox }) return  // já é amigo (os dois se adicionaram)
                val reqs = loadRequests(app)
                if (reqs.none { it.code == code }) saveRequests(app, reqs + FriendRequest(f.name, code, System.currentTimeMillis()))
            }
            topic == m.inbox && o.optString("t") == "msg" -> {
                val from = o.optString("f")
                val friend = loadFriends(app).firstOrNull { it.inbox == from } ?: return  // só de amigos
                val plain = decrypt(app, friend.pub, o.optString("iv"), o.optString("ct")) ?: return
                val p = JSONObject(plain)
                val kind = p.optString("k", "text")
                val name = p.optString("n").takeIf { it.isNotBlank() }
                if (kind != "accept") {
                    appendChat(app, from, ChatMsg(p.optString("id"), false, kind, p.optString("x"), p.optLong("ts"), p.optString("r"), p.optString("g")))
                }
                saveFriends(app, loadFriends(app).map {
                    if (it.inbox == from) it.copy(name = name ?: it.name, unread = if (kind == "accept") it.unread else it.unread + 1) else it
                })
            }
            o.optString("t") == "st" -> {
                val list = loadFriends(app)
                val f = list.firstOrNull { it.status == topic } ?: return
                val p = Presence(o.optBoolean("on"), o.optString("g"), o.optString("s"), o.optLong("ts"), o.optBoolean("w"))
                if ((f.presence?.ts ?: 0) > p.ts) return
                val name = o.optString("n").takeIf { it.isNotBlank() } ?: f.name
                saveFriends(app, list.map { if (it.status == topic) it.copy(presence = p, name = name) else it })
            }
        }
    }
}
