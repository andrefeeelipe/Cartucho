package app.cartucho.net

import android.net.Uri
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import kotlin.concurrent.thread

/**
 * Controle pelo navegador: um servidor HTTP + WebSocket mínimo no próprio celular, na rede Wi-Fi
 * (ou no roteador do celular). O amigo lê o QR, abre a página e vira o jogador 2, 3 ou 4 — sem instalar nada.
 * Mensagens do navegador: "B <botões>" (bitmask RetroPad), "A <alavanca> <x> <y>" (−1..1), "N <nome>".
 */
class RemotePadServer(
    private val onButtons: (port: Int, mask: Int) -> Unit,
    private val onAnalog: (port: Int, stick: Int, x: Float, y: Float) -> Unit,
) {
    data class Player(val id: Int, val port: Int, val name: String)

    val players = mutableStateListOf<Player>()
    val url = mutableStateOf<String?>(null)
    val error = mutableStateOf<String?>(null)

    /** Código da sala online aberta junto (quem tem o app entra nela pelo mesmo QR). */
    @Volatile var roomCode: String? = null
    /** Jogadores já ocupados por quem entrou pela sala online. */
    @Volatile var takenPorts: () -> Set<Int> = { emptySet() }
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    /** Endereço do QR: quem tem o Cartucho cai na sala; quem não tem, no controle pelo navegador. */
    fun qrUrl(): String? {
        val base = url.value ?: return null
        val code = roomCode ?: return base
        return "${base}j?s=$code"
    }

    @Volatile private var server: ServerSocket? = null
    private val clients = HashMap<Int, Socket>()
    private val portOf = HashMap<Int, Int>()

    /** Jogadores ocupados por quem está no navegador. */
    fun usedPorts(): Set<Int> = synchronized(clients) { portOf.values.toSet() }
    private var nextId = 1

    /** Com o Wi-Fi do Cartucho ligado, o endereço mostrado é o dessa rede. */
    @Volatile var preferHotspot = false

    /** Recalcula o endereço (por exemplo, depois de ligar o Wi-Fi do Cartucho). */
    fun refreshUrl() {
        val s = server ?: return start()
        val ip = localIp(preferHotspot) ?: return
        url.value = "http://$ip:${s.localPort}/"
        error.value = null
    }

    fun start() {
        if (server != null) return
        val ip = localIp(preferHotspot)
        if (ip == null) {
            error.value = "Conecte o celular a um Wi-Fi (ou ligue o roteador do celular) para os amigos entrarem."
            return
        }
        val socket = runCatching { ServerSocket(PORT) }.recoverCatching { ServerSocket(0) }.getOrElse {
            error.value = "Não foi possível abrir o controle pelo navegador."
            return
        }
        server = socket
        error.value = null
        url.value = "http://$ip:${socket.localPort}/"
        thread(name = "remote-pad", isDaemon = true) {
            while (!socket.isClosed) {
                val client = runCatching { socket.accept() }.getOrNull() ?: break
                thread(isDaemon = true) { runCatching { handle(client) }; runCatching { client.close() } }
            }
        }
    }

    fun stop() {
        runCatching { server?.close() }
        server = null
        synchronized(clients) { clients.values.forEach { runCatching { it.close() } }; clients.clear(); portOf.clear() }
        for (p in players.toList()) onButtons(p.port, 0)
        players.clear()
        url.value = null
    }

    /** Troca o jogador de um amigo (ex.: passar para o jogador 1). */
    fun setPort(id: Int, port: Int) {
        val i = players.indexOfFirst { it.id == id }
        if (i < 0) return
        onButtons(players[i].port, 0)
        players[i] = players[i].copy(port = port)
        synchronized(clients) { portOf[id] = port }
    }

    private fun handle(socket: Socket) {
        socket.tcpNoDelay = true
        val input = BufferedInputStream(socket.getInputStream())
        val out = socket.getOutputStream()
        val headers = readHeaders(input) ?: return
        val path = headers["_path"].orEmpty()
        val key = headers["sec-websocket-key"]
        if (key != null && path.startsWith("/ws")) {
            webSocket(socket, input, out, key)
            return
        }
        if (path.startsWith("/j")) {
            val code = Signaling.normalizeCode(path.substringAfter("s=", "").take(12)) ?: roomCode
            val android = headers["user-agent"].orEmpty().contains("Android", true)
            if (code != null && android) {
                // Abre o Cartucho direto na sala; sem o app instalado, o Chrome cai no controle pelo navegador.
                val host = headers["host"] ?: url.value?.removePrefix("http://")?.trimEnd('/') ?: ""
                val fallback = Uri.encode("http://$host/")
                val intent = "intent://sala/$code#Intent;scheme=cartucho;package=app.cartucho;S.browser_fallback_url=$fallback;end"
                out.write("HTTP/1.1 302 Found\r\nLocation: $intent\r\nCache-Control: no-store\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                out.flush()
                return
            }
        }
        val body = if (path == "/" || path.startsWith("/?") || path.startsWith("/j")) CONTROLLER_HTML.toByteArray() else "Não encontrado".toByteArray()
        val status = if (body.size > 20) "200 OK" else "404 Not Found"
        out.write(
            ("HTTP/1.1 $status\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${body.size}\r\n" +
                "Cache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray(),
        )
        out.write(body)
        out.flush()
    }

    private fun webSocket(socket: Socket, input: InputStream, out: OutputStream, key: String) {
        val accept = Base64.encodeToString(
            MessageDigest.getInstance("SHA-1").digest((key.trim() + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray()),
            Base64.NO_WRAP,
        )
        out.write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: $accept\r\n\r\n".toByteArray())
        out.flush()

        val id: Int
        val port: Int
        synchronized(clients) {
            val used = portOf.values.toSet() + takenPorts()
            val free = (1..3).firstOrNull { it !in used }
            if (free == null) {
                sendText(out, "F")
                return
            }
            id = nextId++
            port = free
            clients[id] = socket
            portOf[id] = free
        }
        onMain { players.add(Player(id, port, "Amigo $id")) }
        sendText(out, "P ${port + 1}")
        try {
            while (true) {
                val msg = readFrame(input) ?: break
                val current = players.firstOrNull { it.id == id } ?: break
                val parts = msg.split(' ')
                when (parts.firstOrNull()) {
                    "B" -> parts.getOrNull(1)?.toIntOrNull()?.let { onButtons(current.port, it) }
                    "A" -> if (parts.size >= 4) onAnalog(current.port, parts[1].toIntOrNull() ?: 0, parts[2].toFloatOrNull() ?: 0f, parts[3].toFloatOrNull() ?: 0f)
                    "N" -> {
                        val name = msg.removePrefix("N ").take(20).ifBlank { current.name }
                        onMain {
                            val i = players.indexOfFirst { it.id == id }
                            if (i >= 0) players[i] = players[i].copy(name = name)
                        }
                    }
                }
            }
        } finally {
            players.firstOrNull { it.id == id }?.let { onButtons(it.port, 0); onAnalog(it.port, 0, 0f, 0f) }
            onMain { players.removeAll { it.id == id } }
            synchronized(clients) { clients.remove(id); portOf.remove(id) }
        }
    }

    private fun onMain(block: () -> Unit) {
        main.post { runCatching(block) }
    }

    private fun readHeaders(input: InputStream): Map<String, String>? {
        val sb = StringBuilder()
        var last4 = 0
        while (true) {
            val b = input.read()
            if (b < 0) return null
            sb.append(b.toChar())
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) break
            if (sb.length > 16384) return null
        }
        val lines = sb.split("\r\n")
        val map = HashMap<String, String>()
        map["_path"] = lines.firstOrNull()?.split(' ')?.getOrNull(1).orEmpty()
        for (l in lines.drop(1)) {
            val i = l.indexOf(':')
            if (i > 0) map[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim()
        }
        return map
    }

    /** Lê um quadro de texto do navegador (sempre mascarado). Retorna null ao fechar. */
    private fun readFrame(input: InputStream): String? {
        while (true) {
            val b0 = input.read()
            val b1 = input.read()
            if (b0 < 0 || b1 < 0) return null
            val opcode = b0 and 0x0F
            var len = (b1 and 0x7F).toLong()
            if (len == 126L) len = ((input.read() shl 8) or input.read()).toLong()
            else if (len == 127L) { len = 0; repeat(8) { len = (len shl 8) or input.read().toLong() } }
            val mask = ByteArray(4)
            if (b1 and 0x80 != 0) for (i in 0..3) mask[i] = input.read().toByte()
            if (len > 4096) return null
            val data = ByteArray(len.toInt())
            var read = 0
            while (read < data.size) {
                val n = input.read(data, read, data.size - read)
                if (n < 0) return null
                read += n
            }
            for (i in data.indices) data[i] = (data[i].toInt() xor mask[i % 4].toInt()).toByte()
            when (opcode) {
                0x8 -> return null
                0x1 -> return String(data)
                else -> continue  // ping/pong/binário: ignora
            }
        }
    }

    private fun sendText(out: OutputStream, text: String) {
        val data = text.toByteArray()
        synchronized(out) {
            out.write(0x81)
            out.write(data.size)
            out.write(data)
            out.flush()
        }
    }

    companion object {
        const val PORT = 8765

        /** IP do celular na rede local (Wi-Fi ou roteador do celular). */
        fun localIp(preferHotspot: Boolean = false): String? {
            val candidates = runCatching { NetworkInterface.getNetworkInterfaces().toList() }.getOrDefault(emptyList())
                .filter { runCatching { it.isUp && !it.isLoopback }.getOrDefault(false) }
                .flatMap { nif -> nif.inetAddresses.toList().filterIsInstance<Inet4Address>().map { nif.name to it } }
                .filter { it.second.isSiteLocalAddress }
            if (preferHotspot) {
                // Ponto de acesso do próprio celular: interfaces "ap0", "swlan0", "softap0", "wlan1"… e o IP termina em .1.
                candidates.firstOrNull { (n, ip) ->
                    (n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap") || n == "wlan1" || n == "wlan2") && ip.hostAddress.orEmpty().endsWith(".1")
                }?.let { return it.second.hostAddress }
                candidates.firstOrNull { (n, _) -> n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap") }?.let { return it.second.hostAddress }
            }
            val preferred = candidates.firstOrNull { (n, _) -> n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("eth") }
            return (preferred ?: candidates.firstOrNull())?.second?.hostAddress
        }

        /** Página do controle (sem dependências, funciona em qualquer navegador de celular). */
        private val CONTROLLER_HTML = """
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#111111"><title>Cartucho · Controle</title>
<style>
*{box-sizing:border-box;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}
html,body{margin:0;height:100%;background:#111;color:#f2f2f0;font:15px -apple-system,system-ui,sans-serif;overflow:hidden;touch-action:none}
#top{position:fixed;top:0;left:0;right:0;display:flex;justify-content:space-between;align-items:center;padding:calc(10px + env(safe-area-inset-top)) 18px 10px}
#who{font-weight:600}#st{color:#8a8a86;font-size:13px}
.b{position:absolute;display:flex;align-items:center;justify-content:center;background:#222;border:1px solid rgba(255,255,255,.08);color:#d6d6d2;font-weight:600}
.b.on{background:#3a3a3a;color:#fff}
.r{border-radius:50%}.p{border-radius:999px;font-size:13px}
#pad{position:absolute;left:6vmin;bottom:12vmin;width:42vmin;height:42vmin}
#pad .b{width:14vmin;height:14vmin;border-radius:12px}
#faces{position:absolute;right:6vmin;bottom:12vmin;width:42vmin;height:42vmin}
#faces .b{width:15vmin;height:15vmin;font-size:5vmin}
#rot{display:none;position:fixed;inset:0;background:#111;align-items:center;justify-content:center;text-align:center;padding:24px;color:#8a8a86}
@media (orientation:portrait){#rot{display:flex}}
</style></head><body>
<div id="top"><span id="who">Conectando…</span><span id="st">Cartucho</span></div>
<div class="b p" data-b="10" style="left:6vmin;top:calc(48px + env(safe-area-inset-top));width:22vmin;height:9vmin">L</div>
<div class="b p" data-b="12" style="left:30vmin;top:calc(48px + env(safe-area-inset-top));width:16vmin;height:9vmin">L2</div>
<div class="b p" data-b="13" style="right:30vmin;top:calc(48px + env(safe-area-inset-top));width:16vmin;height:9vmin">R2</div>
<div class="b p" data-b="11" style="right:6vmin;top:calc(48px + env(safe-area-inset-top));width:22vmin;height:9vmin">R</div>
<div id="pad">
 <div class="b" data-b="4" style="left:14vmin;top:0"></div>
 <div class="b" data-b="5" style="left:14vmin;top:28vmin"></div>
 <div class="b" data-b="6" style="left:0;top:14vmin"></div>
 <div class="b" data-b="7" style="left:28vmin;top:14vmin"></div>
</div>
<div class="b p" data-b="2" style="left:50%;margin-left:-23vmin;bottom:6vmin;width:20vmin;height:8vmin">Select</div>
<div class="b p" data-b="3" style="left:50%;margin-left:3vmin;bottom:6vmin;width:20vmin;height:8vmin">Start</div>
<div id="faces">
 <div class="b r" data-b="9" style="left:13.5vmin;top:0">X</div>
 <div class="b r" data-b="1" style="left:0;top:13.5vmin">Y</div>
 <div class="b r" data-b="8" style="left:27vmin;top:13.5vmin">A</div>
 <div class="b r" data-b="0" style="left:13.5vmin;top:27vmin">B</div>
</div>
<div id="rot">Vire o celular na horizontal para jogar.</div>
<script>
var ws,mask=0,touches={},els=[].slice.call(document.querySelectorAll('[data-b]'));
function connect(){ws=new WebSocket('ws://'+location.host+'/ws');
 ws.onmessage=function(e){var m=e.data;if(m[0]=='P'){document.getElementById('who').textContent='Jogador '+m.slice(2);document.getElementById('st').textContent='Conectado'}
  else if(m=='F'){document.getElementById('who').textContent='Sala cheia'}};
 ws.onclose=function(){document.getElementById('st').textContent='Reconectando…';setTimeout(connect,1500)};}
connect();
function hit(x,y){for(var i=0;i<els.length;i++){var r=els[i].getBoundingClientRect(),p=10;if(x>=r.left-p&&x<=r.right+p&&y>=r.top-p&&y<=r.bottom+p)return els[i]}return null}
function update(){var m=0;for(var k in touches){var el=touches[k];if(el)m|=1<<(+el.dataset.b)}
 els.forEach(function(el){el.classList.toggle('on',!!(m&(1<<(+el.dataset.b))))});
 if(m!==mask){if((m&~mask)&&navigator.vibrate)navigator.vibrate(8);mask=m;if(ws&&ws.readyState==1)ws.send('B '+m)}}
function onT(e){e.preventDefault();touches={};for(var i=0;i<e.touches.length;i++){var t=e.touches[i];touches[t.identifier]=hit(t.clientX,t.clientY)}update()}
['touchstart','touchmove','touchend','touchcancel'].forEach(function(n){document.addEventListener(n,onT,{passive:false})});
document.addEventListener('mousedown',function(e){touches={m:hit(e.clientX,e.clientY)};update()});
document.addEventListener('mouseup',function(){touches={};update()});
</script></body></html>
"""
    }
}
