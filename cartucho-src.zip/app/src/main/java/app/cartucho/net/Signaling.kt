package app.cartucho.net

import android.util.Base64
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlin.concurrent.thread

/**
 * "Ponto de encontro" da sala online: os celulares trocam as mensagens de conexão (WebRTC)
 * por um tópico público e gratuito do ntfy.sh, identificado pelo código da sala.
 * Depois de conectados, vídeo e controles vão direto de um celular para o outro.
 */
class Signaling(
    private val code: String,
    private val onState: (connected: Boolean) -> Unit = {},
    private val onMessage: (JSONObject) -> Unit,
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()
    @Volatile private var call: Call? = null
    @Volatile private var running = false
    private val topic = "cartucho-sala-" + code.lowercase()

    fun start() {
        running = true
        val since = System.currentTimeMillis() / 1000 - 5
        thread(name = "signaling", isDaemon = true) {
            var backoff = 1000L
            while (running) {
                val req = Request.Builder().url("$BASE/$topic/json?since=$since").build()
                val c = http.newCall(req)
                call = c
                runCatching {
                    c.execute().use { resp ->
                        if (!resp.isSuccessful) throw java.io.IOException("ntfy ${resp.code}")
                        val source = resp.body?.source() ?: return@use
                        backoff = 1000L
                        runCatching { onState(true) }
                        while (running) {
                            val line = source.readUtf8Line() ?: break
                            val o = runCatching { JSONObject(line) }.getOrNull() ?: continue
                            if (o.optString("event") != "message") continue
                            // Mensagens grandes o ntfy guarda como anexo.
                            val text = o.optJSONObject("attachment")?.optString("url")?.takeIf { it.isNotEmpty() }
                                ?.let { url -> runCatching { http.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string() } }.getOrNull() }
                                ?: o.optString("message")
                            val msg = runCatching { JSONObject(text) }.getOrNull() ?: continue
                            deliver(msg)
                        }
                    }
                }.onFailure { if (running) runCatching { onState(false) } }
                if (running) Thread.sleep(backoff).also { backoff = (backoff * 2).coerceAtMost(15000) }
            }
        }
    }

    private val parts = HashMap<String, Array<String?>>()

    /** Junta mensagens que vieram em pedaços (o ntfy aceita até 4 KB por mensagem). */
    private fun deliver(msg: JSONObject) {
        if (msg.optString("t") != "part") {
            runCatching { onMessage(msg) }
            return
        }
        val key = msg.optString("k")
        val n = msg.optInt("n").coerceIn(1, 32)
        val i = msg.optInt("i")
        if (key.isEmpty() || i !in 0 until n) return
        val full = synchronized(parts) {
            val arr = parts.getOrPut(key) { arrayOfNulls(n) }
            if (arr.size != n) return
            arr[i] = msg.optString("d")
            if (arr.any { it == null }) null else arr.joinToString("").also { parts.remove(key) }
        } ?: return
        runCatching { JSONObject(full) }.getOrNull()?.let { runCatching { onMessage(it) } }
    }

    fun send(msg: JSONObject) {
        val text = msg.toString()
        val chunks = if (text.length <= 3500) listOf(text) else {
            val key = newId()
            val pieces = text.chunked(3000)
            pieces.mapIndexed { i, d -> JSONObject().put("t", "part").put("k", key).put("i", i).put("n", pieces.size).put("d", d).toString() }
        }
        thread(isDaemon = true) {
            for (body in chunks) {
                val req = Request.Builder().url("$BASE/$topic")
                    .post(body.toRequestBody("text/plain; charset=utf-8".toMediaType()))
                    .build()
                // Uma nova tentativa se a rede falhar.
                val ok = runCatching { http.newCall(req).execute().use { it.isSuccessful } }.getOrDefault(false)
                if (!ok) runCatching { Thread.sleep(1500); http.newCall(req).execute().close() }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { call?.cancel() }
    }

    companion object {
        private const val BASE = "https://ntfy.sh"
        private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

        fun newCode(): String {
            val r = SecureRandom()
            return (1..6).map { ALPHABET[r.nextInt(ALPHABET.length)] }.joinToString("")
        }

        /** Acha o código da sala num texto lido do QR (link do convite, do Wi-Fi ou o código puro). */
        fun codeFromText(text: String): String? {
            val t = text.trim()
            Regex("[?&#]s=([A-Za-z0-9]{6})").find(t)?.let { return normalizeCode(it.groupValues[1]) }
            Regex("sala(?:\\.html)?[/#]([A-Za-z0-9]{6})").find(t)?.let { return normalizeCode(it.groupValues[1]) }
            Regex("#([A-Za-z0-9]{6})$").find(t)?.let { return normalizeCode(it.groupValues[1]) }
            return if (t.length <= 8) normalizeCode(t) else null
        }

        fun normalizeCode(text: String): String? {
            val c = text.trim().uppercase().filter { it in ALPHABET }
            return c.takeIf { it.length == 6 }
        }

        fun newId(): String = (1..8).map { ALPHABET[SecureRandom().nextInt(ALPHABET.length)] }.joinToString("")

        fun inviteLink(code: String) = "https://andrefeeelipe.github.io/Cartucho/sala.html#$code"

        /** SDP compactado (cabe numa mensagem do ntfy). */
        fun pack(sdp: String): String {
            val bos = ByteArrayOutputStream()
            GZIPOutputStream(bos).use { it.write(sdp.toByteArray()) }
            return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        }

        fun unpack(data: String): String =
            GZIPInputStream(ByteArrayInputStream(Base64.decode(data, Base64.NO_WRAP))).use { String(it.readBytes()) }
    }
}
