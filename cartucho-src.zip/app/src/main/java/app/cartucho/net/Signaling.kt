package app.cartucho.net

import android.util.Base64
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlin.concurrent.thread

/**
 * "Ponto de encontro" da sala online: os celulares trocam as mensagens de conexão (WebRTC)
 * por um tópico público e gratuito do ntfy.sh, identificado pelo código da sala.
 * Depois de conectados, vídeo e controles vão direto de um celular para o outro.
 */
class Signaling(private val code: String, private val onMessage: (JSONObject) -> Unit) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()
    @Volatile private var call: Call? = null
    @Volatile private var running = false
    private val topic = "cartucho-sala-" + code.lowercase()

    fun start() {
        running = true
        val since = System.currentTimeMillis() / 1000 - 5
        thread(name = "signaling", isDaemon = true) {
            var backoff = 1000L
            while (running) {
                val req = Request.Builder().url("$BASE/$topic/json?since=$since").build()
                val c = http.newCall(req)
                call = c
                runCatching {
                    c.execute().use { resp ->
                        val source = resp.body?.source() ?: return@use
                        backoff = 1000L
                        while (running) {
                            val line = source.readUtf8Line() ?: break
                            val o = runCatching { JSONObject(line) }.getOrNull() ?: continue
                            if (o.optString("event") != "message") continue
                            val msg = runCatching { JSONObject(o.optString("message")) }.getOrNull() ?: continue
                            runCatching { onMessage(msg) }
                        }
                    }
                }
                if (running) Thread.sleep(backoff).also { backoff = (backoff * 2).coerceAtMost(15000) }
            }
        }
    }

    fun send(msg: JSONObject) {
        thread(isDaemon = true) {
            val req = Request.Builder().url("$BASE/$topic")
                .post(msg.toString().toRequestBody("text/plain; charset=utf-8".toMediaType()))
                .build()
            runCatching { http.newCall(req).execute().close() }
        }
    }

    fun stop() {
        running = false
        runCatching { call?.cancel() }
    }

    companion object {
        private const val BASE = "https://ntfy.sh"
        private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

        fun newCode(): String {
            val r = SecureRandom()
            return (1..6).map { ALPHABET[r.nextInt(ALPHABET.length)] }.joinToString("")
        }

        fun normalizeCode(text: String): String? {
            val c = text.trim().uppercase().filter { it in ALPHABET }
            return c.takeIf { it.length == 6 }
        }

        fun newId(): String = (1..8).map { ALPHABET[SecureRandom().nextInt(ALPHABET.length)] }.joinToString("")

        fun inviteLink(code: String) = "https://andrefeeelipe.github.io/Cartucho/sala.html#$code"

        /** SDP compactado (cabe numa mensagem do ntfy). */
        fun pack(sdp: String): String {
            val bos = ByteArrayOutputStream()
            GZIPOutputStream(bos).use { it.write(sdp.toByteArray()) }
            return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        }

        fun unpack(data: String): String =
            GZIPInputStream(ByteArrayInputStream(Base64.decode(data, Base64.NO_WRAP))).use { String(it.readBytes()) }
    }
}
