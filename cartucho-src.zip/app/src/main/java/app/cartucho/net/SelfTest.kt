package app.cartucho.net

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import app.cartucho.data.Store
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.JavaI420Buffer
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpTransceiver
import org.webrtc.SessionDescription
import org.webrtc.VideoFrame
import org.webrtc.VideoTrack
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Autoteste da sala online, rodado pelo GitHub Actions num Android de verdade (emulador)
 * antes de publicar cada versão: duas conexões no mesmo aparelho, com vídeo, canal de dados
 * e a troca de convite no mesmo formato da sala, além do servidor de encontro (ntfy).
 * Não mexe em nada do usuário; só escreve o resultado no log ("CartuchoAutoteste").
 */
class SelfTestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply { setPadding(32, 64, 32, 32); textSize = 13f }
        setContentView(ScrollView(this).apply { addView(text) })
        Thread({
            val ok = runCatching {
                SelfTest.run(this) { line ->
                    Log.w(TAG, line)
                    runOnUiThread { text.append(line + "\n") }
                }
            }.getOrElse { e ->
                Log.e(TAG, "erro inesperado", e)
                runOnUiThread { text.append("Erro: $e\n") }
                false
            }
            Log.w(TAG, if (ok) "RESULTADO OK" else "RESULTADO FALHA")
            runOnUiThread { text.append(if (ok) "\nTudo certo." else "\nFalhou.") }
        }, "autoteste").start()
    }

    companion object {
        const val TAG = "CartuchoAutoteste"
    }
}

object SelfTest {
    fun run(context: android.content.Context, log: (String) -> Unit): Boolean {
        RoomHost.initWebRtc(context)
        log("1/6 biblioteca de conexão carregada")

        val egl = EglBase.create()
        val factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()
        val source = factory.createVideoSource(false)
        source.capturerObserver.onCapturerStarted(true)
        val track = factory.createVideoTrack("game", source)
        log("2/6 fábrica e vídeo criados")

        val config = PeerConnection.RTCConfiguration(emptyList()).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
        val framesAtGuest = AtomicInteger()
        val messageAtGuest = AtomicReference<String?>(null)
        val guestChannelOpen = CountDownLatch(1)
        val gotMessage = CountDownLatch(1)
        val hostGathered = CountDownLatch(1)
        val guestGathered = CountDownLatch(1)
        val connected = CountDownLatch(1)

        val host = factory.createPeerConnection(config, object : PeerObserver() {
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {
                if (state == PeerConnection.IceGatheringState.COMPLETE) hostGathered.countDown()
            }
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                if (state == PeerConnection.IceConnectionState.CONNECTED || state == PeerConnection.IceConnectionState.COMPLETED) connected.countDown()
            }
        }) ?: return fail(log, "não criou a conexão do anfitrião")
        val guest = factory.createPeerConnection(config, object : PeerObserver() {
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {
                if (state == PeerConnection.IceGatheringState.COMPLETE) guestGathered.countDown()
            }
            override fun onTrack(transceiver: RtpTransceiver) {
                (transceiver.receiver.track() as? VideoTrack)?.addSink { framesAtGuest.incrementAndGet() }
            }
            override fun onDataChannel(channel: DataChannel) {
                channel.registerObserver(object : DataChannel.Observer {
                    override fun onBufferedAmountChange(previous: Long) {}
                    override fun onStateChange() {
                        if (channel.state() == DataChannel.State.OPEN) guestChannelOpen.countDown()
                    }
                    override fun onMessage(buffer: DataChannel.Buffer) {
                        val b = ByteArray(buffer.data.remaining())
                        buffer.data.get(b)
                        messageAtGuest.set(String(b))
                        gotMessage.countDown()
                    }
                })
                if (channel.state() == DataChannel.State.OPEN) guestChannelOpen.countDown()
            }
        }) ?: return fail(log, "não criou a conexão do convidado")

        host.addTransceiver(track, RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.SEND_ONLY))
        val input = host.createDataChannel("input", DataChannel.Init().apply { ordered = true })

        // Mesmo caminho da sala: oferta completa, compactada (pack) e aberta do outro lado (unpack).
        val offer = await { obs -> host.createOffer(obs, MediaConstraints()) } ?: return fail(log, "não criou a oferta")
        setLocal(host, offer) ?: return fail(log, "não aplicou a oferta")
        if (!hostGathered.await(20, TimeUnit.SECONDS)) log("  aviso: anfitrião demorou para listar caminhos")
        val offerText = Signaling.unpack(Signaling.pack(host.localDescription.description))
        setRemote(guest, SessionDescription(SessionDescription.Type.OFFER, offerText)) ?: return fail(log, "convidado não aceitou a oferta")
        val answer = await { obs -> guest.createAnswer(obs, MediaConstraints()) } ?: return fail(log, "não criou a resposta")
        setLocal(guest, answer) ?: return fail(log, "não aplicou a resposta")
        if (!guestGathered.await(20, TimeUnit.SECONDS)) log("  aviso: convidado demorou para listar caminhos")
        val answerText = Signaling.unpack(Signaling.pack(guest.localDescription.description))
        setRemote(host, SessionDescription(SessionDescription.Type.ANSWER, answerText)) ?: return fail(log, "anfitrião não aceitou a resposta")
        log("3/6 convite trocado (oferta ${offerText.length} b, resposta ${answerText.length} b)")

        if (!connected.await(20, TimeUnit.SECONDS)) return fail(log, "as duas pontas não se conectaram")
        log("4/6 conectados")

        // Vídeo: manda quadros como o jogo manda e confere se chegaram.
        val sender = Thread {
            val start = System.nanoTime()
            repeat(150) { i ->
                val buf = JavaI420Buffer.allocate(320, 240)
                fill(buf.dataY, (i * 3) and 0xff); fill(buf.dataU, 128); fill(buf.dataV, 128)
                val frame = VideoFrame(buf, 0, System.nanoTime() - start)
                source.capturerObserver.onFrameCaptured(frame)
                frame.release()
                Thread.sleep(33)
            }
        }.apply { start() }
        if (!guestChannelOpen.await(15, TimeUnit.SECONDS)) return fail(log, "canal de controle não abriu")
        input.send(DataChannel.Buffer(ByteBuffer.wrap("B 5".toByteArray()), false))
        if (!gotMessage.await(10, TimeUnit.SECONDS) || messageAtGuest.get() != "B 5") return fail(log, "comando do controle não chegou")
        log("5/6 controle funcionando")
        sender.join(8000)
        val frames = framesAtGuest.get()
        if (frames < 5) return fail(log, "vídeo não chegou ($frames quadros)")
        log("6/6 vídeo chegando ($frames quadros)")

        runCatching { input.dispose(); host.dispose(); guest.dispose() }
        runCatching { track.dispose(); source.dispose(); factory.dispose(); egl.release() }

        // Loja: o catálogo tem que vir dentro do app; o download de um jogo é conferido se houver internet.
        val catalog = Store(context).bundledCatalog()
        if (catalog.isEmpty()) return fail(log, "catálogo da Loja vazio")
        log("extra: Loja com ${catalog.size} jogos no catálogo")
        log("extra: Loja por sistema " + catalog.groupingBy { it.systemId }.eachCount() + ", em português: " + catalog.count { it.language == "pt" } + ", com gênero: " + catalog.count { it.genres.isNotEmpty() })
        for (sys in listOf("gb", "zxspectrum", "tic80")) {
            val sample = catalog.firstOrNull { it.systemId == sys && !it.isDemo } ?: continue
            val bytes = runCatching {
                okhttp3.OkHttpClient().newCall(okhttp3.Request.Builder().url(sample.fileUrl).build()).execute().use { r -> if (r.isSuccessful) r.body?.bytes()?.size ?: 0 else -r.code }
            }.getOrElse { -1 }
            log(if (bytes > 0) "extra: download da Loja OK ($sys: ${sample.title}, $bytes bytes)" else "extra: AVISO download da Loja falhou ($sys: ${sample.fileUrl} → $bytes)")
        }

        RoomHost.prepareRelay(context)
        if (!RoomHost.relayReady) log("extra: retransmissão (TURN) não configurada")
        else log(if (relayWorks(context)) "extra: retransmissão (TURN) OK: as duas pontas se ligaram só pelo servidor" else "extra: AVISO retransmissão (TURN) não conectou")
        val ids = runCatching { context.assets.list("ids")?.size ?: 0 }.getOrDefault(0)
        log("extra: listas de reconhecimento de jogos: $ids sistemas")
        // Nome estranho, sem o arquivo: o reconhecimento pelo nome tem que achar o jogo certo.
        val identifier = app.cartucho.data.GameIdentifier(context)
        for ((sys, weird) in listOf(
            "snes" to "super_mario_world_usa.sfc", "gba" to "pokemon-fire-red-v1.gba", "psx" to "crash_bandicoot_ntsc.bin",
            "nds" to "Pokemon Branco (PT-BR) www.romsportugues.com.nds", "snes" to "SuperMetroid_traduzido.smc",
        )) {
            val g = app.cartucho.data.Game(id = "teste-$sys", title = weird.substringBeforeLast('.').replace('_', ' '), fileName = weird,
                uri = "file:///nao/existe/$weird", systemId = sys, size = 0, addedAt = 0)
            val found = runCatching { identifier.identify(g) }.onFailure { log("extra: erro no reconhecimento de $weird: $it") }.getOrNull()
            log("extra: nome \"$weird\" → ${found?.name ?: "não reconhecido"} (${identifier.debugInfo(sys, g)})")
        }

        runCatching { archivesWork(context, log) }.onFailure { log("extra: AVISO compactados: $it") }

        // Servidor de encontro (internet): não bloqueia o resultado, só avisa.
        log(if (signalingWorks()) "extra: servidor de encontro respondeu (inclusive mensagem grande)" else "extra: AVISO servidor de encontro não respondeu (sem internet?)")
        return true
    }

    /** Duas conexões que só podem se falar pelo servidor TURN (como dois celulares nos dados móveis). */
    /** Compactado dentro de compactado, partes .7z.001 dentro de um .zip e pacote com vários jogos. */
    private fun archivesWork(context: android.content.Context, log: (String) -> Unit) {
        val cart = context.applicationContext as app.cartucho.CartuchoApp
        val dir = java.io.File(context.cacheDir, "autoteste-compactados").apply { deleteRecursively(); mkdirs() }
        val rom = ByteArray(64 * 1024) { (it * 7).toByte() }
        fun zip(target: java.io.File, entries: Map<String, ByteArray>) {
            java.util.zip.ZipOutputStream(target.outputStream()).use { z -> for ((n, b) in entries) { z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(b); z.closeEntry() } }
        }
        // 1) .7z cortado em duas partes, dentro de um .zip com nome de download do Drive.
        val seven = java.io.File(dir, "Jogo Teste.gba.7z")
        org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(seven).use { z ->
            z.setContentCompression(org.apache.commons.compress.archivers.sevenz.SevenZMethod.COPY)
            val e = z.createArchiveEntry(java.io.File(dir, "x"), "Jogo Teste (PT-BR).gba")
            z.putArchiveEntry(e); z.write(rom); z.closeArchiveEntry()
        }
        val all = seven.readBytes()
        val half = all.size / 2
        val bundle = java.io.File(dir, "drive-download-20250101T000000Z-1-001.zip")
        zip(bundle, mapOf("pasta/Jogo Teste.gba.7z.001" to all.copyOfRange(0, half), "pasta/Jogo Teste.gba.7z.002" to all.copyOfRange(half, all.size)))
        // 2) Pacote: um .zip com dois jogos de GBA dentro de outro .zip.
        val inner = java.io.File(dir, "inner.zip")
        zip(inner, mapOf("Jogo A.gba" to rom, "Jogo B (PT-BR).gba" to rom.copyOf().also { it[0] = 1 }))
        val pack = java.io.File(dir, "Pacote GBA 2 jogos.zip")
        zip(pack, mapOf("Pacote/inner.zip" to inner.readBytes()))

        val resolver = app.cartucho.data.GameResolver(context, cart.detector)
        fun game(f: java.io.File, sys: String = "") = app.cartucho.data.Game(
            id = "autoteste-" + f.name.hashCode(), title = f.name, fileName = f.name, uri = android.net.Uri.fromFile(f).toString(),
            systemId = sys, size = f.length(), addedAt = 0,
        )
        val g1 = game(bundle)
        val d1 = resolver.detect(g1)
        log("extra: compactado dentro de compactado (partes .7z.001 num .zip): ${d1.system?.id ?: d1.error ?: "?"} / ${d1.mainName}" +
            if (d1.system?.id == "gba" && d1.mainName?.endsWith(".gba") == true) " OK" else " AVISO")
        val g2 = game(pack, "gba")
        cart.library.upsert(g2)
        val before = cart.library.games.value.size
        val look = resolver.needsLook(g2)
        val d2 = resolver.detect(g2)
        val added = cart.library.games.value.filter { it.uri.contains("/packs/${g2.id}/") }
        log("extra: pacote com vários jogos: olhar antes=$look, ${d2.pack} jogos (${added.joinToString { it.title + ":" + it.systemId }})" +
            if (look && d2.pack == 2 && added.size == 2 && added.all { it.systemId == "gba" } && cart.library.find(g2.id)?.pack == 2) " OK" else " AVISO")
        (added.map { it.id } + g2.id).forEach { cart.library.remove(it) }
        java.io.File(context.filesDir, "packs/${g2.id}").deleteRecursively()
        if (cart.library.games.value.size != before - 1) log("extra: AVISO biblioteca não voltou ao normal")
        dir.deleteRecursively()
    }

    private fun relayWorks(context: android.content.Context): Boolean {
        val factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
        val config = PeerConnection.RTCConfiguration(RoomHost.iceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            iceTransportsType = PeerConnection.IceTransportsType.RELAY
        }
        val aGathered = CountDownLatch(1)
        val bGathered = CountDownLatch(1)
        val connected = CountDownLatch(1)
        val a = factory.createPeerConnection(config, object : PeerObserver() {
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) { if (state == PeerConnection.IceGatheringState.COMPLETE) aGathered.countDown() }
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                if (state == PeerConnection.IceConnectionState.CONNECTED || state == PeerConnection.IceConnectionState.COMPLETED) connected.countDown()
            }
        }) ?: return false
        val b = factory.createPeerConnection(config, object : PeerObserver() {
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) { if (state == PeerConnection.IceGatheringState.COMPLETE) bGathered.countDown() }
        }) ?: return false
        return try {
            a.createDataChannel("t", DataChannel.Init())
            val offer = await { obs -> a.createOffer(obs, MediaConstraints()) } ?: return false
            setLocal(a, offer) ?: return false
            aGathered.await(15, TimeUnit.SECONDS)
            if (!a.localDescription.description.contains("typ relay")) return false
            setRemote(b, SessionDescription(SessionDescription.Type.OFFER, a.localDescription.description)) ?: return false
            val answer = await { obs -> b.createAnswer(obs, MediaConstraints()) } ?: return false
            setLocal(b, answer) ?: return false
            bGathered.await(15, TimeUnit.SECONDS)
            setRemote(a, SessionDescription(SessionDescription.Type.ANSWER, b.localDescription.description)) ?: return false
            connected.await(20, TimeUnit.SECONDS)
        } finally {
            runCatching { a.dispose(); b.dispose(); factory.dispose() }
        }
    }

    private fun signalingWorks(): Boolean {
        val code = Signaling.newCode() + Signaling.newCode()
        val ready = CountDownLatch(1)
        val got = CountDownLatch(2)
        val big = "x".repeat(9000)
        val sig = Signaling(code, onState = { if (it) ready.countDown() }) { m ->
            when (m.optString("t")) {
                "ping" -> got.countDown()
                "grande" -> if (m.optString("d") == big) got.countDown()
            }
        }
        sig.start()
        return try {
            if (!ready.await(15, TimeUnit.SECONDS)) return false
            sig.send(JSONObject().put("t", "ping"))
            sig.send(JSONObject().put("t", "grande").put("d", big))
            got.await(20, TimeUnit.SECONDS)
        } finally {
            sig.stop()
        }
    }

    private fun fill(b: ByteBuffer, v: Int) {
        val d = b.duplicate()
        while (d.hasRemaining()) d.put(v.toByte())
    }

    private fun fail(log: (String) -> Unit, why: String): Boolean {
        log("FALHA: $why")
        return false
    }

    private fun await(start: (SimpleSdp) -> Unit): SessionDescription? {
        val result = AtomicReference<SessionDescription?>(null)
        val done = CountDownLatch(1)
        start(object : SimpleSdp() {
            override fun onCreateSuccess(desc: SessionDescription) { result.set(desc); done.countDown() }
            override fun onCreateFailure(error: String?) { done.countDown() }
        })
        done.await(15, TimeUnit.SECONDS)
        return result.get()
    }

    private fun setLocal(pc: PeerConnection, desc: SessionDescription): Unit? = set { obs -> pc.setLocalDescription(obs, desc) }
    private fun setRemote(pc: PeerConnection, desc: SessionDescription): Unit? = set { obs -> pc.setRemoteDescription(obs, desc) }

    private fun set(start: (SimpleSdp) -> Unit): Unit? {
        var ok = false
        val done = CountDownLatch(1)
        start(object : SimpleSdp() {
            override fun onSetSuccess() { ok = true; done.countDown() }
            override fun onSetFailure(error: String?) { done.countDown() }
        })
        done.await(15, TimeUnit.SECONDS)
        return if (ok) Unit else null
    }
}
