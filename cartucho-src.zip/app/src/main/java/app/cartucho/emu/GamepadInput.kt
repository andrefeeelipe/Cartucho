package app.cartucho.emu

import android.content.Context
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt

/** IDs de botão do RetroPad (padrão libretro, layout SNES). */
object RetroPad {
    const val B = 0
    const val Y = 1
    const val SELECT = 2
    const val START = 3
    const val UP = 4
    const val DOWN = 5
    const val LEFT = 6
    const val RIGHT = 7
    const val A = 8
    const val X = 9
    const val L = 10
    const val R = 11
    const val L2 = 12
    const val R2 = 13
    const val L3 = 14
    const val R3 = 15

    val remappable: List<Pair<Int, String>> = listOf(
        A to "A", B to "B", X to "X", Y to "Y", L to "L", R to "R", L2 to "L2", R2 to "R2",
        START to "Start", SELECT to "Select", L3 to "L3", R3 to "R3",
    )

    fun label(id: Int): String = remappable.firstOrNull { it.first == id }?.second ?: id.toString()
}

/**
 * Controles físicos: remapeamentos salvos por modelo de controle.
 * Fica num arquivo (e não em SharedPreferences) porque o jogo roda em outro processo:
 * o que for mapeado durante a partida vale na hora e também aparece em Ajustes.
 */
class RemapStore(context: Context) {
    private val file = java.io.File(context.filesDir, "remaps.json")
    private val legacy = context.getSharedPreferences("cartucho_remaps", Context.MODE_PRIVATE)

    @Synchronized
    private fun readAll(): JSONObject {
        if (!file.exists()) {
            // Migra o formato antigo uma vez.
            val o = JSONObject()
            legacy.all.forEach { (k, v) -> if (v is String) runCatching { o.put(k, JSONObject(v)) } }
            return o
        }
        return runCatching { JSONObject(file.readText()) }.getOrDefault(JSONObject())
    }

    @Synchronized
    private fun writeAll(o: JSONObject) {
        val tmp = java.io.File(file.parentFile, "remaps.json.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(file)
    }

    fun load(descriptor: String): Map<Int, Int> {
        val o = readAll().optJSONObject(descriptor) ?: return emptyMap()
        return runCatching { o.keys().asSequence().associate { it.toInt() to o.getInt(it) } }.getOrDefault(emptyMap())
    }

    fun save(descriptor: String, map: Map<Int, Int>) {
        val m = JSONObject()
        map.forEach { (k, v) -> m.put(k.toString(), v) }
        writeAll(readAll().put(descriptor, m))
    }

    fun clear(descriptor: String) {
        val all = readAll()
        all.remove(descriptor)
        writeAll(all)
    }
}

object Gamepads {
    val defaultMap: Map<Int, Int> = mapOf(
        KeyEvent.KEYCODE_BUTTON_A to RetroPad.B,
        KeyEvent.KEYCODE_BUTTON_B to RetroPad.A,
        KeyEvent.KEYCODE_BUTTON_X to RetroPad.Y,
        KeyEvent.KEYCODE_BUTTON_Y to RetroPad.X,
        KeyEvent.KEYCODE_BUTTON_L1 to RetroPad.L,
        KeyEvent.KEYCODE_BUTTON_R1 to RetroPad.R,
        KeyEvent.KEYCODE_BUTTON_L2 to RetroPad.L2,
        KeyEvent.KEYCODE_BUTTON_R2 to RetroPad.R2,
        KeyEvent.KEYCODE_BUTTON_THUMBL to RetroPad.L3,
        KeyEvent.KEYCODE_BUTTON_THUMBR to RetroPad.R3,
        KeyEvent.KEYCODE_BUTTON_START to RetroPad.START,
        KeyEvent.KEYCODE_BUTTON_SELECT to RetroPad.SELECT,
        KeyEvent.KEYCODE_BUTTON_C to RetroPad.R,
        KeyEvent.KEYCODE_BUTTON_Z to RetroPad.L,
        KeyEvent.KEYCODE_DPAD_UP to RetroPad.UP,
        KeyEvent.KEYCODE_DPAD_DOWN to RetroPad.DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT to RetroPad.LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT to RetroPad.RIGHT,
        // Controles genéricos (modo DirectInput) mandam "botão 1, 2, 3…": layout mais comum desses controles.
        KeyEvent.KEYCODE_BUTTON_1 to RetroPad.Y,
        KeyEvent.KEYCODE_BUTTON_2 to RetroPad.B,
        KeyEvent.KEYCODE_BUTTON_3 to RetroPad.A,
        KeyEvent.KEYCODE_BUTTON_4 to RetroPad.X,
        KeyEvent.KEYCODE_BUTTON_5 to RetroPad.L,
        KeyEvent.KEYCODE_BUTTON_6 to RetroPad.R,
        KeyEvent.KEYCODE_BUTTON_7 to RetroPad.L2,
        KeyEvent.KEYCODE_BUTTON_8 to RetroPad.R2,
        KeyEvent.KEYCODE_BUTTON_9 to RetroPad.SELECT,
        KeyEvent.KEYCODE_BUTTON_10 to RetroPad.START,
        KeyEvent.KEYCODE_BUTTON_11 to RetroPad.L3,
        KeyEvent.KEYCODE_BUTTON_12 to RetroPad.R3,
    )

    /** Teclado físico (USB ou Bluetooth): jogador 1, com o mesmo layout do Cartucho no computador. */
    val keyboardMap: Map<Int, Int> = mapOf(
        KeyEvent.KEYCODE_DPAD_UP to RetroPad.UP,
        KeyEvent.KEYCODE_DPAD_DOWN to RetroPad.DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT to RetroPad.LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT to RetroPad.RIGHT,
        KeyEvent.KEYCODE_Z to RetroPad.B,
        KeyEvent.KEYCODE_X to RetroPad.A,
        KeyEvent.KEYCODE_A to RetroPad.Y,
        KeyEvent.KEYCODE_S to RetroPad.X,
        KeyEvent.KEYCODE_Q to RetroPad.L,
        KeyEvent.KEYCODE_W to RetroPad.R,
        KeyEvent.KEYCODE_E to RetroPad.L2,
        KeyEvent.KEYCODE_R to RetroPad.R2,
        KeyEvent.KEYCODE_D to RetroPad.L3,
        KeyEvent.KEYCODE_F to RetroPad.R3,
        KeyEvent.KEYCODE_ENTER to RetroPad.START,
        KeyEvent.KEYCODE_DEL to RetroPad.SELECT,
        KeyEvent.KEYCODE_SHIFT_RIGHT to RetroPad.SELECT,
    )

    fun isKeyboard(device: InputDevice?): Boolean {
        if (device == null || device.isVirtual || isGamepad(device)) return false
        return device.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC &&
            (device.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD
    }

    /** Mapa padrão do aparelho: controle ou teclado. */
    fun defaultFor(device: InputDevice): Map<Int, Int> = if (isKeyboard(device)) keyboardMap else defaultMap

    /** Controles e teclados de fora (para a tela Controles: testar e mapear). */
    fun inputDevices(): List<InputDevice> =
        InputDevice.getDeviceIds().toList().mapNotNull { InputDevice.getDevice(it) }.filter { d ->
            val external = if (android.os.Build.VERSION.SDK_INT >= 29) d.isExternal else true
            isGamepad(d) || (isKeyboard(d) && external)
        }

    fun isGamepad(device: InputDevice?): Boolean {
        if (device == null || device.isVirtual) return false
        val s = device.sources
        if ((s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        ) return true
        // Alguns controles genéricos Bluetooth se apresentam só como "direcional" (sem dizer que são controle).
        // Teclado de verdade fica de fora.
        if ((s and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD && device.keyboardType != InputDevice.KEYBOARD_TYPE_ALPHABETIC) {
            val keys = device.hasKeys(KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_1, KeyEvent.KEYCODE_BUTTON_START)
            return keys.any { it }
        }
        return false
    }

    fun connected(): List<InputDevice> =
        InputDevice.getDeviceIds().toList().mapNotNull { InputDevice.getDevice(it) }.filter { isGamepad(it) }

    fun descriptorOf(device: InputDevice): String = device.descriptor ?: device.name
}

/**
 * Converte eventos de controles físicos e da tela em estado do RetroPad por porta (até 4 jogadores).
 */
class GamepadInput(context: Context) {
    private val remapStore = RemapStore(context)
    private val portByDevice = LinkedHashMap<Int, Int>()
    private val remapByDevice = HashMap<Int, Map<Int, Int>>()
    private val keyButtons = IntArray(4)
    private val hatButtons = IntArray(4)
    private val triggerButtons = IntArray(4)
    @Volatile private var touchButtons = 0
    /** Botões vindos de controles remotos (navegador pelo QR ou sala online), por jogador. */
    private val remoteButtons = IntArray(4)

    var onMenuRequested: (() -> Unit)? = null
    var menuComboEnabled = true
    /** Teclado físico joga como jogador 1 (dá para desligar em Ajustes > Controles). */
    var keyboardEnabled = true
    private var keyboardButtons = 0

    fun portOf(deviceId: Int): Int? = portByDevice[deviceId]

    private fun assignPort(device: InputDevice): Int {
        portByDevice[device.id]?.let { return it }
        val used = portByDevice.values.toSet()
        val port = (0 until 4).firstOrNull { it !in used } ?: 0
        portByDevice[device.id] = port
        remapByDevice[device.id] = remapStore.load(Gamepads.descriptorOf(device))
        return port
    }

    /** Relê os mapeamentos salvos (depois de mapear um controle durante o jogo). */
    fun reloadRemaps() {
        for (id in portByDevice.keys) {
            val device = InputDevice.getDevice(id) ?: continue
            remapByDevice[id] = remapStore.load(Gamepads.descriptorOf(device))
        }
        for (port in 0 until 4) {
            keyButtons[port] = 0
            push(port)
        }
    }

    fun deviceRemoved(deviceId: Int): Int? {
        val port = portByDevice.remove(deviceId) ?: return null
        remapByDevice.remove(deviceId)
        keyButtons[port] = 0
        hatButtons[port] = 0
        triggerButtons[port] = 0
        NativeBridge.setAnalog(port, 0, 0, 0)
        NativeBridge.setAnalog(port, 1, 0, 0)
        push(port)
        return port
    }

    fun handleKey(event: KeyEvent): Boolean {
        val device = event.device
        if (device != null && keyboardEnabled && Gamepads.isKeyboard(device)) return handleKeyboard(event, device)
        if (!Gamepads.isGamepad(device) || device == null) return false
        if (event.keyCode == KeyEvent.KEYCODE_BUTTON_MODE || event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) onMenuRequested?.invoke()
            return true
        }
        val port = assignPort(device)
        val remap = remapByDevice[device.id] ?: emptyMap()
        val id = lookup(remap, Gamepads.defaultMap, event.keyCode) ?: return false
        val bit = 1 shl id
        keyButtons[port] = if (event.action == KeyEvent.ACTION_DOWN) keyButtons[port] or bit else keyButtons[port] and bit.inv()
        val combo = (1 shl RetroPad.SELECT) or (1 shl RetroPad.START)
        if (menuComboEnabled && event.action == KeyEvent.ACTION_DOWN && (keyButtons[port] and combo) == combo) {
            keyButtons[port] = keyButtons[port] and combo.inv()
            push(port)
            onMenuRequested?.invoke()
            return true
        }
        push(port)
        return true
    }

    /**
     * Botão do jogo para uma tecla: o mapeamento salvo manda; tecla que ele não cita usa o padrão,
     * desde que esse botão do jogo não tenha ido para outra tecla.
     */
    private fun lookup(remap: Map<Int, Int>, defaults: Map<Int, Int>, keyCode: Int): Int? {
        remap[keyCode]?.let { return it }
        val d = defaults[keyCode] ?: return null
        return if (remap.isEmpty() || d !in remap.values) d else null
    }

    private fun handleKeyboard(event: KeyEvent, device: InputDevice): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_UP) onMenuRequested?.invoke()
            return true
        }
        val remap = remapByDevice.getOrPut(device.id) { remapStore.load(Gamepads.descriptorOf(device)) }
        val id = lookup(remap, Gamepads.keyboardMap, event.keyCode) ?: return false
        val bit = 1 shl id
        keyboardButtons = if (event.action == KeyEvent.ACTION_DOWN) keyboardButtons or bit else keyboardButtons and bit.inv()
        push(0)
        return true
    }

    fun handleMotion(event: MotionEvent): Boolean {
        val device = event.device
        if (!Gamepads.isGamepad(device) || device == null) return false
        if (event.action != MotionEvent.ACTION_MOVE) return false
        val port = assignPort(device)

        val lx = axis(event, device, MotionEvent.AXIS_X)
        val ly = axis(event, device, MotionEvent.AXIS_Y)
        // Analógico direito: Z/RZ na maioria (Xbox, PlayStation, 8BitDo); alguns genéricos usam RX/RY.
        val rightOnZ = device.getMotionRange(MotionEvent.AXIS_Z, event.source) != null
        val rx = axis(event, device, if (rightOnZ) MotionEvent.AXIS_Z else MotionEvent.AXIS_RX)
        val ry = axis(event, device, if (rightOnZ) MotionEvent.AXIS_RZ else MotionEvent.AXIS_RY)
        NativeBridge.setAnalog(port, 0, toRetro(lx), toRetro(ly))
        NativeBridge.setAnalog(port, 1, toRetro(rx), toRetro(ry))

        val hx = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
        var hat = 0
        if (hx < -0.5f) hat = hat or (1 shl RetroPad.LEFT)
        if (hx > 0.5f) hat = hat or (1 shl RetroPad.RIGHT)
        if (hy < -0.5f) hat = hat or (1 shl RetroPad.UP)
        if (hy > 0.5f) hat = hat or (1 shl RetroPad.DOWN)
        // Controle sem direcional digital: o analógico esquerdo também serve de direcional.
        if (device.getMotionRange(MotionEvent.AXIS_HAT_X, event.source) == null) {
            if (lx < -0.5f) hat = hat or (1 shl RetroPad.LEFT)
            if (lx > 0.5f) hat = hat or (1 shl RetroPad.RIGHT)
            if (ly < -0.5f) hat = hat or (1 shl RetroPad.UP)
            if (ly > 0.5f) hat = hat or (1 shl RetroPad.DOWN)
        }
        hatButtons[port] = hat

        val lt = maxOf(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE))
        val rt = maxOf(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS))
        var trig = 0
        if (lt > 0.4f) trig = trig or (1 shl RetroPad.L2)
        if (rt > 0.4f) trig = trig or (1 shl RetroPad.R2)
        triggerButtons[port] = trig
        push(port)
        return true
    }

    private fun axis(event: MotionEvent, device: InputDevice, axis: Int): Float {
        val range = device.getMotionRange(axis, event.source) ?: return 0f
        val v = event.getAxisValue(axis)
        val flat = maxOf(range.flat, 0.12f)
        return if (abs(v) < flat) 0f else v
    }

    private fun toRetro(v: Float): Int = (v.coerceIn(-1f, 1f) * 32767f).roundToInt()

    /** Botões dos controles na tela (sempre jogador 1). */
    fun setTouchButtons(mask: Int) {
        touchButtons = mask
        push(0)
    }

    fun setTouchAnalog(stick: Int, x: Float, y: Float) {
        NativeBridge.setAnalog(0, stick, toRetro(x), toRetro(y))
    }

    /** Controle remoto (QR/sala online) apertando botões do jogador [port] (0 = jogador 1). */
    @Synchronized
    fun setRemote(port: Int, mask: Int) {
        if (port !in 0..3) return
        remoteButtons[port] = mask
        push(port)
    }

    fun setRemoteAnalog(port: Int, stick: Int, x: Float, y: Float) {
        if (port !in 0..3) return
        NativeBridge.setAnalog(port, stick, toRetro(x), toRetro(y))
    }

    private fun push(port: Int) {
        var mask = keyButtons[port] or hatButtons[port] or triggerButtons[port] or remoteButtons[port]
        if (port == 0) mask = mask or touchButtons or keyboardButtons
        NativeBridge.setButtons(port, mask)
    }

    fun releaseAll() {
        for (p in 0 until 4) {
            keyButtons[p] = 0; hatButtons[p] = 0; triggerButtons[p] = 0
            if (p == 0) keyboardButtons = 0
            NativeBridge.setButtons(p, 0)
            NativeBridge.setAnalog(p, 0, 0, 0)
            NativeBridge.setAnalog(p, 1, 0, 0)
        }
        touchButtons = 0
    }
}
