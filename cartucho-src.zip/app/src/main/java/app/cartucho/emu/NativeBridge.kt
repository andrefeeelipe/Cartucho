package app.cartucho.emu

/**
 * Ponte com o código nativo (libcartucho.so). Os nomes e assinaturas daqui
 * precisam bater com cartucho_native.cpp e achievements.cpp.
 */
object NativeBridge {
    init {
        System.loadLibrary("cartucho")
    }

    // ---- Emulação (chamar sempre na thread do GL) ----
    @JvmStatic external fun getLastError(): String?
    @JvmStatic external fun setGlesVersion(major: Int)
    @JvmStatic external fun loadCore(corePath: String, systemDir: String, saveDir: String): Boolean
    @JvmStatic external fun setOption(key: String, value: String)
    @JvmStatic external fun setPerformance(resolutionMultiplier: Int, frameskipMode: Int)
    @JvmStatic external fun loadGame(gamePath: String): Boolean
    @JvmStatic external fun onSurfaceCreated()
    @JvmStatic external fun onSurfaceChanged(width: Int, height: Int)
    @JvmStatic external fun setVideoOptions(aspectMode: Int, integerScale: Boolean, linear: Boolean, scanlines: Boolean)
    @JvmStatic external fun runFrame(muteAudio: Boolean)
    @JvmStatic external fun render()
    @JvmStatic external fun setFastForward(enabled: Boolean)
    @JvmStatic external fun getAvInfo(): DoubleArray
    @JvmStatic external fun consumeShutdownRequest(): Boolean
    @JvmStatic external fun saveState(path: String): Boolean
    @JvmStatic external fun loadState(path: String): Boolean
    @JvmStatic external fun saveSram(path: String): Boolean
    @JvmStatic external fun loadSram(path: String): Boolean
    @JvmStatic external fun reset()
    @JvmStatic external fun captureFrame(maxWidth: Int): IntArray?
    @JvmStatic external fun unloadGame()

    // ---- Entrada e áudio (qualquer thread) ----
    @JvmStatic external fun setButtons(port: Int, mask: Int)
    @JvmStatic external fun setAnalog(port: Int, stick: Int, x: Int, y: Int)
    /** Toque na tela do jogo, em coordenadas 0..1 da área de vídeo. */
    @JvmStatic external fun setPointer(x: Float, y: Float, pressed: Boolean)
    /** Desenha o quadro atual na superfície EGL corrente (TV) com o tamanho dado. */
    @JvmStatic external fun renderTo(width: Int, height: Int)
    @JvmStatic external fun clearScreen()
    /** Quadro atual em RGBA w×h (de cima para baixo) num ByteBuffer direto, para transmitir. */
    @JvmStatic external fun captureStream(width: Int, height: Int, dst: java.nio.ByteBuffer): Boolean
    @JvmStatic external fun frameAspect(): Float
    @JvmStatic external fun rgbaToI420(src: java.nio.ByteBuffer, width: Int, height: Int, y: java.nio.ByteBuffer, strideY: Int, u: java.nio.ByteBuffer, strideU: Int, v: java.nio.ByteBuffer, strideV: Int)
    @JvmStatic external fun readAudio(out: ShortArray): Int
    @JvmStatic external fun audioBufferedFrames(): Int

    // ---- RetroAchievements ----
    @JvmStatic external fun raCreate(hardcore: Boolean)
    @JvmStatic external fun raUserAgentClause(): String?
    @JvmStatic external fun raSetHardcore(hardcore: Boolean)
    @JvmStatic external fun raLoginPassword(user: String, password: String)
    @JvmStatic external fun raLoginToken(user: String, token: String)
    @JvmStatic external fun raLogout()
    @JvmStatic external fun raLoadGame(consoleId: Int, path: String)
    @JvmStatic external fun raHttpResponse(id: Int, status: Int, body: ByteArray?)
    @JvmStatic external fun raIdle()
    @JvmStatic external fun raAchievementsJson(): String?

    // ---- Chamados pelo nativo ----
    @Volatile var raListener: RaNativeListener? = null

    @JvmStatic
    fun onRaRequest(id: Int, url: String?, postData: String?, contentType: String?) {
        raListener?.onRequest(id, url ?: "", postData, contentType)
            ?: raHttpResponse(id, -2, null)
    }

    @JvmStatic
    fun onRaLogin(success: Boolean, message: String?, username: String?, token: String?, score: Int) {
        raListener?.onLogin(success, message, username, token, score)
    }

    @JvmStatic
    fun onRaGameLoaded(success: Boolean, message: String?, title: String?, total: Int, unlocked: Int) {
        raListener?.onGameLoaded(success, message, title, total, unlocked)
    }

    @JvmStatic
    fun onRaEvent(type: Int, title: String?, description: String?, points: Int) {
        raListener?.onEvent(type, title, description, points)
    }
}

interface RaNativeListener {
    fun onRequest(id: Int, url: String, postData: String?, contentType: String?)
    fun onLogin(success: Boolean, message: String?, username: String?, token: String?, score: Int)
    fun onGameLoaded(success: Boolean, message: String?, title: String?, total: Int, unlocked: Int)
    fun onEvent(type: Int, title: String?, description: String?, points: Int)
}
