package app.cartucho.emu

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import app.cartucho.data.Latency

/** Toca o áudio do core lendo o ring buffer nativo em uma thread dedicada. */
class AudioPlayer(val sampleRate: Int, latency: Latency) {
    private val track: AudioTrack?
    @Volatile private var running = true
    @Volatile private var paused = false
    private val thread: Thread
    /** Recebe uma cópia do áudio tocado (sala online transmite para os amigos). */
    @Volatile var tap: ((ShortArray, Int) -> Unit)? = null
    val targetBufferedFrames: Int = sampleRate * (if (latency == Latency.LOW) 50 else 100) / 1000

    init {
        val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val wanted = targetBufferedFrames * 4
        val bufferBytes = maxOf(if (minBuf > 0) minBuf else 4096, wanted)
        track = runCatching {
            @Suppress("DEPRECATION")
            AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferBytes,
                AudioTrack.MODE_STREAM,
            ).takeIf { it.state == AudioTrack.STATE_INITIALIZED }
        }.getOrNull()
        track?.play()
        thread = Thread({ loop() }, "CartuchoAudio").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    private fun loop() {
        val buffer = ShortArray(2048)
        while (running) {
            if (paused || track == null) {
                // Mesmo pausado, drena o buffer para não acumular atraso.
                NativeBridge.readAudio(buffer)
                Thread.sleep(10)
                continue
            }
            val n = NativeBridge.readAudio(buffer)
            if (n > 0) {
                track.write(buffer, 0, n)
                tap?.invoke(buffer, n)
            } else {
                Thread.sleep(2)
            }
        }
    }

    fun setVolume(volume: Float, muted: Boolean) {
        val v = if (muted) 0f else volume.coerceIn(0f, 1f)
        runCatching { track?.setVolume(v) }
    }

    fun pause() {
        paused = true
        runCatching { track?.pause(); track?.flush() }
    }

    fun resume() {
        paused = false
        runCatching { track?.play() }
    }

    fun release() {
        running = false
        runCatching { thread.join(300) }
        runCatching { track?.stop(); track?.release() }
    }
}
