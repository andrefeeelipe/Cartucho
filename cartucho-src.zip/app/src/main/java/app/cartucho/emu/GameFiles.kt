package app.cartucho.emu

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.system.Os
import app.cartucho.data.Game
import app.cartucho.data.GameScanner
import app.cartucho.data.GameSystem
import app.cartucho.data.Systems
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Transforma um documento do Storage Access Framework em um caminho que o core consegue abrir,
 * sem copiar o arquivo: cria links simbólicos para /proc/self/fd/N. Jogos em .zip de consoles
 * são extraídos para o cache (cores de console não leem zip).
 */
class PreparedGame(val path: String, private val descriptors: List<ParcelFileDescriptor>) {
    fun close() {
        descriptors.forEach { runCatching { it.close() } }
    }
}

class GameFiles(private val context: Context, private val scanner: GameScanner) {

    fun prepare(game: Game, system: GameSystem): PreparedGame {
        val dir = File(context.cacheDir, "run")
        dir.deleteRecursively()
        dir.mkdirs()
        val ext = game.fileName.substringAfterLast('.', "").lowercase()
        val uri = Uri.parse(game.uri)

        if (ext == "zip" && system.id != "arcade") {
            return PreparedGame(extractZip(uri, dir, system), emptyList())
        }

        val fds = ArrayList<ParcelFileDescriptor>()
        val treeUri = game.treeUri?.let { Uri.parse(it) }
        val parent = game.parentDocId

        if (treeUri != null && parent != null && (ext in system.multiFileExtensions || system.id == "arcade")) {
            val siblings = scanner.listChildren(treeUri, parent).filter { !it.isDir }
            val wanted = if (system.id == "arcade") {
                siblings.filter { it.name.equals(game.fileName, true) || it.name.equals("neogeo.zip", true) }
            } else {
                siblings.take(96)
            }
            for (entry in wanted) {
                val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, entry.docId)
                link(docUri, File(dir, entry.name), fds)
            }
            val main = File(dir, game.fileName)
            if (!main.exists()) link(uri, main, fds)
            return PreparedGame(main.absolutePath, fds)
        }

        val target = File(dir, game.fileName)
        link(uri, target, fds)
        return PreparedGame(target.absolutePath, fds)
    }

    private fun link(uri: Uri, linkFile: File, fds: MutableList<ParcelFileDescriptor>) {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Não foi possível abrir o arquivo do jogo.")
        fds.add(pfd)
        if (linkFile.exists()) linkFile.delete()
        Os.symlink("/proc/self/fd/${pfd.fd}", linkFile.absolutePath)
    }

    private fun extractZip(uri: Uri, dir: File, system: GameSystem): String {
        context.contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(raw).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.isDirectory) continue
                    val name = entry.name.substringAfterLast('/')
                    val e = name.substringAfterLast('.', "").lowercase()
                    if (e in system.extensions || Systems.candidatesForExtension(e).any { it.id == system.id }) {
                        val out = File(dir, name)
                        out.outputStream().use { zip.copyTo(it) }
                        return out.absolutePath
                    }
                }
            }
        }
        throw IllegalStateException("O .zip não contém um jogo de ${system.name}.")
    }
}
