package app.cartucho.update

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import app.cartucho.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Uma versão publicada no GitHub. */
data class Release(
    val version: String,
    val notes: List<String>,
    /** Nome do arquivo → link de download. */
    val files: Map<String, String>,
    val sizes: Map<String, Long>,
)

/**
 * Atualização do app pelo GitHub: confere a versão mais nova ao abrir (no máximo a cada 6 horas),
 * baixa o APK certo para o celular e pede ao Android para instalar por cima, sem perder nada.
 */
object Updater {
    private const val API = "https://api.github.com/repos/andrefeeelipe/Cartucho/releases/latest"
    private const val PREFS = "atualizacao"
    private const val EVERY = 6L * 3600 * 1000
    private val http = OkHttpClient.Builder().connectTimeout(12, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    sealed interface State {
        data object Idle : State
        data class Downloading(val percent: Int) : State
        data object Installing : State
        data class Failed(val message: String) : State
    }

    private val _available = MutableStateFlow<Release?>(null)
    /** Versão nova encontrada (null = o app já está na mais nova ou ainda não conferiu). */
    val available: StateFlow<Release?> = _available
    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state

    val current: String get() = BuildConfig.VERSION_NAME

    /** "1.0.89" > "1.0.88": compara número a número. */
    fun isNewer(candidate: String, installed: String): Boolean {
        fun parts(v: String) = v.trim().removePrefix("v").split('.', '-').map { it.toIntOrNull() ?: 0 }
        val a = parts(candidate)
        val b = parts(installed)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** Confere no GitHub. Bloqueante na rede: chame numa corrotina. */
    suspend fun check(context: Context, force: Boolean = false): Release? = withContext(Dispatchers.IO) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val last = prefs.getLong("conferido", 0L)
        val cached = prefs.getString("json", null)
        val json = if (!force && cached != null && System.currentTimeMillis() - last < EVERY) cached else {
            runCatching {
                http.newCall(Request.Builder().url(API).header("Accept", "application/vnd.github+json").build()).execute().use { r ->
                    if (r.isSuccessful) r.body?.string() else null
                }
            }.getOrNull()?.also { prefs.edit().putLong("conferido", System.currentTimeMillis()).putString("json", it).apply() } ?: cached
        } ?: return@withContext null
        val release = runCatching { parse(JSONObject(json)) }.getOrNull()
        val newer = release?.takeIf { isNewer(it.version, current) }
        _available.value = newer
        newer
    }

    private fun parse(o: JSONObject): Release {
        val files = LinkedHashMap<String, String>()
        val sizes = HashMap<String, Long>()
        val assets = o.optJSONArray("assets")
        if (assets != null) for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            files[a.optString("name")] = a.optString("browser_download_url")
            sizes[a.optString("name")] = a.optLong("size")
        }
        return Release(o.optString("tag_name").removePrefix("v"), notesOf(o.optString("body")), files, sizes)
    }

    /** Os itens da seção "Novidades" das notas da versão (até 4). */
    fun notesOf(body: String): List<String> {
        val lines = body.lines()
        val start = lines.indexOfFirst { it.contains("Novidades", ignoreCase = true) }
        if (start < 0) return emptyList()
        return lines.drop(start + 1)
            .dropWhile { it.isBlank() }
            .takeWhile { it.trimStart().startsWith("- ") || it.trimStart().startsWith("* ") }
            .map { it.trimStart().drop(2).replace("**", "").trim() }
            .filter { it.isNotEmpty() }
            .take(4)
    }

    /** O APK feito para este celular (64 bits, 32 bits, x86_64) ou, na dúvida, o universal. */
    fun apkFor(release: Release): Pair<String, String>? {
        val abis = Build.SUPPORTED_ABIS.toList()
        val order = abis.mapNotNull { abi -> listOf("arm64-v8a", "armeabi-v7a", "x86_64").firstOrNull { it == abi } } + "universal"
        for (abi in order) {
            val name = release.files.keys.firstOrNull { it.endsWith("-$abi.apk") } ?: continue
            return name to release.files.getValue(name)
        }
        return null
    }

    /** O Android deixa o Cartucho instalar a atualização? (No Android 8+ a pessoa libera uma vez nos ajustes.) */
    fun canInstall(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /**
     * Baixa o APK direto para dentro de uma sessão de instalação do Android (sem cópia extra) e pede para instalar.
     * Jogos, saves e ajustes continuam: é a mesma assinatura, o Android só troca o app.
     */
    suspend fun install(context: Context, release: Release) = withContext(Dispatchers.IO) {
        val (name, url) = apkFor(release) ?: run {
            _state.value = State.Failed("Não achei o arquivo desta versão para o seu celular. Tente de novo em alguns minutos.")
            return@withContext
        }
        _state.value = State.Downloading(0)
        val installer = context.packageManager.packageInstaller
        var sessionId = -1
        try {
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            params.setAppPackageName(context.packageName)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            sessionId = installer.createSession(params)
            installer.openSession(sessionId).use { session ->
                http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    if (!r.isSuccessful) throw IllegalStateException("O download falhou (${r.code}).")
                    val body = r.body ?: throw IllegalStateException("O download veio vazio.")
                    val total = body.contentLength().takeIf { it > 0 } ?: (release.sizes[name] ?: -1L)
                    session.openWrite(name, 0, total).use { out ->
                        body.byteStream().use { input ->
                            val buf = ByteArray(1 shl 16)
                            var done = 0L
                            var last = -1
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (total > 0) {
                                    val pct = (done * 100 / total).toInt()
                                    if (pct != last) { last = pct; _state.value = State.Downloading(pct) }
                                }
                            }
                        }
                        session.fsync(out)
                    }
                }
                _state.value = State.Installing
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
                val pi = PendingIntent.getBroadcast(context, sessionId, Intent(context, UpdateReceiver::class.java), flags)
                session.commit(pi.intentSender)
            }
        } catch (e: Exception) {
            if (sessionId >= 0) runCatching { installer.abandonSession(sessionId) }
            _state.value = State.Failed(e.message ?: "Não foi possível atualizar.")
        }
    }

    internal fun finished(message: String?) {
        _state.value = if (message == null) State.Idle else State.Failed(message)
    }

    fun reset() {
        _state.value = State.Idle
    }

    /** "Depois": não insiste nesta versão ao abrir o app (continua em Ajustes). */
    fun dismiss(context: Context, version: String) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("adiada", version).apply()

    fun dismissed(context: Context, version: String): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("adiada", null) == version
}

/** Resposta do Android à instalação: pede a confirmação da pessoa ou avisa o erro. */
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) context.startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            PackageInstaller.STATUS_SUCCESS -> Updater.finished(null)
            PackageInstaller.STATUS_FAILURE_ABORTED -> Updater.finished(null)
            else -> {
                val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
                Updater.finished("O Android não instalou a atualização" + (msg?.let { " ($it)" } ?: "") + ".")
            }
        }
    }
}
