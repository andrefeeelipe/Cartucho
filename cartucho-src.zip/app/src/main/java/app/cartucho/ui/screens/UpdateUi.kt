package app.cartucho.ui.screens

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.widget.VideoView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.cartucho.R
import app.cartucho.update.Release
import app.cartucho.update.Updater
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.theme.Brand
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.Inter
import app.cartucho.ui.theme.SpaceGrotesk
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Mono = FontFamily(Font(R.font.geist_mono, FontWeight.Normal))
/** Cor de fundo dos vídeos de abertura (um tom do roxo da marca). */
private val IntroBackground = Color(0xFF4A3CB7)

/**
 * Abertura do app: o vídeo da fita entrando e os sinais acendendo, com a versão embaixo.
 * Toque para pular. Quem pediu menos movimento no sistema vê só o símbolo por um instante.
 * Não interrompe a música de quem está ouvindo algo, e fica mudo com o celular no silencioso.
 */
@Composable
fun IntroOverlay(onDone: () -> Unit) {
    val context = LocalContext.current
    val alpha = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    val reduced = Cartucho.reducedMotion
    val finished = remember { booleanArrayOf(false) }
    fun finish() {
        if (finished[0]) return
        finished[0] = true
        scope.launch {
            alpha.animateTo(0f, tween(if (reduced) 120 else 260))
            onDone()
        }
    }
    LaunchedEffect(Unit) {
        // O vídeo dura 7 s; a animação e o som terminam aos 6 s.
        delay(if (reduced) 700L else 6200L)
        finish()
    }
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .alpha(alpha.value)
            .background(IntroBackground)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finish() },
    ) {
        val landscape = maxWidth > maxHeight
        if (!reduced) {
            AndroidView(
                factory = { ctx ->
                    VideoView(ctx).apply {
                        setBackgroundColor(android.graphics.Color.TRANSPARENT)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) setAudioFocusRequest(AudioManager.AUDIOFOCUS_NONE)
                        setVideoPath("android.resource://${ctx.packageName}/" + if (landscape) R.raw.intro_land else R.raw.intro)
                        setOnPreparedListener { mp ->
                            if (!soundAllowed(ctx)) mp.setVolume(0f, 0f)
                            start()
                        }
                        setOnCompletionListener { finish() }
                        setOnErrorListener { _, _, _ -> finish(); true }
                    }
                },
                modifier = Modifier.align(Alignment.Center).fillMaxSize(),
            )
        } else {
            Canvas(Modifier.align(Alignment.Center).size(150.dp)) { drawSymbol(this.size.minDimension) }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("v${Updater.current}", style = TextStyle(fontFamily = Mono, fontSize = 12.sp), color = Brand.lavender)
        }
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(10.dp)) {
            listOf(Brand.purple, Brand.lavenderMid, Brand.lavender).forEach { Box(Modifier.weight(1f).fillMaxSize().background(it)) }
        }
    }
}

/** Som só com o celular no modo normal e sem outra música tocando. */
private fun soundAllowed(context: Context): Boolean {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
    if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
    if (am.isMusicActive) return false
    return true
}

/** O símbolo do Cartucho (placa, sulcos, rótulo e sinais), na grade de 100 do Claude Design. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSymbol(side: Float) {
    val k = side / 73f
    val xoff = (side - 70f * k) / 2f
    fun x(v: Float) = (v - 15f) * k + xoff
    fun y(v: Float) = (v - 14f) * k
    val plate = Path().apply {
        moveTo(x(24f), y(16f)); lineTo(x(76f), y(16f)); quadraticBezierTo(x(83f), y(16f), x(83f), y(23f))
        lineTo(x(83f), y(33f)); lineTo(x(77f), y(40f)); lineTo(x(77f), y(82f)); quadraticBezierTo(x(77f), y(85f), x(74f), y(85f))
        lineTo(x(26f), y(85f)); quadraticBezierTo(x(23f), y(85f), x(23f), y(82f)); lineTo(x(23f), y(40f)); lineTo(x(17f), y(33f))
        lineTo(x(17f), y(23f)); quadraticBezierTo(x(17f), y(16f), x(24f), y(16f)); close()
    }
    drawPath(plate, Color(0xFFD2D2DB))
    for (gx in listOf(24f, 29f, 69.6f, 74.6f)) drawRoundRect(Color(0xFFA9A9B8), Offset(x(gx), y(20f)), Size(2.4f * k, 8f * k), CornerRadius(1.2f * k))
    drawRoundRect(Brand.graphite, Offset(x(30f), y(38f)), Size(40f * k, 38f * k), CornerRadius(4f * k))
    listOf(Triple(50f, 49.8f, Brand.dotBlue), Triple(57.2f, 57f, Brand.dotRed), Triple(50f, 64.2f, Brand.dotYellow), Triple(42.8f, 57f, Brand.dotGreen))
        .forEach { (cx, cy, col) -> drawCircle(col, 3.6f * k, Offset(x(cx), y(cy))) }
}

/** Folha "Atualização disponível" (prancheta App · 10 do Claude Design). */
@Composable
fun UpdateSheet(release: Release?, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by Updater.state.collectAsState()
    BottomSheet(visible = release != null, onDismiss = { if (state !is Updater.State.Downloading) onDismiss() }) {
        val r = release ?: return@BottomSheet
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Box(Modifier.fillMaxWidth().padding(top = 4.dp), contentAlignment = Alignment.Center) { VersionCartridge(r.version) }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ATUALIZAÇÃO DISPONÍVEL", style = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, letterSpacing = 0.08.em), color = Brand.purple)
                Text("Tem versão nova do Cartucho.", style = TextStyle(fontFamily = SpaceGrotesk, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 30.sp, letterSpacing = (-0.03).em), color = Brand.ink)
                Text("${Updater.current} → ${r.version}", style = TextStyle(fontFamily = Mono, fontSize = 13.sp), color = Brand.muted2)
            }
            val notes = r.notes.ifEmpty { listOf("Correções de erros", "Mais desempenho", "Ajustes na interface") }
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val dots = listOf(Brand.dotBlue, Brand.dotRed, Brand.dotYellow, Brand.dotGreen)
                notes.forEachIndexed { i, note ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(dots[i % 4]))
                        Spacer(Modifier.width(9.dp))
                        Text(note, style = TextStyle(fontFamily = Inter, fontSize = 15.sp, lineHeight = 20.sp), color = Brand.ink)
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                when (val s = state) {
                    is Updater.State.Downloading -> {
                        ProgressBar(s.percent / 100f)
                        Text("Baixando… ${s.percent}%", style = Cartucho.type.caption, color = Brand.muted2, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    }
                    Updater.State.Installing -> Text(
                        "Confirme a instalação na tela do Android. Seus jogos, saves e ajustes continuam.",
                        style = Cartucho.type.caption, color = Brand.muted2, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                    )
                    else -> {
                        if (s is Updater.State.Failed) Text(s.message, style = Cartucho.type.caption, color = Cartucho.colors.danger, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                        val needsPermission = !Updater.canInstall(context)
                        PrimaryButton(
                            if (needsPermission) "Permitir e atualizar" else if (s is Updater.State.Failed) "Tentar de novo" else "Atualizar agora",
                            {
                                if (!Updater.canInstall(context)) Updater.openInstallPermission(context)
                                else scope.launch { Updater.install(context, r) }
                            },
                            Modifier.fillMaxWidth(),
                        )
                        if (needsPermission) Text(
                            "O Android pede para liberar uma vez: ative \"Permitir desta fonte\" para o Cartucho e volte.",
                            style = Cartucho.type.caption, color = Brand.muted2, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                        )
                        Box(
                            Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(999.dp)).clickable { onDismiss() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("Depois", style = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 15.sp), color = Brand.purple)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressBar(fraction: Float) {
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(99.dp)).background(Brand.lavenderSoft)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(8.dp).clip(RoundedCornerShape(99.dp)).background(Brand.purple))
    }
}

/** O cartucho da atualização: placa cinza com sulcos e, no rótulo, "NOVA VERSÃO", os sinais e o número. */
@Composable
private fun VersionCartridge(version: String) {
    Box(Modifier.size(width = 230.dp, height = 210.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val u = w / 230f
            val plate = Path().apply {
                moveTo(16f * u, 0f); lineTo(w - 16f * u, 0f); quadraticBezierTo(w, 0f, w, 16f * u)
                lineTo(w, 50f * u); lineTo(w - 23f * u, 73f * u); lineTo(w - 23f * u, h - 10f * u); quadraticBezierTo(w - 23f * u, h, w - 33f * u, h)
                lineTo(33f * u, h); quadraticBezierTo(23f * u, h, 23f * u, h - 10f * u); lineTo(23f * u, 73f * u); lineTo(0f, 50f * u)
                lineTo(0f, 16f * u); quadraticBezierTo(0f, 0f, 16f * u, 0f); close()
            }
            drawPath(plate, Color(0xFFD2D2DB))
            for (gx in listOf(23f, 39f, 183f, 199f)) drawRoundRect(Color(0xFFA9A9B8), Offset(gx * u, 13f * u), Size(8f * u, 25f * u), CornerRadius(4f * u))
        }
        Column(
            Modifier
                .padding(start = 39.dp, end = 39.dp, top = 79.dp, bottom = 15.dp)
                .fillMaxSize()
                .clip(RoundedCornerShape(8.dp))
                .background(Brand.graphite)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("NOVA VERSÃO", style = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 9.sp, letterSpacing = 0.08.em), color = Brand.lavender, modifier = Modifier.weight(1f))
                CrossDots()
            }
            Text(version, style = TextStyle(fontFamily = SpaceGrotesk, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 36.sp, letterSpacing = (-0.05).em), color = Color.White, maxLines = 1)
            Text("Android", style = TextStyle(fontFamily = Mono, fontSize = 8.sp), color = Color(0xFFA9A9B8))
        }
    }
}

/** Os quatro sinais em cruz: azul em cima, vermelho à direita, amarelo embaixo, verde à esquerda. */
@Composable
private fun CrossDots() {
    Canvas(Modifier.size(19.dp)) {
        val d = size.width / 3f
        val r = d * 0.36f
        drawCircle(Brand.dotBlue, r, Offset(d * 1.5f, d * 0.5f))
        drawCircle(Brand.dotRed, r, Offset(d * 2.5f, d * 1.5f))
        drawCircle(Brand.dotYellow, r, Offset(d * 1.5f, d * 2.5f))
        drawCircle(Brand.dotGreen, r, Offset(d * 0.5f, d * 1.5f))
    }
}
