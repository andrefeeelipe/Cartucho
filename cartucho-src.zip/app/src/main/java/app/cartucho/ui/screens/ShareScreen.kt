package app.cartucho.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.data.CardFormat
import app.cartucho.data.Game
import app.cartucho.data.GameCard
import app.cartucho.ui.MainActivity
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.ScreenHeader
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SegmentedControl
import app.cartucho.ui.components.Toast
import app.cartucho.ui.theme.Brand
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.Motion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Tela Compartilhar, aberta pela página do jogo. */
@Composable
fun ShareScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val game = activity.shareTarget
    if (game == null) {
        LaunchedEffect(Unit) { activity.back() }
        return
    }
    var notice by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(notice) {
        if (notice != null) {
            delay(3000)
            notice = null
        }
    }
    Box(Modifier.fillMaxSize().background(Cartucho.colors.background).windowInsetsPadding(WindowInsets.safeDrawing)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            ScreenHeader("Compartilhar", onBack = { activity.back() }, backLabel = "Jogo")
            ShareCardContent(app, game, onMessage = { notice = it }, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.height(32.dp))
        }
        AnimatedVisibility(
            visible = notice != null,
            enter = fadeIn(Motion.fade()),
            exit = fadeOut(Motion.fade()),
            modifier = Modifier.align(Alignment.BottomCenter).padding(20.dp),
        ) { Toast(notice ?: "") }
    }
}

/**
 * Conteúdo de compartilhar: formato (Story, Feed, Link), prévia do card, comentário curto,
 * Compartilhar e Salvar imagem. Usado na biblioteca e no menu do jogo.
 */
@Composable
fun ShareCardContent(app: CartuchoApp, game: Game, onMessage: (String) -> Unit, modifier: Modifier = Modifier) {
    val c = Cartucho.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val formats = CardFormat.values().toList()
    var format by remember { mutableStateOf(GameCard.defaultFormat(context)) }
    var comment by remember { mutableStateOf(app.collection.get(game.id).review.take(120)) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }

    // Redesenha quando o formato ou o comentário mudam (espera o dedo parar de digitar).
    LaunchedEffect(format, comment) {
        delay(if (preview == null) 0 else 350)
        val bmp = withContext(Dispatchers.IO) {
            runCatching { GameCard.renderCard(app, GameCard.buildData(app, game, comment), format) }.getOrNull()
        }
        preview = bmp
    }

    fun act(save: Boolean) {
        val bmp = preview ?: return
        if (busy) return
        busy = true
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    if (save) GameCard.saveToGallery(app, bmp, game.title)
                    else GameCard.writeCache(app, bmp, game.id + "-" + format.name.lowercase()).let { f -> withContext(Dispatchers.Main) { GameCard.share(context, f) }; true }
                }.getOrDefault(false)
            }
            busy = false
            if (save) onMessage(if (ok) "Imagem salva em Imagens › Cartucho." else "Não foi possível salvar a imagem.")
            else if (!ok) onMessage("Não foi possível gerar o card.")
        }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SegmentedControl(formats.map { it.label }, formats.indexOf(format), { format = formats[it] })

        // Prévia: o card inteiro, do jeito que vai sair.
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surfaceRaised).padding(16.dp),
            contentAlignment = Alignment.Center,
        ) {
            val maxH = if (format == CardFormat.STORY) 420.dp else 340.dp
            Box(
                Modifier
                    .heightIn(max = maxH)
                    .aspectRatio(format.width.toFloat() / format.height)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brand.surface)
                    .border(1.dp, c.border, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center,
            ) {
                val bmp = preview
                if (bmp != null && bmp.width == format.width && bmp.height == format.height) {
                    Image(bmp.asImageBitmap(), contentDescription = "Prévia do card", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                } else {
                    CircularProgressIndicator(color = c.accent, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                }
            }
        }

        Column {
            Text("Seu comentário", style = Cartucho.type.label.copy(fontSize = 14.sp), color = c.text)
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 76.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.surface)
                    .border(1.dp, if (c.isDark) c.border else Brand.line, RoundedCornerShape(12.dp))
                    .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 12.dp),
            ) {
                Row(Modifier.fillMaxWidth()) {
                    Box(Modifier.weight(1f)) {
                        if (comment.isEmpty()) Text("Escreva uma frase curta…", style = Cartucho.type.body, color = c.textSecondary)
                        BasicTextField(
                            value = comment,
                            onValueChange = { comment = it.replace('\n', ' ').take(120) },
                            textStyle = Cartucho.type.body.copy(color = c.text),
                            cursorBrush = SolidColor(c.accent),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    Spacer(Modifier.size(8.dp))
                    Text("${comment.length}/120", style = Cartucho.type.caption.copy(fontSize = 12.sp, fontWeight = FontWeight.Medium), color = c.textSecondary)
                }
            }
        }

        PrimaryButton("Compartilhar", { act(save = false) }, Modifier.fillMaxWidth(), icon = R.drawable.ic_upload, enabled = preview != null && !busy)
        SecondaryButton("Salvar imagem", { act(save = true) }, Modifier.fillMaxWidth(), icon = R.drawable.ic_image, enabled = preview != null && !busy)
    }
}
