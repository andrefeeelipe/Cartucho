package app.cartucho.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.cartucho.CartuchoApp
import app.cartucho.achievements.AchievementCache
import app.cartucho.data.Game
import app.cartucho.data.GameFacts
import app.cartucho.data.GameFactsRepo
import app.cartucho.data.PlayStatus
import app.cartucho.data.Systems
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.pressable
import app.cartucho.ui.theme.Brand
import app.cartucho.ui.theme.Cartucho
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Uma prateleira da estante: um título e os jogos em pé, mostrando a lombada. */
data class Shelf(val title: String, val groups: List<List<Game>>)

/** Monta as prateleiras: primeiro os zerados (troféus), depois uma por console. */
fun buildShelves(app: CartuchoApp, groups: List<List<Game>>): List<Shelf> {
    val out = ArrayList<Shelf>()
    val beaten = groups.filter { g ->
        val st = app.collection.get(g.first().id).status
        st == PlayStatus.BEATEN || st == PlayStatus.PLATINUM
    }
    if (beaten.isNotEmpty()) out += Shelf("Zerados", beaten)
    for (s in Systems.all) {
        val list = groups.filter { it.first().systemId == s.id }.sortedBy { it.first().title.lowercase() }
        if (list.isNotEmpty()) out += Shelf(s.name, list)
    }
    val unknown = groups.filter { g -> Systems.get(g.first().systemId) == null }
    if (unknown.isNotEmpty()) out += Shelf("Outros", unknown)
    return out
}

/** Uma prateleira: a fila de lombadas e a tábua embaixo. */
@Composable
fun ShelfRow(app: CartuchoApp, shelf: Shelf, coverVersion: Int, onOpen: (List<Game>) -> Unit) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(shelf.title, style = Cartucho.type.headline.copy(fontSize = 17.sp), color = c.text, modifier = Modifier.weight(1f))
            Text("${shelf.groups.size}", style = Cartucho.type.caption, color = c.textSecondary)
        }
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
            items(shelf.groups, key = { it.first().id }) { group -> Spine(app, group.first(), coverVersion) { onOpen(group) } }
        }
        // A tábua da prateleira.
        Box(
            Modifier.fillMaxWidth().height(12.dp).shadow(4.dp, RoundedCornerShape(3.dp))
                .clip(RoundedCornerShape(3.dp))
                .background(Brush.verticalGradient(listOf(Brand.lavender, Brand.purple.copy(alpha = 0.55f)))),
        )
    }
}

/** Cor da lombada: a cor média da capa, um pouco mais escura para o título aparecer. */
private fun spineColor(bmp: ImageBitmap?): Color {
    if (bmp == null) return Brand.purple
    return runCatching {
        val one = android.graphics.Bitmap.createScaledBitmap(bmp.asAndroidBitmap(), 1, 1, true).getPixel(0, 0)
        val r = (one shr 16) and 0xFF
        val g = (one shr 8) and 0xFF
        val b = one and 0xFF
        Color(r * 0.78f / 255f, g * 0.78f / 255f, b * 0.78f / 255f)
    }.getOrDefault(Brand.purple)
}

/** Texto em pé (de baixo para cima), como na lombada de uma caixa. */
private fun Modifier.vertical() = layout { measurable, constraints ->
    val p = measurable.measure(Constraints(maxWidth = constraints.maxHeight, maxHeight = constraints.maxWidth))
    layout(p.height, p.width) { p.place(-(p.width - p.height) / 2, (p.width - p.height) / 2) }
}.graphicsLayer { rotationZ = -90f }

@Composable
private fun Spine(app: CartuchoApp, game: Game, coverVersion: Int, onClick: () -> Unit) {
    val cover by produceState<ImageBitmap?>(null, game.id, coverVersion) {
        value = withContext(Dispatchers.IO) { loadCover(app.covers.file(game.id)) }
    }
    val color = remember(cover) { spineColor(cover) }
    val light = (color.red * 0.3f + color.green * 0.59f + color.blue * 0.11f) > 0.62f
    val ink = if (light) Color(0xFF1E1E24) else Color.White
    val system = Systems.get(game.systemId)
    Box(
        Modifier.width(44.dp).height(196.dp).shadow(3.dp, RoundedCornerShape(5.dp))
            .clip(RoundedCornerShape(5.dp)).background(color)
            .pressable(shape = RoundedCornerShape(5.dp), onClick = onClick)
            .semantics { contentDescription = game.title },
    ) {
        // Faixa de cima com as cores do Cartucho, como a marca na lombada.
        Row(Modifier.align(Alignment.TopCenter).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (dot in listOf(Brand.dotRed, Brand.dotYellow, Brand.dotGreen, Brand.dotBlue)) Box(Modifier.size(5.dp).clip(RoundedCornerShape(50)).background(dot))
        }
        Box(Modifier.align(Alignment.Center).padding(vertical = 22.dp)) {
            Text(
                game.title,
                style = Cartucho.type.title.copy(fontSize = 14.sp, lineHeight = 15.sp),
                color = ink,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 150.dp).vertical(),
            )
        }
        Text(
            system?.short ?: "",
            style = Cartucho.type.mono.copy(fontSize = 9.sp),
            color = ink.copy(alpha = 0.8f),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 7.dp),
        )
    }
}

/**
 * A caixa tirada da prateleira: frente com a capa, verso (gira com um toque) com as informações
 * de colecionador do jogo e do jogador.
 */
@Composable
fun BoxView(
    app: CartuchoApp,
    group: List<Game>,
    coverVersion: Int,
    onClose: () -> Unit,
    onPlay: (Game) -> Unit,
    onDetails: (List<Game>) -> Unit,
) {
    val c = Cartucho.colors
    val game = group.first()
    val system = Systems.get(game.systemId)
    var flipped by remember { mutableStateOf(false) }
    val angle by animateFloatAsState(if (flipped) 180f else 0f, tween(520), label = "virar")
    val cover by produceState<ImageBitmap?>(null, game.id, coverVersion) {
        value = withContext(Dispatchers.IO) { loadCover(app.covers.file(game.id)) }
    }
    val stats by produceState(Triple(0L, 0 to 0, 0L), game.id) {
        value = withContext(Dispatchers.IO) {
            val sessions = app.collection.sessions().filter { s -> group.any { it.id == s.gameId } }
            val seconds = sessions.sumOf { it.seconds }
            val ach = AchievementCache.load(app, game.id)
            Triple(seconds, ach.count { it.unlocked } to ach.size, sessions.minOfOrNull { it.start } ?: 0L)
        }
    }
    val facts by produceState<GameFacts?>(null, game.id) {
        value = withContext(Dispatchers.IO) { runCatching { GameFactsRepo.load(app, game, system?.name ?: "") }.getOrNull() }
    }
    val entry = app.collection.get(game.id)
    val uri = LocalUriHandler.current

    Box(
        Modifier.fillMaxSize().background(Color(0xCC14141A))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(20.dp)) {
            Box(
                Modifier.widthIn(max = 320.dp).fillMaxWidth().aspectRatio(0.72f)
                    .graphicsLayer {
                        rotationY = angle
                        cameraDistance = 14f * density
                    }
                    .shadow(16.dp, RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { flipped = !flipped },
            ) {
                if (angle <= 90f) {
                    // Frente: a capa.
                    Box(Modifier.fillMaxSize().background(c.placeholder), contentAlignment = Alignment.Center) {
                        val bmp = cover
                        if (bmp != null) Image(bmp, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        else Text(game.title, style = Cartucho.type.title, color = Brand.purpleDark, textAlign = TextAlign.Center, modifier = Modifier.padding(20.dp))
                    }
                } else {
                    // Verso (desenhado de trás para frente para ler direito depois do giro).
                    Column(
                        Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }.background(c.surface)
                            .border(1.dp, c.border, RoundedCornerShape(14.dp))
                            .verticalScroll(rememberScrollState()).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(game.title, style = Cartucho.type.title.copy(fontSize = 20.sp, lineHeight = 23.sp), color = c.text)
                        val f = facts
                        val line = listOfNotNull(
                            system?.name,
                            f?.year?.takeIf { it.isNotBlank() },
                        ).joinToString(" · ")
                        Text(line, style = Cartucho.type.caption, color = c.textSecondary)
                        // Do jogador.
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            BackStat(hoursText(stats.first), "jogado")
                            if (stats.second.second > 0) BackStat("${stats.second.first}/${stats.second.second}", "conquistas")
                            if (entry.rating > 0) BackStat("${entry.rating / 2.0}".replace(".0", "").replace('.', ','), "nota")
                        }
                        if (stats.third > 0) {
                            val d = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale("pt", "BR")).format(java.util.Date(stats.third))
                            Text("Na sua coleção desde $d", style = Cartucho.type.caption, color = c.textSecondary)
                        }
                        // Do jogo (Wikidata + Wikipédia).
                        when {
                            f == null -> Text("Buscando a ficha do jogo…", style = Cartucho.type.caption, color = c.textSecondary)
                            !f.found -> Text("Sem ficha de colecionador para este jogo ainda.", style = Cartucho.type.caption, color = c.textSecondary)
                            else -> {
                                FactRow("Desenvolvido por", f.developers.joinToString(", "))
                                FactRow("Publicado por", f.publishers.joinToString(", "))
                                FactRow("Gênero", f.genres.joinToString(", "))
                                FactRow("Série", f.series)
                                if (f.summary.isNotBlank()) {
                                    Text(f.summary, style = Cartucho.type.body.copy(fontSize = 14.sp, lineHeight = 20.sp), color = c.text)
                                }
                                Text(
                                    "Fonte: Wikipédia (${f.sourceTitle}), texto sob licença CC BY-SA · dados: Wikidata",
                                    style = Cartucho.type.caption.copy(fontSize = 11.sp),
                                    color = c.accent,
                                    modifier = Modifier.pressable(shape = RoundedCornerShape(6.dp)) { runCatching { uri.openUri(f.sourceUrl) } },
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(if (flipped) "Toque na caixa para ver a capa" else "Toque na caixa para ver o verso", style = Cartucho.type.caption, color = Color.White.copy(alpha = 0.75f))
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.widthIn(max = 360.dp)) {
                PrimaryButton("Jogar", { onPlay(game) }, Modifier.weight(1f))
                SecondaryButton("Página do jogo", { onDetails(group) }, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun BackStat(value: String, label: String) {
    val c = Cartucho.colors
    Column {
        Text(value, style = Cartucho.type.title.copy(fontSize = 18.sp), color = c.accent)
        Text(label, style = Cartucho.type.caption.copy(fontSize = 11.sp), color = c.textSecondary)
    }
}

@Composable
private fun FactRow(label: String, value: String) {
    if (value.isBlank()) return
    val c = Cartucho.colors
    Column {
        Text(label.uppercase(), style = Cartucho.type.mono.copy(fontSize = 10.sp), color = c.textSecondary)
        Text(value, style = Cartucho.type.body.copy(fontSize = 14.sp, fontWeight = FontWeight.Medium), color = c.text)
    }
}

private fun hoursText(seconds: Long): String = when {
    seconds <= 0 -> "0 min"
    seconds < 3600 -> "${seconds / 60} min"
    else -> "${seconds / 3600}h ${(seconds % 3600) / 60}min"
}
