package app.cartucho.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.data.Game
import app.cartucho.data.Patches
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SheetAction
import app.cartucho.ui.theme.Cartucho
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Hacks e traduções de um jogo: escolher o patch ativo, adicionar de um arquivo,
 * baixar por link ou procurar na web. O jogo original nunca é alterado.
 */
@Composable
fun HackSheet(app: CartuchoApp, game: Game?, onDismiss: () -> Unit, onMessage: (String) -> Unit) {
    val c = Cartucho.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    var showLink by remember { mutableStateOf(false) }
    var link by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(game?.id) {
        showLink = false
        link = ""
        error = null
    }

    val current = game?.let { g -> app.library.find(g.id) ?: g }
    val patches = remember(current?.id, refresh) { current?.let { Patches.list(app, it.id) }.orEmpty() }

    fun activate(name: String) {
        val g = current ?: return
        app.library.setPatch(g.id, name)
        refresh++
        onMessage(if (name.isEmpty()) "Jogando a versão original" else "Patch ativo: $name")
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val g = current
        if (uri == null || g == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            error = null
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
                    if (cur.moveToFirst()) cur.getString(0) else null
                }
            }.getOrNull() ?: "patch"
            val result = withContext(Dispatchers.IO) { runCatching { Patches.installFromUri(app, g.id, uri, name) } }
            busy = false
            result.onSuccess { activate(it.name) }.onFailure { error = it.message }
        }
    }

    BottomSheet(visible = game != null, onDismiss = onDismiss) {
        val g = current ?: return@BottomSheet
        Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState())) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                Text("Hacks e traduções", style = Cartucho.type.title, color = c.text)
                Text(
                    "${g.title}. O arquivo original não é alterado: o patch é aplicado numa cópia.",
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                )
            }
            Spacer(Modifier.height(6.dp))
            SheetAction(
                "Jogo original", if (g.patch.isEmpty()) R.drawable.ic_check else R.drawable.ic_play,
                { activate("") },
                subtitle = if (g.patch.isEmpty()) "Em uso" else null,
            )
            patches.forEach { f ->
                SheetAction(
                    f.name, if (g.patch == f.name) R.drawable.ic_check else R.drawable.ic_play,
                    { activate(f.name) },
                    subtitle = if (g.patch == f.name) "Em uso · toque em Remover abaixo para apagar" else "Toque para usar",
                )
            }
            if (g.patch.isNotEmpty()) {
                SheetAction("Remover o patch em uso", R.drawable.ic_trash, {
                    Patches.remove(app, g.id, g.patch)
                    activate("")
                }, danger = true)
            }

            Spacer(Modifier.height(8.dp))
            SheetAction("Adicionar de um arquivo", R.drawable.ic_file_plus, { picker.launch(arrayOf("*/*")) }, enabled = !busy, subtitle = ".ips, .ups, .bps ou um .zip/.7z/.rar com o patch")
            SheetAction("Baixar por link", R.drawable.ic_cloud, { showLink = !showLink }, enabled = !busy, subtitle = "Cole o link direto do patch")
            SheetAction("Procurar hacks na internet", R.drawable.ic_search, {
                val q = Uri.encode("${g.title} rom hack OR tradução patch ips bps")
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")))
                }
            }, subtitle = "Abre o navegador. Depois copie o link do patch e use \"Baixar por link\".")

            if (showLink) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(c.surfaceRaised)
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.weight(1f)) {
                            if (link.isEmpty()) Text("https://…", style = Cartucho.type.body, color = c.textSecondary)
                            BasicTextField(
                                value = link,
                                onValueChange = { link = it },
                                singleLine = true,
                                textStyle = Cartucho.type.body.copy(color = c.text),
                                cursorBrush = SolidColor(c.accent),
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    PrimaryButton(if (busy) "Baixando…" else "Baixar e aplicar", {
                        if (busy || link.isBlank()) return@PrimaryButton
                        busy = true
                        error = null
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { runCatching { Patches.installFromUrl(app, g.id, link) } }
                            busy = false
                            result.onSuccess {
                                link = ""
                                showLink = false
                                activate(it.name)
                            }.onFailure { error = it.message ?: "Não foi possível baixar." }
                        }
                    }, Modifier.fillMaxWidth(), enabled = !busy)
                    Spacer(Modifier.height(6.dp))
                    SecondaryButton("Colar da área de transferência", {
                        val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                        cm?.primaryClip?.getItemAt(0)?.text?.toString()?.let { link = it.trim() }
                    }, Modifier.fillMaxWidth())
                }
            }

            error?.let {
                Text(it, style = Cartucho.type.caption, color = c.danger, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            }
            Text(
                "Use o patch feito para a mesma versão (região) do seu jogo. Patches .xdelta e .ppf (comuns em jogos de CD) ainda não são suportados.",
                style = Cartucho.type.caption,
                color = c.textSecondary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
            )
        }
    }
}
