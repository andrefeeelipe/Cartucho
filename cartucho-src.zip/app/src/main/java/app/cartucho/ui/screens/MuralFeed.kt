package app.cartucho.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.cartucho.CartuchoApp
import app.cartucho.achievements.RaComment
import app.cartucho.achievements.RaWeb
import app.cartucho.social.Interaction
import app.cartucho.social.Mural
import app.cartucho.social.Post
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.theme.Cartucho
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest

/**
 * Mural: o que você e quem você segue no RetroAchievements estão jogando, zeraram ou platinaram,
 * com curtidas, emojis e comentários.
 */
@Composable
fun MuralFeed(app: CartuchoApp, me: String, key: String, friends: List<String>?) {
    val c = Cartucho.colors
    val context = LocalContext.current
    val mural = app.mural
    val version by mural.version.collectAsState()
    var posts by remember { mutableStateOf<List<Post>?>(null) }
    var wall by remember { mutableStateOf<List<RaComment>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(me, friends) {
        val list = friends ?: return@LaunchedEffect
        val web = RaWeb(me, key)
        runCatching { mural.feed(web, me, list) }
            .onSuccess { posts = it; error = null }
            .onFailure { error = it.message ?: "Não foi possível carregar o mural." }
        wall = withContext(Dispatchers.IO) { runCatching { web.wall(me, 5) }.getOrDefault(emptyList()) }
    }
    // Reações e comentários: busca agora e a cada 20 s enquanto o mural estiver aberto.
    LaunchedEffect(posts) {
        val owners = posts?.map { it.user }?.distinct() ?: return@LaunchedEffect
        while (true) {
            mural.sync(owners)
            mural.notifiedUntil = System.currentTimeMillis()  // já está vendo: não precisa avisar
            delay(20_000)
        }
    }
    LaunchedEffect(Unit) { Mural.schedule(context) }

    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NotificationAsk()
        val news = remember(version) { mural.news(me).take(8) }
        if (news.isNotEmpty()) {
            Label("Novidades")
            ListGroup {
                news.forEachIndexed { i, n ->
                    if (i > 0) Divider()
                    NewsRow(n)
                }
            }
        }
        if (wall.isNotEmpty()) {
            Label("Recados no seu perfil do RetroAchievements")
            ListGroup {
                wall.forEachIndexed { i, w ->
                    if (i > 0) Divider()
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                        Text("${w.user} · ${ago(w.at)}", style = Cartucho.type.caption, color = c.textSecondary)
                        Text(w.text, style = Cartucho.type.body, color = c.text)
                    }
                }
            }
        }
        val list = posts
        when {
            error != null -> Text(error ?: "", style = Cartucho.type.body, color = c.textSecondary)
            list == null -> Text("Carregando o mural…", style = Cartucho.type.body, color = c.textSecondary)
            list.isEmpty() -> Text(
                "Nada por aqui ainda. Jogue algo com o RetroAchievements ligado, ou siga amigos no site: o que vocês jogam e zeram aparece aqui.",
                style = Cartucho.type.body,
                color = c.textSecondary,
            )
            else -> {
                Label("Mural")
                list.forEach { post -> PostCard(app, post, me, version) }
            }
        }
        Text(
            "Curtidas e comentários chegam na hora para quem estiver com o app aberto, e o Cartucho avisa quando alguém interagir com você. " +
                "Quem passar mais de 12 horas sem abrir o app pode perder alguma.",
            style = Cartucho.type.caption,
            color = c.textSecondary,
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun Label(text: String) {
    Text(text.uppercase(), style = Cartucho.type.mono, color = Cartucho.colors.textSecondary, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
}

@Composable
private fun NotificationAsk() {
    if (Build.VERSION.SDK_INT < 33) return
    val c = Cartucho.colors
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    if (granted) return
    ListGroup {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Saber quando curtirem", style = Cartucho.type.headline, color = c.text)
            Text("Receba um aviso quando um amigo reagir ou comentar no que você jogou.", style = Cartucho.type.caption, color = c.textSecondary)
            SecondaryButton("Ativar avisos", { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun NewsRow(n: Interaction) {
    val c = Cartucho.colors
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (n.type == "c") "💬" else n.value, fontSize = 20.sp, modifier = Modifier.width(34.dp))
        Column(Modifier.weight(1f)) {
            Text(Mural.describe(n), style = Cartucho.type.body, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (n.type == "c") Text("“${n.value}”", style = Cartucho.type.caption, color = c.textSecondary, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        Text(ago(n.at), style = Cartucho.type.caption, color = c.textSecondary)
    }
}

@Composable
private fun PostCard(app: CartuchoApp, post: Post, me: String, version: Int) {
    val c = Cartucho.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val mural = app.mural
    val reactions = remember(version, post.id) { mural.reactions(post.id) }
    val mine = remember(version, post.id) { mural.myReaction(post.id, me) }
    val comments = remember(version, post.id) { mural.comments(post.id) }
    var showAll by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    val isMe = post.user.equals(me, true)

    ListGroup {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RemoteImage(post.avatar, Modifier.size(32.dp).clip(CircleShape))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        (if (isMe) "Você" else post.user) + " " + post.verb + if (post.kind == "platinou") " 🏆" else "",
                        style = Cartucho.type.body.copy(fontWeight = FontWeight.Medium),
                        color = c.text,
                    )
                    Text(ago(post.game.at), style = Cartucho.type.caption, color = c.textSecondary)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RemoteImage(post.game.icon, Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(post.game.title, style = Cartucho.type.headline, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(post.game.console, style = Cartucho.type.caption, color = c.textSecondary)
                    if (post.detail.isNotBlank()) {
                        Text(post.detail, style = Cartucho.type.caption, color = c.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            // Reações: toque para reagir, toque de novo para tirar.
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Mural.EMOJIS.forEach { e ->
                    val count = reactions[e]?.size ?: 0
                    val selected = mine == e
                    Row(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(if (selected) c.accent.copy(alpha = 0.18f) else c.surfaceRaised)
                            .border(1.dp, if (selected) c.accent else c.border, RoundedCornerShape(50))
                            .clickable { scope.launch { mural.react(post, me, if (selected) "" else e) } }
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(e, fontSize = 16.sp)
                        if (count > 0) {
                            Spacer(Modifier.width(3.dp))
                            Text("$count", style = Cartucho.type.caption, color = c.text)
                        }
                    }
                }
            }
            val who = reactions.values.flatten().distinct()
            if (who.isNotEmpty()) {
                Text(
                    "Reagiram: " + who.take(4).joinToString(", ") { if (it.equals(me, true)) "você" else it } + if (who.size > 4) " e mais ${who.size - 4}" else "",
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                )
            }
            val shown = if (showAll) comments else comments.takeLast(3)
            if (comments.size > shown.size) {
                Text("Ver os ${comments.size} comentários", style = Cartucho.type.caption, color = c.accent, modifier = Modifier.clickable { showAll = true })
            }
            shown.forEach { cm ->
                Column {
                    Text("${if (cm.from.equals(me, true)) "Você" else cm.from} · ${ago(cm.at)}", style = Cartucho.type.caption, color = c.textSecondary)
                    Text(cm.value, style = Cartucho.type.body, color = c.text)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(c.surfaceRaised).padding(horizontal = 14.dp, vertical = 10.dp),
                ) {
                    if (draft.isEmpty()) Text(if (isMe) "Responder…" else "Comentar…", style = Cartucho.type.body, color = c.textSecondary)
                    BasicTextField(
                        value = draft,
                        onValueChange = { draft = it.take(280) },
                        textStyle = Cartucho.type.body.copy(color = c.text),
                        cursorBrush = SolidColor(c.accent),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (draft.isNotBlank()) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Enviar",
                        style = Cartucho.type.label,
                        color = c.accent,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                            val text = draft
                            draft = ""
                            scope.launch { mural.comment(post, me, text) }
                        }.padding(8.dp),
                    )
                }
            }
            if (!isMe) {
                Text(
                    "Deixar um recado no perfil dele no RetroAchievements",
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                    modifier = Modifier.clickable {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://retroachievements.org/user/${Uri.encode(post.user)}")))
                        }
                    },
                )
            }
        }
    }
}

private fun ago(ms: Long): String {
    if (ms <= 0) return ""
    val s = (System.currentTimeMillis() - ms) / 1000
    return when {
        s < 60 -> "agora"
        s < 3600 -> "há ${s / 60} min"
        s < 86400 -> "há ${s / 3600} h"
        s < 86400 * 30 -> "há ${s / 86400} d"
        else -> "há ${s / (86400 * 30)} meses"
    }
}

// ------------------------------------------------------------ imagens remotas (avatares, ícones)

private val imageCache = LruCache<String, Bitmap>(80)
private val imageHttp by lazy { OkHttpClient() }

@Composable
fun RemoteImage(url: String, modifier: Modifier) {
    val c = Cartucho.colors
    val context = LocalContext.current
    val bmp by produceState<Bitmap?>(imageCache.get(url), url) {
        if (url.isEmpty() || value != null) return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                val name = MessageDigest.getInstance("SHA-1").digest(url.toByteArray()).joinToString("") { "%02x".format(it) }
                val f = File(context.cacheDir, "ra-img/$name")
                if (!f.exists()) {
                    f.parentFile?.mkdirs()
                    imageHttp.newCall(Request.Builder().url(url).build()).execute().use { r ->
                        if (r.isSuccessful) r.body?.bytes()?.let { f.writeBytes(it) }
                    }
                }
                BitmapFactory.decodeFile(f.absolutePath)?.also { imageCache.put(url, it) }
            }.getOrNull()
        }
    }
    Box(modifier.background(c.surfaceRaised)) {
        bmp?.let { Image(it.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
    }
}
