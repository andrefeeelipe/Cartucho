package app.cartucho.ui.screens

import app.cartucho.ui.components.Stripes
import app.cartucho.ui.theme.Brand

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import androidx.compose.ui.unit.sp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.achievements.RetroAchievements
import app.cartucho.cloud.DriveApi
import app.cartucho.cloud.DriveAuth
import app.cartucho.cloud.DriveAuthException
import app.cartucho.cloud.DriveFile
import app.cartucho.cloud.SyncEngine
import app.cartucho.ui.MainActivity
import app.cartucho.ui.Route
import app.cartucho.ui.components.CIcon
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.NavRow
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SectionLabel
import app.cartucho.ui.components.ToggleRow
import app.cartucho.ui.theme.Cartucho
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CloudScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val s by app.prefs.settings.collectAsState()
    val c = Cartucho.colors
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var askConsent by remember { mutableStateOf(false) }

    val recover = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val signIn = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        DriveAuth.parseResult(result.data)
            .onSuccess { account ->
                // Já liga o backup na pasta "Cartucho" do Meu Drive e faz a primeira cópia.
                app.prefs.update {
                    it.copy(
                        driveAccount = account.email ?: "",
                        driveEnabled = true,
                        driveFolderId = it.driveFolderId.ifEmpty { "root" },
                        driveFolderName = it.driveFolderName.ifEmpty { "Meu Drive" },
                    )
                }
                message = "Backup ligado. Os saves vão para Meu Drive / Cartucho."
                busy = true
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { SyncEngine(app).sync(app.prefs.current.driveFolderId) } }
                    busy = false
                    r.onSuccess { rep ->
                        app.prefs.update { it.copy(lastSync = System.currentTimeMillis(), lastSyncError = "") }
                        message = "Backup ligado. Primeira cópia: ${rep.uploaded} enviados, ${rep.downloaded} baixados."
                    }.onFailure { e ->
                        (e as? DriveAuthException)?.recoverIntent?.let { recover.launch(it) }
                        app.prefs.update { it.copy(lastSyncError = e.message ?: "Erro") }
                        message = e.message
                    }
                }
            }
            .onFailure { message = it.message }
    }

    SettingsPage(
        "Nuvem",
        onBack = { activity.back() },
        subtitle = "Seus saves ficam sempre no celular. O Google Drive guarda uma cópia, na pasta que você escolher.",
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(16.dp))
                if (message != null) {
                    ListGroup {
                        Text(message ?: "", style = Cartucho.type.body, color = c.text, modifier = Modifier.padding(16.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                }
                if (askConsent) {
                    ListGroup {
                        Column(Modifier.padding(16.dp)) {
                            Text("Conectar ao Google Drive", style = Cartucho.type.title, color = c.text)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Você escolhe qual conta Google usar. Em seguida o Google mostra a tela de permissão: " +
                                    "o Cartucho só poderá ver e alterar os arquivos que ele mesmo criar no seu Drive (a pasta \"Cartucho\" com seus saves). " +
                                    "Ele não vê suas fotos, documentos nem outros arquivos. Você pode desconectar quando quiser, aqui ou em myaccount.google.com.",
                                style = Cartucho.type.body,
                                color = c.textSecondary,
                            )
                            Spacer(Modifier.height(14.dp))
                            PrimaryButton("Aceitar e escolher a conta", {
                                askConsent = false
                                // Sempre mostra a escolha de conta (sem reaproveitar um login anterior).
                                DriveAuth.client(activity).signOut().addOnCompleteListener {
                                    signIn.launch(DriveAuth.client(activity).signInIntent)
                                }
                            }, Modifier.fillMaxWidth())
                            Spacer(Modifier.height(8.dp))
                            SecondaryButton("Agora não", { askConsent = false }, Modifier.fillMaxWidth())
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                ListGroup {
                    ToggleRow(
                        "Backup no Google Drive",
                        s.driveEnabled,
                        { on ->
                            message = null
                            if (on && s.driveAccount.isEmpty()) {
                                // Antes do Google, explica o que será permitido e pede o aceite.
                                askConsent = true
                            } else {
                                app.prefs.update {
                                    it.copy(
                                        driveEnabled = on,
                                        driveFolderId = it.driveFolderId.ifEmpty { "root" },
                                        driveFolderName = it.driveFolderName.ifEmpty { "Meu Drive" },
                                    )
                                }
                            }
                        },
                        subtitle = if (s.driveAccount.isNotEmpty()) s.driveAccount else "Desligado",
                    )
                    if (s.driveAccount.isNotEmpty()) {
                        Divider()
                        NavRow("Pasta no Drive", { activity.navigate(Route.DriveFolders) }, value = s.driveFolderName.ifEmpty { "Escolher" })
                        Divider()
                        ToggleRow("Só no Wi-Fi", s.driveWifiOnly, { v -> app.prefs.update { it.copy(driveWifiOnly = v) } })
                    }
                }
                if (s.driveEnabled) {
                    SectionLabel("Status")
                    ListGroup {
                        NavRow("Última sincronização", {}, value = formatDate(s.lastSync), showChevron = false, subtitle = s.lastSyncError.ifEmpty { null })
                    }
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton(if (busy) "Sincronizando…" else "Sincronizar agora", {
                        if (busy) return@PrimaryButton
                        busy = true
                        message = null
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                runCatching { SyncEngine(app).sync(app.prefs.current.driveFolderId) }
                            }
                            busy = false
                            result.onSuccess { r ->
                                app.prefs.update { it.copy(lastSync = System.currentTimeMillis(), lastSyncError = "") }
                                message = "Pronto: ${r.uploaded} enviados, ${r.downloaded} baixados."
                            }.onFailure { e ->
                                val intent = (e as? DriveAuthException)?.recoverIntent
                                if (intent != null) recover.launch(intent)
                                app.prefs.update { it.copy(lastSyncError = e.message ?: "Erro") }
                                message = e.message
                            }
                        }
                    }, Modifier.fillMaxWidth(), icon = R.drawable.ic_sync, enabled = !busy)
                }
                if (s.driveAccount.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    SecondaryButton("Sair da conta Google", {
                        DriveAuth.signOut(activity)
                        app.prefs.update { it.copy(driveEnabled = false, driveAccount = "", driveFolderId = "", driveFolderName = "") }
                    }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
fun DriveFolderScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val scope = rememberCoroutineScope()
    val path = remember { mutableStateListOf(DriveFile("root", "Meu Drive", true, 0L, null)) }
    var folders by remember { mutableStateOf<List<DriveFile>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var creating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("Cartucho Saves") }
    val recover = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val current = path.last()

    LaunchedEffect(current.id) {
        loading = true
        error = null
        val result = withContext(Dispatchers.IO) { runCatching { DriveApi(DriveAuth.token(app)).listFolders(current.id) } }
        loading = false
        result.onSuccess { folders = it }.onFailure { e ->
            (e as? DriveAuthException)?.recoverIntent?.let { recover.launch(it) }
            error = e.message ?: "Não foi possível abrir o Drive."
        }
    }

    fun choose(folder: DriveFile) {
        app.prefs.update { it.copy(driveFolderId = folder.id, driveFolderName = path.joinToString(" / ") { p -> p.name }, driveEnabled = true) }
        activity.back()
    }

    SettingsPage("Escolher pasta", onBack = {
        if (path.size > 1) path.removeAt(path.lastIndex) else activity.back()
    }, subtitle = path.joinToString(" / ") { it.name }) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(12.dp))
                PrimaryButton("Usar esta pasta", { choose(current) }, Modifier.fillMaxWidth(), icon = R.drawable.ic_check)
                Spacer(Modifier.height(8.dp))
                Text("O Cartucho cria uma subpasta \"Cartucho\" aqui dentro. Por privacidade, o app só enxerga as pastas que ele mesmo criou.", style = Cartucho.type.caption, color = c.textSecondary)
                SectionLabel("Pastas")
                ListGroup {
                    when {
                        loading -> Text("Carregando…", style = Cartucho.type.body, color = c.textSecondary, modifier = Modifier.padding(16.dp))
                        error != null -> Text(error ?: "", style = Cartucho.type.body, color = c.danger, modifier = Modifier.padding(16.dp))
                        folders.isEmpty() -> Text("Nenhuma subpasta.", style = Cartucho.type.body, color = c.textSecondary, modifier = Modifier.padding(16.dp))
                        else -> folders.forEachIndexed { i, f ->
                            if (i > 0) Divider()
                            NavRow(f.name, { path.add(f) }, icon = R.drawable.ic_folder)
                        }
                    }
                }
                SectionLabel("Nova pasta")
                ListGroup {
                    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        BasicTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            singleLine = true,
                            textStyle = Cartucho.type.body.copy(color = c.text),
                            cursorBrush = SolidColor(c.accent),
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                SecondaryButton(if (creating) "Criando…" else "Criar e usar", {
                    if (creating || newName.isBlank()) return@SecondaryButton
                    creating = true
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { runCatching { DriveApi(DriveAuth.token(app)).createFolder(newName.trim(), current.id) } }
                        creating = false
                        result.onSuccess { f ->
                            path.add(f)
                            choose(f)
                        }.onFailure { error = it.message }
                    }
                }, Modifier.fillMaxWidth(), icon = R.drawable.ic_folder_plus)
            }
        }
    }
}

@Composable
fun RaScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val s by app.prefs.settings.collectAsState()
    val ra = remember { RetroAchievements.get() }
    val state by ra.state.collectAsState()
    val c = Cartucho.colors
    var user by remember { mutableStateOf(s.raUser) }
    var password by remember { mutableStateOf("") }
    var webKey by remember { mutableStateOf(app.secure.raWebKey) }
    var webKeySaved by remember { mutableStateOf(app.secure.raWebKey.isNotEmpty()) }

    SettingsPage(
        "RetroAchievements",
        onBack = { activity.back() },
        subtitle = "Conquistas para jogos clássicos. É a única função do app que fica online durante o jogo.",
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(16.dp))
                if (s.raEnabled) {
                    ListGroup {
                        NavRow(s.raUser, {}, icon = R.drawable.ic_user, value = "${s.raScore} pts", showChevron = false)
                        Divider()
                        ToggleRow(
                            "Modo hardcore",
                            s.raHardcore,
                            { v -> ra.setHardcore(v) },
                            subtitle = "Vale mais pontos. Desativa carregar estado e avanço rápido.",
                        )
                    }
                    SectionLabel("Ranking com amigos")
                    Text(
                        "Para ver seus amigos e o ranking na Coleção, cole sua Web API Key (retroachievements.org > Configurações > Keys). Ela fica cifrada no aparelho.",
                        style = Cartucho.type.caption,
                        color = c.textSecondary,
                    )
                    Spacer(Modifier.height(8.dp))
                    ListGroup {
                        // Visível enquanto digita; depois de salva fica oculta (toque para editar de novo).
                        InputRow(
                            "API Key",
                            webKey,
                            { webKey = it.trim(); webKeySaved = false },
                            secret = webKeySaved,
                            plainKeyboard = true,
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    SecondaryButton(if (webKeySaved) "Chave salva" else "Salvar chave", {
                        app.secure.raWebKey = webKey
                        webKeySaved = true
                    }, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(16.dp))
                    SecondaryButton("Sair", { ra.logout(); password = "" }, Modifier.fillMaxWidth())
                } else {
                    Text("Entre com sua conta do retroachievements.org. Guardamos só um token cifrado no aparelho, nunca a senha.", style = Cartucho.type.caption, color = c.textSecondary)
                    Spacer(Modifier.height(12.dp))
                    ListGroup {
                        InputRow("Usuário", user, { user = it })
                        Divider()
                        InputRow("Senha", password, { password = it }, secret = true)
                    }
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton(
                        if (state.busy) "Entrando…" else "Entrar",
                        { if (!state.busy && user.isNotBlank() && password.isNotEmpty()) ra.loginWithPassword(user, password) { ok -> if (ok) password = "" } },
                        Modifier.fillMaxWidth(),
                        enabled = !state.busy,
                    )
                    state.message?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, style = Cartucho.type.caption, color = c.danger)
                    }
                }
            }
        }
    }
}

/**
 * Campo de texto de uma linha. [secret] oculta os caracteres; [plainKeyboard] desliga
 * corretor e sugestões (para chaves e códigos, que precisam aparecer exatamente como digitados).
 */
@Composable
private fun InputRow(label: String, value: String, onChange: (String) -> Unit, secret: Boolean = false, plainKeyboard: Boolean = false) {
    val c = Cartucho.colors
    var reveal by remember { mutableStateOf(false) }
    val hidden = secret && !reveal
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = Cartucho.type.body, color = c.text, modifier = Modifier.width(90.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = Cartucho.type.body.copy(color = c.text),
            cursorBrush = SolidColor(c.accent),
            visualTransformation = if (hidden) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(
                autoCorrect = false,
                keyboardType = when {
                    hidden -> KeyboardType.Password
                    plainKeyboard -> KeyboardType.Ascii
                    else -> KeyboardType.Text
                },
            ),
            modifier = Modifier.weight(1f),
        )
        if (secret && value.isNotEmpty()) {
            Text(
                if (reveal) "Ocultar" else "Mostrar",
                style = Cartucho.type.caption,
                color = c.accent,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { reveal = !reveal }.padding(horizontal = 8.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxSize().background(c.background)) {
        Stripes(height = 6.dp)
        Column(
            Modifier.weight(1f).fillMaxWidth().windowInsetsPadding(WindowInsets.safeDrawing).padding(horizontal = 24.dp),
        ) {
            Spacer(Modifier.height(40.dp))
            Box(
                Modifier.size(84.dp).clip(RoundedCornerShape(20.dp)).background(Brand.plate),
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(R.drawable.brand_icon),
                    contentDescription = null,
                    modifier = Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)),
                )
            }
            Spacer(Modifier.height(28.dp))
            Text("Bem-vindo ao Cartucho.", style = Cartucho.type.display.copy(fontSize = 34.sp, lineHeight = 36.sp), color = c.text)
            Spacer(Modifier.height(10.dp))
            Text(
                "Um console para todos os consoles. Sem configuração, é só jogar.",
                style = Cartucho.type.body.copy(fontSize = 17.sp, lineHeight = 25.sp),
                color = c.textSecondary,
            )
            Spacer(Modifier.height(28.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OnboardRow(R.drawable.ic_folder, Brand.purple, "Seus jogos", "Abra os arquivos que são seus. O Cartucho reconhece o console e baixa a capa.")
                OnboardRow(R.drawable.ic_controller, Brand.dotRed, "Qualquer controle", "Conectou, funcionou. Bluetooth, USB ou os botões na tela.")
                OnboardRow(R.drawable.ic_cloud, Brand.dotGreen, "Online só se quiser", "Backup no Google Drive e conquistas ficam em Ajustes. Para jogar, nada precisa de internet.")
            }
            Spacer(Modifier.weight(1f))
            PrimaryButton("Começar", onDone, Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun OnboardRow(icon: Int, color: androidx.compose.ui.graphics.Color, title: String, text: String) {
    val c = Cartucho.colors
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surfaceRaised).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(color), contentAlignment = Alignment.Center) {
            CIcon(icon, tint = androidx.compose.ui.graphics.Color.White, size = 22.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = Cartucho.type.headline.copy(fontSize = 16.sp), color = c.text)
            Text(text, style = Cartucho.type.caption, color = c.textSecondary)
        }
    }
}
