package app.cartucho.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.achievements.RaAwards
import app.cartucho.achievements.RaProfile
import app.cartucho.achievements.RaUnlock
import app.cartucho.achievements.RaWeb
import app.cartucho.data.AvatarKind
import app.cartucho.data.CollectionStore
import app.cartucho.data.PlayStatus
import app.cartucho.data.Profile
import app.cartucho.ui.MainActivity
import app.cartucho.ui.Route
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.BuiltinAvatar
import app.cartucho.ui.components.CIcon
import app.cartucho.ui.components.IconButton
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.ProfileAvatar
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SectionLabel
import app.cartucho.ui.components.SheetAction
import app.cartucho.ui.components.pressable
import app.cartucho.ui.theme.Cartucho
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

/** Perfil: foto, nível, pontos e troféus do RetroAchievements, e números da coleção. */
@Composable
fun ProfileScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val profile by app.profile.data.collectAsState()
    val settings by app.prefs.settings.collectAsState()
    val games by app.library.games.collectAsState()
    val entries by app.collection.entries.collectAsState()
    val scope = rememberCoroutineScope()

    val seconds = remember { app.collection.secondsByGame().values.sum() }
    val beatenLocal = entries.count { it.value.status == PlayStatus.BEATEN || it.value.status == PlayStatus.PLATINUM }
    val raConfigured = settings.raUser.isNotEmpty() && app.secure.raWebKey.isNotEmpty()

    var ra by remember { mutableStateOf<RaProfile?>(null) }
    var awards by remember { mutableStateOf<RaAwards?>(null) }
    var unlocks by remember { mutableStateOf<List<RaUnlock>?>(null) }
    var raError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(raConfigured, settings.raUser) {
        if (!raConfigured) return@LaunchedEffect
        val web = RaWeb(settings.raUser, app.secure.raWebKey)
        withContext(Dispatchers.IO) {
            runCatching { web.profile() }.onSuccess { ra = it }.onFailure { raError = it.message }
            runCatching { web.awards() }.onSuccess { awards = it }
            runCatching { web.unlocks(days = 365) }.onSuccess { unlocks = it }.onFailure { if (unlocks == null) unlocks = emptyList() }
        }
    }

    val points = ra?.points ?: settings.raScore
    val beaten = maxOf(beatenLocal, awards?.beaten ?: 0)
    val (level, progress) = Profile.level(Profile.xp(points, seconds, beaten))
    val displayName = profile.name.ifBlank { ra?.user ?: settings.raUser.ifBlank { "Jogador" } }

    var editing by remember { mutableStateOf(false) }
    var howTo by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { withContext(Dispatchers.IO) { runCatching { app.profile.setPhoto(uri) } } }
    }

    Box(Modifier.fillMaxSize().background(c.background)) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 48.dp)) {
            item {
                // Faixa no topo com o degradê da cor do Cartucho e o avatar por cima.
                Box(Modifier.fillMaxWidth().height(250.dp)) {
                    Box(
                        Modifier.fillMaxWidth().height(170.dp).background(
                            Brush.linearGradient(listOf(c.accent, c.accent.copy(alpha = 0.55f), c.background)),
                        ),
                    ) {
                        PixelSky(Modifier.fillMaxSize())
                    }
                    Box(Modifier.align(Alignment.BottomCenter).size(132.dp), contentAlignment = Alignment.Center) {
                        LevelRing(progress, 132.dp)
                        Box(
                            Modifier.size(112.dp).clip(CircleShape).border(4.dp, c.background, CircleShape)
                                .pressable(shape = CircleShape) { editing = true },
                        ) {
                            ProfileAvatar(profile, app.profile.photoFile, ra?.avatarUrl.orEmpty(), 112.dp)
                        }
                        Box(
                            Modifier.align(Alignment.BottomEnd).offset((-6).dp, (-6).dp).size(32.dp).clip(CircleShape)
                                .background(c.text).pressable(shape = CircleShape) { editing = true },
                            contentAlignment = Alignment.Center,
                        ) { CIcon(R.drawable.ic_camera, tint = c.background, size = 16.dp) }
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(10.dp))
                    Text(displayName, style = Cartucho.type.title, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (settings.raUser.isNotEmpty()) "@${settings.raUser} · RetroAchievements" else "Perfil local",
                        style = Cartucho.type.caption,
                        color = c.textSecondary,
                    )
                    Spacer(Modifier.height(18.dp))
                    // Pontos (como as "moedas" do RetroAchievements) e como ganhar mais.
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(999.dp)).border(1.dp, c.border, RoundedCornerShape(999.dp)),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            Modifier.clip(RoundedCornerShape(999.dp)).background(c.accent).padding(horizontal = 18.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CIcon(R.drawable.ic_trophy, tint = c.onAccent, size = 20.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("%,d".format(points).replace(',', '.'), style = Cartucho.type.headline, color = c.onAccent)
                        }
                        Text(
                            "Como ganhar pontos?",
                            style = Cartucho.type.label,
                            color = c.accent,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f).pressable(shape = RoundedCornerShape(999.dp)) { howTo = true }.padding(vertical = 12.dp),
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Tile("Nível", level.toString(), R.drawable.ic_trophy, Color(0xFF2FA35A), Modifier.weight(1f))
                        Tile("Tempo", CollectionStore.formatHours(seconds), R.drawable.ic_play, Color(0xFF2E6BE8), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Tile("Zerados", beaten.toString(), R.drawable.ic_check, Color(0xFFE0457D), Modifier.weight(1f))
                        Tile("Jogos", games.size.toString(), R.drawable.ic_controller, Color(0xFFE0A100), Modifier.weight(1f))
                    }
                    if (awards != null) {
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Tile("Platinas", awards!!.masteries.toString(), R.drawable.ic_trophy, Color(0xFF8A4FE0), Modifier.weight(1f))
                            Tile("Medalhas", awards!!.total.toString(), R.drawable.ic_trophy, Color(0xFF16A3A3), Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }

            item { SectionLabel("Troféus", Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) }
            when {
                !raConfigured -> item {
                    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "Seus troféus vêm do RetroAchievements: cada conquista desbloqueada nos jogos aparece aqui, com os pontos. " +
                                "Entre na conta e cole a Web API Key para ver tudo.",
                            style = Cartucho.type.body,
                            color = c.textSecondary,
                        )
                        PrimaryButton("Conectar RetroAchievements", { activity.navigate(Route.Achievements) }, Modifier.fillMaxWidth())
                    }
                }
                raError != null && unlocks.isNullOrEmpty() -> item {
                    Text(raError ?: "", style = Cartucho.type.body, color = c.danger, modifier = Modifier.padding(horizontal = 20.dp))
                }
                unlocks == null -> item {
                    Text("Carregando seus troféus…", style = Cartucho.type.body, color = c.textSecondary, modifier = Modifier.padding(horizontal = 20.dp))
                }
                unlocks!!.isEmpty() -> item {
                    Text(
                        "Nenhuma conquista no último ano. Jogue algo com conquistas (o troféu aparece no canto do jogo) e volte aqui.",
                        style = Cartucho.type.body,
                        color = c.textSecondary,
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
                else -> items(unlocks!!.take(60), key = { it.title + it.at }) { u -> UnlockRow(u) }
            }
            item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 20.dp)) {
                    SecondaryButton("Ver coleção e amigos", { activity.navigate(Route.Collection) }, Modifier.fillMaxWidth(), icon = R.drawable.ic_users)
                }
            }
        }
        Row(Modifier.windowInsetsPadding(WindowInsets.safeDrawing).padding(horizontal = 8.dp)) {
            Box(Modifier.clip(CircleShape).background(c.background.copy(alpha = 0.7f))) {
                IconButton(R.drawable.ic_back, "Voltar", { activity.back() })
            }
        }
    }

    // Editar perfil: nome e foto.
    BottomSheet(visible = editing, onDismiss = { editing = false }) {
        var name by remember(editing) { mutableStateOf(profile.name) }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Editar perfil", style = Cartucho.type.title, color = c.text)
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surfaceRaised).padding(horizontal = 14.dp, vertical = 12.dp)) {
                if (name.isEmpty()) Text(ra?.user ?: "Seu nome", style = Cartucho.type.body, color = c.textSecondary)
                BasicTextField(
                    value = name,
                    onValueChange = { name = it.take(24); app.profile.update { p -> p.copy(name = name.trim()) } },
                    singleLine = true,
                    textStyle = Cartucho.type.body.copy(color = c.text),
                    cursorBrush = SolidColor(c.accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        SheetAction("Escolher foto da galeria", R.drawable.ic_camera, {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            editing = false
        })
        if (!ra?.avatarUrl.isNullOrEmpty()) {
            SheetAction("Usar a foto do RetroAchievements", R.drawable.ic_trophy, {
                app.profile.update { it.copy(avatar = AvatarKind.RA) }
                editing = false
            })
        }
        AvatarGrid(selected = if (profile.avatar == AvatarKind.BUILTIN) profile.builtin else -1) { i ->
            app.profile.update { it.copy(avatar = AvatarKind.BUILTIN, builtin = i) }
            editing = false
        }
        Spacer(Modifier.height(12.dp))
    }

    BottomSheet(visible = howTo, onDismiss = { howTo = false }) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Como ganhar pontos", style = Cartucho.type.title, color = c.text)
            Text(
                "Os pontos são do RetroAchievements. Cada jogo tem uma lista de conquistas, como passar de fase, achar um segredo ou zerar sem morrer. " +
                    "Ao desbloquear uma, o troféu aparece na tela e os pontos entram no seu perfil. No modo Hardcore, sem estados salvos e sem câmera lenta, os pontos valem mais.",
                style = Cartucho.type.body,
                color = c.textSecondary,
            )
            Text(
                "Seu nível aqui no Cartucho junta os pontos, as horas jogadas e os jogos que você zerou.",
                style = Cartucho.type.body,
                color = c.textSecondary,
            )
            PrimaryButton(if (settings.raUser.isEmpty()) "Entrar no RetroAchievements" else "Configurações de conquistas", {
                howTo = false
                activity.navigate(Route.Achievements)
            }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AvatarGrid(selected: Int, onPick: (Int) -> Unit) {
    val c = Cartucho.colors
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text("Avatares do Cartucho", style = Cartucho.type.label, color = c.textSecondary)
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (i in 0 until Profile.AVATARS) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape)
                        .border(if (i == selected) 3.dp else 0.dp, c.text, CircleShape)
                        .pressable(shape = CircleShape) { onPick(i) },
                ) { BuiltinAvatar(i, Modifier.fillMaxSize()) }
            }
        }
    }
}

@Composable
private fun Tile(label: String, value: String, icon: Int, tint: Color, modifier: Modifier) {
    val c = Cartucho.colors
    Row(
        modifier.clip(RoundedCornerShape(20.dp)).background(tint.copy(alpha = 0.10f)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(c.background), contentAlignment = Alignment.Center) {
            CIcon(icon, tint = tint, size = 22.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(label, style = Cartucho.type.caption, color = c.textSecondary)
            Text(value, style = Cartucho.type.headline, color = c.text, maxLines = 1)
        }
    }
}

@Composable
private fun UnlockRow(u: RaUnlock) {
    val c = Cartucho.colors
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        RemoteImage(u.badge, Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(u.title, style = Cartucho.type.headline, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                listOf(u.game, u.description).filter { it.isNotBlank() }.joinToString(" · "),
                style = Cartucho.type.caption,
                color = c.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            if (u.at > 0) Text(DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(u.at)), style = Cartucho.type.caption, color = c.textSecondary)
        }
        Spacer(Modifier.width(10.dp))
        Text("+${u.points}", style = Cartucho.type.label, color = if (u.hardcore) c.accent else c.text)
    }
}

/** Anel de progresso até o próximo nível, em volta do avatar. */
@Composable
private fun LevelRing(progress: Float, size: Dp) {
    val c = Cartucho.colors
    Canvas(Modifier.size(size)) {
        val stroke = 5.dp.toPx()
        val inset = stroke / 2
        drawArc(c.border, 0f, 360f, false, Offset(inset, inset), Size(this.size.width - stroke, this.size.height - stroke), style = Stroke(stroke))
        drawArc(
            c.accent, -90f, 360f * progress.coerceIn(0.02f, 1f), false, Offset(inset, inset),
            Size(this.size.width - stroke, this.size.height - stroke), style = Stroke(stroke, cap = StrokeCap.Round),
        )
    }
}

/** Estrelas em pixel no céu do topo (decoração discreta, sempre igual). */
@Composable
private fun PixelSky(modifier: Modifier) {
    Canvas(modifier) {
        val r = java.util.Random(42)
        repeat(40) {
            val x = r.nextFloat() * size.width
            val y = r.nextFloat() * size.height * 0.8f
            val s = (if (r.nextInt(5) == 0) 3 else 2).dp.toPx()
            drawRect(Color.White.copy(alpha = 0.25f + r.nextFloat() * 0.4f), Offset(x, y), Size(s, s))
        }
    }
}
