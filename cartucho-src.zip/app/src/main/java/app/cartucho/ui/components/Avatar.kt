package app.cartucho.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import app.cartucho.data.AvatarKind
import app.cartucho.data.ProfileData
import app.cartucho.ui.screens.RemoteImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Random

/** Cores de cada avatar do Cartucho (fundo, criatura, olhos). */
private val AVATAR_COLORS = listOf(
    Triple(0xFFFFE3D3, 0xFFE8572E, 0xFF231A16),
    Triple(0xFFDDEBFF, 0xFF2E6BE8, 0xFF0F1A33),
    Triple(0xFFE2F6E6, 0xFF2FA35A, 0xFF10261A),
    Triple(0xFFF3E5FF, 0xFF8A4FE0, 0xFF1F1233),
    Triple(0xFFFFF4CC, 0xFFE0A100, 0xFF2B2000),
    Triple(0xFFFFE0EC, 0xFFE0457D, 0xFF2E0F1B),
    Triple(0xFFD9F5F5, 0xFF16A3A3, 0xFF082626),
    Triple(0xFFEDEDED, 0xFF3A3A3A, 0xFFFFFFFF),
    Triple(0xFF1E1E2A, 0xFF7CF29C, 0xFF1E1E2A),
    Triple(0xFF26170F, 0xFFFF9A3C, 0xFF26170F),
    Triple(0xFF101B33, 0xFF6FB1FF, 0xFF101B33),
    Triple(0xFF2A0F1F, 0xFFFF6FAE, 0xFF2A0F1F),
)

/** Um dos avatares do Cartucho: um bichinho em pixel art, sempre o mesmo para cada número. */
@Composable
fun BuiltinAvatar(index: Int, modifier: Modifier = Modifier) {
    val (bg, fg, eye) = AVATAR_COLORS[Math.floorMod(index, AVATAR_COLORS.size)]
    val cells = remember(index) { creature(index) }
    Canvas(modifier.background(Color(bg))) {
        val grid = 8
        val pad = size.minDimension * 0.18f
        val cell = (size.minDimension - pad * 2) / grid
        val ox = (size.width - cell * grid) / 2
        val oy = (size.height - cell * grid) / 2 + cell * 0.3f
        for (y in 0 until grid) for (x in 0 until grid) {
            val v = cells[y * grid + x]
            if (v == 0) continue
            drawRect(
                color = if (v == 2) Color(eye) else Color(fg),
                topLeft = Offset(ox + x * cell, oy + y * cell),
                size = Size(cell + 0.6f, cell + 0.6f),
            )
        }
    }
}

/** Grade 8x8 espelhada: 0 vazio, 1 corpo, 2 olho. */
private fun creature(index: Int): IntArray {
    val r = Random(index * 7919L + 17)
    val g = IntArray(64)
    for (y in 0 until 8) for (x in 0 until 4) {
        val chance = when (y) { 0 -> 0.35; 7 -> 0.45; else -> 0.62 }
        val filled = (x >= 2 && y in 2..5) || r.nextDouble() < chance
        if (filled) { g[y * 8 + x] = 1; g[y * 8 + 7 - x] = 1 }
    }
    // Olhos sempre no mesmo lugar, com o corpo em volta.
    val eyeRow = 3
    val eyeCol = 2 + r.nextInt(2) - 1
    g[eyeRow * 8 + eyeCol] = 2; g[eyeRow * 8 + 7 - eyeCol] = 2
    g[(eyeRow + 1) * 8 + eyeCol] = 1; g[(eyeRow + 1) * 8 + 7 - eyeCol] = 1
    return g
}

/** Foto do perfil: a da galeria, a do RetroAchievements ou um avatar do Cartucho. */
@Composable
fun ProfileAvatar(data: ProfileData, photo: File, raAvatarUrl: String, size: Dp, modifier: Modifier = Modifier) {
    Box(modifier.size(size).clip(CircleShape), contentAlignment = Alignment.Center) {
        when {
            data.avatar == AvatarKind.PHOTO && photo.exists() -> {
                val bmp by produceState<ImageBitmap?>(null, data.photoVersion) {
                    value = withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(photo.path)?.asImageBitmap() }.getOrNull() }
                }
                bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                    ?: BuiltinAvatar(data.builtin, Modifier.fillMaxSize())
            }
            data.avatar == AvatarKind.RA && raAvatarUrl.isNotEmpty() -> RemoteImage(raAvatarUrl, Modifier.fillMaxSize())
            else -> BuiltinAvatar(data.builtin, Modifier.fillMaxSize())
        }
    }
}
