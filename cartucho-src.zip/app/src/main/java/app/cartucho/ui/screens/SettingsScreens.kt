package app.cartucho.ui.screens

import android.net.Uri
import android.view.InputDevice
import android.view.KeyEvent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.cartucho.BuildConfig
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.data.AspectMode
import app.cartucho.data.BiosCatalog
import app.cartucho.data.BiosEntry
import app.cartucho.data.BiosStatus
import app.cartucho.data.ControlMode
import app.cartucho.data.Frameskip
import app.cartucho.data.Latency
import app.cartucho.data.OrientationMode
import app.cartucho.data.Systems
import app.cartucho.data.ThemeMode
import app.cartucho.emu.Gamepads
import app.cartucho.emu.RemapStore
import app.cartucho.emu.RetroPad
import app.cartucho.ui.KeyCapture
import app.cartucho.ui.MainActivity
import app.cartucho.ui.Route
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.NavRow
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.ScreenHeader
import app.cartucho.ui.components.SectionLabel
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SegmentedRow
import app.cartucho.ui.components.SliderRow
import app.cartucho.ui.components.ToggleRow
import app.cartucho.ui.theme.Cartucho
import java.text.DateFormat
import java.util.Date

@Composable
fun SettingsPage(title: String, onBack: (() -> Unit)?, subtitle: String? = null, content: LazyListScope.() -> Unit) {
    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 48.dp),
        ) {
            item { ScreenHeader(title, onBack, subtitle) }
            item { Spacer(Modifier.height(4.dp)) }
            content()
        }
    }
}

fun LazyListScope.group(label: String?, content: @Composable () -> Unit) {
    item {
        Column(Modifier.padding(horizontal = 20.dp)) {
            if (label != null) SectionLabel(label) else Spacer(Modifier.height(16.dp))
            ListGroup { content() }
        }
    }
}

@Composable
fun SettingsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val s by app.prefs.settings.collectAsState()
    SettingsPage("Ajustes", onBack = { activity.back() }) {
        group("Jogo") {
            NavRow("Controles", { activity.navigate(Route.Controls) }, icon = R.drawable.ic_controller)
            Divider()
            NavRow("Áudio", { activity.navigate(Route.Audio) }, icon = R.drawable.ic_audio)
            Divider()
            NavRow("Vídeo", { activity.navigate(Route.Video) }, icon = R.drawable.ic_video)
        }
        group("Online (opcional)") {
            NavRow("Nuvem", { activity.navigate(Route.Cloud) }, icon = R.drawable.ic_cloud, value = if (s.driveEnabled) "Google Drive" else "Desligada")
            Divider()
            NavRow("RetroAchievements", { activity.navigate(Route.Achievements) }, icon = R.drawable.ic_trophy, value = if (s.raEnabled) s.raUser else "Desligado")
        }
        group("Aparelho") {
            NavRow("BIOS", { activity.navigate(Route.Bios) }, icon = R.drawable.ic_cpu)
            Divider()
            NavRow("Sistemas neste aparelho", { activity.navigate(Route.Systems) }, icon = R.drawable.ic_info)
        }
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                SectionLabel("Aparência")
                ListGroup {
                    SegmentedRow("Tema", listOf("Sistema", "Escuro", "Claro"), s.theme.ordinal, { i ->
                        app.prefs.update { it.copy(theme = ThemeMode.entries[i]) }
                    })
                }
            }
        }
        group(null) {
            NavRow("Sobre e licenças", { activity.navigate(Route.About) }, icon = R.drawable.ic_info)
        }
    }
}

@Composable
fun AudioSettingsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    SettingsPage("Áudio", onBack = { activity.back() }) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(16.dp))
                AudioGroup(app)
            }
        }
    }
}

@Composable
fun AudioGroup(app: CartuchoApp) {
    val s by app.prefs.settings.collectAsState()
    ListGroup {
        SliderRow("Volume", s.volume, { v -> app.prefs.update { it.copy(volume = v) } }, "${(s.volume * 100).toInt()}%")
        Divider()
        ToggleRow("Mudo", s.muted, { v -> app.prefs.update { it.copy(muted = v) } })
        Divider()
        SegmentedRow("Latência", Latency.entries.map { it.label }, s.latency.ordinal, { i ->
            app.prefs.update { it.copy(latency = Latency.entries[i]) }
        }, subtitle = "Baixa responde mais rápido; Normal evita estalos em aparelhos simples.")
        Divider()
        ToggleRow("Sincronizar áudio", s.audioSync, { v -> app.prefs.update { it.copy(audioSync = v) } }, subtitle = "Ajusta o ritmo do jogo para o som não falhar.")
    }
}

@Composable
fun VideoSettingsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    SettingsPage("Vídeo", onBack = { activity.back() }) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(16.dp))
                VideoGroup(app)
            }
        }
    }
}

@Composable
fun VideoGroup(app: CartuchoApp) {
    val s by app.prefs.settings.collectAsState()
    ListGroup {
        SegmentedRow("Proporção", AspectMode.entries.map { it.label }, s.aspect.ordinal, { i -> app.prefs.update { it.copy(aspect = AspectMode.entries[i]) } })
        Divider()
        ToggleRow("Escala inteira", s.integerScale, { v -> app.prefs.update { it.copy(integerScale = v) } }, subtitle = "Pixels nítidos e uniformes, com bordas maiores.")
        Divider()
        SegmentedRow("Filtro", listOf("Nítido", "Suave"), if (s.smoothFilter) 1 else 0, { i -> app.prefs.update { it.copy(smoothFilter = i == 1) } })
        Divider()
        ToggleRow("CRT leve", s.crt, { v -> app.prefs.update { it.copy(crt = v) } }, subtitle = "Linhas de varredura discretas.")
        Divider()
        SegmentedRow("Resolução interna", listOf("1x", "2x", "3x"), (s.resolution - 1).coerceIn(0, 2), { i ->
            app.prefs.update { it.copy(resolution = i + 1) }
        }, subtitle = "Só para sistemas 3D (N64, PS1, PSP, Dreamcast, PS2). Mais alto pesa mais.")
        Divider()
        SegmentedRow("Pular quadros", Frameskip.entries.map { it.label }, s.frameskip.ordinal, { i -> app.prefs.update { it.copy(frameskip = Frameskip.entries[i]) } })
        Divider()
        ToggleRow("Mostrar FPS", s.showFps, { v -> app.prefs.update { it.copy(showFps = v) } })
        Divider()
        SegmentedRow("Orientação", OrientationMode.entries.map { it.label }, s.orientation.ordinal, { i -> app.prefs.update { it.copy(orientation = OrientationMode.entries[i]) } })
    }
}

@Composable
fun TouchGroup(app: CartuchoApp) {
    val s by app.prefs.settings.collectAsState()
    ListGroup {
        SegmentedRow(
            "Jogar com",
            ControlMode.entries.map { it.label },
            s.controlMode.ordinal,
            { i -> app.prefs.update { it.copy(controlMode = ControlMode.entries[i]) } },
            subtitle = when (s.controlMode) {
                ControlMode.AUTO -> "Botões na tela até um controle ser conectado."
                ControlMode.GAMEPAD -> "Só o controle físico. Os botões da tela ficam escondidos."
                ControlMode.TOUCH -> "Sempre os botões na tela, mesmo com controle conectado."
            },
        )
        Divider()
        SliderRow("Opacidade dos controles na tela", s.touchOpacity, { v -> app.prefs.update { it.copy(touchOpacity = v) } }, "${(s.touchOpacity * 100).toInt()}%", 0.15f..1f)
        Divider()
        SliderRow("Tamanho", s.touchScale, { v -> app.prefs.update { it.copy(touchScale = v) } }, "${(s.touchScale * 100).toInt()}%", 0.7f..1.4f)
        Divider()
        ToggleRow("Vibração ao tocar", s.vibration, { v -> app.prefs.update { it.copy(vibration = v) } })
        Divider()
        ToggleRow("Menu com Select + Start", s.menuCombo, { v -> app.prefs.update { it.copy(menuCombo = v) } }, subtitle = "O botão Home/Guide do controle também abre o menu.")
    }
}

@Composable
fun ControlsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    var refresh by remember { mutableIntStateOf(0) }
    val devices = remember(refresh) { Gamepads.connected() }
    var remapping by remember { mutableStateOf<InputDevice?>(null) }

    DisposableEffect(Unit) {
        val listener = object : android.hardware.input.InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(deviceId: Int) { refresh++ }
            override fun onInputDeviceRemoved(deviceId: Int) { refresh++ }
            override fun onInputDeviceChanged(deviceId: Int) { refresh++ }
        }
        val im = activity.getSystemService(android.content.Context.INPUT_SERVICE) as android.hardware.input.InputManager
        im.registerInputDeviceListener(listener, null)
        onDispose { im.unregisterInputDeviceListener(listener) }
    }

    val device = remapping
    if (device != null) {
        RemapFlow(app, device) { remapping = null }
        return
    }

    SettingsPage("Controles", onBack = { activity.back() }, subtitle = "Controles USB e Bluetooth são reconhecidos ao conectar, até 4 jogadores.") {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                SectionLabel("Modo de jogo")
                TouchGroup(app)
                SectionLabel("Controles conectados")
                ListGroup {
                    if (devices.isEmpty()) {
                        Text(
                            "Nenhum controle conectado. Sem controle, o jogo mostra botões na tela.",
                            style = Cartucho.type.body,
                            color = c.textSecondary,
                            modifier = Modifier.padding(16.dp),
                        )
                    }
                    devices.forEachIndexed { i, d ->
                        if (i > 0) Divider()
                        NavRow(d.name, { remapping = d }, icon = R.drawable.ic_controller, subtitle = "Jogador ${i + 1} · Toque para remapear")
                    }
                }
            }
        }
    }
}

@Composable
private fun RemapFlow(app: CartuchoApp, device: InputDevice, onDone: () -> Unit) {
    val c = Cartucho.colors
    val store = remember { RemapStore(app) }
    val descriptor = remember { Gamepads.descriptorOf(device) }
    val targets = RetroPad.remappable
    var step by remember { mutableIntStateOf(0) }
    val result = remember { HashMap<Int, Int>() }

    DisposableEffect(device.id) {
        KeyCapture.listener = { event ->
            if (event.deviceId == device.id && event.action == KeyEvent.ACTION_UP && step < targets.size) {
                result[event.keyCode] = targets[step].first
                step++
                if (step >= targets.size) store.save(descriptor, result)
                true
            } else {
                event.deviceId == device.id
            }
        }
        onDispose { KeyCapture.listener = null }
    }

    SettingsPage("Remapear", onBack = onDone, subtitle = device.name) {
        item {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                if (step < targets.size) {
                    Text("Pressione o botão para", style = Cartucho.type.body, color = c.textSecondary)
                    Text(targets[step].second, style = Cartucho.type.display, color = c.text)
                    Text("${step + 1} de ${targets.size}", style = Cartucho.type.mono, color = c.textSecondary)
                    SecondaryButton("Pular este botão", { step++; if (step >= targets.size) store.save(descriptor, result) }, Modifier.fillMaxWidth())
                } else {
                    Text("Pronto", style = Cartucho.type.display, color = c.text)
                    Text("O mapeamento foi salvo para este modelo de controle.", style = Cartucho.type.body, color = c.textSecondary)
                    PrimaryButton("Concluir", onDone, Modifier.fillMaxWidth())
                }
                SecondaryButton("Voltar ao padrão", {
                    store.clear(descriptor)
                    onDone()
                }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun BiosScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    var refresh by remember { mutableIntStateOf(0) }
    var pending by remember { mutableStateOf<BiosEntry?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    val statuses = remember(refresh) { BiosCatalog.entries.associateWith { BiosCatalog.status(app, it) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val entry = pending
        pending = null
        if (uri != null && entry != null) {
            val status = runCatching { BiosCatalog.install(app, entry, uri) }.getOrDefault(BiosStatus.MISSING)
            notice = when (status) {
                BiosStatus.RECOGNIZED -> "${entry.fileName} instalada e reconhecida."
                BiosStatus.UNKNOWN -> "${entry.fileName} instalada, mas é diferente da versão esperada. Pode funcionar."
                BiosStatus.MISSING -> "Não foi possível ler o arquivo."
            }
            refresh++
        }
    }

    SettingsPage("BIOS", onBack = { activity.back() }, subtitle = "Alguns sistemas usam arquivos de BIOS do console original. Selecione os que você já possui.") {
        if (notice != null) {
            item { Text(notice ?: "", style = Cartucho.type.caption, color = c.accent, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) }
        }
        val bySystem = BiosCatalog.entries.groupBy { it.systemId }
        bySystem.forEach { (systemId, entries) ->
            group(Systems.get(systemId)?.name ?: systemId) {
                entries.forEachIndexed { i, e ->
                    if (i > 0) Divider()
                    val status = statuses[e] ?: BiosStatus.MISSING
                    val value = when (status) {
                        BiosStatus.MISSING -> if (e.required) "Necessária" else "Opcional"
                        BiosStatus.RECOGNIZED -> "Instalada"
                        BiosStatus.UNKNOWN -> "Versão diferente"
                    }
                    NavRow(e.fileName, { pending = e; picker.launch(arrayOf("*/*")) }, value = value, subtitle = e.description)
                }
            }
        }
    }
}

@Composable
fun SystemsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val d = app.device
    SettingsPage(
        "Sistemas",
        onBack = { activity.back() },
        subtitle = "Avaliação para este aparelho: ${d.primaryAbi}, ${d.cpuCores} núcleos, ${"%.1f".format(d.ramGb)} GB de RAM, OpenGL ES ${d.glesMajor}.",
    ) {
        group(null) {
            Systems.all.forEachIndexed { i, s ->
                if (i > 0) Divider()
                val r = d.rate(s)
                NavRow(s.name, {}, value = r.rating.label, subtitle = r.reason, showChevron = false)
            }
        }
        item {
            Text(
                "\"Pode engasgar\" significa que o sistema abre, mas jogos mais pesados podem ficar lentos. Reduzir a resolução interna ajuda.",
                style = Cartucho.type.caption,
                color = Cartucho.colors.textSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
            )
        }
    }
}

@Composable
fun AboutScreen(activity: MainActivity) {
    val c = Cartucho.colors
    SettingsPage("Sobre", onBack = { activity.back() }, subtitle = "Cartucho ${BuildConfig.VERSION_NAME}") {
        item {
            Text(
                "O Cartucho não inclui jogos nem BIOS e não indica onde obtê-los. Use apenas arquivos que você possui. " +
                    "Para jogar, o app funciona 100% offline. A rede só é usada pelo RetroAchievements e pelo Google Drive, se você ativar.",
                style = Cartucho.type.body,
                color = c.textSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )
        }
        group("Licenças dos emuladores") {
            Licenses.cores.forEachIndexed { i, (name, license) ->
                if (i > 0) Divider()
                NavRow(name, {}, value = license, showChevron = false)
            }
        }
        group("Outros componentes") {
            Licenses.others.forEachIndexed { i, (name, license) ->
                if (i > 0) Divider()
                NavRow(name, {}, value = license, showChevron = false)
            }
        }
        item {
            Text(
                "Código-fonte de cada emulador: github.com/libretro. Snes9x é distribuído sob licença não comercial; por isso o Cartucho é gratuito e sem fins comerciais.",
                style = Cartucho.type.caption,
                color = c.textSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
            )
        }
    }
}

object Licenses {
    val cores = listOf(
        "Stella (Atari 2600)" to "GPLv2",
        "ProSystem (Atari 7800)" to "GPLv2",
        "Handy (Lynx)" to "Zlib",
        "FCEUmm (NES)" to "GPLv2",
        "Snes9x (SNES)" to "Não comercial",
        "Gambatte (GB/GBC)" to "GPLv2",
        "mGBA (GBA)" to "MPL 2.0",
        "Genesis Plus GX" to "Não comercial",
        "PicoDrive (32X)" to "Não comercial",
        "Beetle PCE Fast" to "GPLv2",
        "Beetle NeoPop" to "GPLv2",
        "Beetle Cygne" to "GPLv2",
        "FinalBurn Neo (Arcade)" to "Não comercial",
        "Mupen64Plus-Next (N64)" to "GPLv2",
        "melonDS (DS)" to "GPLv3",
        "PCSX ReARMed (PS1)" to "GPLv2",
        "PPSSPP (PSP)" to "GPLv2",
        "Flycast (Dreamcast)" to "GPLv2",
        "Yabause (Saturn)" to "GPLv2",
        "Play! (PS2)" to "BSD 2",
    )
    val others = listOf(
        "rcheevos" to "MIT",
        "Geist (fonte)" to "OFL 1.1",
        "Phosphor Icons" to "MIT",
        "OkHttp" to "Apache 2.0",
        "AndroidX / Jetpack Compose" to "Apache 2.0",
    )
}

fun formatDate(ms: Long): String =
    if (ms <= 0) "Nunca" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(ms))
