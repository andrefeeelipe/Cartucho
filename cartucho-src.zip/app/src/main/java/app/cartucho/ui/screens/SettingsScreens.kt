package app.cartucho.ui.screens

import app.cartucho.data.Rating
import app.cartucho.ui.theme.Brand

import android.net.Uri
import android.view.InputDevice
import android.view.KeyEvent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.unit.sp
import app.cartucho.BuildConfig
import androidx.compose.foundation.background
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.data.AspectMode
import app.cartucho.data.BiosCatalog
import app.cartucho.data.BiosEntry
import app.cartucho.data.BiosStatus
import app.cartucho.data.ControlMode
import app.cartucho.data.Frameskip
import app.cartucho.data.Latency
import app.cartucho.data.OrientationMode
import app.cartucho.data.Systems
import app.cartucho.data.ThemeMode
import app.cartucho.emu.Gamepads
import app.cartucho.emu.RemapStore
import app.cartucho.emu.RetroPad
import app.cartucho.ui.KeyCapture
import app.cartucho.ui.MainActivity
import app.cartucho.ui.Route
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.NavRow
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.ScreenHeader
import app.cartucho.ui.components.SectionLabel
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SegmentedRow
import app.cartucho.ui.components.SliderRow
import app.cartucho.ui.components.ToggleRow
import app.cartucho.ui.theme.Cartucho
import java.text.DateFormat
import java.util.Date

@Composable
fun SettingsPage(
    title: String,
    onBack: (() -> Unit)?,
    subtitle: String? = null,
    backLabel: String = "Ajustes",
    raised: Boolean = false,
    content: LazyListScope.() -> Unit,
) {
    val bg = if (raised) Cartucho.colors.surfaceRaised else Cartucho.colors.background
    Box(Modifier.fillMaxSize().background(bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 48.dp),
        ) {
            item { ScreenHeader(title, onBack, subtitle, backLabel) }
            item { Spacer(Modifier.height(4.dp)) }
            content()
        }
    }
}

fun LazyListScope.group(label: String?, content: @Composable () -> Unit) {
    item {
        Column(Modifier.padding(horizontal = 20.dp)) {
            if (label != null) SectionLabel(label) else Spacer(Modifier.height(16.dp))
            ListGroup { content() }
        }
    }
}

@Composable
fun SettingsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val s by app.prefs.settings.collectAsState()
    SettingsPage("Ajustes", onBack = null, raised = true) {
        group("Jogo") {
            NavRow("Controles", { activity.navigate(Route.Controls) }, value = "Qualquer controle")
            Divider()
            NavRow("Vídeo", { activity.navigate(Route.Video) })
            Divider()
            NavRow("Áudio", { activity.navigate(Route.Audio) })
        }
        group("Conta") {
            NavRow("Backup no Google Drive", { activity.navigate(Route.Cloud) }, value = if (s.driveEnabled) "Conectado" else "Desligado")
            Divider()
            NavRow("RetroAchievements", { activity.navigate(Route.Achievements) }, value = if (s.raEnabled && s.raUser.isNotEmpty()) "@${s.raUser}" else "Desligado")
        }
        group("Sistema") {
            NavRow("BIOS", { activity.navigate(Route.Bios) })
            Divider()
            NavRow("Sistemas neste aparelho", { activity.navigate(Route.Systems) })
        }
        group("Biblioteca") {
            ToggleRow(
                "Baixar capas automaticamente",
                s.coverDownload,
                { v -> app.prefs.update { it.copy(coverDownload = v) } },
                subtitle = "Busca a capa de cada jogo no acervo aberto libretro-thumbnails. Precisa de internet só na primeira vez.",
            )
        }
        group("Sobre") {
            NavRow("Versão", { activity.navigate(Route.About) }, value = BuildConfig.VERSION_NAME, showChevron = false)
            Divider()
            NavRow("Sobre e licenças", { activity.navigate(Route.About) })
        }
    }
}

@Composable
fun AudioSettingsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    SettingsPage("Áudio", onBack = { activity.back() }) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(16.dp))
                AudioGroup(app)
            }
        }
    }
}

@Composable
fun AudioGroup(app: CartuchoApp) {
    val s by app.prefs.settings.collectAsState()
    ListGroup {
        SliderRow("Volume", s.volume, { v -> app.prefs.update { it.copy(volume = v) } }, "${(s.volume * 100).toInt()}%")
        Divider()
        ToggleRow("Mudo", s.muted, { v -> app.prefs.update { it.copy(muted = v) } })
        Divider()
        SegmentedRow("Latência", Latency.entries.map { it.label }, s.latency.ordinal, { i ->
            app.prefs.update { it.copy(latency = Latency.entries[i]) }
        }, subtitle = "Baixa responde mais rápido; Normal evita estalos em aparelhos simples.")
        Divider()
        ToggleRow("Sincronizar áudio", s.audioSync, { v -> app.prefs.update { it.copy(audioSync = v) } }, subtitle = "Ajusta o ritmo do jogo para o som não falhar.")
    }
}

@Composable
fun VideoSettingsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    SettingsPage("Vídeo", onBack = { activity.back() }) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(16.dp))
                VideoGroup(app)
            }
        }
    }
}

@Composable
fun VideoGroup(app: CartuchoApp) {
    val s by app.prefs.settings.collectAsState()
    ListGroup {
        SegmentedRow("Proporção", AspectMode.entries.map { it.label }, s.aspect.ordinal, { i -> app.prefs.update { it.copy(aspect = AspectMode.entries[i]) } })
        Divider()
        ToggleRow("Escala inteira", s.integerScale, { v -> app.prefs.update { it.copy(integerScale = v) } }, subtitle = "Pixels nítidos e uniformes, com bordas maiores.")
        Divider()
        SegmentedRow("Filtro", listOf("Nítido", "Suave"), if (s.smoothFilter) 1 else 0, { i -> app.prefs.update { it.copy(smoothFilter = i == 1) } })
        Divider()
        ToggleRow("CRT leve", s.crt, { v -> app.prefs.update { it.copy(crt = v) } }, subtitle = "Linhas de varredura discretas.")
        Divider()
        SegmentedRow("Resolução interna", listOf("1x", "2x", "3x"), (s.resolution - 1).coerceIn(0, 2), { i ->
            app.prefs.update { it.copy(resolution = i + 1) }
        }, subtitle = "Só para sistemas 3D (N64, PS1, PSP, Dreamcast, PS2). Mais alto pesa mais.")
        Divider()
        SegmentedRow("Pular quadros", Frameskip.entries.map { it.label }, s.frameskip.ordinal, { i -> app.prefs.update { it.copy(frameskip = Frameskip.entries[i]) } })
        Divider()
        ToggleRow("Mostrar FPS", s.showFps, { v -> app.prefs.update { it.copy(showFps = v) } })
        Divider()
        SegmentedRow("Orientação", OrientationMode.entries.map { it.label }, s.orientation.ordinal, { i -> app.prefs.update { it.copy(orientation = OrientationMode.entries[i]) } })
    }
}

@Composable
fun TouchGroup(app: CartuchoApp) {
    val s by app.prefs.settings.collectAsState()
    ListGroup {
        SegmentedRow(
            "Jogar com",
            ControlMode.entries.map { it.label },
            s.controlMode.ordinal,
            { i -> app.prefs.update { it.copy(controlMode = ControlMode.entries[i]) } },
            subtitle = when (s.controlMode) {
                ControlMode.AUTO -> "Botões na tela até um controle ser conectado."
                ControlMode.GAMEPAD -> "Só o controle físico. Os botões da tela ficam escondidos."
                ControlMode.TOUCH -> "Sempre os botões na tela, mesmo com controle conectado."
            },
        )
        Divider()
        SliderRow("Opacidade dos controles na tela", s.touchOpacity, { v -> app.prefs.update { it.copy(touchOpacity = v) } }, "${(s.touchOpacity * 100).toInt()}%", 0.15f..1f)
        Divider()
        SliderRow("Tamanho", s.touchScale, { v -> app.prefs.update { it.copy(touchScale = v) } }, "${(s.touchScale * 100).toInt()}%", 0.7f..1.4f)
        Divider()
        ToggleRow("Vibração ao tocar", s.vibration, { v -> app.prefs.update { it.copy(vibration = v) } })
        Divider()
        ToggleRow("Menu com Select + Start", s.menuCombo, { v -> app.prefs.update { it.copy(menuCombo = v) } }, subtitle = "O botão Home/Guide do controle também abre o menu.")
    }
}

@Composable
fun ControlsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    var refresh by remember { mutableIntStateOf(0) }
    val devices = remember(refresh) { Gamepads.connected() }
    var remapping by remember { mutableStateOf<InputDevice?>(null) }

    DisposableEffect(Unit) {
        val listener = object : android.hardware.input.InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(deviceId: Int) { refresh++ }
            override fun onInputDeviceRemoved(deviceId: Int) { refresh++ }
            override fun onInputDeviceChanged(deviceId: Int) { refresh++ }
        }
        val im = activity.getSystemService(android.content.Context.INPUT_SERVICE) as android.hardware.input.InputManager
        im.registerInputDeviceListener(listener, null)
        onDispose { im.unregisterInputDeviceListener(listener) }
    }

    val device = remapping
    if (device != null) {
        RemapFlow(app, device) { remapping = null }
        return
    }

    SettingsPage("Controles", onBack = { activity.back() }, subtitle = "Controles USB e Bluetooth são reconhecidos ao conectar, até 4 jogadores.") {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                SectionLabel("Modo de jogo")
                TouchGroup(app)
                SectionLabel("Controles conectados")
                ListGroup {
                    if (devices.isEmpty()) {
                        Text(
                            "Nenhum controle conectado. Sem controle, o jogo mostra botões na tela.",
                            style = Cartucho.type.body,
                            color = c.textSecondary,
                            modifier = Modifier.padding(16.dp),
                        )
                    }
                    devices.forEachIndexed { i, d ->
                        if (i > 0) Divider()
                        NavRow(d.name, { remapping = d }, icon = R.drawable.ic_controller, subtitle = "Jogador ${i + 1} · Toque para mapear os botões")
                    }
                }
            }
        }
    }
}

@Composable
fun RemapFlow(app: android.content.Context, device: InputDevice, onDone: () -> Unit) {
    val c = Cartucho.colors
    val store = remember { RemapStore(app) }
    val descriptor = remember { Gamepads.descriptorOf(device) }
    val targets = RetroPad.remappable + listOf(RetroPad.UP to "Cima", RetroPad.DOWN to "Baixo", RetroPad.LEFT to "Esquerda", RetroPad.RIGHT to "Direita")
    // Mapa atual: tecla do controle -> botão do jogo.
    var mapping by remember { mutableStateOf(Gamepads.defaultMap + store.load(descriptor)) }
    // Botão do jogo esperando uma tecla (um só) ou -1; sequência completa usa o índice.
    var waitingFor by remember { mutableIntStateOf(-1) }
    var sequenceIndex by remember { mutableIntStateOf(-1) }

    fun assign(keyCode: Int, retroId: Int) {
        // Um botão do jogo por tecla, e cada botão do jogo em uma tecla só.
        val next = mapping.filterValues { it != retroId }.toMutableMap()
        next[keyCode] = retroId
        mapping = next
        store.save(descriptor, next)
    }

    fun keyFor(retroId: Int): String {
        val code = mapping.entries.firstOrNull { it.value == retroId }?.key ?: return "—"
        return KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").removePrefix("BUTTON_").replace('_', ' ')
    }

    DisposableEffect(device.id) {
        KeyCapture.listener = { event ->
            if (event.deviceId != device.id) {
                false
            } else if (event.action == KeyEvent.ACTION_UP && (waitingFor >= 0 || sequenceIndex >= 0)) {
                if (sequenceIndex >= 0) {
                    assign(event.keyCode, targets[sequenceIndex].first)
                    sequenceIndex = if (sequenceIndex + 1 < targets.size) sequenceIndex + 1 else -1
                } else {
                    assign(event.keyCode, waitingFor)
                    waitingFor = -1
                }
                true
            } else {
                waitingFor >= 0 || sequenceIndex >= 0
            }
        }
        onDispose { KeyCapture.listener = null }
    }

    val asking = when {
        sequenceIndex >= 0 -> targets[sequenceIndex].second
        waitingFor >= 0 -> targets.firstOrNull { it.first == waitingFor }?.second
        else -> null
    }

    SettingsPage("Mapear controle", onBack = onDone, subtitle = device.name) {
        item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (asking != null) {
                    ListGroup {
                        Column(Modifier.padding(20.dp)) {
                            Text("Pressione no controle o botão para", style = Cartucho.type.body, color = c.textSecondary)
                            Text(asking, style = Cartucho.type.display, color = c.text)
                            if (sequenceIndex >= 0) Text("${sequenceIndex + 1} de ${targets.size}", style = Cartucho.type.mono, color = c.textSecondary)
                        }
                    }
                    SecondaryButton(if (sequenceIndex >= 0) "Pular" else "Cancelar", {
                        if (sequenceIndex >= 0) {
                            sequenceIndex = if (sequenceIndex + 1 < targets.size) sequenceIndex + 1 else -1
                        } else {
                            waitingFor = -1
                        }
                    }, Modifier.fillMaxWidth())
                } else {
                    Text("Toque em um botão do jogo e depois aperte o botão do controle que quer usar.", style = Cartucho.type.caption, color = c.textSecondary)
                }
            }
        }
        group("Botões") {
            targets.forEachIndexed { i, (id, label) ->
                if (i > 0) Divider()
                NavRow(label, { waitingFor = id; sequenceIndex = -1 }, value = keyFor(id))
            }
        }
        item {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton("Mapear todos em sequência", { waitingFor = -1; sequenceIndex = 0 }, Modifier.fillMaxWidth())
                SecondaryButton("Voltar ao padrão", {
                    store.clear(descriptor)
                    mapping = Gamepads.defaultMap
                }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun BiosScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    var refresh by remember { mutableIntStateOf(0) }
    var pending by remember { mutableStateOf<BiosEntry?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    val statuses = remember(refresh) { BiosCatalog.entries.associateWith { BiosCatalog.status(app, it) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val entry = pending
        pending = null
        if (uri != null && entry != null) {
            val status = runCatching { BiosCatalog.install(app, entry, uri) }.getOrDefault(BiosStatus.MISSING)
            notice = when (status) {
                BiosStatus.RECOGNIZED -> "${entry.fileName} instalada e reconhecida."
                BiosStatus.UNKNOWN -> "${entry.fileName} instalada, mas é diferente da versão esperada. Pode funcionar."
                BiosStatus.MISSING -> "Não foi possível ler o arquivo."
            }
            refresh++
        }
    }

    SettingsPage("BIOS", onBack = { activity.back() }, subtitle = "Alguns sistemas usam arquivos de BIOS do console original. Selecione os que você já possui.") {
        if (notice != null) {
            item { Text(notice ?: "", style = Cartucho.type.caption, color = c.accent, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) }
        }
        val bySystem = BiosCatalog.entries.groupBy { it.systemId }
        bySystem.forEach { (systemId, entries) ->
            group(Systems.get(systemId)?.name ?: systemId) {
                entries.forEachIndexed { i, e ->
                    if (i > 0) Divider()
                    val status = statuses[e] ?: BiosStatus.MISSING
                    val value = when (status) {
                        BiosStatus.MISSING -> if (e.required) "Necessária" else "Opcional"
                        BiosStatus.RECOGNIZED -> "Instalada"
                        BiosStatus.UNKNOWN -> "Versão diferente"
                    }
                    NavRow(e.fileName, { pending = e; picker.launch(arrayOf("*/*")) }, value = value, subtitle = e.description)
                }
            }
        }
    }
}

@Composable
fun SystemsScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val d = app.device
    SettingsPage("Sistemas neste aparelho", onBack = { activity.back() }) {
        item {
            Column(
                Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Cartucho.colors.surfaceRaised).padding(16.dp),
            ) {
                Text("ESTE APARELHO", style = Cartucho.type.mono, color = Cartucho.colors.textSecondary)
                Spacer(Modifier.height(4.dp))
                Text(
                    "${android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${android.os.Build.MODEL} · ${d.cpuCores} núcleos · ${"%.1f".format(d.ramGb)} GB",
                    style = Cartucho.type.headline,
                    color = Cartucho.colors.text,
                )
                Spacer(Modifier.height(4.dp))
                Text("O Cartucho avisa antes de abrir um jogo pesado.", style = Cartucho.type.caption, color = Cartucho.colors.textSecondary)
            }
        }
        group(null) {
            Systems.all.forEachIndexed { i, s ->
                if (i > 0) Divider()
                val r = d.rate(s)
                Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, style = Cartucho.type.body, color = Cartucho.colors.text)
                        r.reason?.let { Text(it, style = Cartucho.type.caption, color = Cartucho.colors.textSecondary) }
                    }
                    Spacer(Modifier.width(10.dp))
                    PerformanceStatus(r.rating)
                }
            }
        }
        item {
            Text(
                "\"Engasga\" quer dizer que o sistema abre, mas jogos mais pesados podem ficar lentos. Reduzir a resolução interna ajuda.",
                style = Cartucho.type.caption,
                color = Cartucho.colors.textSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
            )
        }
    }
}

/** Roda liso / Engasga / Não roda: cor dos pontos, sempre com ícone e texto. */
@Composable
private fun PerformanceStatus(rating: Rating) {
    val B = Brand
    val bg: androidx.compose.ui.graphics.Color
    val fg: androidx.compose.ui.graphics.Color
    val mark: String
    val label: String
    when (rating) {
        Rating.GOOD -> { bg = B.dotGreen; fg = androidx.compose.ui.graphics.Color.White; mark = "✓"; label = "Roda liso" }
        Rating.MAY_STUTTER -> { bg = B.dotYellow; fg = B.dotYellowInk; mark = "!"; label = "Engasga" }
        Rating.UNSUPPORTED -> { bg = B.dotRed; fg = androidx.compose.ui.graphics.Color.White; mark = "×"; label = "Não roda" }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(18.dp).clip(androidx.compose.foundation.shape.CircleShape).background(bg), contentAlignment = Alignment.Center) {
            Text(mark, style = Cartucho.type.caption.copy(fontSize = 11.sp, lineHeight = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold), color = fg)
        }
        Spacer(Modifier.width(6.dp))
        Text(label, style = Cartucho.type.caption.copy(fontSize = 13.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold), color = Cartucho.colors.text)
    }
}

@Composable
fun AboutScreen(activity: MainActivity) {
    val c = Cartucho.colors
    SettingsPage("Sobre", onBack = { activity.back() }, subtitle = "Cartucho ${BuildConfig.VERSION_NAME}") {
        item {
            Text(
                "O Cartucho não inclui jogos nem BIOS e não indica onde obtê-los. Use apenas arquivos que você possui. " +
                    "Para jogar, o app funciona 100% offline. A internet só é usada para capas (pode desligar), hacks que você mesmo baixar, " +
                    "RetroAchievements e Google Drive.",
                style = Cartucho.type.body,
                color = c.textSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )
        }
        group("Licenças dos emuladores") {
            Licenses.cores.forEachIndexed { i, (name, license) ->
                if (i > 0) Divider()
                NavRow(name, {}, value = license, showChevron = false)
            }
        }
        group("Outros componentes") {
            Licenses.others.forEachIndexed { i, (name, license) ->
                if (i > 0) Divider()
                NavRow(name, {}, value = license, showChevron = false)
            }
        }
        item {
            Text(
                "Código-fonte de cada emulador: github.com/libretro. Snes9x é distribuído sob licença não comercial; por isso o Cartucho é gratuito e sem fins comerciais.",
                style = Cartucho.type.caption,
                color = c.textSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
            )
        }
    }
}

object Licenses {
    val cores = listOf(
        "Stella (Atari 2600)" to "GPLv2",
        "ProSystem (Atari 7800)" to "GPLv2",
        "Handy (Lynx)" to "Zlib",
        "FCEUmm (NES)" to "GPLv2",
        "Snes9x (SNES)" to "Não comercial",
        "Gambatte (GB/GBC)" to "GPLv2",
        "mGBA (GBA)" to "MPL 2.0",
        "Genesis Plus GX" to "Não comercial",
        "PicoDrive (32X)" to "Não comercial",
        "Beetle PCE Fast" to "GPLv2",
        "Beetle NeoPop" to "GPLv2",
        "Beetle Cygne" to "GPLv2",
        "FinalBurn Neo (Arcade)" to "Não comercial",
        "Mupen64Plus-Next (N64)" to "GPLv2",
        "melonDS (DS)" to "GPLv3",
        "PCSX ReARMed (PS1)" to "GPLv2",
        "PPSSPP (PSP)" to "GPLv2",
        "Flycast (Dreamcast)" to "GPLv2",
        "Yabause (Saturn)" to "GPLv2",
        "Play! (PS2)" to "BSD 2",
    )
    val others = listOf(
        "rcheevos" to "MIT",
        "Inter e Space Grotesk (fontes)" to "OFL 1.1",
        "Phosphor Icons" to "MIT",
        "Capas: libretro-thumbnails" to "Uso comunitário",
        "Apache Commons Compress, XZ, junrar" to "Apache 2.0 / domínio público / UnRAR",
        "OkHttp" to "Apache 2.0",
        "AndroidX / Jetpack Compose" to "Apache 2.0",
    )
}

fun formatDate(ms: Long): String =
    if (ms <= 0) "Nunca" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(ms))
