package app.cartucho.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.cartucho.ui.components.pressable
import androidx.compose.ui.unit.sp
import app.cartucho.CartuchoApp
import app.cartucho.data.Store
import app.cartucho.data.StoreGame
import app.cartucho.data.Systems
import app.cartucho.ui.MainActivity
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.FilterGroup
import app.cartucho.ui.components.FilterPanel
import app.cartucho.ui.components.LetterBar
import app.cartucho.ui.components.SelectChip
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.theme.Cartucho
import kotlinx.coroutines.launch

/** Loja: jogos homebrew gratuitos, publicados pelos próprios autores, para baixar e jogar. */
@Composable
fun StoreScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val store = app.store
    val all by store.games.collectAsState()
    val library by app.library.games.collectAsState()
    var query by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("") }
    var letter by remember { mutableStateOf<Char?>(null) }
    var lang by remember { mutableStateOf("") }
    var era by remember { mutableStateOf(0) }
    var players by remember { mutableStateOf(0) }
    var kind by remember { mutableStateOf("game") }
    var show by remember { mutableStateOf(0) }
    var sort by remember { mutableStateOf(0) }
    var filtersOpen by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<StoreGame?>(null) }
    val progress = remember { mutableStateMapOf<String, Int>() }
    var notice by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val installedFiles = remember(library) { library.map { it.uri }.toSet() }
    fun installed(g: StoreGame): Boolean = store.localFile(g)?.let { Uri.fromFile(it).toString() in installedFiles } == true
    val installedSlugs = remember(library) {
        library.filter { it.folderPath == "Loja" }.mapNotNull { Uri.parse(it.uri).path?.let { p -> java.io.File(p).parentFile?.name } }.toSet()
    }

    val platforms = remember(all) { Systems.all.filter { s -> all.any { it.systemId == s.id } } }
    val q = query.trim().lowercase()
    // Filtros, menos a letra (para saber quais letras têm jogos).
    val base = remember(all, q, platform, genre, lang, era, players, kind, show, installedSlugs) {
        all.filter { g ->
            (platform.isEmpty() || g.systemId == platform) &&
                (kind.isEmpty() || (kind == "demo") == g.isDemo) &&
                (genre.isEmpty() || genre in g.genres) &&
                (lang.isEmpty() || (if (lang == "outros") g.language.isNotEmpty() && g.language !in setOf("pt", "en", "es") else g.language == lang)) &&
                (era == 0 || (g.yearInt in era until era + 10) || (era == 2020 && g.yearInt >= 2020)) &&
                (players == 0 || (players == 1 && g.players <= 1) || (players == 2 && g.players >= 2)) &&
                (show == 0 || (show == 1) == (g.slug in installedSlugs)) &&
                (q.isEmpty() || g.title.lowercase().contains(q) || g.developer.lowercase().contains(q) ||
                    g.tags.any { it.lowercase().contains(q) } || g.genres.any { it.lowercase().contains(q) })
        }
    }
    val letters = remember(base) { base.map { it.letter }.toSet() }
    val shown = remember(base, letter, sort) {
        val l = base.filter { letter == null || it.letter == letter }
        when (sort) {
            1 -> l.sortedByDescending { it.title.lowercase() }
            2 -> l.sortedByDescending { it.yearInt }
            3 -> l.sortedBy { if (it.yearInt == 0) 9999 else it.yearInt }
            else -> l.sortedBy { it.title.lowercase() }
        }
    }
    val activeFilters = listOf(genre.isNotEmpty(), lang.isNotEmpty(), era != 0, players != 0, kind != "game", show != 0, sort != 0).count { it }
    val ptCount = remember(all) { all.count { it.language == "pt" } }

    fun play(g: StoreGame) {
        if (progress.containsKey(g.slug)) return
        progress[g.slug] = 0
        scope.launch {
            runCatching {
                val game = store.install(g, app.library, app.covers) { p -> progress[g.slug] = p }
                progress.remove(g.slug)
                open = null
                activity.launchGame(game)?.let { notice = it }
            }.onFailure {
                progress.remove(g.slug)
                notice = it.message ?: "Não foi possível baixar o jogo."
            }
        }
    }

    SettingsPage(
        "Loja",
        onBack = null,
        subtitle = "Jogos gratuitos, liberados pelos próprios autores.",
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                app.cartucho.ui.components.SearchBox(query, { query = it.take(60) }, "Buscar na Loja", onClear = { query = "" })
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SelectChip("Todos", platform.isEmpty(), { platform = "" })
                    platforms.forEach { sys -> SelectChip(sys.name, platform == sys.id, { platform = if (platform == sys.id) "" else sys.id }) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SelectChip(if (activeFilters > 0) "Filtros · $activeFilters" else "Filtros", activeFilters > 0, { filtersOpen = true })
                    if (ptCount > 0) SelectChip("Em português", lang == "pt", { lang = if (lang == "pt") "" else "pt" })
                    listOf("Ação", "Aventura", "Plataforma", "Quebra-cabeça", "Corrida", "RPG", "Tiro", "Esporte").forEach { gn ->
                        SelectChip(gn, genre == gn, { genre = if (genre == gn) "" else gn })
                    }
                }
                LetterBar(letter, letters, { letter = it })
                notice?.let { Text(it, style = Cartucho.type.caption, color = c.danger) }
                Text(
                    when {
                        !store.loaded -> "Carregando o catálogo…"
                        all.isEmpty() -> "O catálogo não está disponível agora. Tente de novo com internet."
                        else -> "${shown.size} de ${all.size} títulos" + (letter?.let { " · letra $it" } ?: "")
                    },
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                )
            }
        }
        items(shown, key = { it.slug }) { g ->
            StoreRow(g, installed(g), progress[g.slug], onOpen = { open = g }, onPlay = { play(g) })
        }
        item {
            Text(
                "Catálogo do Homebrew Hub (hh.gbdev.io), do ZXDB/Spectrum Computing (jogos de ZX Spectrum com distribuição liberada pelos autores e editoras) e do TIC-80 (tic80.com). Cada jogo é baixado direto do site de origem, com o crédito do autor. O Cartucho não oferece jogos comerciais.",
                style = Cartucho.type.caption,
                color = c.textSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
            )
        }
    }

    BottomSheet(visible = filtersOpen, onDismiss = { filtersOpen = false }) {
        FilterPanel(
            count = shown.size,
            onClear = { genre = ""; lang = ""; era = 0; players = 0; kind = "game"; show = 0; sort = 0; letter = null },
            onDone = { filtersOpen = false },
        ) {
            FilterGroup("Ordenar", listOf(0 to "A–Z", 1 to "Z–A", 2 to "Mais novos", 3 to "Mais antigos"), sort) { sort = it }
            FilterGroup("Gênero", listOf("" to "Todos") + Store.GENRES.filter { gn -> all.any { gn in it.genres } }.map { it to it }, genre) { genre = it }
            FilterGroup(
                "Idioma",
                listOf("" to "Todos", "pt" to "Português ($ptCount)", "en" to "Inglês", "es" to "Espanhol", "outros" to "Outros"),
                lang,
            ) { lang = it }
            FilterGroup("Época", listOf(0 to "Todas", 1980 to "Anos 80", 1990 to "Anos 90", 2000 to "Anos 2000", 2010 to "Anos 2010", 2020 to "2020 em diante"), era) { era = it }
            FilterGroup("Jogadores", listOf(0 to "Tanto faz", 1 to "1 jogador", 2 to "2 ou mais"), players) { players = it }
            FilterGroup("Tipo", listOf("game" to "Jogos", "demo" to "Demos", "" to "Tudo"), kind) { kind = it }
            FilterGroup("Mostrar", listOf(0 to "Todos", 1 to "Já baixados", 2 to "Ainda não baixados"), show) { show = it }
        }
    }

    BottomSheet(visible = open != null, onDismiss = { open = null }) {
        val g = open ?: return@BottomSheet
        val isInstalled = installed(g)
        val p = progress[g.slug]
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (g.screenshotUrl.isNotEmpty()) {
                RemoteImage(g.screenshotUrl, Modifier.fillMaxWidth().aspectRatio(10f / 9f).clip(RoundedCornerShape(12.dp)))
            }
            Text(g.title, style = Cartucho.type.title, color = c.text)
            Text(
                listOfNotNull(
                    g.developer.ifBlank { null },
                    Systems.get(g.systemId)?.name,
                    g.year.ifBlank { null },
                ).joinToString(" · "),
                style = Cartucho.type.caption,
                color = c.textSecondary,
            )
            if (g.description.isNotBlank()) Text(g.description, style = Cartucho.type.body, color = c.text, maxLines = 8, overflow = TextOverflow.Ellipsis)
            if (g.genres.isNotEmpty()) Text(g.genres.joinToString(" · "), style = Cartucho.type.caption, color = c.text)
            Text(
                "Licença: " + g.license.ifBlank { "definida pelo autor" } + " · Fonte: " + g.source,
                style = Cartucho.type.caption,
                color = c.textSecondary,
            )
            PrimaryButton(
                when {
                    p != null -> "Baixando… $p%"
                    isInstalled -> "Jogar"
                    else -> "Baixar e jogar"
                },
                { play(g) },
                Modifier.fillMaxWidth(),
                enabled = p == null,
            )
            SecondaryButton("Página do jogo", {
                runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.website.ifBlank { g.pageUrl }))) }
            }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StoreRow(g: StoreGame, installed: Boolean, progress: Int?, onOpen: () -> Unit, onPlay: () -> Unit) {
    val c = Cartucho.colors
    Column(Modifier.padding(horizontal = 20.dp)) {
        Row(
            Modifier.fillMaxWidth().pressable(shape = RoundedCornerShape(12.dp), onClick = onOpen).padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RemoteImage(g.screenshotUrl, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(c.placeholder))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(g.title, style = Cartucho.type.headline.copy(fontSize = 16.sp), color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    listOfNotNull(Systems.get(g.systemId)?.short, g.genres.firstOrNull(), g.language.takeIf { it == "pt" }?.let { "Em português" } ?: g.developer.ifBlank { null }, g.year.ifBlank { null }).joinToString(" · "),
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(10.dp))
            app.cartucho.ui.components.SoftButton(
                when {
                    progress != null -> "$progress%"
                    installed -> "Jogar"
                    else -> "Baixar"
                },
                onPlay,
                enabled = progress == null,
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.placeholder))
    }
}
