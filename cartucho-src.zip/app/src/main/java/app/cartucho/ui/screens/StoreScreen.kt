package app.cartucho.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.cartucho.CartuchoApp
import app.cartucho.data.StoreGame
import app.cartucho.data.Systems
import app.cartucho.ui.MainActivity
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.theme.Cartucho
import kotlinx.coroutines.launch

/** Loja: jogos homebrew gratuitos, publicados pelos próprios autores, para baixar e jogar. */
@Composable
fun StoreScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val store = app.store
    val all by store.games.collectAsState()
    val library by app.library.games.collectAsState()
    var query by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf("") }
    var demos by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<StoreGame?>(null) }
    val progress = remember { mutableStateMapOf<String, Int>() }
    var notice by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val q = query.trim().lowercase()
    val shown = remember(all, q, platform, demos) {
        all.filter { g ->
            (platform.isEmpty() || g.systemId == platform) &&
                (g.isDemo == demos) &&
                (q.isEmpty() || g.title.lowercase().contains(q) || g.developer.lowercase().contains(q) || g.tags.any { it.lowercase().contains(q) })
        }
    }
    val installedFiles = remember(library) { library.map { it.uri }.toSet() }
    fun installed(g: StoreGame): Boolean = store.localFile(g)?.let { Uri.fromFile(it).toString() in installedFiles } == true

    fun play(g: StoreGame) {
        if (progress.containsKey(g.slug)) return
        progress[g.slug] = 0
        scope.launch {
            runCatching {
                val game = store.install(g, app.library, app.covers) { p -> progress[g.slug] = p }
                progress.remove(g.slug)
                open = null
                activity.launchGame(game)?.let { notice = it }
            }.onFailure {
                progress.remove(g.slug)
                notice = it.message ?: "Não foi possível baixar o jogo."
            }
        }
    }

    SettingsPage(
        "Loja",
        onBack = { activity.back() },
        subtitle = "Jogos gratuitos feitos por fãs e estúdios independentes, publicados pelos próprios autores.",
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surfaceRaised).padding(horizontal = 14.dp, vertical = 12.dp),
                ) {
                    if (query.isEmpty()) Text("Buscar por nome, autor ou gênero", style = Cartucho.type.body, color = c.textSecondary)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it.take(60) },
                        singleLine = true,
                        textStyle = Cartucho.type.body.copy(color = c.text),
                        cursorBrush = SolidColor(c.accent),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Todos", platform.isEmpty()) { platform = "" }
                    Chip("Game Boy", platform == "gb") { platform = "gb" }
                    Chip("Game Boy Color", platform == "gbc") { platform = "gbc" }
                    Chip("GBA", platform == "gba") { platform = "gba" }
                    Chip("NES", platform == "nes") { platform = "nes" }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Jogos", !demos) { demos = false }
                    Chip("Demos", demos) { demos = true }
                }
                notice?.let { Text(it, style = Cartucho.type.caption, color = c.danger) }
                Text(
                    when {
                        !store.loaded -> "Carregando o catálogo…"
                        all.isEmpty() -> "O catálogo não está disponível agora. Tente de novo com internet."
                        else -> "${shown.size} de ${all.size} títulos"
                    },
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                )
            }
        }
        items(shown, key = { it.slug }) { g ->
            StoreRow(g, installed(g), progress[g.slug], onOpen = { open = g }, onPlay = { play(g) })
        }
        item {
            Text(
                "Catálogo do Homebrew Hub (hh.gbdev.io). Cada jogo é baixado direto do servidor dele, com o crédito e a licença do autor. O Cartucho não oferece jogos comerciais.",
                style = Cartucho.type.caption,
                color = c.textSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
            )
        }
    }

    BottomSheet(visible = open != null, onDismiss = { open = null }) {
        val g = open ?: return@BottomSheet
        val isInstalled = installed(g)
        val p = progress[g.slug]
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (g.screenshotUrl.isNotEmpty()) {
                RemoteImage(g.screenshotUrl, Modifier.fillMaxWidth().aspectRatio(10f / 9f).clip(RoundedCornerShape(12.dp)))
            }
            Text(g.title, style = Cartucho.type.title, color = c.text)
            Text(
                listOfNotNull(
                    g.developer.ifBlank { null },
                    Systems.get(g.systemId)?.name,
                    g.year.ifBlank { null },
                ).joinToString(" · "),
                style = Cartucho.type.caption,
                color = c.textSecondary,
            )
            if (g.description.isNotBlank()) Text(g.description, style = Cartucho.type.body, color = c.text, maxLines = 8, overflow = TextOverflow.Ellipsis)
            Text(
                "Licença: " + g.license.ifBlank { "definida pelo autor" },
                style = Cartucho.type.caption,
                color = c.textSecondary,
            )
            PrimaryButton(
                when {
                    p != null -> "Baixando… $p%"
                    isInstalled -> "Jogar"
                    else -> "Baixar e jogar"
                },
                { play(g) },
                Modifier.fillMaxWidth(),
                enabled = p == null,
            )
            SecondaryButton("Página do jogo", {
                runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.website.ifBlank { g.pageUrl }))) }
            }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StoreRow(g: StoreGame, installed: Boolean, progress: Int?, onOpen: () -> Unit, onPlay: () -> Unit) {
    val c = Cartucho.colors
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RemoteImage(g.screenshotUrl, Modifier.size(64.dp, 58.dp).clip(RoundedCornerShape(8.dp)))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(g.title, style = Cartucho.type.headline, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                listOfNotNull(Systems.get(g.systemId)?.short, g.developer.ifBlank { null }).joinToString(" · "),
                style = Cartucho.type.caption,
                color = c.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            when {
                progress != null -> "$progress%"
                installed -> "Jogar"
                else -> "Baixar"
            },
            style = Cartucho.type.label,
            color = c.accent,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .border(1.dp, c.accent, RoundedCornerShape(50))
                .clickable(enabled = progress == null, onClick = onPlay)
                .padding(horizontal = 14.dp, vertical = 6.dp),
        )
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val c = Cartucho.colors
    Text(
        text,
        style = Cartucho.type.label,
        color = if (selected) c.background else c.text,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) c.text else c.surfaceRaised)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}
