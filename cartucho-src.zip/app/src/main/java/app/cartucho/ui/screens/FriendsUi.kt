package app.cartucho.ui.screens

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.game.qrBitmap
import app.cartucho.net.Friends
import app.cartucho.net.RoomGuestActivity
import app.cartucho.ui.MainActivity
import app.cartucho.ui.components.CIcon
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SoftButton
import app.cartucho.ui.components.pressable
import app.cartucho.ui.theme.Brand
import app.cartucho.ui.theme.Cartucho
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

/** Seção Amigos na aba Online. */
@Composable
fun FriendsSection(
    activity: MainActivity,
    onOpenChat: (String) -> Unit,
    onMyCode: () -> Unit,
    onAdd: () -> Unit,
    onMessage: (String) -> Unit,
) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val profile by app.profile.data.collectAsState()
    var started by remember { mutableStateOf(Friends.hasIdentity(app)) }
    val friends by Friends.friends.collectAsState()
    val requests by Friends.requests.collectAsState()

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surface)
            .border(1.dp, c.border, RoundedCornerShape(16.dp)).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Amigos", style = Cartucho.type.title, color = c.text)
        if (!started) {
            Text(
                "Adicione amigos pelo código ou QR, veja quem está online e o que está jogando, converse e chame para jogar junto. " +
                    "Sem conta e sem cadastro: as mensagens vão cifradas e a lista fica só no seu celular.",
                style = Cartucho.type.body,
                color = c.textSecondary,
            )
            PrimaryButton("Começar", {
                Friends.start(app, profile.name)
                started = true
            }, Modifier.fillMaxWidth())
            return@Column
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SoftButton("Meu código", onMyCode, Modifier.weight(1f), icon = R.drawable.ic_qr)
            SecondaryButton("Adicionar", onAdd, Modifier.weight(1f), icon = R.drawable.ic_plus)
        }
        requests.forEach { r ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.accentSoft).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(r.name, style = Cartucho.type.headline.copy(fontSize = 16.sp), color = c.text)
                    Text("quer ser seu amigo no Cartucho", style = Cartucho.type.caption, color = c.textSecondary)
                }
                Text("Aceitar", style = Cartucho.type.label, color = c.accent, modifier = Modifier.pressable(shape = RoundedCornerShape(8.dp)) {
                    Friends.accept(app, r)
                    onMessage("${r.name} agora é seu amigo.")
                }.padding(8.dp))
                Text("Recusar", style = Cartucho.type.label, color = c.textSecondary, modifier = Modifier.pressable(shape = RoundedCornerShape(8.dp)) {
                    Friends.decline(app, r)
                }.padding(8.dp))
            }
        }
        if (friends.isEmpty()) {
            Text("Nenhum amigo ainda. Mande o seu código para um amigo, ou adicione o código dele.", style = Cartucho.type.caption, color = c.textSecondary)
        }
        val sorted = friends.sortedWith(compareByDescending<Friends.Friend> { Friends.isOnline(it.presence) }.thenByDescending { it.unread }.thenBy { it.name.lowercase() })
        sorted.forEach { f -> FriendRow(f) { onOpenChat(f.inbox) } }
    }
}

@Composable
private fun FriendRow(f: Friends.Friend, onClick: () -> Unit) {
    val c = Cartucho.colors
    val online = Friends.isOnline(f.presence)
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).pressable(shape = RoundedCornerShape(12.dp), onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(f.name, online)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, style = Cartucho.type.headline.copy(fontSize = 16.sp), color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(statusLine(f.presence), style = Cartucho.type.caption, color = if (online) c.accent else c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (f.unread > 0) {
            Box(Modifier.size(22.dp).clip(CircleShape).background(Brand.dotRed), contentAlignment = Alignment.Center) {
                Text("${f.unread.coerceAtMost(9)}", style = Cartucho.type.caption.copy(fontSize = 11.sp), color = androidx.compose.ui.graphics.Color.White)
            }
        }
    }
}

@Composable
private fun Avatar(name: String, online: Boolean) {
    val c = Cartucho.colors
    Box {
        Box(Modifier.size(40.dp).clip(CircleShape).background(c.accentSoft), contentAlignment = Alignment.Center) {
            Text(name.take(1).uppercase(), style = Cartucho.type.title.copy(fontSize = 18.sp), color = c.onAccentSoft)
        }
        Box(
            Modifier.align(Alignment.BottomEnd).size(12.dp).clip(CircleShape).background(c.surface).padding(2.dp)
                .clip(CircleShape).background(if (online) Brand.dotGreen else Brand.line),
        )
    }
}

private fun statusLine(p: Friends.Presence?): String {
    if (p == null) return "Ainda sem notícias"
    if (Friends.isOnline(p)) return if (p.game.isNotBlank()) "Jogando ${p.game}" + (if (p.system.isNotBlank()) " · ${p.system}" else "") else "Online"
    val min = (System.currentTimeMillis() - p.ts) / 60000
    return when {
        min < 60 -> "Visto há $min min"
        min < 24 * 60 -> "Visto há ${min / 60} h"
        else -> "Visto há ${min / (24 * 60)} dias"
    }
}

/** Meu código: QR para o amigo ler, e o link para mandar por mensagem. */
@Composable
fun MyCodeSheet(activity: MainActivity, onMessage: (String) -> Unit) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val profile by app.profile.data.collectAsState()
    val code = remember(profile.name) { Friends.myCode(app, profile.name) }
    val qr = remember(code) { qrBitmap(code, 600).asImageBitmap() }
    val clipboard = LocalClipboardManager.current
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Meu código de amigo", style = Cartucho.type.title, color = c.text)
        Text("Seu amigo lê este QR no Cartucho dele (Online › Amigos › Adicionar), ou você manda o link.", style = Cartucho.type.caption, color = c.textSecondary)
        Box(Modifier.size(220.dp).clip(RoundedCornerShape(16.dp)).background(androidx.compose.ui.graphics.Color.White).padding(10.dp)) {
            Image(qr, "QR do meu código", modifier = Modifier.fillMaxSize())
        }
        Text("Aparece como: ${profile.name.ifBlank { "Jogador" }} (o nome do seu perfil)", style = Cartucho.type.caption, color = c.textSecondary)
        PrimaryButton("Mandar meu código", {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "Me adiciona no Cartucho! Abra no app: Online › Amigos › Adicionar e cole este código:\n$code")
            activity.startActivity(Intent.createChooser(send, "Mandar código"))
        }, Modifier.fillMaxWidth(), icon = R.drawable.ic_upload)
        SecondaryButton("Copiar", {
            clipboard.setText(AnnotatedString(code))
            onMessage("Código copiado.")
        }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
    }
}

/** Adicionar amigo: ler o QR dele ou colar o código. */
@Composable
fun AddFriendSheet(activity: MainActivity, onDone: (String?) -> Unit) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    fun add(t: String) {
        val name = Friends.addByCode(app, t)
        if (name == null) error = "Esse código não é de um amigo do Cartucho (ou é o seu)." else onDone("Pedido enviado para $name. Assim que aceitar, aparece online aqui.")
    }
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Adicionar amigo", style = Cartucho.type.title, color = c.text)
        PrimaryButton("Ler o QR do amigo", {
            runCatching {
                GmsBarcodeScanning.getClient(activity, GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
                    .startScan()
                    .addOnSuccessListener { b -> add(b.rawValue.orEmpty()) }
                    .addOnFailureListener { error = "Não foi possível abrir o leitor de QR. Cole o código." }
            }
        }, Modifier.fillMaxWidth(), icon = R.drawable.ic_qr)
        Text("Ou cole o código que ele mandou:", style = Cartucho.type.caption, color = c.textSecondary)
        Box(
            Modifier.fillMaxWidth().heightIn(min = 52.dp).clip(RoundedCornerShape(12.dp)).background(c.surface)
                .border(1.dp, Brand.line, RoundedCornerShape(12.dp)).padding(14.dp),
        ) {
            if (text.isEmpty()) Text("Código ou link do amigo", style = Cartucho.type.body, color = c.textSecondary)
            BasicTextField(text, { text = it; error = null }, textStyle = Cartucho.type.body.copy(color = c.text), cursorBrush = SolidColor(c.accent), modifier = Modifier.fillMaxWidth())
        }
        error?.let { Text(it, style = Cartucho.type.caption, color = Brand.dotRed) }
        SecondaryButton("Adicionar", { add(text) }, Modifier.fillMaxWidth(), enabled = text.isNotBlank())
        Spacer(Modifier.height(8.dp))
    }
}

/** Conversa com um amigo: mensagens, convites para jogar e status dele no topo. */
@Composable
fun FriendChat(activity: MainActivity, inbox: String, onBack: () -> Unit, onInvite: () -> Unit, onMessage: (String) -> Unit) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val friends by Friends.friends.collectAsState()
    val version by Friends.chatVersion.collectAsState()
    val friend = friends.firstOrNull { it.inbox == inbox }
    if (friend == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val msgs = remember(version, inbox) { Friends.loadChat(app, inbox) }
    LaunchedEffect(version, inbox) { Friends.markRead(app, inbox) }
    var draft by remember { mutableStateOf("") }
    var confirmRemove by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().background(c.background).windowInsetsPadding(WindowInsets.safeDrawing).imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).pressable(shape = CircleShape, onClick = onBack), contentAlignment = Alignment.Center) {
                CIcon(R.drawable.ic_back, tint = c.accent, size = 20.dp)
            }
            Avatar(friend.name, Friends.isOnline(friend.presence))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(friend.name, style = Cartucho.type.headline.copy(fontSize = 17.sp), color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(statusLine(friend.presence), style = Cartucho.type.caption, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(
                if (confirmRemove) "Confirmar" else "Remover",
                style = Cartucho.type.caption,
                color = if (confirmRemove) Brand.dotRed else c.textSecondary,
                modifier = Modifier.pressable(shape = RoundedCornerShape(8.dp)) {
                    if (confirmRemove) {
                        Friends.remove(app, inbox)
                        onMessage("${friend.name} saiu da sua lista.")
                        onBack()
                    } else confirmRemove = true
                }.padding(8.dp),
            )
        }
        Box(Modifier.padding(horizontal = 16.dp)) {
            SoftButton("Convidar para jogar", onInvite, Modifier.fillMaxWidth(), icon = R.drawable.ic_people)
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = list,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (msgs.isEmpty()) {
                item {
                    Text("Diga oi! As mensagens vão cifradas, só vocês dois leem. Quem estiver sem internet recebe em até 12 horas.", style = Cartucho.type.caption, color = c.textSecondary)
                }
            }
            items(msgs, key = { it.id }) { m -> Bubble(activity, m) }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.weight(1f).heightIn(min = 48.dp).clip(RoundedCornerShape(24.dp)).background(c.surface)
                    .border(1.dp, Brand.line, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 13.dp),
            ) {
                if (draft.isEmpty()) Text("Mensagem", style = Cartucho.type.body, color = c.textSecondary)
                BasicTextField(draft, { draft = it.take(1000) }, textStyle = Cartucho.type.body.copy(color = c.text), cursorBrush = SolidColor(c.accent), modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(if (draft.isBlank()) c.accentSoft else c.accent)
                    .pressable(shape = CircleShape) {
                        if (draft.isNotBlank()) {
                            Friends.sendText(app, inbox, draft.trim())
                            draft = ""
                        }
                    },
                contentAlignment = Alignment.Center,
            ) { CIcon(R.drawable.ic_upload, tint = if (draft.isBlank()) c.onAccentSoft else androidx.compose.ui.graphics.Color.White, size = 20.dp) }
        }
    }
}

@Composable
private fun Bubble(activity: MainActivity, m: Friends.ChatMsg) {
    val c = Cartucho.colors
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromMe) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(16.dp))
                .background(if (m.fromMe) c.accent else c.surfaceRaised).padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            val ink = if (m.fromMe) androidx.compose.ui.graphics.Color.White else c.text
            if (m.kind == "invite") {
                Text(if (m.fromMe) "Você chamou para jogar" else "Convite para jogar", style = Cartucho.type.caption, color = ink.copy(alpha = 0.8f))
                Text(m.game.ifBlank { "Sala online" }, style = Cartucho.type.headline.copy(fontSize = 16.sp), color = ink)
                if (!m.fromMe && m.room.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Entrar na sala ${m.room}",
                        style = Cartucho.type.label,
                        color = c.accent,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(androidx.compose.ui.graphics.Color.White)
                            .pressable(shape = RoundedCornerShape(10.dp)) { RoomGuestActivity.open(activity, m.room) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    )
                } else if (m.room.isNotBlank()) {
                    Text("Sala ${m.room}", style = Cartucho.type.caption, color = ink.copy(alpha = 0.8f))
                }
            } else {
                Text(m.text, style = Cartucho.type.body, color = ink)
            }
            val t = java.text.SimpleDateFormat("HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date(m.ts))
            Text(t, style = Cartucho.type.caption.copy(fontSize = 10.sp), color = ink.copy(alpha = 0.65f))
        }
    }
}
