package app.cartucho.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import app.cartucho.CartuchoApp
import app.cartucho.cloud.SyncScheduler
import app.cartucho.data.Game
import app.cartucho.data.Rating
import app.cartucho.data.Systems
import app.cartucho.game.GameActivity
import app.cartucho.ui.screens.AboutScreen
import app.cartucho.ui.screens.AudioSettingsScreen
import app.cartucho.ui.screens.BiosScreen
import app.cartucho.ui.screens.CloudScreen
import app.cartucho.ui.screens.ControlsScreen
import app.cartucho.ui.screens.DriveFolderScreen
import app.cartucho.ui.screens.LibraryScreen
import app.cartucho.ui.screens.OnboardingScreen
import app.cartucho.ui.screens.RaScreen
import app.cartucho.ui.screens.SettingsScreen
import app.cartucho.ui.screens.SystemsScreen
import app.cartucho.ui.screens.VideoSettingsScreen
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.CartuchoTheme
import app.cartucho.ui.theme.Motion

enum class Route { Library, Settings, Controls, Audio, Video, Cloud, DriveFolders, Achievements, Bios, Systems, About }

/** Captura de teclas do controle para a tela de remapeamento. */
object KeyCapture {
    @Volatile var listener: ((KeyEvent) -> Boolean)? = null
}

class MainActivity : ComponentActivity() {
    private val app get() = application as CartuchoApp
    private val stack = mutableStateListOf(Route.Library)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            val settings by app.prefs.settings.collectAsState()
            CartuchoTheme(settings.theme) {
                Box(Modifier.fillMaxSize().background(Cartucho.colors.background)) {
                    if (!settings.onboardingDone) {
                        OnboardingScreen(onDone = { app.prefs.update { it.copy(onboardingDone = true) } })
                    } else {
                        AppNavigation()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // O processo do jogo pode ter alterado ajustes; relê e sincroniza saves se a nuvem estiver ligada.
        app.prefs.reload()
        if (app.prefs.current.driveEnabled) SyncScheduler.enqueue(this)
    }

    fun navigate(route: Route) {
        stack.add(route)
    }

    fun back() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun launchGame(game: Game): String? {
        val system = Systems.get(game.systemId) ?: return "Sistema desconhecido."
        val rating = app.device.rate(system)
        if (rating.rating == Rating.UNSUPPORTED) return rating.reason ?: "Este sistema não é suportado neste aparelho."
        app.library.markPlayed(game.id)
        startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_GAME_ID, game.id))
        return null
    }

    @Composable
    private fun AppNavigation() {
        val current = stack.last()
        val depth = stack.size
        BackHandler(enabled = depth > 1) { back() }
        val reduced = Cartucho.reducedMotion
        val previousDepth = remember { intArrayOf(depth) }
        AnimatedContent(
            targetState = current,
            transitionSpec = {
                val forward = depth >= previousDepth[0]
                previousDepth[0] = depth
                if (reduced) {
                    ContentTransform(fadeIn(Motion.fade()), fadeOut(Motion.fade()))
                } else if (forward) {
                    (slideInHorizontally(Motion.standard()) { it / 3 } + fadeIn(Motion.fade()))
                        .togetherWith(slideOutHorizontally(Motion.standard()) { -it / 6 } + fadeOut(Motion.fade()))
                } else {
                    (slideInHorizontally(Motion.standard()) { -it / 6 } + fadeIn(Motion.fade()))
                        .togetherWith(slideOutHorizontally(Motion.standard()) { it / 3 } + fadeOut(Motion.fade()))
                }
            },
            label = "nav",
        ) { route ->
            when (route) {
                Route.Library -> LibraryScreen(this@MainActivity)
                Route.Settings -> SettingsScreen(this@MainActivity)
                Route.Controls -> ControlsScreen(this@MainActivity)
                Route.Audio -> AudioSettingsScreen(this@MainActivity)
                Route.Video -> VideoSettingsScreen(this@MainActivity)
                Route.Cloud -> CloudScreen(this@MainActivity)
                Route.DriveFolders -> DriveFolderScreen(this@MainActivity)
                Route.Achievements -> RaScreen(this@MainActivity)
                Route.Bios -> BiosScreen(this@MainActivity)
                Route.Systems -> SystemsScreen(this@MainActivity)
                Route.About -> AboutScreen(this@MainActivity)
            }
        }
    }

    /** Botões de controle navegam na interface: A confirma, B volta. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        KeyCapture.listener?.let { if (it(event)) return true }
        val mapped = when (event.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER
            KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK
            else -> null
        }
        if (mapped != null) {
            return super.dispatchKeyEvent(KeyEvent(event.downTime, event.eventTime, event.action, mapped, event.repeatCount, event.metaState, event.deviceId, event.scanCode, event.flags, event.source))
        }
        return super.dispatchKeyEvent(event)
    }
}
