package app.cartucho.ui

import app.cartucho.game.RunningGame
import app.cartucho.ui.screens.CollectionScreen
import app.cartucho.ui.screens.StoreScreen
import app.cartucho.ui.screens.ProfileScreen

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.cartucho.social.Mural
import app.cartucho.CrashReport
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import app.cartucho.CartuchoApp
import app.cartucho.cloud.SyncScheduler
import app.cartucho.data.Game
import app.cartucho.data.Rating
import app.cartucho.data.Systems
import app.cartucho.game.GameActivity
import app.cartucho.ui.screens.AboutScreen
import app.cartucho.ui.screens.AudioSettingsScreen
import app.cartucho.ui.screens.BiosScreen
import app.cartucho.ui.screens.CloudScreen
import app.cartucho.ui.screens.ControlsScreen
import app.cartucho.ui.screens.DriveFolderScreen
import app.cartucho.ui.screens.LibraryScreen
import app.cartucho.ui.screens.OnboardingScreen
import app.cartucho.ui.screens.RaScreen
import app.cartucho.ui.screens.SettingsScreen
import app.cartucho.ui.screens.SystemsScreen
import app.cartucho.ui.screens.VideoSettingsScreen
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.CartuchoTheme
import app.cartucho.ui.theme.Motion

enum class Route { Library, Profile, Store, Collection, Settings, Controls, Audio, Video, Cloud, DriveFolders, Achievements, Bios, Systems, About }

/** Captura de teclas do controle para a tela de remapeamento. */
object KeyCapture {
    @Volatile var listener: ((KeyEvent) -> Boolean)? = null
}

class MainActivity : ComponentActivity() {
    private val app get() = application as CartuchoApp
    private val stack = mutableStateListOf(Route.Library)
    /** Aberto por um aviso do mural: vai direto para Coleção > Mural. */
    var openMural by mutableStateOf(false)

    private fun handleIntent(intent: android.content.Intent?) {
        if (intent?.getStringExtra("abrir") == "mural") {
            intent.removeExtra("abrir")
            openMural = true
            if (stack.lastOrNull() != Route.Collection) stack.add(Route.Collection)
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        handleIntent(intent)
        if (app.prefs.current.raUser.isNotEmpty() && app.secure.raWebKey.isNotEmpty()) Mural.schedule(this)
        setContent {
            val settings by app.prefs.settings.collectAsState()
            CartuchoTheme(settings.theme) {
                Box(Modifier.fillMaxSize().background(Cartucho.colors.background)) {
                    if (!settings.onboardingDone) {
                        OnboardingScreen(onDone = { app.prefs.update { it.copy(onboardingDone = true) } })
                    } else {
                        AppNavigation()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // O processo do jogo pode ter alterado ajustes; relê e sincroniza saves se a nuvem estiver ligada.
        app.prefs.reload()
        if (app.prefs.current.driveEnabled) SyncScheduler.enqueue(this)
        // Se o jogo fechou por erro, mostra os detalhes para o usuário copiar e mandar.
        window.decorView.postDelayed({
            if (isFinishing) return@postDelayed
            val ended = RunningGame.endedAbruptly(this)
            val details = CrashReport.pending(this)
            val game = ended?.let { app.library.find(it.gameId) }
            if (game != null) {
                // O jogo fechou sozinho: explica e oferece voltar ao último ponto salvo automaticamente.
                val b = android.app.AlertDialog.Builder(this)
                    .setTitle("O jogo fechou sozinho")
                    .setMessage(buildString {
                        append(game.title).append(" fechou de repente.")
                        if (ended.autoFile != null) append(" O Cartucho salva o seu progresso a cada 2 minutos: dá para continuar de onde parou.")
                        else append(" Não deu tempo de salvar um ponto de retomada (ele é salvo a cada 2 minutos).")
                        if (game.systemId == "ps2") append("\n\nNo PS2, colocar o BIOS do seu console ativa o motor ARMSX2, que roda mais jogos sem fechar.")
                        details?.let { append("\n\nDetalhes:\n").append(it.take(1500)) }
                    })
                    .setNegativeButton("Fechar", null)
                if (ended.autoFile != null) b.setPositiveButton("Continuar de onde parou") { _, _ -> launchGame(game, resume = true) }
                if (details != null) b.setNeutralButton("Copiar detalhes") { _, _ ->
                    getSystemService(android.content.ClipboardManager::class.java)
                        .setPrimaryClip(android.content.ClipData.newPlainText("Erro do Cartucho", details))
                }
                b.show()
            } else details?.let { CrashReport.show(this, it) }
        }, 600)
    }

    fun navigate(route: Route) {
        stack.add(route)
    }

    fun back() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun launchGame(game: Game, resume: Boolean = false): String? {
        val system = Systems.get(game.systemId) ?: return "Sistema desconhecido."
        val rating = app.device.rate(system)
        if (rating.rating == Rating.UNSUPPORTED) return rating.reason ?: "Este sistema não é suportado neste aparelho."
        app.library.markPlayed(game.id)
        startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_GAME_ID, game.id).putExtra(GameActivity.EXTRA_RESUME, resume))
        return null
    }

    @Composable
    private fun AppNavigation() {
        val current = stack.last()
        val depth = stack.size
        BackHandler(enabled = depth > 1) { back() }
        val reduced = Cartucho.reducedMotion
        val previousDepth = remember { intArrayOf(depth) }
        AnimatedContent(
            targetState = current,
            transitionSpec = {
                val forward = depth >= previousDepth[0]
                previousDepth[0] = depth
                if (reduced) {
                    ContentTransform(fadeIn(Motion.fade()), fadeOut(Motion.fade()))
                } else if (forward) {
                    (slideInHorizontally(Motion.standard()) { it / 3 } + fadeIn(Motion.fade()))
                        .togetherWith(slideOutHorizontally(Motion.standard()) { -it / 6 } + fadeOut(Motion.fade()))
                } else {
                    (slideInHorizontally(Motion.standard()) { -it / 6 } + fadeIn(Motion.fade()))
                        .togetherWith(slideOutHorizontally(Motion.standard()) { it / 3 } + fadeOut(Motion.fade()))
                }
            },
            label = "nav",
        ) { route ->
            when (route) {
                Route.Library -> LibraryScreen(this@MainActivity)
                Route.Store -> StoreScreen(this@MainActivity)
                Route.Profile -> ProfileScreen(this@MainActivity)
                Route.Collection -> CollectionScreen(this@MainActivity)
                Route.Settings -> SettingsScreen(this@MainActivity)
                Route.Controls -> ControlsScreen(this@MainActivity)
                Route.Audio -> AudioSettingsScreen(this@MainActivity)
                Route.Video -> VideoSettingsScreen(this@MainActivity)
                Route.Cloud -> CloudScreen(this@MainActivity)
                Route.DriveFolders -> DriveFolderScreen(this@MainActivity)
                Route.Achievements -> RaScreen(this@MainActivity)
                Route.Bios -> BiosScreen(this@MainActivity)
                Route.Systems -> SystemsScreen(this@MainActivity)
                Route.About -> AboutScreen(this@MainActivity)
            }
        }
    }

    /** Botões de controle navegam na interface: A confirma, B volta. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        KeyCapture.listener?.let { if (it(event)) return true }
        val mapped = when (event.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER
            KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK
            else -> null
        }
        if (mapped != null) {
            return super.dispatchKeyEvent(KeyEvent(event.downTime, event.eventTime, event.action, mapped, event.repeatCount, event.metaState, event.deviceId, event.scanCode, event.flags, event.source))
        }
        return super.dispatchKeyEvent(event)
    }
}
