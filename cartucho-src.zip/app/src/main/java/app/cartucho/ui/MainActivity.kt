package app.cartucho.ui

import app.cartucho.R

import app.cartucho.game.RunningGame
import app.cartucho.ui.screens.CollectionScreen
import app.cartucho.ui.screens.StoreScreen
import app.cartucho.ui.screens.ProfileScreen

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.cartucho.social.Mural
import app.cartucho.CrashReport
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import app.cartucho.CartuchoApp
import app.cartucho.cloud.SyncScheduler
import app.cartucho.data.Game
import app.cartucho.data.Rating
import app.cartucho.data.Systems
import app.cartucho.game.GameActivity
import app.cartucho.ui.screens.AboutScreen
import app.cartucho.ui.screens.AudioSettingsScreen
import app.cartucho.ui.screens.BiosScreen
import app.cartucho.ui.screens.CloudScreen
import app.cartucho.ui.screens.ControlsScreen
import app.cartucho.ui.screens.DriveFolderScreen
import app.cartucho.ui.screens.LibraryScreen
import app.cartucho.ui.screens.OnboardingScreen
import app.cartucho.ui.screens.RaScreen
import app.cartucho.ui.screens.SettingsScreen
import app.cartucho.ui.screens.SystemsScreen
import app.cartucho.ui.screens.VideoSettingsScreen
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.CartuchoTheme
import app.cartucho.ui.theme.Motion
import app.cartucho.data.ThemeMode
import app.cartucho.ui.screens.OnlineScreen
import app.cartucho.ui.screens.ShareScreen
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.cartucho.ui.components.CIcon
import app.cartucho.ui.components.pressable

enum class Route { Library, Profile, Store, Collection, Settings, Controls, Audio, Video, Cloud, DriveFolders, Achievements, Bios, Systems, About, Online, Share }

/** As quatro abas do app, na ordem do wireframe. */
private val TABS = listOf(
    Triple(Route.Library, "Biblioteca", R.drawable.ic_grid),
    Triple(Route.Store, "Loja", R.drawable.ic_bag),
    Triple(Route.Online, "Online", R.drawable.ic_people),
    Triple(Route.Settings, "Ajustes", R.drawable.ic_gear),
)

/** Captura de teclas do controle para a tela de remapeamento. */
object KeyCapture {
    @Volatile var listener: ((KeyEvent) -> Boolean)? = null
}

class MainActivity : ComponentActivity() {
    private val app get() = application as CartuchoApp
    private val stack = mutableStateListOf(Route.Library)
    /** Aberto por um aviso do mural: vai direto para Coleção > Mural. */
    var openMural by mutableStateOf(false)
    /** Esconde a barra de abas (página do jogo aberta na Biblioteca). */
    var tabBarHidden by mutableStateOf(false)
    /** Jogo da tela Compartilhar. */
    var shareTarget by mutableStateOf<Game?>(null)

    /** Troca de aba: a pilha recomeça na raiz da aba. */
    fun selectTab(route: Route) {
        tabBarHidden = false
        stack.clear()
        stack.add(route)
    }

    fun openShare(game: Game) {
        shareTarget = game
        navigate(Route.Share)
    }

    private fun handleIntent(intent: android.content.Intent?) {
        if (intent?.getStringExtra("abrir") == "mural") {
            intent.removeExtra("abrir")
            openMural = true
            if (stack.lastOrNull() != Route.Collection) stack.add(Route.Collection)
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // Tema claro: ícones escuros na barra de status e na de navegação.
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
        handleIntent(intent)
        if (app.prefs.current.raUser.isNotEmpty() && app.secure.raWebKey.isNotEmpty()) Mural.schedule(this)
        setContent {
            val settings by app.prefs.settings.collectAsState()
            CartuchoTheme(ThemeMode.LIGHT) {
                Box(Modifier.fillMaxSize().background(Cartucho.colors.background)) {
                    if (!settings.onboardingDone) {
                        OnboardingScreen(onDone = { app.prefs.update { it.copy(onboardingDone = true) } })
                    } else {
                        AppNavigation()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // O processo do jogo pode ter alterado ajustes; relê e sincroniza saves se a nuvem estiver ligada.
        app.prefs.reload()
        if (app.prefs.current.driveEnabled) SyncScheduler.enqueue(this)
        // Se o jogo fechou por erro, mostra os detalhes para o usuário copiar e mandar.
        window.decorView.postDelayed({
            if (isFinishing) return@postDelayed
            val ended = RunningGame.endedAbruptly(this)
            val details = CrashReport.pending(this)
            val game = ended?.let { app.library.find(it.gameId) }
            if (game != null) {
                // O jogo fechou sozinho: explica e oferece voltar ao último ponto salvo automaticamente.
                val b = android.app.AlertDialog.Builder(this)
                    .setTitle("O jogo fechou sozinho")
                    .setMessage(buildString {
                        append(game.title).append(" fechou de repente.")
                        if (ended.autoFile != null) append(" O Cartucho salva o seu progresso a cada 2 minutos: dá para continuar de onde parou.")
                        else append(" Não deu tempo de salvar um ponto de retomada (ele é salvo a cada 2 minutos).")
                        if (game.systemId == "ps2") append("\n\nNo PS2, colocar o BIOS do seu console ativa o motor ARMSX2, que roda mais jogos sem fechar.")
                        details?.let { append("\n\nDetalhes:\n").append(it.take(1500)) }
                    })
                    .setNegativeButton("Fechar", null)
                if (ended.autoFile != null) b.setPositiveButton("Continuar de onde parou") { _, _ -> launchGame(game, resume = true) }
                if (details != null) b.setNeutralButton("Copiar detalhes") { _, _ ->
                    getSystemService(android.content.ClipboardManager::class.java)
                        .setPrimaryClip(android.content.ClipData.newPlainText("Erro do Cartucho", details))
                }
                b.show()
            } else details?.let { CrashReport.show(this, it) }
        }, 600)
    }

    fun navigate(route: Route) {
        stack.add(route)
    }

    fun back() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun launchGame(game: Game, resume: Boolean = false, openRoom: Boolean = false): String? {
        val system = Systems.get(game.systemId) ?: return "Sistema desconhecido."
        val rating = app.device.rate(system)
        if (rating.rating == Rating.UNSUPPORTED) return rating.reason ?: "Este sistema não é suportado neste aparelho."
        app.library.markPlayed(game.id)
        startActivity(
            Intent(this, GameActivity::class.java)
                .putExtra(GameActivity.EXTRA_GAME_ID, game.id)
                .putExtra(GameActivity.EXTRA_RESUME, resume)
                .putExtra(GameActivity.EXTRA_OPEN_ROOM, openRoom)
        )
        return null
    }

    @Composable
    private fun AppNavigation() {
        val current = stack.last()
        val depth = stack.size
        BackHandler(enabled = depth > 1) { back() }
        // Numa aba que não é a Biblioteca, voltar leva para a Biblioteca.
        BackHandler(enabled = depth == 1 && current != Route.Library) { selectTab(Route.Library) }
        val reduced = Cartucho.reducedMotion
        val previousDepth = remember { intArrayOf(depth) }
        val showTabs = depth == 1 && TABS.any { it.first == current } && !tabBarHidden
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).then(if (showTabs) Modifier.consumeWindowInsets(WindowInsets.navigationBars) else Modifier)) {
                AnimatedContent(
                    targetState = current,
                    transitionSpec = {
                        val forward = depth >= previousDepth[0]
                        previousDepth[0] = depth
                        val tabSwitch = TABS.any { it.first == initialState } && TABS.any { it.first == targetState } && depth == 1
                        if (reduced || tabSwitch) {
                            ContentTransform(fadeIn(Motion.fade()), fadeOut(Motion.fade()))
                        } else if (forward) {
                            (slideInHorizontally(Motion.standard()) { it / 3 } + fadeIn(Motion.fade()))
                                .togetherWith(slideOutHorizontally(Motion.standard()) { -it / 6 } + fadeOut(Motion.fade()))
                        } else {
                            (slideInHorizontally(Motion.standard()) { -it / 6 } + fadeIn(Motion.fade()))
                                .togetherWith(slideOutHorizontally(Motion.standard()) { it / 3 } + fadeOut(Motion.fade()))
                        }
                    },
                    label = "nav",
                ) { route ->
                    when (route) {
                        Route.Library -> LibraryScreen(this@MainActivity)
                        Route.Store -> StoreScreen(this@MainActivity)
                        Route.Profile -> ProfileScreen(this@MainActivity)
                        Route.Collection -> CollectionScreen(this@MainActivity)
                        Route.Settings -> SettingsScreen(this@MainActivity)
                        Route.Controls -> ControlsScreen(this@MainActivity)
                        Route.Audio -> AudioSettingsScreen(this@MainActivity)
                        Route.Video -> VideoSettingsScreen(this@MainActivity)
                        Route.Cloud -> CloudScreen(this@MainActivity)
                        Route.DriveFolders -> DriveFolderScreen(this@MainActivity)
                        Route.Achievements -> RaScreen(this@MainActivity)
                        Route.Bios -> BiosScreen(this@MainActivity)
                        Route.Systems -> SystemsScreen(this@MainActivity)
                        Route.About -> AboutScreen(this@MainActivity)
                        Route.Online -> OnlineScreen(this@MainActivity)
                        Route.Share -> ShareScreen(this@MainActivity)
                    }
                }
            }
            if (showTabs) TabBar(current)
        }
    }

    /** Barra de abas: branca, ícone e nome; a aba ativa em roxo. */
    @Composable
    private fun TabBar(current: Route) {
        val c = Cartucho.colors
        Column(Modifier.fillMaxWidth().background(c.background)) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(c.placeholder))
            Row(
                Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.navigationBars).heightIn(min = 60.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TABS.forEach { (route, label, icon) ->
                    val active = route == current
                    val tint = if (active) c.accent else c.textSecondary
                    Column(
                        Modifier.weight(1f).heightIn(min = 52.dp)
                            .pressable(shape = RoundedCornerShape(12.dp), role = androidx.compose.ui.semantics.Role.Tab) { if (!active) selectTab(route) }
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                    ) {
                        CIcon(icon, tint = tint, size = 22.dp)
                        Box(Modifier.height(4.dp))
                        Text(
                            label,
                            style = Cartucho.type.caption.copy(fontSize = 11.sp, lineHeight = 13.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium),
                            color = tint,
                        )
                    }
                }
            }
        }
    }

    /** Botões de controle navegam na interface: A confirma, B volta. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        KeyCapture.listener?.let { if (it(event)) return true }
        val mapped = when (event.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER
            KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK
            else -> null
        }
        if (mapped != null) {
            return super.dispatchKeyEvent(KeyEvent(event.downTime, event.eventTime, event.action, mapped, event.repeatCount, event.metaState, event.deviceId, event.scanCode, event.flags, event.source))
        }
        return super.dispatchKeyEvent(event)
    }
}
