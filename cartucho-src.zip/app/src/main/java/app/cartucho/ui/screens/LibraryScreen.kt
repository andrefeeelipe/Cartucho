package app.cartucho.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.data.Game
import app.cartucho.data.GameLibrary
import app.cartucho.data.GameScanner
import app.cartucho.data.GameResolver
import app.cartucho.data.Detection
import app.cartucho.data.Archives
import app.cartucho.data.Patches
import app.cartucho.data.GameSystem
import app.cartucho.data.LibraryFolder
import app.cartucho.data.Systems
import app.cartucho.data.Covers
import app.cartucho.ui.MainActivity
import app.cartucho.ui.Route
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.CIcon
import app.cartucho.ui.components.IconButton
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SectionLabel
import app.cartucho.ui.components.SheetAction
import app.cartucho.ui.components.pressable
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.Motion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class PendingChoice(val game: Game, val candidates: List<GameSystem>)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val games by app.library.games.collectAsState()
    val scope = rememberCoroutineScope()

    var filter by remember { mutableStateOf<String?>(null) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf<String?>(null) }
    var scanning by remember { mutableStateOf<Int?>(null) }
    var choice by remember { mutableStateOf<PendingChoice?>(null) }
    var options by remember { mutableStateOf<Game?>(null) }
    var versionsFor by remember { mutableStateOf<List<Game>?>(null) }
    var working by remember { mutableStateOf<String?>(null) }

    /** Abre o jogo; se o sistema ainda não é conhecido (compactados, pastas da nuvem), identifica antes. */
    fun open(game: Game) {
        if (working != null) return
        if (game.systemKnown) {
            activity.launchGame(game)?.let { notice = it }
            return
        }
        scope.launch {
            working = "Identificando o jogo…"
            val detection = withContext(Dispatchers.IO) {
                runCatching { GameResolver(app, app.detector).detect(game) }
                    .getOrElse { Detection(null, emptyList(), it.message ?: "Não foi possível ler o arquivo.") }
            }
            working = null
            when {
                detection.error != null -> notice = detection.error
                detection.system != null -> {
                    app.library.setSystem(game.id, detection.system.id)
                    activity.launchGame(game.copy(systemId = detection.system.id))?.let { notice = it }
                }
                detection.candidates.size > 1 -> choice = PendingChoice(game, detection.candidates)
                detection.candidates.size == 1 -> {
                    val s0 = detection.candidates.first()
                    app.library.setSystem(game.id, s0.id)
                    activity.launchGame(game.copy(systemId = s0.id))?.let { notice = it }
                }
                else -> notice = "Não reconheci o sistema deste jogo."
            }
        }
    }

    var coverFor by remember { mutableStateOf<Game?>(null) }
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        val g = coverFor
        coverFor = null
        if (uri != null && g != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { runCatching { app.covers.setManual(g.id, uri) }.getOrDefault(false) }
                notice = if (ok) "Capa trocada." else "Não foi possível usar essa imagem."
            }
        }
    }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            activity.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        scope.launch {
            working = "Lendo o arquivo…"
            val result = withContext(Dispatchers.IO) { importFile(app, uri) }
            working = null
            when (result) {
                is ImportResult.Error -> notice = result.message
                is ImportResult.Ok -> open(result.game)
                is ImportResult.Ask -> choice = PendingChoice(result.game, result.candidates)
            }
        }
    }

    val openFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree: Uri? ->
        if (tree == null) return@rememberLauncherForActivityResult
        runCatching {
            activity.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        scanning = 0
        scope.launch {
            val found = withContext(Dispatchers.IO) {
                val scanner = GameScanner(app, app.detector)
                val list = scanner.scan(tree) { n -> scanning = n }
                val name = runCatching {
                    DocumentsContract.getTreeDocumentId(tree).substringAfterLast(':').substringAfterLast('/')
                }.getOrDefault("Pasta")
                app.library.addFolder(LibraryFolder(tree.toString(), name))
                app.library.upsertAll(list)
                list.size
            }
            scanning = null
            notice = if (found == 0) "Nenhum jogo reconhecido nessa pasta." else "$found jogos adicionados."
        }
    }

    LaunchedEffect(notice) {
        if (notice != null) {
            kotlinx.coroutines.delay(3500)
            notice = null
        }
    }

    val settingsState by app.prefs.settings.collectAsState()
    val coverVersion by app.covers.version.collectAsState()
    var hacksFor by remember { mutableStateOf<Game?>(null) }
    var reviewFor by remember { mutableStateOf<Game?>(null) }
    LaunchedEffect(games, settingsState.coverDownload) { app.covers.enqueue(games, settingsState.coverDownload) }

    // Recentes: uma entrada por jogo (a versão jogada por último).
    val recents = remember(games) {
        games.filter { it.lastPlayed > 0 }.sortedByDescending { it.lastPlayed }.distinctBy { titleKey(it) }.take(10)
    }
    val systemsInLibrary = remember(games) { Systems.all.filter { s -> games.any { it.systemId == s.id } } }
    // Versões do mesmo jogo (regiões, revisões, traduções) viram um só cartão.
    val visible = remember(games, filter, query) {
        games.asSequence()
            .filter { filter == null || it.systemId == filter }
            .filter { query.isBlank() || it.title.contains(query.trim(), ignoreCase = true) }
            .let { groupVersions(it.toList()) }
            .map { group -> group.sortedWith(compareByDescending<Game> { it.lastPlayed }.thenBy { versionRank(it) }) }
            .sortedBy { it.first().title.lowercase() }
            .toList()
    }
    fun openGroup(group: List<Game>) {
        if (group.size > 1) versionsFor = group else open(group.first())
    }

    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(152.dp),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 40.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.weight(1f))
                        IconButton(R.drawable.ic_trophy, "Coleção", { activity.navigate(Route.Collection) })
                        IconButton(R.drawable.ic_search, "Buscar", { searching = !searching; if (!searching) query = "" })
                        IconButton(R.drawable.ic_settings, "Ajustes", { activity.navigate(Route.Settings) })
                    }
                    Text("Biblioteca", style = Cartucho.type.display, color = c.text)
                    AnimatedVisibility(searching, enter = fadeIn(Motion.fade()), exit = fadeOut(Motion.fade())) {
                        SearchField(query) { query = it }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PrimaryButton("Abrir jogo", { openFile.launch(arrayOf("*/*")) }, Modifier.weight(1f), icon = R.drawable.ic_file_plus)
                        SecondaryButton("Adicionar pasta", { openFolder.launch(null) }, Modifier.weight(1f), icon = R.drawable.ic_folder_plus)
                    }
                    if (scanning != null) {
                        Spacer(Modifier.height(12.dp))
                        Text("Procurando jogos… ${scanning ?: 0} encontrados. Pastas na nuvem podem levar alguns minutos.", style = Cartucho.type.caption, color = c.textSecondary)
                    }
                    if (working != null) {
                        Spacer(Modifier.height(12.dp))
                        Text(working ?: "", style = Cartucho.type.caption, color = c.textSecondary)
                    }
                }
            }

            if (games.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) { EmptyState() }
            } else {
                if (recents.isNotEmpty() && query.isBlank() && filter == null) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Column {
                            SectionLabel("Recentes")
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(recents, key = { "r" + it.id }) { g ->
                                    GameTile(g, coverVersion, Modifier.width(140.dp), onClick = { open(g) }, onLongClick = { options = g })
                                }
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        SectionLabel("Todos · ${visible.size}")
                        if (systemsInLibrary.size > 1) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                item { FilterChip("Todos", filter == null) { filter = null } }
                                items(systemsInLibrary, key = { it.id }) { s ->
                                    FilterChip(s.short, filter == s.id) { filter = if (filter == s.id) null else s.id }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
                items(visible, key = { it.first().id }) { group ->
                    val g = group.first()
                    GameTile(g, coverVersion, Modifier.fillMaxWidth(), onClick = { openGroup(group) }, onLongClick = { options = g }, versions = group.size)
                }
            }
        }

        AnimatedVisibility(
            visible = notice != null,
            enter = slideInVertically(Motion.standard()) { it } + fadeIn(Motion.fade()),
            exit = slideOutVertically(Motion.standard()) { it } + fadeOut(Motion.fade()),
            modifier = Modifier.align(Alignment.BottomCenter).padding(20.dp),
        ) {
            Text(
                text = notice ?: "",
                style = Cartucho.type.label,
                color = c.background,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(c.text).padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }

        BottomSheet(visible = choice != null, onDismiss = { choice = null }) {
            val pending = choice
            Text("De qual sistema é este jogo?", style = Cartucho.type.title, color = c.text, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            Text(pending?.game?.fileName ?: "", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.height(8.dp))
            if (pending != null) pending.candidates.forEach { s ->
                SheetAction(s.name, R.drawable.ic_controller, {
                    val game = pending.game.copy(systemId = s.id)
                    app.library.upsert(game)
                    app.library.setSystem(game.id, s.id)
                    choice = null
                    activity.launchGame(game)?.let { notice = it }
                })
            }
        }

        BottomSheet(visible = versionsFor != null, onDismiss = { versionsFor = null }) {
            val group = versionsFor
            if (group != null) {
                Text(group.first().title, style = Cartucho.type.title, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                Text("Qual versão você quer jogar?", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 20.dp))
                Spacer(Modifier.height(8.dp))
                group.forEach { v ->
                    SheetAction(
                        versionLabel(v),
                        R.drawable.ic_play,
                        { versionsFor = null; open(v) },
                        subtitle = versionDetails(v),
                    )
                }
                Spacer(Modifier.height(4.dp))
                SheetAction("Opções da versão mais recente", R.drawable.ic_settings, { versionsFor = null; options = group.first() })
            }
        }

        BottomSheet(visible = options != null, onDismiss = { options = null }) {
            val g = options
            if (g != null) {
                Text(g.title, style = Cartucho.type.title, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                Text(Systems.get(g.systemId)?.name ?: "", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 20.dp))
                Spacer(Modifier.height(8.dp))
                SheetAction("Jogar", R.drawable.ic_play, { options = null; open(g) })
                val ext = g.fileName.substringAfterLast('.', "").lowercase()
                val alternatives = if (Archives.isArchive(g.fileName)) Systems.all else Systems.candidatesForExtension(ext)
                if (alternatives.size > 1) {
                    SheetAction("Mudar sistema", R.drawable.ic_sync, {
                        options = null
                        choice = PendingChoice(g, alternatives)
                    }, subtitle = "Use se o jogo foi reconhecido errado")
                }
                SheetAction("Avaliar e marcar como zerado", R.drawable.ic_trophy, { options = null; reviewFor = g })
                SheetAction("Trocar capa", R.drawable.ic_file_plus, {
                    options = null
                    coverFor = g
                    pickCover.launch("image/*")
                }, subtitle = "Escolher uma imagem do celular")
                SheetAction("Procurar capa de novo", R.drawable.ic_search, {
                    options = null
                    app.covers.retry(g)
                    notice = "Procurando a capa…"
                }, subtitle = if (app.covers.isGenerated(g.id)) "Capa provisória: ainda não achamos a oficial" else null)
                val sys = Systems.get(g.systemId)
                if (sys != null && Patches.supports(sys)) {
                    SheetAction(
                        "Hacks e traduções", R.drawable.ic_plus, { options = null; hacksFor = g },
                        subtitle = if (g.patch.isNotEmpty()) "Ativo: ${g.patch}" else "Aplicar um patch .ips, .ups ou .bps",
                    )
                }
                SheetAction("Remover da biblioteca", R.drawable.ic_trash, {
                    app.library.remove(g.id)
                    options = null
                }, danger = true, subtitle = "O arquivo continua no seu aparelho")
            }
        }

        HackSheet(app, hacksFor, onDismiss = { hacksFor = null }, onMessage = { notice = it })
        ReviewSheet(app, reviewFor, onDismiss = { reviewFor = null })
    }
}

@Composable
private fun EmptyState() {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(top = 56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        CIcon(R.drawable.ic_controller, tint = c.textSecondary, size = 40.dp)
        Spacer(Modifier.height(16.dp))
        Text("Nenhum jogo ainda", style = Cartucho.type.headline, color = c.text)
        Spacer(Modifier.height(6.dp))
        Text(
            "Abra um arquivo de jogo que você possui, ou adicione uma pasta para o Cartucho encontrar todos de uma vez.",
            style = Cartucho.type.body,
            color = c.textSecondary,
            modifier = Modifier.padding(horizontal = 24.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    val c = Cartucho.colors
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Row(
        Modifier
            .padding(top = 16.dp)
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(c.surfaceRaised)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CIcon(R.drawable.ic_search, tint = c.textSecondary, size = 18.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text("Buscar na biblioteca", style = Cartucho.type.body, color = c.textSecondary)
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = Cartucho.type.body.copy(color = c.text),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = Cartucho.colors
    Box(
        Modifier
            .heightIn(min = 40.dp)
            .pressable(shape = RoundedCornerShape(999.dp), onClick = onClick)
            .background(if (selected) c.text else Color.Transparent)
            .border(1.dp, if (selected) c.text else c.border, RoundedCornerShape(999.dp))
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = Cartucho.type.mono, color = if (selected) c.background else c.textSecondary)
    }
}

/** Cartão com a capa (quando baixada) ou um cartão tipográfico gerado no aparelho. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameTile(game: Game, coverVersion: Int, modifier: Modifier, onClick: () -> Unit, onLongClick: () -> Unit, versions: Int = 1) {
    val c = Cartucho.colors
    val app = CartuchoApp.instance
    val system = Systems.get(game.systemId)
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    val cover by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, game.id, coverVersion) {
        value = withContext(Dispatchers.IO) { loadCover(app.covers.file(game.id)) }
    }
    Column(
        modifier = modifier
            .clip(shape)
            .background(c.surface)
            .border(if (focused) 2.dp else 1.dp, if (focused) c.accent else c.border, shape)
            .combinedClickable(interactionSource = interaction, indication = null, onClick = onClick, onLongClick = onLongClick),
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.82f).background(c.surfaceRaised),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = cover
            if (bmp != null) {
                androidx.compose.foundation.Image(
                    bitmap = bmp,
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                )
            } else {
                Text(
                    game.title,
                    style = Cartucho.type.headline,
                    color = c.textSecondary,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(14.dp),
                )
            }
            Text(
                system?.short ?: "NOVO",
                style = Cartucho.type.mono,
                color = c.textSecondary,
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp).clip(RoundedCornerShape(4.dp)).background(c.surface).padding(horizontal = 6.dp, vertical = 2.dp),
            )
            if (game.patch.isNotEmpty()) {
                Text(
                    "HACK",
                    style = Cartucho.type.mono,
                    color = c.background,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).clip(RoundedCornerShape(4.dp)).background(c.accent).padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Text(game.title, style = Cartucho.type.label, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                when {
                    versions > 1 -> "${system?.short ?: ""} · $versions versões".trimStart(' ', '·')
                    else -> system?.name ?: "Toque para identificar"
                },
                style = Cartucho.type.caption,
                color = c.textSecondary,
                maxLines = 1,
            )
        }
    }
}

internal fun loadCover(file: java.io.File): androidx.compose.ui.graphics.ImageBitmap? {
    if (!file.exists()) return null
    return runCatching {
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 360) sample *= 2
        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)?.asImageBitmap()
    }.getOrNull()
}

sealed interface ImportResult {
    data class Ok(val game: Game) : ImportResult
    data class Ask(val game: Game, val candidates: List<GameSystem>) : ImportResult
    data class Error(val message: String) : ImportResult
}

private fun importFile(app: CartuchoApp, uri: Uri): ImportResult {
    var name = "jogo"
    var size = 0L
    runCatching {
        app.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                name = cur.getString(0) ?: name
                size = if (cur.isNull(1)) 0L else cur.getLong(1)
            }
        }
    }
    val ext = name.substringAfterLast('.', "").lowercase()
    if (ext in setOf("cue", "gdi", "m3u", "ccd")) {
        return ImportResult.Error("Jogos .$ext usam vários arquivos. Use \"Adicionar pasta\" e escolha a pasta onde ele está, ou compacte tudo em um .zip/.7z.")
    }
    if (ext !in Systems.allExtensions) {
        return ImportResult.Error("O formato .$ext não é de um jogo que o Cartucho reconheça.")
    }
    val uriString = uri.toString()
    val existing = app.library.find(GameLibrary.idFor(uriString))
    var game = Game(
        id = GameLibrary.idFor(uriString),
        title = GameLibrary.titleFromFileName(name),
        fileName = name,
        uri = uriString,
        systemId = existing?.systemId ?: "",
        size = size,
        addedAt = System.currentTimeMillis(),
    )
    if (game.systemKnown) {
        app.library.upsert(game)
        return ImportResult.Ok(game)
    }
    val detection = runCatching { GameResolver(app, app.detector).detect(game) }
        .getOrElse { Detection(null, emptyList(), it.message ?: "Não foi possível ler o arquivo.") }
    detection.error?.let { return ImportResult.Error(it) }
    val system = detection.system ?: detection.candidates.singleOrNull()
    if (system != null) {
        game = game.copy(systemId = system.id)
        app.library.upsert(game)
        return ImportResult.Ok(game)
    }
    if (detection.candidates.isEmpty()) return ImportResult.Error("Não reconheci o sistema deste jogo.")
    app.library.upsert(game)
    return ImportResult.Ask(game, detection.candidates)
}


/** Título comparável: sem região, revisão, marcas de tradução/hack, pontuação ou espaços. */
internal fun titleKey(g: Game): String {
    // Palavras sem marcas, com romanos viram números ("Final Fantasy III" = "Final Fantasy 3").
    val fromFile = Covers.tokens(g.fileName.substringBeforeLast('.')).joinToString("")
    return fromFile.ifEmpty { Covers.tokens(g.title).joinToString("") }.ifEmpty { g.id }
}

/**
 * Junta as versões de um mesmo jogo pelo título. Um jogo ainda não identificado (sistema
 * desconhecido, comum em .zip da nuvem) entra junto das versões já identificadas;
 * só ficam separados títulos iguais de sistemas diferentes (ex.: Tetris de NES e de Game Boy).
 */
internal fun groupVersions(games: List<Game>): List<List<Game>> {
    val out = ArrayList<List<Game>>()
    for ((_, sameTitle) in games.groupBy { titleKey(it) }) {
        val known = sameTitle.filter { it.systemKnown }.groupBy { it.systemId }
        val unknown = sameTitle.filter { !it.systemKnown }
        if (known.isEmpty()) {
            out.add(unknown)
            continue
        }
        val biggest = known.maxByOrNull { it.value.size }!!.key
        for ((sys, list) in known) out.add(if (sys == biggest) list + unknown else list)
    }
    return out
}

/** Ordem quando nenhuma versão foi jogada: originais em inglês/BR primeiro, hacks e betas por último. */
private fun versionRank(g: Game): Int {
    val n = g.fileName.lowercase()
    return when {
        g.patch.isNotEmpty() || "hack" in n || "beta" in n || "proto" in n -> 9
        "(usa" in n || "(world" in n -> 0
        "(brazil" in n || "pt-br" in n || "ptbr" in n || "(br)" in n || "[br]" in n -> 1
        "(europe" in n -> 2
        "(japan" in n -> 3
        else -> 4
    }
}

/** O que diferencia esta versão: as marcas do nome do arquivo, ou o próprio nome. */
private fun versionLabel(g: Game): String {
    val stem = g.fileName.substringBeforeLast('.')
    val tags = Regex("""[\(\[][^\)\]]*[\)\]]""").findAll(stem).joinToString(" ") { it.value }
    val base = when {
        tags.isNotEmpty() -> tags
        stem.equals(g.title, ignoreCase = true) -> stem
        else -> stem
    }
    return if (g.patch.isNotEmpty()) "$base + ${g.patch.substringBeforeLast('.')}" else base
}

private fun versionDetails(g: Game): String {
    val parts = mutableListOf<String>()
    parts += g.fileName
    if (g.folderPath.isNotEmpty()) parts += g.folderPath.substringAfterLast('/')
    if (g.size > 0) parts += formatSize(g.size)
    return parts.joinToString(" · ")
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1L shl 30 -> String.format(java.util.Locale.US, "%.1f GB", bytes / (1L shl 30).toDouble())
    bytes >= 1L shl 20 -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1L shl 20).toDouble())
    else -> "${(bytes / 1024).coerceAtLeast(1)} KB"
}
