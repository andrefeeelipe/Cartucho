package app.cartucho.ui.screens

import app.cartucho.data.Translation
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInHorizontally
import app.cartucho.ui.theme.Brand
import app.cartucho.ui.components.NavRow
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.Tag
import app.cartucho.ui.components.Toast
import app.cartucho.ui.components.SearchBox
import app.cartucho.ui.components.Chip
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import app.cartucho.net.RoomGuestActivity
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import app.cartucho.net.Signaling
import app.cartucho.data.GameCard
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.data.Game
import app.cartucho.data.GameLibrary
import app.cartucho.data.GameScanner
import app.cartucho.data.GameResolver
import app.cartucho.data.Detection
import app.cartucho.data.Archives
import app.cartucho.data.Patches
import app.cartucho.data.GameSystem
import app.cartucho.data.LibraryFolder
import app.cartucho.data.Systems
import app.cartucho.data.Covers
import app.cartucho.ui.MainActivity
import app.cartucho.ui.Route
import app.cartucho.data.GameIdentifier
import app.cartucho.data.Store
import app.cartucho.data.StoreGame
import app.cartucho.data.titleLetter
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ProfileAvatar
import app.cartucho.ui.components.FilterGroup
import app.cartucho.ui.components.FilterPanel
import app.cartucho.ui.components.LetterBar
import app.cartucho.ui.components.CIcon
import app.cartucho.ui.components.IconButton
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SectionLabel
import app.cartucho.ui.components.SheetAction
import app.cartucho.ui.components.pressable
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.Motion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class PendingChoice(val game: Game, val candidates: List<GameSystem>)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val everything by app.library.games.collectAsState()
    // Pacotes já abertos (um .rar com 200 jogos, por exemplo) somem: os jogos de dentro aparecem um a um.
    val games = remember(everything) { everything.filter { it.pack == 0 } }
    val scope = rememberCoroutineScope()

    var filter by remember { mutableStateOf<String?>(null) }
    var genreFilter by remember { mutableStateOf("") }
    var letterFilter by remember { mutableStateOf<Char?>(null) }
    var ptOnly by remember { mutableStateOf(false) }
    var playedFilter by remember { mutableStateOf(0) }
    var sortMode by remember { mutableStateOf(0) }
    var libFiltersOpen by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf<String?>(null) }
    var scanning by remember { mutableStateOf<Int?>(null) }
    var choice by remember { mutableStateOf<PendingChoice?>(null) }
    var options by remember { mutableStateOf<Game?>(null) }
    var versionsFor by remember { mutableStateOf<List<Game>?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    val profile by app.profile.data.collectAsState()
    var offer by remember { mutableStateOf<TranslationOffer?>(null) }
    var working by remember { mutableStateOf<String?>(null) }
    var addOpen by remember { mutableStateOf(false) }
    /** Página do jogo aberta (o grupo de versões do mesmo jogo). */
    var detail by remember { mutableStateOf<List<Game>?>(null) }
    LaunchedEffect(detail) { activity.tabBarHidden = detail != null }
    androidx.activity.compose.BackHandler(enabled = detail != null) { detail = null }

    /** Abre o jogo; se o sistema ainda não é conhecido (compactados, pastas da nuvem), identifica antes. */
    fun launchDirect(game: Game) {
        if (game.systemKnown && !GameResolver(app, app.detector).needsLook(game)) {
            activity.launchGame(game)?.let { notice = it }
            return
        }
        scope.launch {
            working = "Identificando o jogo…"
            val detection = withContext(Dispatchers.IO) {
                runCatching { GameResolver(app, app.detector).detect(game) }
                    .getOrElse { Detection(null, emptyList(), it.message ?: "Não foi possível ler o arquivo.") }
            }
            working = null
            // Pacotes como "drive-download-…": o nome vem do jogo que estava dentro.
            detection.mainName?.let { inner ->
                if (game.canonical.isEmpty() || game.canonical == "-") app.library.setIdentity(game.id, game.canonical, GameLibrary.titleFromFileName(inner), null)
            }
            when {
                detection.pack > 0 -> notice = "Este arquivo tinha ${detection.pack} jogos. Agora cada um aparece separado na sua biblioteca."
                detection.error != null -> notice = detection.error
                detection.system != null -> {
                    app.library.setSystem(game.id, detection.system.id)
                    activity.launchGame(game.copy(systemId = detection.system.id))?.let { notice = it }
                }
                detection.candidates.size > 1 -> choice = PendingChoice(game, detection.candidates)
                detection.candidates.size == 1 -> {
                    val s0 = detection.candidates.first()
                    app.library.setSystem(game.id, s0.id)
                    activity.launchGame(game.copy(systemId = s0.id))?.let { notice = it }
                }
                else -> notice = "Não reconheci o sistema deste jogo."
            }
        }
    }

    fun open(game: Game) {
        if (working != null) return
        // Tradução PT-BR da comunidade disponível? Pergunta uma vez por jogo.
        if (game.patch.isEmpty() && !app.translations.wasOffered(game.id)) {
            val found = app.translations.find(game)
            if (found.isNotEmpty()) {
                offer = TranslationOffer(game, found)
                return
            }
        }
        launchDirect(game)
    }

    var coverFor by remember { mutableStateOf<Game?>(null) }
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        val g = coverFor
        coverFor = null
        if (uri != null && g != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { runCatching { app.covers.setManual(g.id, uri) }.getOrDefault(false) }
                notice = if (ok) "Capa trocada." else "Não foi possível usar essa imagem."
            }
        }
    }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            activity.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        scope.launch {
            working = "Lendo o arquivo…"
            val result = withContext(Dispatchers.IO) { importFile(app, uri) }
            working = null
            when (result) {
                is ImportResult.Error -> notice = result.message
                is ImportResult.Ok -> open(result.game)
                is ImportResult.Ask -> choice = PendingChoice(result.game, result.candidates)
            }
        }
    }

    val openFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree: Uri? ->
        if (tree == null) return@rememberLauncherForActivityResult
        runCatching {
            activity.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        scanning = 0
        scope.launch {
            val found = withContext(Dispatchers.IO) {
                val scanner = GameScanner(app, app.detector)
                val list = scanner.scan(tree) { n -> scanning = n }
                val name = runCatching {
                    DocumentsContract.getTreeDocumentId(tree).substringAfterLast(':').substringAfterLast('/')
                }.getOrDefault("Pasta")
                app.library.addFolder(LibraryFolder(tree.toString(), name))
                app.library.upsertAll(list)
                list.size
            }
            scanning = null
            notice = if (found == 0) "Nenhum jogo reconhecido nessa pasta." else "$found jogos adicionados."
        }
    }

    LaunchedEffect(notice) {
        if (notice != null) {
            kotlinx.coroutines.delay(3500)
            notice = null
        }
    }

    val settingsState by app.prefs.settings.collectAsState()
    val coverVersion by app.covers.version.collectAsState()
    var hacksFor by remember { mutableStateOf<Game?>(null) }
    var reviewFor by remember { mutableStateOf<Game?>(null) }
    LaunchedEffect(games, settingsState.coverDownload) { app.covers.enqueue(games, settingsState.coverDownload) }
    LaunchedEffect(games, settingsState.coverDownload) { app.identifier.enqueue(app.library, app.covers, games, settingsState.coverDownload) }

    // Recentes: uma entrada por jogo (a versão jogada por último).
    val recents = remember(games) {
        games.filter { it.lastPlayed > 0 }.sortedByDescending { it.lastPlayed }.distinctBy { titleKey(it) }.take(10)
    }
    val systemsInLibrary = remember(games) { Systems.all.filter { s -> games.any { it.systemId == s.id } } }
    // Gênero e idioma dos jogos que vieram da Loja (a pasta do arquivo tem o código do jogo).
    val storeCatalog by app.store.games.collectAsState()
    LaunchedEffect(Unit) { app.store.load() }
    val storeMeta = remember(storeCatalog) { storeCatalog.associateBy { it.slug } }
    fun meta(g: Game): StoreGame? =
        if (g.folderPath != "Loja") null else android.net.Uri.parse(g.uri).path?.let { java.io.File(it).parentFile?.name }?.let { storeMeta[it] }
    fun isPortuguese(group: List<Game>): Boolean = group.any { g ->
        meta(g)?.language == "pt" || PT_NAME.containsMatchIn(g.fileName) || PT_NAME.containsMatchIn(g.patch) || PT_NAME.containsMatchIn(g.title)
    }
    fun genresOf(group: List<Game>): List<String> = group.flatMap { meta(it)?.genres.orEmpty() }.distinct()
    // Versões do mesmo jogo (regiões, revisões, traduções) viram um só cartão.
    val grouped = remember(games, filter, query, storeMeta) {
        games.asSequence()
            .filter { filter == null || it.systemId == filter }
            .filter { query.isBlank() || it.title.contains(query.trim(), ignoreCase = true) }
            .let { groupVersions(it.toList()) }
            .map { group -> group.sortedWith(compareByDescending<Game> { it.lastPlayed }.thenBy { versionRank(it) }) }
            .toList()
    }
    val genresInLibrary = remember(grouped) { Store.GENRES.filter { gn -> grouped.any { gn in genresOf(it) } } }
    val filtered = remember(grouped, genreFilter, ptOnly, playedFilter) {
        grouped.filter { group ->
            (genreFilter.isEmpty() || genreFilter in genresOf(group)) &&
                (!ptOnly || isPortuguese(group)) &&
                (playedFilter == 0 || (playedFilter == 1) == group.any { it.lastPlayed > 0 })
        }
    }
    val lettersInLibrary = remember(filtered) { filtered.map { titleLetter(it.first().title) }.toSet() }
    val visible = remember(filtered, letterFilter, sortMode) {
        val l = filtered.filter { letterFilter == null || titleLetter(it.first().title) == letterFilter }
        when (sortMode) {
            1 -> l.sortedByDescending { g -> g.maxOf { it.lastPlayed } }
            2 -> l.sortedByDescending { g -> g.maxOf { it.addedAt } }
            3 -> l.sortedByDescending { it.first().title.lowercase() }
            else -> l.sortedBy { it.first().title.lowercase() }
        }
    }
    val libActive = listOf(genreFilter.isNotEmpty(), ptOnly, playedFilter != 0, sortMode != 0).count { it }
    val anyFilter = filter != null || libActive > 0 || letterFilter != null
    fun openGroup(group: List<Game>) {
        if (group.size > 1) versionsFor = group else open(group.first())
    }

    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(top = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Biblioteca", style = Cartucho.type.display, color = c.text, modifier = Modifier.weight(1f))
                        IconButton(R.drawable.ic_plus, "Adicionar jogos", { addOpen = true })
                        Box(
                            Modifier.size(44.dp).pressable(shape = androidx.compose.foundation.shape.CircleShape) { menuOpen = true }
                                .semantics { contentDescription = "Perfil e coleção" },
                            contentAlignment = Alignment.Center,
                        ) { ProfileAvatar(profile, app.profile.photoFile, "", 36.dp) }
                    }
                    Spacer(Modifier.height(14.dp))
                    SearchBox(query, { query = it }, "Buscar jogo", onClear = { query = "" })
                    if (scanning != null) {
                        Spacer(Modifier.height(12.dp))
                        Text("Procurando jogos… ${scanning ?: 0} encontrados. Pastas na nuvem podem levar alguns minutos.", style = Cartucho.type.caption, color = c.textSecondary)
                    }
                    if (working != null) {
                        Spacer(Modifier.height(12.dp))
                        Text(working ?: "", style = Cartucho.type.caption, color = c.textSecondary)
                    }
                    if (games.isNotEmpty()) {
                        Spacer(Modifier.height(14.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item { Chip("Todos", filter == null) { filter = null } }
                            items(systemsInLibrary, key = { it.id }) { s ->
                                Chip(s.short, filter == s.id) { filter = if (filter == s.id) null else s.id }
                            }
                            item { Chip("Em português", ptOnly) { ptOnly = !ptOnly } }
                            items(genresInLibrary, key = { "g$it" }) { gn -> Chip(gn, genreFilter == gn) { genreFilter = if (genreFilter == gn) "" else gn } }
                            item { Chip(if (libActive > 0) "Filtros · $libActive" else "Filtros", libActive > 0) { libFiltersOpen = true } }
                        }
                    }
                }
            }

            if (games.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) { EmptyState(onOpen = { openFile.launch(arrayOf("*/*")) }, onFolder = { openFolder.launch(null) }) }
            } else {
                val last = recents.firstOrNull()
                if (last != null && query.isBlank() && !anyFilter) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        ContinueCard(last, coverVersion, onOpen = { detail = grouped.firstOrNull { g -> g.any { it.id == last.id } } ?: listOf(last) }, onPlay = { open(last) })
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        if (grouped.size > 12) {
                            LetterBar(letterFilter, lettersInLibrary, { letterFilter = it })
                            Spacer(Modifier.height(4.dp))
                        }
                        if (visible.isEmpty()) {
                            Text("Nenhum jogo com esses filtros.", style = Cartucho.type.body, color = c.textSecondary, modifier = Modifier.padding(vertical = 16.dp))
                        }
                    }
                }
                items(visible, key = { it.first().id }) { group ->
                    val g = group.first()
                    GameTile(g, coverVersion, Modifier.fillMaxWidth(), onClick = { detail = group }, onLongClick = { options = g }, versions = group.size)
                }
            }
        }

        AnimatedVisibility(
            visible = notice != null,
            enter = slideInVertically(Motion.standard()) { it } + fadeIn(Motion.fade()),
            exit = slideOutVertically(Motion.standard()) { it } + fadeOut(Motion.fade()),
            modifier = Modifier.align(Alignment.BottomCenter).padding(20.dp),
        ) {
            Toast(notice ?: "")
        }

        BottomSheet(visible = libFiltersOpen, onDismiss = { libFiltersOpen = false }) {
            FilterPanel(
                count = visible.size,
                onClear = { genreFilter = ""; ptOnly = false; playedFilter = 0; sortMode = 0; letterFilter = null; filter = null },
                onDone = { libFiltersOpen = false },
            ) {
                FilterGroup("Ordenar", listOf(0 to "A–Z", 3 to "Z–A", 1 to "Jogados por último", 2 to "Adicionados por último"), sortMode) { sortMode = it }
                FilterGroup("Console", listOf<Pair<String?, String>>(null to "Todos") + systemsInLibrary.map { it.id to it.name }, filter) { filter = it }
                if (genresInLibrary.isNotEmpty()) FilterGroup("Gênero", listOf("" to "Todos") + genresInLibrary.map { it to it }, genreFilter) { genreFilter = it }
                FilterGroup("Idioma", listOf(false to "Todos", true to "Em português (traduzidos e brasileiros)"), ptOnly) { ptOnly = it }
                FilterGroup("Mostrar", listOf(0 to "Todos", 1 to "Já jogados", 2 to "Nunca jogados"), playedFilter) { playedFilter = it }
                Text(
                    "O gênero aparece nos jogos baixados pela Loja. \"Em português\" mostra os jogos com tradução PT-BR aplicada, versões brasileiras e os feitos em português.",
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
        }

        BottomSheet(visible = choice != null, onDismiss = { choice = null }) {
            val pending = choice
            Text("De qual sistema é este jogo?", style = Cartucho.type.title, color = c.text, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            Text(pending?.game?.fileName ?: "", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.height(8.dp))
            if (pending != null) pending.candidates.forEach { s ->
                SheetAction(s.name, R.drawable.ic_controller, {
                    val game = pending.game.copy(systemId = s.id)
                    app.library.upsert(game)
                    app.library.setSystem(game.id, s.id)
                    choice = null
                    activity.launchGame(game)?.let { notice = it }
                })
            }
        }

        // Tradução PT-BR encontrada no catálogo: aplicar em um toque.
        BottomSheet(visible = offer != null, onDismiss = { offer = null }) {
            val o = offer
            if (o != null) {
                Text("Tradução PT-BR disponível", style = Cartucho.type.title, color = c.text, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
                Text(
                    "A comunidade brasileira traduziu ${o.game.title}. Quer aplicar? O jogo original continua intacto.",
                    style = Cartucho.type.body,
                    color = c.textSecondary,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
                Spacer(Modifier.height(8.dp))
                o.options.take(4).forEach { t ->
                    SheetAction(
                        "Aplicar a tradução de ${t.credit}",
                        R.drawable.ic_translate,
                        {
                            offer = null
                            app.translations.markOffered(o.game.id)
                            scope.launch {
                                working = "Baixando a tradução de ${t.credit}…"
                                val r = withContext(Dispatchers.IO) { runCatching { Patches.installFromUrl(app, o.game.id, t.url) } }
                                working = null
                                r.onSuccess { f ->
                                    app.library.setPatch(o.game.id, f.name)
                                    launchDirect(app.library.find(o.game.id) ?: o.game.copy(patch = f.name))
                                }.onFailure { notice = "Não foi possível baixar a tradução: ${it.message}" }
                            }
                        },
                        subtitle = listOf(t.name, t.version.takeIf { it.isNotBlank() }?.let { "v$it" }, t.progress.takeIf { it.isNotBlank() }).filterNotNull().joinToString(" · "),
                    )
                }
                SheetAction("Jogar sem tradução", R.drawable.ic_play, {
                    offer = null
                    app.translations.markOffered(o.game.id)
                    launchDirect(o.game)
                })
                Text(
                    "Traduções feitas pelas equipes da comunidade, catalogadas pelo PO.B.R.E (romhackers.org). Você pode trocar depois em Hacks e traduções.",
                    style = Cartucho.type.caption,
                    color = c.textSecondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
        }

        // Entrar na sala online de um amigo pelo código.
        // Menu único: perfil, baixar jogos, amigos, coleção, busca e ajustes.
        BottomSheet(visible = menuOpen, onDismiss = { menuOpen = false }) {
            val settingsNow = app.prefs.current
            Row(
                Modifier.fillMaxWidth().pressable(shape = RoundedCornerShape(16.dp)) { menuOpen = false; activity.navigate(Route.Profile) }
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ProfileAvatar(profile, app.profile.photoFile, "", 52.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(profile.name.ifBlank { settingsNow.raUser.ifBlank { "Jogador" } }, style = Cartucho.type.headline, color = c.text)
                    Text("Ver perfil e troféus", style = Cartucho.type.caption, color = c.textSecondary)
                }
                CIcon(R.drawable.ic_chevron, tint = c.textSecondary, size = 18.dp)
            }
            Divider()
            SheetAction("Coleção", R.drawable.ic_trophy, { menuOpen = false; activity.navigate(Route.Collection) }, subtitle = "Zerados, notas e mural dos amigos")
            SheetAction("Adicionar jogos", R.drawable.ic_plus, { menuOpen = false; addOpen = true })
            Spacer(Modifier.height(8.dp))
        }

        BottomSheet(visible = addOpen, onDismiss = { addOpen = false }) {
            Text("Adicionar jogos", style = Cartucho.type.title, color = c.text, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            Text("Use apenas arquivos que são seus.", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.height(8.dp))
            SheetAction("Abrir um jogo", R.drawable.ic_file_plus, { addOpen = false; openFile.launch(arrayOf("*/*")) }, subtitle = "Escolha um arquivo do aparelho")
            SheetAction("Adicionar pasta", R.drawable.ic_folder_plus, { addOpen = false; openFolder.launch(null) }, subtitle = "O Cartucho encontra todos os jogos de uma vez")
            SheetAction("Baixar jogos grátis", R.drawable.ic_bag, { addOpen = false; activity.selectTab(Route.Store) }, subtitle = "Na Loja, liberados pelos próprios autores")
            Spacer(Modifier.height(8.dp))
        }

        BottomSheet(visible = versionsFor != null, onDismiss = { versionsFor = null }) {
            val group = versionsFor
            if (group != null) {
                Text(group.first().title, style = Cartucho.type.title, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                Text("Qual versão você quer jogar?", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 20.dp))
                Spacer(Modifier.height(8.dp))
                group.forEach { v ->
                    SheetAction(
                        versionLabel(v),
                        R.drawable.ic_play,
                        { versionsFor = null; open(v) },
                        subtitle = versionDetails(v),
                    )
                }
                Spacer(Modifier.height(4.dp))
                SheetAction("Opções da versão mais recente", R.drawable.ic_settings, { versionsFor = null; options = group.first() })
            }
        }

        BottomSheet(visible = options != null, onDismiss = { options = null }) {
            val g = options
            if (g != null) {
                Text(g.title, style = Cartucho.type.title, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                Text(Systems.get(g.systemId)?.name ?: "", style = Cartucho.type.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 20.dp))
                Spacer(Modifier.height(8.dp))
                SheetAction("Jogar", R.drawable.ic_play, { options = null; open(g) })
                val ext = g.fileName.substringAfterLast('.', "").lowercase()
                val alternatives = if (Archives.isArchive(g.fileName)) Systems.all else Systems.candidatesForExtension(ext)
                if (alternatives.size > 1) {
                    SheetAction("Mudar sistema", R.drawable.ic_sync, {
                        options = null
                        choice = PendingChoice(g, alternatives)
                    }, subtitle = "Use se o jogo foi reconhecido errado")
                }
                SheetAction("Avaliar e marcar como zerado", R.drawable.ic_trophy, { options = null; reviewFor = g })
                SheetAction("Compartilhar card", R.drawable.ic_upload, {
                    options = null
                    activity.openShare(g)
                }, subtitle = "Story, feed ou link, com a capa e o seu resultado")
                SheetAction("Trocar capa", R.drawable.ic_file_plus, {
                    options = null
                    coverFor = g
                    pickCover.launch("image/*")
                }, subtitle = "Escolher uma imagem do celular")
                SheetAction("Procurar capa de novo", R.drawable.ic_search, {
                    options = null
                    app.covers.retry(g)
                    notice = "Procurando a capa…"
                }, subtitle = if (app.covers.isGenerated(g.id)) "Capa provisória: ainda não achamos a oficial" else null)
                val sys = Systems.get(g.systemId)
                if (sys != null && Patches.supports(sys)) {
                    SheetAction(
                        "Hacks e traduções", R.drawable.ic_plus, { options = null; hacksFor = g },
                        subtitle = if (g.patch.isNotEmpty()) "Ativo: ${g.patch}" else "Aplicar um patch .ips, .ups ou .bps",
                    )
                }
                SheetAction("Remover da biblioteca", R.drawable.ic_trash, {
                    app.library.remove(g.id)
                    options = null
                }, danger = true, subtitle = "O arquivo continua no seu aparelho")
            }
        }

        AnimatedVisibility(
            visible = detail != null,
            enter = slideInHorizontally(Motion.standard()) { it / 3 } + fadeIn(Motion.fade()),
            exit = slideOutHorizontally(Motion.standard()) { it / 3 } + fadeOut(Motion.fade()),
        ) {
            val group = detail
            if (group != null) {
                GameDetail(
                    app = app,
                    group = group,
                    coverVersion = coverVersion,
                    onBack = { detail = null },
                    onPlay = { g -> open(g) },
                    onVersions = { versionsFor = group },
                    onHacks = { g -> hacksFor = g },
                    onShare = { g -> activity.openShare(g) },
                    onReview = { g -> reviewFor = g },
                    onOptions = { g -> options = g },
                )
            }
        }

        HackSheet(app, hacksFor, onDismiss = { hacksFor = null }, onMessage = { notice = it })
        ReviewSheet(app, reviewFor, onDismiss = { reviewFor = null })
    }
}

@Composable
private fun EmptyState(onOpen: () -> Unit, onFolder: () -> Unit) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(96.dp).clip(RoundedCornerShape(22.dp)).background(Brand.plate),
            contentAlignment = Alignment.Center,
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(R.drawable.brand_icon),
                contentDescription = null,
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)),
            )
        }
        Spacer(Modifier.height(20.dp))
        Text("Nenhum jogo ainda.", style = Cartucho.type.title, color = c.text)
        Spacer(Modifier.height(6.dp))
        Text(
            "Abra um jogo que você possui, ou escolha uma pasta para o Cartucho encontrar todos de uma vez.",
            style = Cartucho.type.body,
            color = c.textSecondary,
            modifier = Modifier.padding(horizontal = 16.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        PrimaryButton("Abrir um jogo", onOpen, Modifier.fillMaxWidth(), icon = R.drawable.ic_file_plus)
        Spacer(Modifier.height(10.dp))
        SecondaryButton("Adicionar pasta", onFolder, Modifier.fillMaxWidth(), icon = R.drawable.ic_folder_plus)
    }
}

/** "Continuar jogando": o último jogo, com o botão roxo de jogar. */
@Composable
private fun ContinueCard(game: Game, coverVersion: Int, onOpen: () -> Unit, onPlay: () -> Unit) {
    val c = Cartucho.colors
    val app = CartuchoApp.instance
    val cover by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, game.id, coverVersion) {
        value = withContext(Dispatchers.IO) { loadCover(app.covers.file(game.id)) }
    }
    Row(
        Modifier
            .padding(top = 4.dp, bottom = 4.dp)
            .fillMaxWidth()
            .pressable(shape = RoundedCornerShape(16.dp), onClick = onOpen)
            .background(c.surfaceRaised)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(c.placeholder), contentAlignment = Alignment.Center) {
            cover?.let {
                androidx.compose.foundation.Image(it, null, contentScale = androidx.compose.ui.layout.ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("CONTINUAR JOGANDO", style = Cartucho.type.mono.copy(fontSize = 11.sp), color = c.textSecondary)
            Spacer(Modifier.height(2.dp))
            Text(game.title, style = Cartucho.type.headline.copy(fontSize = 16.sp), color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(agoText(game.lastPlayed), style = Cartucho.type.caption, color = c.textSecondary, maxLines = 1)
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier.size(48.dp).pressable(shape = androidx.compose.foundation.shape.CircleShape, onClick = onPlay)
                .background(c.accent).semantics { contentDescription = "Jogar ${game.title}" },
            contentAlignment = Alignment.Center,
        ) { CIcon(R.drawable.ic_play, tint = c.onAccent, size = 20.dp) }
    }
}

private fun agoText(t: Long): String {
    if (t <= 0) return ""
    val min = (System.currentTimeMillis() - t) / 60000
    return when {
        min < 1 -> "Jogado agora há pouco"
        min < 60 -> "Jogado há $min min"
        min < 60 * 24 -> "Jogado há ${min / 60} h"
        min < 60 * 24 * 2 -> "Jogado ontem"
        else -> "Jogado há ${min / (60 * 24)} dias"
    }
}

/** Capa na grade: imagem em cantos de 12dp, nome e console embaixo. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameTile(game: Game, coverVersion: Int, modifier: Modifier, onClick: () -> Unit, onLongClick: () -> Unit, versions: Int = 1) {
    val c = Cartucho.colors
    val app = CartuchoApp.instance
    val system = Systems.get(game.systemId)
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    val cover by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, game.id, coverVersion) {
        value = withContext(Dispatchers.IO) { loadCover(app.covers.file(game.id)) }
    }
    Column(
        modifier = modifier
            .combinedClickable(interactionSource = interaction, indication = null, onClick = onClick, onLongClick = onLongClick),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.8f)
                .then(if (focused) Modifier.border(3.dp, c.accent, shape) else Modifier)
                .clip(shape)
                .background(c.placeholder),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = cover
            if (bmp != null) {
                androidx.compose.foundation.Image(
                    bitmap = bmp,
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Text(
                    game.title,
                    style = Cartucho.type.title.copy(fontSize = 18.sp, lineHeight = 21.sp),
                    color = Brand.purpleDark,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(14.dp),
                )
            }
            if (game.patch.isNotEmpty()) {
                Box(Modifier.align(Alignment.TopEnd).padding(8.dp)) { Tag("Hack", c.accentSoft, c.onAccentSoft) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(game.title, style = Cartucho.type.label, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            when {
                versions > 1 -> "${system?.short ?: ""} · $versions versões".trimStart(' ', '·')
                else -> system?.name ?: "Toque para identificar"
            },
            style = Cartucho.type.caption,
            color = c.textSecondary,
            maxLines = 1,
        )
    }
}

/** Página do jogo: capa, desempenho no aparelho, conquistas, números, Jogar e Compartilhar. */
@Composable
private fun GameDetail(
    app: CartuchoApp,
    group: List<Game>,
    coverVersion: Int,
    onBack: () -> Unit,
    onPlay: (Game) -> Unit,
    onVersions: () -> Unit,
    onHacks: (Game) -> Unit,
    onShare: (Game) -> Unit,
    onReview: (Game) -> Unit,
    onOptions: (Game) -> Unit,
) {
    val c = Cartucho.colors
    val game = group.first()
    val system = Systems.get(game.systemId)
    val entries by app.collection.entries.collectAsState()
    val entry = entries[game.id] ?: app.collection.get(game.id)
    val cover by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, game.id, coverVersion) {
        value = withContext(Dispatchers.IO) { loadCover(app.covers.file(game.id)) }
    }
    val info by produceState(Triple(0L, 0, emptyList<app.cartucho.achievements.Achievement>()), game.id) {
        value = withContext(Dispatchers.IO) {
            val seconds = group.sumOf { g -> app.collection.secondsByGame()[g.id] ?: 0L }
            val saves = runCatching {
                val base = game.fileName.substringBeforeLast('.').replace(Regex("""[\\/:*?"<>|]"""), "_")
                java.io.File(app.filesDir, "states/${game.systemId}/$base").listFiles { f -> f.name.matches(Regex("slot\\d\\.state")) }?.size ?: 0
            }.getOrDefault(0)
            Triple(seconds, saves, app.cartucho.achievements.AchievementCache.load(app, game.id))
        }
    }
    val rating = system?.let { app.device.rate(it) }
    Column(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Box(Modifier.height(52.dp), contentAlignment = Alignment.CenterStart) {
            Row(
                Modifier.offset(x = (-8).dp).heightIn(min = 44.dp).pressable(shape = RoundedCornerShape(12.dp), onClick = onBack).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CIcon(R.drawable.ic_back, tint = c.accent, size = 18.dp)
                Spacer(Modifier.width(4.dp))
                Text("Biblioteca", style = Cartucho.type.body, color = c.accent)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Box(Modifier.width(132.dp).aspectRatio(0.75f).clip(RoundedCornerShape(12.dp)).background(c.placeholder), contentAlignment = Alignment.Center) {
                val bmp = cover
                if (bmp != null) {
                    androidx.compose.foundation.Image(bmp, null, contentScale = androidx.compose.ui.layout.ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    Text(game.title, style = Cartucho.type.title.copy(fontSize = 16.sp, lineHeight = 19.sp), color = Brand.purpleDark, textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 5, modifier = Modifier.padding(10.dp))
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(game.title, style = Cartucho.type.title.copy(fontSize = 26.sp, lineHeight = 29.sp), color = c.text, maxLines = 4, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Text(system?.name ?: "Sistema ainda não identificado", style = Cartucho.type.body.copy(fontSize = 15.sp), color = c.textSecondary)
                if (rating != null) {
                    Spacer(Modifier.height(8.dp))
                    PerformanceTag(rating.rating)
                }
            }
        }
        if (group.size > 1) {
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier.fillMaxWidth().pressable(shape = RoundedCornerShape(16.dp), onClick = onVersions)
                    .border(1.dp, c.border, RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Versão · ${group.size} disponíveis", style = Cartucho.type.caption, color = c.textSecondary)
                    Text(versionLabel(game), style = Cartucho.type.headline.copy(fontSize = 16.sp), color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                CIcon(R.drawable.ic_chevron, tint = c.textSecondary, size = 14.dp)
            }
        }
        val ach = info.third
        if (ach.isNotEmpty()) {
            val unlocked = ach.count { it.unlocked }
            val pct = unlocked * 100 / ach.size
            Spacer(Modifier.height(16.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surfaceRaised).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("CONQUISTAS", style = Cartucho.type.mono, color = c.textSecondary, modifier = Modifier.weight(1f))
                    Text("$unlocked de ${ach.size} · $pct%", style = Cartucho.type.caption, color = c.textSecondary)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    val n = 20
                    val filled = (unlocked * n + ach.size / 2) / ach.size
                    for (i in 0 until n) Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(if (i < filled) c.accent else c.accentSoft))
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth()) {
            DetailStat(if (info.first >= 60) app.cartucho.data.CollectionStore.formatHours(info.first) else "—", "Jogado", Modifier.weight(1f))
            DetailStat(info.second.toString(), "Saves", Modifier.weight(1f))
            Column(Modifier.weight(1f).pressable(shape = RoundedCornerShape(12.dp)) { onReview(game) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Row { for (i in 0 until 5) CIcon(R.drawable.ic_star, tint = if (entry.rating >= (i + 1) * 2 - 1) c.accent else Brand.line, size = 18.dp) }
                Spacer(Modifier.height(4.dp))
                Text(if (entry.rating > 0) "Minha nota" else "Dar nota", style = Cartucho.type.caption, color = c.textSecondary)
            }
        }
        Spacer(Modifier.height(20.dp))
        PrimaryButton("Jogar", { onPlay(game) }, Modifier.fillMaxWidth().heightIn(min = 52.dp), icon = R.drawable.ic_play)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (system != null && Patches.supports(system)) {
                SecondaryButton("Hacks e traduções", { onHacks(game) }, Modifier.weight(1f))
            }
            SecondaryButton("Compartilhar", { onShare(game) }, Modifier.weight(1f), icon = R.drawable.ic_upload)
        }
        Spacer(Modifier.height(24.dp))
        ListGroup {
            NavRow("Avaliar e marcar como zerado", { onReview(game) }, value = entry.status.label.takeIf { entry.status != app.cartucho.data.PlayStatus.NONE })
            Divider()
            NavRow("Mais opções", { onOptions(game) }, subtitle = "Capa, sistema e remover da biblioteca")
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun DetailStat(value: String, label: String, modifier: Modifier) {
    val c = Cartucho.colors
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = Cartucho.type.headline.copy(fontSize = 18.sp), color = c.text, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Text(label, style = Cartucho.type.caption, color = c.textSecondary)
    }
}

/** Status de desempenho: a única vez em que a cor quer dizer algo — sempre com ícone e texto. */
@Composable
internal fun PerformanceTag(rating: app.cartucho.data.Rating) {
    val (bg, fg, mark, text) = when (rating) {
        app.cartucho.data.Rating.GOOD -> listOf(Brand.dotGreen, Color.White, "✓", "Roda liso neste aparelho")
        app.cartucho.data.Rating.MAY_STUTTER -> listOf(Brand.dotYellow, Brand.dotYellowInk, "!", "Pode engasgar neste aparelho")
        app.cartucho.data.Rating.UNSUPPORTED -> listOf(Brand.dotRed, Color.White, "×", "Não roda neste aparelho")
    }
    Row(
        Modifier.clip(RoundedCornerShape(999.dp)).background(Cartucho.colors.surfaceRaised).padding(start = 6.dp, end = 10.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(16.dp).clip(androidx.compose.foundation.shape.CircleShape).background(bg as Color), contentAlignment = Alignment.Center) {
            Text(mark as String, style = Cartucho.type.caption.copy(fontSize = 10.sp, lineHeight = 10.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold), color = fg as Color)
        }
        Spacer(Modifier.width(6.dp))
        Text(text as String, style = Cartucho.type.caption.copy(fontSize = 12.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold), color = Cartucho.colors.text)
    }
}

internal fun loadCover(file: java.io.File): androidx.compose.ui.graphics.ImageBitmap? {
    if (!file.exists()) return null
    return runCatching {
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 360) sample *= 2
        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
        android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)?.asImageBitmap()
    }.getOrNull()
}

sealed interface ImportResult {
    data class Ok(val game: Game) : ImportResult
    data class Ask(val game: Game, val candidates: List<GameSystem>) : ImportResult
    data class Error(val message: String) : ImportResult
}

private fun importFile(app: CartuchoApp, uri: Uri): ImportResult {
    var name = "jogo"
    var size = 0L
    runCatching {
        app.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                name = cur.getString(0) ?: name
                size = if (cur.isNull(1)) 0L else cur.getLong(1)
            }
        }
    }
    val ext = name.substringAfterLast('.', "").lowercase()
    if (ext in setOf("cue", "gdi", "m3u", "ccd")) {
        return ImportResult.Error("Jogos .$ext usam vários arquivos. Use \"Adicionar pasta\" e escolha a pasta onde ele está, ou compacte tudo em um .zip/.7z.")
    }
    if (ext !in Systems.allExtensions) {
        return ImportResult.Error("O formato .$ext não é de um jogo que o Cartucho reconheça.")
    }
    val uriString = uri.toString()
    val existing = app.library.find(GameLibrary.idFor(uriString))
    var game = Game(
        id = GameLibrary.idFor(uriString),
        title = GameLibrary.titleFromFileName(name),
        fileName = name,
        uri = uriString,
        systemId = existing?.systemId ?: "",
        size = size,
        addedAt = System.currentTimeMillis(),
    )
    if (game.systemKnown) {
        app.library.upsert(game)
        return ImportResult.Ok(game)
    }
    val detection = runCatching { GameResolver(app, app.detector).detect(game) }
        .getOrElse { Detection(null, emptyList(), it.message ?: "Não foi possível ler o arquivo.") }
    detection.error?.let { return ImportResult.Error(it) }
    val system = detection.system ?: detection.candidates.singleOrNull()
    if (system != null) {
        game = game.copy(systemId = system.id)
        app.library.upsert(game)
        return ImportResult.Ok(game)
    }
    if (detection.candidates.isEmpty()) return ImportResult.Error("Não reconheci o sistema deste jogo.")
    app.library.upsert(game)
    return ImportResult.Ask(game, detection.candidates)
}


/** Título comparável: sem região, revisão, marcas de tradução/hack, pontuação ou espaços. */
/** Nome de arquivo/patch de versão em português (traduções da comunidade e lançamentos brasileiros). */
private val PT_NAME = Regex("pt[-_ ]?br|\\(br\\)|\\[br\\]|\\(brazil|portugu|tradu[cç]|\\[t[+-]?(por|bra)|\\(pt\\)|\\bptbr\\b", RegexOption.IGNORE_CASE)

internal fun titleKey(g: Game): String {
    // Reconhecido pelo conteúdo: o nome oficial manda (um arquivo "sm_w.sfc" e um "Super Mario World (USA).sfc" são o mesmo).
    if (g.canonical.length > 1) Covers.tokens(GameIdentifier.cleanTitle(g.canonical)).joinToString("").takeIf { it.isNotEmpty() }?.let { return it }
    // Palavras sem marcas, com romanos viram números ("Final Fantasy III" = "Final Fantasy 3").
    val fromFile = Covers.tokens(g.fileName.substringBeforeLast('.')).joinToString("")
    return fromFile.ifEmpty { Covers.tokens(g.title).joinToString("") }.ifEmpty { g.id }
}

/**
 * Junta as versões e as cópias de um mesmo jogo num cartão só. Dois arquivos são o mesmo jogo quando
 * têm o mesmo título (oficial, se reconhecido), o mesmo conteúdo (CRC ou código do disco) ou o mesmo
 * nome e tamanho (a mesma cópia em pastas diferentes). Um jogo de sistema ainda desconhecido entra
 * junto das versões já identificadas; só ficam separados títulos iguais de sistemas diferentes
 * (ex.: Tetris de NES e de Game Boy).
 */
internal fun groupVersions(games: List<Game>): List<List<Game>> {
    // União por chaves em comum.
    val parent = IntArray(games.size) { it }
    fun find(x: Int): Int { var r = x; while (parent[r] != r) { parent[r] = parent[parent[r]]; r = parent[r] }; return r }
    fun union(a: Int, b: Int) { val ra = find(a); val rb = find(b); if (ra != rb) parent[rb] = ra }
    val firstByKey = HashMap<String, Int>()
    games.forEachIndexed { i, g ->
        val keys = buildList {
            add("t:" + titleKey(g))
            if (g.fingerprint.isNotEmpty()) add("f:" + g.fingerprint)
            if (g.size > 0) add("n:" + g.fileName.lowercase() + ":" + g.size)
        }
        for (k in keys) {
            val j = firstByKey[k]
            if (j == null) firstByKey[k] = i else union(j, i)
        }
    }
    val clusters = games.indices.groupBy { find(it) }.values.map { idx -> idx.map { games[it] } }
    val out = ArrayList<List<Game>>()
    for (sameGame in clusters) {
        val known = sameGame.filter { it.systemKnown }.groupBy { it.systemId }
        val unknown = sameGame.filter { !it.systemKnown }
        if (known.isEmpty()) {
            out.add(unknown)
            continue
        }
        val biggest = known.maxByOrNull { it.value.size }!!.key
        for ((sys, list) in known) out.add(if (sys == biggest) list + unknown else list)
    }
    return out
}

/** Ordem quando nenhuma versão foi jogada: originais em inglês/BR primeiro, hacks e betas por último. */
private fun versionRank(g: Game): Int {
    val n = g.fileName.lowercase()
    return when {
        g.patch.isNotEmpty() || "hack" in n || "beta" in n || "proto" in n -> 9
        "(usa" in n || "(world" in n -> 0
        "(brazil" in n || "pt-br" in n || "ptbr" in n || "(br)" in n || "[br]" in n -> 1
        "(europe" in n -> 2
        "(japan" in n -> 3
        else -> 4
    }
}

/** O que diferencia esta versão: as marcas do nome do arquivo, ou o próprio nome. */
private fun versionLabel(g: Game): String {
    val stem = g.fileName.substringBeforeLast('.')
    val tags = Regex("""[\(\[][^\)\]]*[\)\]]""").findAll(stem).joinToString(" ") { it.value }
    val base = when {
        tags.isNotEmpty() -> tags
        stem.equals(g.title, ignoreCase = true) -> stem
        else -> stem
    }
    return if (g.patch.isNotEmpty()) "$base + ${g.patch.substringBeforeLast('.')}" else base
}

private fun versionDetails(g: Game): String {
    val parts = mutableListOf<String>()
    parts += g.fileName
    if (g.folderPath.isNotEmpty()) parts += g.folderPath.substringAfterLast('/')
    if (g.size > 0) parts += formatSize(g.size)
    return parts.joinToString(" · ")
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1L shl 30 -> String.format(java.util.Locale.US, "%.1f GB", bytes / (1L shl 30).toDouble())
    bytes >= 1L shl 20 -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1L shl 20).toDouble())
    else -> "${(bytes / 1024).coerceAtLeast(1)} KB"
}


private data class TranslationOffer(val game: Game, val options: List<Translation>)
