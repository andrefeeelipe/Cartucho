package app.cartucho.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.cartucho.ui.theme.Cartucho

/** Letras do filtro A–Z ("#" = números e símbolos). */
val LETTERS: List<Char> = listOf('#') + ('A'..'Z').toList()

/** Pílula de escolha usada em todos os filtros. */
@Composable
fun SelectChip(label: String, selected: Boolean, onClick: () -> Unit, enabled: Boolean = true) {
    val c = Cartucho.colors
    Box(
        Modifier
            .heightIn(min = 36.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(999.dp), onClick = onClick)
            .background(if (selected) c.text else c.surface)
            .border(1.dp, if (selected) c.text else app.cartucho.ui.theme.Brand.line, RoundedCornerShape(999.dp))
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            style = Cartucho.type.label.copy(fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium),
            color = when {
                selected -> c.background
                enabled -> c.text
                else -> c.textSecondary.copy(alpha = 0.4f)
            },
        )
    }
}

/** Faixa A–Z rolável. As letras sem jogos ficam apagadas. */
@Composable
fun LetterBar(selected: Char?, available: Set<Char>, onSelect: (Char?) -> Unit, modifier: Modifier = Modifier) {
    val c = Cartucho.colors
    LazyRow(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            SelectChip("A–Z", selected == null, { onSelect(null) })
        }
        items(LETTERS, key = { it.toString() }) { l ->
            val has = l in available
            Box(
                Modifier
                    .size(36.dp)
                    .pressable(enabled = has || selected == l, shape = RoundedCornerShape(999.dp), onClick = { onSelect(if (selected == l) null else l) })
                    .background(if (selected == l) c.text else Color.Transparent, RoundedCornerShape(999.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    l.toString(),
                    style = Cartucho.type.label,
                    color = when {
                        selected == l -> c.background
                        has -> c.text
                        else -> c.textSecondary.copy(alpha = 0.35f)
                    },
                )
            }
        }
    }
}

/** Um grupo do painel de filtros: título e as opções em linhas que quebram. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> FilterGroup(title: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(title.uppercase(), style = Cartucho.type.mono, color = c.textSecondary)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, label) -> SelectChip(label, value == selected, { onSelect(value) }) }
        }
    }
}

/** Corpo rolável do painel de filtros, com "Limpar" e "Mostrar N jogos". */
@Composable
fun FilterPanel(count: Int, onClear: () -> Unit, onDone: () -> Unit, content: @Composable () -> Unit) {
    val c = Cartucho.colors
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Filtros", style = Cartucho.type.title, color = c.text, modifier = Modifier.weight(1f))
        Text(
            "Limpar",
            style = Cartucho.type.label,
            color = c.accent,
            modifier = Modifier.pressable(shape = RoundedCornerShape(8.dp), onClick = onClear).padding(horizontal = 10.dp, vertical = 8.dp),
        )
    }
    Column(Modifier.fillMaxWidth().heightIn(max = 460.dp).verticalScroll(rememberScrollState())) { content() }
    Spacer(Modifier.height(8.dp))
    PrimaryButton(if (count == 1) "Mostrar 1 jogo" else "Mostrar $count jogos", onDone, Modifier.fillMaxWidth().padding(horizontal = 20.dp))
}
