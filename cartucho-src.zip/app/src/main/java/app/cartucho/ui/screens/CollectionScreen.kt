package app.cartucho.ui.screens

import app.cartucho.data.GameCard
import app.cartucho.data.CollectionEntry

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.achievements.RaWeb
import app.cartucho.data.CollectionStore
import app.cartucho.data.Game
import app.cartucho.data.PlayStatus
import app.cartucho.data.Systems
import app.cartucho.ui.MainActivity
import app.cartucho.ui.Route
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.Divider
import app.cartucho.ui.components.ListGroup
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.SectionLabel
import app.cartucho.ui.components.SegmentedRow
import app.cartucho.ui.components.pressable
import app.cartucho.ui.theme.Cartucho
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

private data class FriendRow(val user: String, val points: Int, val masteries: Int?, val me: Boolean)

@Composable
fun CollectionScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    val games by app.library.games.collectAsState()
    val entries by app.collection.entries.collectAsState()
    val settings by app.prefs.settings.collectAsState()
    val coverVersion by app.covers.version.collectAsState()
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var review by remember { mutableStateOf<Game?>(null) }
    var refresh by remember { mutableIntStateOf(0) }

    val seconds = remember(refresh) { app.collection.secondsByGame() }
    val sessions = remember(refresh) { app.collection.sessions() }
    val byId = remember(games) { games.associateBy { it.id } }
    val beaten = entries.count { it.value.status == PlayStatus.BEATEN || it.value.status == PlayStatus.PLATINUM }
    val localPlatinum = entries.count { it.value.status == PlayStatus.PLATINUM }
    val totalSeconds = seconds.values.sum()

    // Muda quando a chave é salva ou removida aqui mesmo, para tentar de novo.
    var keyVersion by remember { mutableIntStateOf(0) }
    val raConfigured = remember(settings.raUser, keyVersion) { settings.raUser.isNotEmpty() && app.secure.raWebKey.isNotEmpty() }
    var raMasteries by remember { mutableStateOf<Int?>(null) }
    var friends by remember { mutableStateOf<List<FriendRow>?>(null) }
    var friendsError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(raConfigured, keyVersion) {
        friends = null
        friendsError = null
        if (!raConfigured) return@LaunchedEffect
        val web = RaWeb(settings.raUser, app.secure.raWebKey)
        val result = withContext(Dispatchers.IO) {
            runCatching {
                val me = web.profile()
                val myAwards = web.awards()
                val follow = web.following()
                Triple(me, myAwards, follow)
            }
        }
        result.onSuccess { (me, myAwards, follow) ->
            raMasteries = myAwards.masteries
            val rows = (follow.map { FriendRow(it.user, it.points, null, false) } + FriendRow(me.user, me.points, myAwards.masteries, true))
                .sortedByDescending { it.points }
            friends = rows
            // Mestrias dos amigos chegam aos poucos (uma consulta por pessoa).
            val updated = rows.toMutableList()
            for ((i, row) in rows.withIndex().take(25)) {
                if (row.me) continue
                val m = withContext(Dispatchers.IO) { runCatching { web.awards(row.user).masteries }.getOrNull() }
                updated[i] = row.copy(masteries = m)
                friends = updated.toList()
            }
        }.onFailure { friendsError = it.message }
    }

    val friendNames = remember(friends?.map { it.user }) { friends?.filter { !it.me }?.map { it.user } }
    LaunchedEffect(activity.openMural) {
        if (activity.openMural) { tab = 3; activity.openMural = false }
    }

    SettingsPage(
        "Coleção",
        onBack = { activity.back() },
        backLabel = "Biblioteca",
        subtitle = if (settings.raUser.isNotEmpty()) "@${settings.raUser}" else "Seu histórico de jogos",
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Zerados", beaten.toString(), Modifier.weight(1f))
                    StatCard("Horas", (totalSeconds / 3600).toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Platinas", (raMasteries ?: localPlatinum).toString(), Modifier.weight(1f), if (raMasteries != null) "RetroAchievements" else null)
                    StatCard("Na biblioteca", games.size.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))
                SecondaryButton("Compartilhar meu cartão", {
                    scope.launch {
                        val file = withContext(Dispatchers.IO) {
                            runCatching { shareCard(app, settings.raUser, beaten, totalSeconds, raMasteries ?: localPlatinum, games, entries) }.getOrNull()
                        }
                        if (file != null) {
                            val uri = FileProvider.getUriForFile(activity, "app.cartucho.files", file)
                            val intent = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            activity.startActivity(Intent.createChooser(intent, "Compartilhar"))
                        }
                    }
                }, Modifier.fillMaxWidth(), icon = R.drawable.ic_cloud_up)
                Spacer(Modifier.height(8.dp))
                ListGroup {
                    SegmentedRow("", listOf("Diário", "Jogos", "Amigos", "Mural"), tab, { tab = it; refresh++ })
                }
            }
        }

        when (tab) {
            0 -> {
                val days = sessions.groupBy { dayKey(it.start) }.entries.take(30)
                val finished = entries.filter { it.value.finishedAt > 0 }.entries.sortedByDescending { it.value.finishedAt }.take(20)
                if (finished.isNotEmpty()) {
                    group("Zerados recentemente") {
                        finished.forEachIndexed { i, (id, e) ->
                            if (i > 0) Divider()
                            val g = byId[id]
                            if (g != null) {
                                GameRow(app, g, coverVersion, "${e.status.label} em ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(e.finishedAt))}", e.rating) { review = g }
                            }
                        }
                    }
                }
                if (days.isEmpty() && finished.isEmpty()) {
                    item { EmptyNote("Jogue alguma coisa: suas sessões aparecem aqui, dia a dia.") }
                }
                days.forEach { (day, list) ->
                    group(day) {
                        list.groupBy { it.gameId }.entries.forEachIndexed { i, (id, s) ->
                            if (i > 0) Divider()
                            val g = byId[id] ?: return@forEachIndexed
                            GameRow(app, g, coverVersion, "Jogou ${CollectionStore.formatHours(s.sumOf { it.seconds })}", entries[id]?.rating ?: 0) { review = g }
                        }
                    }
                }
            }
            1 -> {
                val ranked = games
                    .filter { (entries[it.id]?.status ?: PlayStatus.NONE) != PlayStatus.NONE || (seconds[it.id] ?: 0L) > 0L }
                    .sortedWith(compareByDescending<Game> { entries[it.id]?.rating ?: 0 }.thenByDescending { seconds[it.id] ?: 0L })
                if (ranked.isEmpty()) {
                    item { EmptyNote("Segure um jogo na biblioteca e escolha \"Avaliar e marcar como zerado\", ou só jogue: ele aparece aqui.") }
                } else {
                    group(null) {
                        ranked.forEachIndexed { i, g ->
                            if (i > 0) Divider()
                            val e = entries[g.id]
                            val parts = listOfNotNull(
                                e?.status?.takeIf { it != PlayStatus.NONE }?.label,
                                seconds[g.id]?.takeIf { it > 0 }?.let { CollectionStore.formatHours(it) },
                            )
                            GameRow(app, g, coverVersion, parts.joinToString(" · "), e?.rating ?: 0) { review = g }
                        }
                    }
                }
            }
            3 -> {
                when {
                    !raConfigured -> item {
                        EmptyNote("O mural usa o RetroAchievements: entre na conta e cole sua Web API Key na aba Amigos. Aí você vê o que seus amigos jogam e zeram, e pode curtir, reagir e comentar.")
                    }
                    friendsError != null -> item { EmptyNote(friendsError ?: "") }
                    else -> item { MuralFeed(app, settings.raUser, app.secure.raWebKey, friendNames) }
                }
            }
            else -> {
                if (settings.raUser.isNotEmpty() && (!raConfigured || friendsError != null)) {
                    // Chave ausente ou recusada: o campo fica sempre disponível para tentar de novo (ou deixar em branco).
                    item {
                        WebKeyEditor(
                            app = app,
                            error = friendsError,
                            onSaved = { keyVersion++ },
                        )
                    }
                } else if (!raConfigured) {
                    item {
                        Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Ranking com amigos", style = Cartucho.type.headline, color = c.text)
                            Text(
                                "O ranking usa sua conta do RetroAchievements: quem você segue lá aparece aqui, ordenado por pontos, com as mestrias (platinas) de cada um. " +
                                    "Entre na conta e cole sua Web API Key (retroachievements.org > Configurações > Keys).",
                                style = Cartucho.type.body,
                                color = c.textSecondary,
                            )
                            PrimaryButton("Configurar RetroAchievements", { activity.navigate(Route.Achievements) }, Modifier.fillMaxWidth())
                        }
                    }
                } else {
                    val list = friends
                    when {
                        friendsError != null -> item { EmptyNote(friendsError ?: "") }
                        list == null -> item { EmptyNote("Carregando o ranking…") }
                        list.size <= 1 -> item { EmptyNote("Você ainda não segue ninguém no RetroAchievements. Siga amigos no site e eles aparecem aqui.") }
                        else -> group("Ranking") {
                            list.forEachIndexed { i, f ->
                                if (i > 0) Divider()
                                FriendRowView(i + 1, f)
                            }
                        }
                    }
                }
            }
        }
    }

    ReviewSheet(app, review, onDismiss = { review = null; refresh++ })
}

@Composable
private fun WebKeyEditor(app: CartuchoApp, error: String?, onSaved: () -> Unit) {
    val c = Cartucho.colors
    var key by remember { mutableStateOf(app.secure.raWebKey) }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Ranking com amigos", style = Cartucho.type.headline, color = c.text)
        if (error != null) {
            Text("$error Confira a chave e tente de novo.", style = Cartucho.type.body, color = c.danger)
        } else {
            Text(
                "Cole sua Web API Key (retroachievements.org > Configurações > Keys) para ver quem você segue, por pontos e platinas. É opcional.",
                style = Cartucho.type.body,
                color = c.textSecondary,
            )
        }
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(c.surfaceRaised)
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            if (key.isEmpty()) Text("Web API Key", style = Cartucho.type.body, color = c.textSecondary)
            BasicTextField(
                value = key,
                onValueChange = { key = it.trim() },
                singleLine = true,
                textStyle = Cartucho.type.mono.copy(color = c.text),
                cursorBrush = SolidColor(c.accent),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Ascii,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        PrimaryButton("Salvar e tentar de novo", {
            app.secure.raWebKey = key
            onSaved()
        }, Modifier.fillMaxWidth(), enabled = key.isNotEmpty())
        SecondaryButton("Deixar sem chave", {
            key = ""
            app.secure.raWebKey = ""
            onSaved()
        }, Modifier.fillMaxWidth())
    }
}

private fun dayKey(ms: Long): String {
    val cal = Calendar.getInstance()
    val today = cal.get(Calendar.DAY_OF_YEAR) to cal.get(Calendar.YEAR)
    cal.timeInMillis = ms
    val that = cal.get(Calendar.DAY_OF_YEAR) to cal.get(Calendar.YEAR)
    return if (that == today) "Hoje" else DateFormat.getDateInstance(DateFormat.LONG).format(Date(ms))
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, caption: String? = null) {
    val c = Cartucho.colors
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(c.surface)
            .border(1.dp, c.border, RoundedCornerShape(12.dp))
            .padding(16.dp),
    ) {
        Text(value, style = Cartucho.type.display, color = c.text)
        Text(label, style = Cartucho.type.caption, color = c.textSecondary)
        if (caption != null) Text(caption, style = Cartucho.type.mono, color = c.textSecondary)
    }
}

@Composable
private fun EmptyNote(text: String) {
    Text(text, style = Cartucho.type.body, color = Cartucho.colors.textSecondary, modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
}

@Composable
fun Stars(rating: Int, size: Int = 14) {
    val c = Cartucho.colors
    if (rating <= 0) return
    val full = rating / 2
    val half = rating % 2 == 1
    Text(
        "★".repeat(full) + (if (half) "½" else ""),
        style = Cartucho.type.label.copy(fontSize = size.sp),
        color = c.accent,
    )
}

@Composable
private fun GameRow(app: CartuchoApp, game: Game, coverVersion: Int, subtitle: String, rating: Int, onClick: () -> Unit) {
    val c = Cartucho.colors
    val cover by produceState<ImageBitmap?>(null, game.id, coverVersion) {
        value = withContext(Dispatchers.IO) { loadCover(app.covers.file(game.id)) }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .pressable(shape = RoundedCornerShape(0.dp), onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(width = 40.dp, height = 52.dp).clip(RoundedCornerShape(6.dp)).background(c.surfaceRaised), contentAlignment = Alignment.Center) {
            val bmp = cover
            if (bmp != null) Image(bmp, null, contentScale = ContentScale.Crop, modifier = Modifier.size(width = 40.dp, height = 52.dp))
            else Text(Systems.get(game.systemId)?.short ?: "?", style = Cartucho.type.mono, color = c.textSecondary)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(game.title, style = Cartucho.type.body, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotEmpty()) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary, maxLines = 1)
        }
        Stars(rating)
    }
}

@Composable
private fun FriendRowView(position: Int, f: FriendRow) {
    val c = Cartucho.colors
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("$position", style = Cartucho.type.mono, color = c.textSecondary, modifier = Modifier.width(28.dp))
        Column(Modifier.weight(1f)) {
            Text(if (f.me) "${f.user} (você)" else f.user, style = Cartucho.type.body, color = if (f.me) c.accent else c.text)
            Text(f.masteries?.let { "$it platinas" } ?: "…", style = Cartucho.type.caption, color = c.textSecondary)
        }
        Text("${f.points} pts", style = Cartucho.type.mono, color = c.text)
    }
}

/** Status, nota em meias estrelas, favorito e resenha de um jogo. */
@Composable
fun ReviewSheet(app: CartuchoApp, game: Game?, onDismiss: () -> Unit) {
    val c = Cartucho.colors
    val entries by app.collection.entries.collectAsState()
    var draft by remember(game?.id) { mutableStateOf(game?.let { app.collection.get(it.id).review } ?: "") }
    val shareScope = rememberCoroutineScope()

    BottomSheet(visible = game != null, onDismiss = onDismiss) {
        val g = game ?: return@BottomSheet
        val e = entries[g.id] ?: CollectionEntry()
        Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Text(g.title, style = Cartucho.type.title, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(Systems.get(g.systemId)?.name ?: "", style = Cartucho.type.caption, color = c.textSecondary)

            SectionLabel("Status")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(PlayStatus.entries.filter { it != PlayStatus.NONE }) { st ->
                    val active = e.status == st
                    Box(
                        Modifier
                            .heightIn(min = 40.dp)
                            .pressable(shape = RoundedCornerShape(999.dp)) {
                                app.collection.update(g.id) { it.copy(status = if (active) PlayStatus.NONE else st) }
                            }
                            .background(if (active) c.text else Color.Transparent)
                            .border(1.dp, if (active) c.text else c.border, RoundedCornerShape(999.dp))
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(st.label, style = Cartucho.type.label, color = if (active) c.background else c.text)
                    }
                }
            }

            SectionLabel("Nota")
            Row(verticalAlignment = Alignment.CenterVertically) {
                for (star in 1..5) {
                    val fullValue = star * 2
                    val symbol = if (e.rating >= fullValue - 1) "★" else "☆"
                    val starColor = when {
                        e.rating >= fullValue -> c.accent
                        e.rating == fullValue - 1 -> c.accent.copy(alpha = 0.45f)
                        else -> c.textSecondary
                    }
                    Box(
                        Modifier.size(48.dp).pressable(shape = RoundedCornerShape(24.dp)) {
                            // Toque repetido na mesma estrela alterna entre inteira e meia.
                            val next = when (e.rating) {
                                fullValue -> fullValue - 1
                                fullValue - 1 -> 0
                                else -> fullValue
                            }
                            app.collection.update(g.id) { it.copy(rating = next) }
                        },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(symbol, style = Cartucho.type.title.copy(fontSize = 28.sp), color = starColor)
                    }
                }
                Spacer(Modifier.width(8.dp))
                Text(if (e.rating > 0) "%.1f".format(e.rating / 2f) else "Sem nota", style = Cartucho.type.mono, color = c.textSecondary)
            }

            Spacer(Modifier.height(8.dp))
            SecondaryButton(if (e.favorite) "♥ Favorito" else "♡ Marcar como favorito", {
                app.collection.update(g.id) { it.copy(favorite = !it.favorite) }
            }, Modifier.fillMaxWidth())

            SectionLabel("Resenha")
            Box(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 110.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(c.surfaceRaised)
                    .padding(14.dp),
            ) {
                if (draft.isEmpty()) Text("O que você achou?", style = Cartucho.type.body, color = c.textSecondary)
                BasicTextField(
                    value = draft,
                    onValueChange = { draft = it.take(2000) },
                    textStyle = Cartucho.type.body.copy(color = c.text),
                    cursorBrush = SolidColor(c.accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(12.dp))
            PrimaryButton("Salvar", {
                app.collection.update(g.id) { it.copy(review = draft.trim()) }
                onDismiss()
            }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            // Card para Stories/WhatsApp: capa, status (zerado, platinado, jogando), estrelas e horas.
            SecondaryButton("Compartilhar card", {
                app.collection.update(g.id) { it.copy(review = draft.trim()) }
                shareScope.launch { GameCard.shareGame(app, g) }
            }, Modifier.fillMaxWidth(), icon = R.drawable.ic_cloud_up)
            Spacer(Modifier.height(16.dp))
        }
    }
}

/** Gera a imagem 1080x1350 para compartilhar nas redes. */
private fun shareCard(
    app: CartuchoApp,
    user: String,
    beaten: Int,
    seconds: Long,
    platinum: Int,
    games: List<Game>,
    entries: Map<String, CollectionEntry>,
): File {
    val w = 1080
    val h = 1350
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    // Identidade do Cartucho: cinza console, roxo de destaque, Space Grotesk nos títulos e as três listras.
    canvas.drawColor(0xFFE3E3EA.toInt())
    val display = ResourcesCompat.getFont(app, R.font.space_grotesk_bold)
    val bold = ResourcesCompat.getFont(app, R.font.inter_bold)
    val semibold = ResourcesCompat.getFont(app, R.font.inter_semibold)
    val regular = ResourcesCompat.getFont(app, R.font.inter_regular)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val ink = 0xFF1E1E24.toInt()
    val muted = 0xFF55556A.toInt()
    val purple = 0xFF4F43AE.toInt()
    val dots = intArrayOf(0xFFD3262F.toInt(), 0xFFF0BE1E.toInt(), 0xFF23965A.toInt(), 0xFF2A5DB8.toInt())

    // Selo: ícone + Cartucho + quatro pontos.
    runCatching { BitmapFactory.decodeResource(app.resources, R.drawable.brand_icon) }.getOrNull()?.let { icon ->
        canvas.save()
        val r = RectF(80f, 96f, 132f, 148f)
        canvas.clipPath(android.graphics.Path().apply { addRoundRect(r, 12f, 12f, android.graphics.Path.Direction.CW) })
        canvas.drawBitmap(icon, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
        canvas.restore()
    }
    p.typeface = display; p.color = ink; p.textSize = 34f; p.letterSpacing = -0.02f
    canvas.drawText("Cartucho", 148f, 134f, p)
    var dx = 148f + p.measureText("Cartucho") + 16f
    dots.forEach { col -> p.color = col; canvas.drawCircle(dx + 6f, 122f, 6f, p); dx += 18f }
    p.letterSpacing = 0f
    p.typeface = semibold; p.color = muted; p.textSize = 30f
    canvas.drawText(if (user.isNotEmpty()) "@$user" else "", 1000f - p.measureText(if (user.isNotEmpty()) "@$user" else ""), 134f, p)

    p.typeface = display; p.color = ink; p.textSize = 96f; p.letterSpacing = -0.035f
    canvas.drawText("Minha coleção.", 76f, 290f, p)
    p.letterSpacing = 0f

    val stats = listOf("ZERADOS" to beaten.toString(), "HORAS" to (seconds / 3600).toString(), "PLATINAS" to platinum.toString())
    stats.forEachIndexed { i, (label, value) ->
        val x = 80f + i * 320f
        p.color = dots[i]; canvas.drawCircle(x + 7f, 371f, 7f, p)
        p.typeface = bold; p.color = muted; p.textSize = 26f; p.letterSpacing = 0.08f
        canvas.drawText(label, x + 24f, 380f, p)
        p.letterSpacing = -0.03f
        p.typeface = display; p.color = purple; p.textSize = 120f
        canvas.drawText(value, x - 4f, 500f, p)
        p.letterSpacing = 0f
    }

    p.typeface = bold; p.color = muted; p.textSize = 26f; p.letterSpacing = 0.08f
    canvas.drawText("FAVORITOS", 80f, 620f, p)
    p.letterSpacing = 0f
    val top = games
        .filter { entries[it.id] != null }
        .sortedWith(compareByDescending<Game> { entries[it.id]?.favorite == true }.thenByDescending { entries[it.id]?.rating ?: 0 })
        .take(4)
    top.forEachIndexed { i, g ->
        val left = 80f + i * 235f
        val rect = RectF(left, 650f, left + 210f, 650f + 280f)
        p.color = 0xFFE9E9EE.toInt()
        canvas.drawRoundRect(rect, 16f, 16f, p)
        val coverFile = app.covers.file(g.id)
        val cover = if (coverFile.exists()) BitmapFactory.decodeFile(coverFile.absolutePath) else null
        if (cover != null) {
            canvas.save()
            val path = android.graphics.Path().apply { addRoundRect(rect, 16f, 16f, android.graphics.Path.Direction.CW) }
            canvas.clipPath(path)
            val scale = maxOf(rect.width() / cover.width, rect.height() / cover.height)
            val cw = cover.width * scale
            val chh = cover.height * scale
            canvas.drawBitmap(cover, null, RectF(rect.centerX() - cw / 2, rect.centerY() - chh / 2, rect.centerX() + cw / 2, rect.centerY() + chh / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
            cover.recycle()
        }
        p.typeface = semibold; p.color = ink; p.textSize = 26f
        val title = android.text.TextUtils.ellipsize(g.title, android.text.TextPaint(p), 205f, android.text.TextUtils.TruncateAt.END).toString()
        canvas.drawText(title, left, 975f, p)
        val r = entries[g.id]?.rating ?: 0
        if (r > 0) {
            p.typeface = regular; p.color = purple; p.textSize = 28f
            canvas.drawText("★".repeat(r / 2) + if (r % 2 == 1) "½" else "", left, 1015f, p)
        }
    }

    p.typeface = semibold; p.color = muted; p.textSize = 24f; p.letterSpacing = 0.08f
    canvas.drawText("CARTUCHO · EMULADOR", 80f, 1270f, p)
    p.letterSpacing = 0f
    var fx = 1000f - (4 * 14f + 3 * 7f)
    dots.forEach { col -> p.color = col; canvas.drawCircle(fx + 7f, 1262f, 7f, p); fx += 21f }
    listOf(purple, 0xFF8F86D6.toInt(), 0xFFC9C6EE.toInt()).forEachIndexed { i, col ->
        p.color = col
        canvas.drawRect(w * i / 3f, h - 16f, w * (i + 1) / 3f, h.toFloat(), p)
    }

    val dir = File(app.cacheDir, "share").apply { mkdirs() }
    val out = File(dir, "cartao-cartucho.png")
    out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return out
}
