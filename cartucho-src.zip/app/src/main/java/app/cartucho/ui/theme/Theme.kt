package app.cartucho.ui.theme

import android.provider.Settings as AndroidSettings
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.cartucho.R
import app.cartucho.data.ThemeMode
import kotlin.math.PI
import kotlin.math.pow

@Immutable
data class CartuchoColors(
    val background: Color,
    val surface: Color,
    val surfaceRaised: Color,
    val border: Color,
    val text: Color,
    val textSecondary: Color,
    val accent: Color,
    val onAccent: Color,
    val danger: Color,
    val success: Color,
    val scrim: Color,
    val isDark: Boolean,
)

val DarkColors = CartuchoColors(
    background = Color(0xFF111111),
    surface = Color(0xFF1A1A1A),
    surfaceRaised = Color(0xFF222222),
    border = Color(0x14FFFFFF),
    text = Color(0xFFF2F2F0),
    textSecondary = Color(0xFF8A8A86),
    accent = Color(0xFF9DB8FF),
    onAccent = Color(0xFF111111),
    danger = Color(0xFFE58A86),
    success = Color(0xFF8FC79A),
    scrim = Color(0x99000000),
    isDark = true,
)

val LightColors = CartuchoColors(
    background = Color(0xFFFBFBFA),
    surface = Color(0xFFFFFFFF),
    surfaceRaised = Color(0xFFF4F4F2),
    border = Color(0xFFEAEAEA),
    text = Color(0xFF2F3437),
    textSecondary = Color(0xFF787774),
    accent = Color(0xFF2F5BD3),
    onAccent = Color(0xFFFFFFFF),
    danger = Color(0xFF9F2F2D),
    success = Color(0xFF346538),
    scrim = Color(0x66000000),
    isDark = false,
)

val Geist = FontFamily(
    Font(R.font.geist_regular, FontWeight.Normal),
    Font(R.font.geist_medium, FontWeight.Medium),
    Font(R.font.geist_semibold, FontWeight.SemiBold),
)
val GeistMono = FontFamily(Font(R.font.geist_mono, FontWeight.Normal))

@Immutable
data class CartuchoType(
    val display: TextStyle,
    val title: TextStyle,
    val headline: TextStyle,
    val body: TextStyle,
    val label: TextStyle,
    val caption: TextStyle,
    val mono: TextStyle,
)

val Type = CartuchoType(
    display = TextStyle(fontFamily = Geist, fontWeight = FontWeight.SemiBold, fontSize = 34.sp, lineHeight = 38.sp, letterSpacing = (-0.02).em),
    title = TextStyle(fontFamily = Geist, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 26.sp, letterSpacing = (-0.015).em),
    headline = TextStyle(fontFamily = Geist, fontWeight = FontWeight.Medium, fontSize = 17.sp, lineHeight = 22.sp, letterSpacing = (-0.005).em),
    body = TextStyle(fontFamily = Geist, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    label = TextStyle(fontFamily = Geist, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 20.sp),
    caption = TextStyle(fontFamily = Geist, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.01.em),
    mono = TextStyle(fontFamily = GeistMono, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.04.em),
)

/**
 * Molas no vocabulário da Apple (amortecimento + resposta em segundos), convertidas para rigidez.
 * Padrão sem quique; folhas que vêm de gesto ganham um leve quique.
 */
object Motion {
    private fun stiffness(response: Float): Float = (2f * PI.toFloat() / response).pow(2)

    fun <T> standard(): FiniteAnimationSpec<T> = spring(dampingRatio = 1f, stiffness = stiffness(0.35f))
    fun <T> sheet(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.8f, stiffness = stiffness(0.3f))
    fun <T> press(): FiniteAnimationSpec<T> = spring(dampingRatio = 1f, stiffness = stiffness(0.18f))
    fun <T> fade(): FiniteAnimationSpec<T> = tween(durationMillis = 160)
}

val LocalColors = staticCompositionLocalOf { DarkColors }
val LocalReducedMotion = staticCompositionLocalOf { false }

object Cartucho {
    val colors: CartuchoColors @Composable get() = LocalColors.current
    val type: CartuchoType get() = Type
    val reducedMotion: Boolean @Composable get() = LocalReducedMotion.current

    /** Escolhe a mola ou um fade curto quando o usuário pediu para remover animações. */
    @Composable
    fun <T> spec(spring: FiniteAnimationSpec<T>): FiniteAnimationSpec<T> =
        if (LocalReducedMotion.current) tween(durationMillis = 120) else spring
}

@Composable
fun CartuchoTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val colors = if (dark) DarkColors else LightColors
    val context = LocalContext.current
    val reduced = remember {
        runCatching {
            AndroidSettings.Global.getFloat(context.contentResolver, AndroidSettings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }
    val material = if (dark) {
        darkColorScheme(primary = colors.accent, background = colors.background, surface = colors.surface, onSurface = colors.text, onBackground = colors.text)
    } else {
        lightColorScheme(primary = colors.accent, background = colors.background, surface = colors.surface, onSurface = colors.text, onBackground = colors.text)
    }
    CompositionLocalProvider(LocalColors provides colors, LocalReducedMotion provides reduced) {
        MaterialTheme(colorScheme = material, content = content)
    }
}
