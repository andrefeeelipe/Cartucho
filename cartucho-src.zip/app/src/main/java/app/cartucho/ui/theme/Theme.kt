package app.cartucho.ui.theme

import android.provider.Settings as AndroidSettings
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.cartucho.R
import app.cartucho.data.ThemeMode
import kotlin.math.PI
import kotlin.math.pow

/**
 * Cores da identidade do Cartucho (design system "Cartucho", novembro de 2026).
 * Um tema só, o claro. O grafite aparece em seções próprias (menu de pausa, sala online), não como modo escuro.
 */
object Brand {
    val surface = Color(0xFFE3E3EA)
    val surfaceRaised = Color(0xFFF3F3F7)
    val card = Color(0xFFFFFFFF)
    val line = Color(0xFFCACAD3)
    val lineSoft = Color(0xFFE1E1E8)
    val placeholder = Color(0xFFE9E9EE)
    val pauseSurface = Color(0xFF111116)
    val ink = Color(0xFF1E1E24)
    val text = Color(0xFF232329)
    val muted = Color(0xFF4A4A55)
    val muted2 = Color(0xFF55556A)
    val purple = Color(0xFF4F43AE)
    val purpleDark = Color(0xFF3A3088)
    val lavender = Color(0xFFC9C6EE)
    val lavenderMid = Color(0xFF8F86D6)
    val lavenderSoft = Color(0xFFE6E4F8)
    val lavenderInk = Color(0xFF2A2366)
    val graphite = Color(0xFF2B2B33)
    val graphiteRaised = Color(0xFF393944)
    val graphiteLine = Color(0xFF4A4A55)
    val graphiteText = Color(0xFFC4C4D0)
    val graphiteMeta = Color(0xFFA9A9B8)
    val graphiteLabel = Color(0xFFBDBCE6)
    val dotRed = Color(0xFFD3262F)
    val dotYellow = Color(0xFFF0BE1E)
    val dotYellowInk = Color(0xFF2A2410)
    val dotGreen = Color(0xFF23965A)
    val dotBlue = Color(0xFF2A5DB8)
    val plate = Color(0xFFD2D2DB)
    val plateHighlight = Color(0xFFEDEDF2)
    val plateShade = Color(0xFFB9B9C4)
    val pad = Color(0xFFBDBDC8)

    /** Os quatro pontos, na ordem dos botões de um controle. */
    val dots = listOf(dotRed, dotYellow, dotGreen, dotBlue)
}

@Immutable
data class CartuchoColors(
    val background: Color,
    val surface: Color,
    val surfaceRaised: Color,
    val border: Color,
    val text: Color,
    val textSecondary: Color,
    val accent: Color,
    val onAccent: Color,
    val danger: Color,
    val success: Color,
    val scrim: Color,
    val isDark: Boolean,
    /** Fundo de pílula/etiqueta e segmento vazio de barra. */
    val accentSoft: Color,
    /** Texto sobre accentSoft. */
    val onAccentSoft: Color,
    /** Espaço reservado de imagem e divisórias dentro de grupos. */
    val placeholder: Color,
)

/** Tema claro: página branca, campos e cartões em surface-raised, roxo como único destaque. */
val LightColors = CartuchoColors(
    background = Brand.card,
    surface = Brand.card,
    surfaceRaised = Brand.surfaceRaised,
    border = Brand.lineSoft,
    text = Brand.ink,
    textSecondary = Brand.muted2,
    accent = Brand.purple,
    onAccent = Color.White,
    danger = Color(0xFF9F2F2D),
    success = Brand.dotGreen,
    scrim = Color(0x661E1E24),
    isDark = false,
    accentSoft = Brand.lavenderSoft,
    onAccentSoft = Brand.purpleDark,
    placeholder = Brand.placeholder,
)

/** Seções em grafite (menu de pausa, sala online): mesmos papéis, tokens graphite-*. */
val DarkColors = CartuchoColors(
    background = Brand.graphite,
    surface = Brand.graphite,
    surfaceRaised = Brand.graphiteRaised,
    border = Brand.graphiteLine,
    text = Color.White,
    textSecondary = Brand.graphiteText,
    accent = Brand.lavender,
    onAccent = Brand.lavenderInk,
    danger = Color(0xFFF0A3A0),
    success = Color(0xFF7FD3A5),
    scrim = Color(0x99000000),
    isDark = true,
    accentSoft = Brand.graphiteRaised,
    onAccentSoft = Brand.graphiteLabel,
    placeholder = Brand.graphiteRaised,
)

/** Inter: texto e interface. */
val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

/** Space Grotesk 700: títulos e a marca. */
val SpaceGrotesk = FontFamily(Font(R.font.space_grotesk_bold, FontWeight.Bold))

@Immutable
data class CartuchoType(
    /** Título de tela (display-l reduzido para o celular). */
    val display: TextStyle,
    /** Título de folha e de card grande (display-m). */
    val title: TextStyle,
    val headline: TextStyle,
    val body: TextStyle,
    val label: TextStyle,
    val caption: TextStyle,
    /** Rótulo em caixa alta (label do design system). */
    val mono: TextStyle,
    /** Nome "Cartucho" ao lado do ícone. */
    val wordmark: TextStyle,
)

val Type = CartuchoType(
    display = TextStyle(fontFamily = SpaceGrotesk, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 34.sp, letterSpacing = (-0.03).em),
    title = TextStyle(fontFamily = SpaceGrotesk, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 26.sp, letterSpacing = (-0.02).em),
    headline = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp),
    body = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    label = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp),
    caption = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp),
    mono = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.08.em),
    wordmark = TextStyle(fontFamily = SpaceGrotesk, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 23.sp, letterSpacing = (-0.02).em),
)

/**
 * Molas no vocabulário da Apple (amortecimento + resposta em segundos), convertidas para rigidez.
 * Padrão sem quique; folhas que vêm de gesto ganham um leve quique.
 */
object Motion {
    private fun stiffness(response: Float): Float = (2f * PI.toFloat() / response).pow(2)

    fun <T> standard(): FiniteAnimationSpec<T> = spring(dampingRatio = 1f, stiffness = stiffness(0.35f))
    fun <T> sheet(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.8f, stiffness = stiffness(0.3f))
    fun <T> press(): FiniteAnimationSpec<T> = spring(dampingRatio = 1f, stiffness = stiffness(0.18f))
    fun <T> fade(): FiniteAnimationSpec<T> = tween(durationMillis = 160)
}

val LocalColors = staticCompositionLocalOf { LightColors }
val LocalReducedMotion = staticCompositionLocalOf { false }

object Cartucho {
    val colors: CartuchoColors @Composable get() = LocalColors.current
    val type: CartuchoType get() = Type
    val reducedMotion: Boolean @Composable get() = LocalReducedMotion.current

    /** Escolhe a mola ou um fade curto quando o usuário pediu para remover animações. */
    @Composable
    fun <T> spec(spring: FiniteAnimationSpec<T>): FiniteAnimationSpec<T> =
        if (LocalReducedMotion.current) tween(durationMillis = 120) else spring
}

/**
 * O app usa sempre o tema claro. ThemeMode.DARK fica só para as seções em grafite
 * (jogo e sala online), que chamam o tema explicitamente.
 */
@Composable
fun CartuchoTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = mode == ThemeMode.DARK
    val colors = if (dark) DarkColors else LightColors
    val context = LocalContext.current
    val reduced = remember {
        runCatching {
            AndroidSettings.Global.getFloat(context.contentResolver, AndroidSettings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }
    val material = if (dark) {
        darkColorScheme(primary = colors.accent, background = colors.background, surface = colors.surface, onSurface = colors.text, onBackground = colors.text)
    } else {
        lightColorScheme(primary = colors.accent, background = colors.background, surface = colors.surface, onSurface = colors.text, onBackground = colors.text)
    }
    CompositionLocalProvider(LocalColors provides colors, LocalReducedMotion provides reduced) {
        MaterialTheme(colorScheme = material, content = content)
    }
}
