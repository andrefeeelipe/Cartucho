package app.cartucho.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import app.cartucho.R
import app.cartucho.ui.theme.Brand
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.Motion
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Toque com resposta imediata (escala), anel de foco para navegação por controle e sem ripple. */
@Composable
fun Modifier.pressable(
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(12.dp),
    role: Role = Role.Button,
    onClick: () -> Unit,
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val focused by interaction.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = Cartucho.spec(Motion.press()),
        label = "press",
    )
    val accent = Cartucho.colors.accent
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .then(if (focused) Modifier.border(3.dp, accent, shape) else Modifier)
        .clip(shape)
        .clickable(interactionSource = interaction, indication = null, enabled = enabled, role = role, onClick = onClick)
}

@Composable
fun CIcon(@DrawableRes res: Int, tint: Color = Cartucho.colors.text, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    androidx.compose.foundation.Image(
        painter = painterResource(res),
        contentDescription = null,
        colorFilter = ColorFilter.tint(tint),
        modifier = modifier.size(size),
    )
}

@Composable
fun IconButton(@DrawableRes res: Int, description: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Cartucho.colors.text) {
    Box(
        modifier = modifier
            .size(48.dp)
            .pressable(shape = RoundedCornerShape(24.dp), onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        CIcon(res, tint = tint)
    }
}

/** Botão principal: pílula roxa, texto branco, 48dp de altura. */
@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, @DrawableRes icon: Int? = null, enabled: Boolean = true) {
    val c = Cartucho.colors
    val fg = if (enabled) c.onAccent else c.textSecondary
    Row(
        modifier = modifier
            .heightIn(min = 48.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(999.dp), onClick = onClick)
            .background(if (enabled) c.accent else c.accentSoft)
            .padding(horizontal = 22.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            CIcon(icon, tint = fg, size = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = Cartucho.type.label, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Botão secundário: pílula branca com contorno de 1px. */
@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, @DrawableRes icon: Int? = null, enabled: Boolean = true) {
    val c = Cartucho.colors
    val outline = if (c.isDark) c.border else Brand.line
    Row(
        modifier = modifier
            .heightIn(min = 48.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(999.dp), onClick = onClick)
            .background(c.surface)
            .border(1.dp, outline, RoundedCornerShape(999.dp))
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            CIcon(icon, tint = if (enabled) c.text else c.textSecondary, size = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = Cartucho.type.label, color = if (enabled) c.text else c.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/** Botão suave: pílula lavanda (secundário com cor), como "Baixar" na Loja. */
@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, @DrawableRes icon: Int? = null, enabled: Boolean = true) {
    val c = Cartucho.colors
    val fg = if (c.isDark) c.onAccent else Brand.lavenderInk
    Row(
        modifier = modifier
            .heightIn(min = 44.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(999.dp), onClick = onClick)
            .background(if (c.isDark) c.accent else Brand.lavender)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            CIcon(icon, tint = fg, size = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = Cartucho.type.label, color = fg, maxLines = 1)
    }
}

/** Rótulo de seção em caixa alta (estilo label: Inter 700, +8%). */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        style = Cartucho.type.mono,
        color = Cartucho.colors.textSecondary,
        modifier = modifier.padding(start = 4.dp, top = 24.dp, bottom = 8.dp),
    )
}

/** Grupo de linhas: card branco de 16dp com borda de 1px e divisórias internas. */
@Composable
fun ListGroup(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = Cartucho.colors
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (c.isDark) c.surfaceRaised else c.surface)
            .then(if (c.isDark) Modifier else Modifier.border(1.dp, c.border, RoundedCornerShape(16.dp))),
        content = content,
    )
}

@Composable
fun Divider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp)
            .height(1.dp)
            .background(Cartucho.colors.placeholder)
    )
}

@Composable
fun NavRow(
    title: String,
    onClick: () -> Unit,
    value: String? = null,
    @DrawableRes icon: Int? = null,
    subtitle: String? = null,
    showChevron: Boolean = true,
) {
    val c = Cartucho.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(shape = RoundedCornerShape(0.dp), onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            CIcon(icon, tint = c.text, size = 20.dp)
            Spacer(Modifier.width(14.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = Cartucho.type.body, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary)
        }
        if (value != null) {
            Text(value, style = Cartucho.type.body.copy(fontSize = 15.sp), color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 180.dp))
            Spacer(Modifier.width(8.dp))
        }
        if (showChevron) CIcon(R.drawable.ic_chevron, tint = c.textSecondary, size = 14.dp)
    }
}

@Composable
fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit, subtitle: String? = null, enabled: Boolean = true) {
    val c = Cartucho.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(0.dp), role = Role.Switch) { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Cartucho.type.body, color = if (enabled) c.text else c.textSecondary)
            if (subtitle != null) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = null,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = c.accent,
                checkedBorderColor = c.accent,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = if (c.isDark) c.border else Brand.line,
                uncheckedBorderColor = if (c.isDark) c.border else Brand.line,
            ),
        )
    }
}

@Composable
fun SliderRow(title: String, value: Float, onChange: (Float) -> Unit, valueLabel: String, range: ClosedFloatingPointRange<Float> = 0f..1f, steps: Int = 0) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = Cartucho.type.body, color = c.text, modifier = Modifier.weight(1f))
            Text(valueLabel, style = Cartucho.type.caption, color = c.textSecondary)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = c.accent,
                activeTrackColor = c.accent,
                inactiveTrackColor = c.accentSoft,
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent,
            ),
        )
    }
}

/** Controle segmentado: trilho em surface-raised e a opção ativa em pílula branca (Story · Feed · Link). */
@Composable
fun SegmentedControl(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val c = Cartucho.colors
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(c.surfaceRaised)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEachIndexed { i, label ->
            val active = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 40.dp)
                    .pressable(shape = RoundedCornerShape(9.dp), role = Role.RadioButton) { onSelect(i) }
                    .background(if (active) (if (c.isDark) c.border else c.surface) else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, style = Cartucho.type.label.copy(fontSize = 14.sp), color = if (active) c.text else c.textSecondary, maxLines = 1)
            }
        }
    }
}

/** Controle segmentado com título (até 4 opções) — escolhas visíveis de uma vez, sem menus escondidos. */
@Composable
fun SegmentedRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit, subtitle: String? = null) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = Cartucho.type.body, color = c.text)
        if (subtitle != null) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary)
        Spacer(Modifier.height(10.dp))
        SegmentedControl(options, selected, onSelect)
    }
}

/** Etiqueta em pílula (tag: Inter 600, 12sp). */
@Composable
fun Tag(text: String, background: Color, foreground: Color) {
    Text(
        text = text,
        style = Cartucho.type.caption.copy(fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 15.sp),
        color = foreground,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(background)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

/** Pílula de filtro: preenchida em ink quando ativa, contornada quando não. */
@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = Cartucho.colors
    Box(
        Modifier
            .heightIn(min = 36.dp)
            .pressable(shape = RoundedCornerShape(999.dp), role = Role.Checkbox, onClick = onClick)
            .background(if (selected) c.text else c.surface)
            .then(if (selected) Modifier else Modifier.border(1.dp, if (c.isDark) c.border else Brand.line, RoundedCornerShape(999.dp)))
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = Cartucho.type.label.copy(fontSize = 14.sp, fontWeight = FontWeight.Medium), color = if (selected) c.background else c.text, maxLines = 1)
    }
}

/** Os quatro pontos (vermelho, amarelo, verde, azul), como os botões de um controle. */
@Composable
fun Dots(size: Dp = 8.dp, gap: Dp = 4.dp, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(gap), verticalAlignment = Alignment.CenterVertically) {
        Brand.dots.forEach { Box(Modifier.size(size).clip(CircleShape).background(it)) }
    }
}

/** As listras: três faixas iguais em roxo, lavanda média e lavanda. */
@Composable
fun Stripes(modifier: Modifier = Modifier, height: Dp = 6.dp) {
    Row(modifier.fillMaxWidth().height(height)) {
        listOf(Brand.purple, Brand.lavenderMid, Brand.lavender).forEach { Box(Modifier.weight(1f).fillMaxHeight().background(it)) }
    }
}

/** Selo: ícone + nome Cartucho + os quatro pontos. */
@Composable
fun Selo(modifier: Modifier = Modifier, iconSize: Dp = 30.dp) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.Image(
            painter = painterResource(R.drawable.brand_icon),
            contentDescription = null,
            modifier = Modifier.size(iconSize).clip(RoundedCornerShape(iconSize * 0.24f)),
        )
        Spacer(Modifier.width(10.dp))
        Text("Cartucho", style = Cartucho.type.wordmark, color = Cartucho.colors.text)
        Spacer(Modifier.width(8.dp))
        Dots(size = 7.dp, gap = 4.dp)
    }
}

/** Campo de busca: fundo surface-raised, cantos de 12dp e lupa. */
@Composable
fun SearchBox(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier, onClear: (() -> Unit)? = null) {
    val c = Cartucho.colors
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(c.surfaceRaised)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CIcon(R.drawable.ic_search, tint = c.textSecondary, size = 18.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty()) Text(placeholder, style = Cartucho.type.body, color = c.textSecondary, maxLines = 1)
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = Cartucho.type.body.copy(color = c.text),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (value.isNotEmpty() && onClear != null) {
            Box(Modifier.size(32.dp).pressable(shape = CircleShape, onClick = onClear), contentAlignment = Alignment.Center) {
                CIcon(R.drawable.ic_close, tint = c.textSecondary, size = 16.dp)
            }
        }
    }
}

/** Barra superior: link de voltar em roxo (‹ Biblioteca) e título grande em Space Grotesk. */
@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?, subtitle: String? = null, backLabel: String = "Voltar") {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Box(Modifier.height(52.dp), contentAlignment = Alignment.CenterStart) {
            if (onBack != null) {
                Row(
                    Modifier
                        .offset(x = (-8).dp)
                        .heightIn(min = 44.dp)
                        .pressable(shape = RoundedCornerShape(12.dp), onClick = onBack)
                        .semantics { contentDescription = "Voltar para $backLabel" }
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CIcon(R.drawable.ic_back, tint = c.accent, size = 18.dp)
                    Spacer(Modifier.width(4.dp))
                    Text(backLabel, style = Cartucho.type.body, color = c.accent)
                }
            }
        }
        Text(title, style = Cartucho.type.display, color = c.text)
        if (subtitle != null) {
            Spacer(Modifier.height(6.dp))
            Text(subtitle, style = Cartucho.type.body.copy(fontSize = 15.sp, lineHeight = 22.sp), color = c.textSecondary)
        }
        Spacer(Modifier.height(16.dp))
    }
}

/** Aviso flutuante (toast) no rodapé: pílula ink com texto branco. */
@Composable
fun Toast(text: String, modifier: Modifier = Modifier) {
    val c = Cartucho.colors
    Text(
        text = text,
        style = Cartucho.type.label,
        color = if (c.isDark) Brand.ink else Color.White,
        modifier = modifier.clip(RoundedCornerShape(16.dp)).background(if (c.isDark) Color.White else Brand.ink).padding(horizontal = 18.dp, vertical = 12.dp),
    )
}

/**
 * Folha inferior com fundo escurecido. Acompanha o dedo 1:1, usa a velocidade da soltura para
 * decidir fechar ou voltar e anima com mola interrompível.
 */
@Composable
fun BottomSheet(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val c = Cartucho.colors
    AnimatedVisibility(visible = visible, enter = fadeIn(Motion.fade()), exit = fadeOut(Motion.fade())) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(c.scrim)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
            )
            SheetPanel(onDismiss, content)
        }
    }
}

@Composable
private fun BoxScope.SheetPanel(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val c = Cartucho.colors
    val density = LocalDensity.current
    val offset = remember { Animatable(with(density) { 400.dp.toPx() }) }
    val scope = rememberCoroutineScope()
    val sheetSpec = Cartucho.spec(Motion.sheet<Float>())
    LaunchedEffect(Unit) { offset.animateTo(0f, sheetSpec) }
    val dragState = rememberDraggableState { delta ->
        scope.launch {
            val next = offset.value + delta
            // Resistência elástica ao puxar para cima além do limite.
            offset.snapTo(if (next < 0f) next * 0.3f else next)
        }
    }
    Column(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .widthIn(max = 640.dp)
            .offset { IntOffset(0, offset.value.roundToInt()) }
            .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
            .background(c.surface)
            .draggable(
                state = dragState,
                orientation = Orientation.Vertical,
                onDragStopped = { velocity ->
                    // Projeção de momento: decide pelo ponto de chegada, não pelo ponto de soltura.
                    val projected = offset.value + velocity * 0.2f
                    if (projected > with(density) { 160.dp.toPx() }) {
                        onDismiss()
                    } else {
                        offset.animateTo(0f, sheetSpec, initialVelocity = velocity)
                    }
                },
            )
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(bottom = 12.dp),
    ) {
        Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(width = 36.dp, height = 5.dp).clip(RoundedCornerShape(3.dp)).background(if (c.isDark) c.border else Brand.line))
        }
        content()
    }
}

@Composable
fun SheetAction(title: String, @DrawableRes icon: Int, onClick: () -> Unit, enabled: Boolean = true, danger: Boolean = false, subtitle: String? = null) {
    val c = Cartucho.colors
    val tint = when {
        !enabled -> c.textSecondary
        danger -> c.danger
        else -> c.text
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(0.dp), onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CIcon(icon, tint = tint, size = 22.dp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = Cartucho.type.body, color = tint)
            if (subtitle != null) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary)
        }
    }
}


/**
 * Carregamento por cima de tudo (inclusive da página do jogo): fundo escurecido e um cartão
 * com a rodinha e o que está acontecendo. Bloqueia toques enquanto aparece.
 */
@Composable
fun LoadingOverlay(text: String?, hint: String? = null) {
    val c = Cartucho.colors
    androidx.compose.animation.AnimatedVisibility(
        visible = text != null,
        enter = androidx.compose.animation.fadeIn(app.cartucho.ui.theme.Motion.fade()),
        exit = androidx.compose.animation.fadeOut(app.cartucho.ui.theme.Motion.fade()),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(c.scrim)
                .pointerInput(Unit) { awaitPointerEventScope { while (true) awaitPointerEvent() } },
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .padding(32.dp)
                    .widthIn(max = 340.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(c.surface)
                    .padding(horizontal = 24.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                androidx.compose.material3.CircularProgressIndicator(color = c.accent, strokeWidth = 3.dp, modifier = Modifier.size(36.dp))
                Spacer(Modifier.height(16.dp))
                Text(text ?: "", style = Cartucho.type.headline, color = c.text, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                if (hint != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(hint, style = Cartucho.type.caption, color = c.textSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        }
    }
}
