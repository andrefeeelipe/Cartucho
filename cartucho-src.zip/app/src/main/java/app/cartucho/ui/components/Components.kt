package app.cartucho.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import app.cartucho.R
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.Motion
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Toque com resposta imediata (escala), anel de foco para navegação por controle e sem ripple. */
@Composable
fun Modifier.pressable(
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(12.dp),
    role: Role = Role.Button,
    onClick: () -> Unit,
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val focused by interaction.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = Cartucho.spec(Motion.press()),
        label = "press",
    )
    val accent = Cartucho.colors.accent
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .then(if (focused) Modifier.border(2.dp, accent, shape) else Modifier)
        .clip(shape)
        .clickable(interactionSource = interaction, indication = null, enabled = enabled, role = role, onClick = onClick)
}

@Composable
fun CIcon(@DrawableRes res: Int, tint: Color = Cartucho.colors.text, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    androidx.compose.foundation.Image(
        painter = painterResource(res),
        contentDescription = null,
        colorFilter = ColorFilter.tint(tint),
        modifier = modifier.size(size),
    )
}

@Composable
fun IconButton(@DrawableRes res: Int, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(48.dp)
            .pressable(shape = RoundedCornerShape(24.dp), onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        CIcon(res)
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, @DrawableRes icon: Int? = null, enabled: Boolean = true) {
    val c = Cartucho.colors
    Row(
        modifier = modifier
            .heightIn(min = 52.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(8.dp), onClick = onClick)
            .background(if (enabled) c.text else c.border)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            CIcon(icon, tint = c.background, size = 20.dp)
            Spacer(Modifier.width(10.dp))
        }
        Text(text, style = Cartucho.type.label, color = c.background)
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, @DrawableRes icon: Int? = null, enabled: Boolean = true) {
    val c = Cartucho.colors
    Row(
        modifier = modifier
            .heightIn(min = 52.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(8.dp), onClick = onClick)
            .border(1.dp, c.border, RoundedCornerShape(8.dp))
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            CIcon(icon, tint = c.text, size = 20.dp)
            Spacer(Modifier.width(10.dp))
        }
        Text(text, style = Cartucho.type.label, color = if (enabled) c.text else c.textSecondary)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        style = Cartucho.type.mono,
        color = Cartucho.colors.textSecondary,
        modifier = modifier.padding(start = 4.dp, top = 24.dp, bottom = 8.dp),
    )
}

/** Grupo de linhas com borda de 1px e divisores (estilo lista agrupada). */
@Composable
fun ListGroup(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = Cartucho.colors
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(c.surface)
            .border(1.dp, c.border, RoundedCornerShape(12.dp)),
        content = content,
    )
}

@Composable
fun Divider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp)
            .height(1.dp)
            .background(Cartucho.colors.border)
    )
}

@Composable
fun NavRow(
    title: String,
    onClick: () -> Unit,
    value: String? = null,
    @DrawableRes icon: Int? = null,
    subtitle: String? = null,
    showChevron: Boolean = true,
) {
    val c = Cartucho.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .pressable(shape = RoundedCornerShape(0.dp), onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            CIcon(icon, tint = c.text, size = 20.dp)
            Spacer(Modifier.width(14.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = Cartucho.type.body, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary)
        }
        if (value != null) {
            Text(value, style = Cartucho.type.body, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 180.dp))
            Spacer(Modifier.width(6.dp))
        }
        if (showChevron) CIcon(R.drawable.ic_chevron, tint = c.textSecondary, size = 16.dp)
    }
}

@Composable
fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit, subtitle: String? = null, enabled: Boolean = true) {
    val c = Cartucho.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(0.dp), role = Role.Switch) { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Cartucho.type.body, color = if (enabled) c.text else c.textSecondary)
            if (subtitle != null) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = null,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = c.background,
                checkedTrackColor = c.text,
                checkedBorderColor = c.text,
                uncheckedThumbColor = c.textSecondary,
                uncheckedTrackColor = c.surfaceRaised,
                uncheckedBorderColor = c.border,
            ),
        )
    }
}

@Composable
fun SliderRow(title: String, value: Float, onChange: (Float) -> Unit, valueLabel: String, range: ClosedFloatingPointRange<Float> = 0f..1f, steps: Int = 0) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = Cartucho.type.body, color = c.text, modifier = Modifier.weight(1f))
            Text(valueLabel, style = Cartucho.type.mono, color = c.textSecondary)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = c.text,
                activeTrackColor = c.text,
                inactiveTrackColor = c.surfaceRaised,
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent,
            ),
        )
    }
}

/** Controle segmentado (até 4 opções) — escolhas visíveis de uma vez, sem menus escondidos. */
@Composable
fun SegmentedRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit, subtitle: String? = null) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = Cartucho.type.body, color = c.text)
        if (subtitle != null) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary)
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(c.surfaceRaised)
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            options.forEachIndexed { i, label ->
                val active = i == selected
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 44.dp)
                        .pressable(shape = RoundedCornerShape(8.dp), role = Role.RadioButton) { onSelect(i) }
                        .background(if (active) c.surface else Color.Transparent)
                        .then(if (active) Modifier.border(1.dp, c.border, RoundedCornerShape(8.dp)) else Modifier),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, style = Cartucho.type.label, color = if (active) c.text else c.textSecondary, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun Tag(text: String, background: Color, foreground: Color) {
    Text(
        text = text.uppercase(),
        style = Cartucho.type.mono,
        color = foreground,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(background)
            .padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

/** Barra superior com voltar e título grande, no estilo das telas de ajustes do iOS. */
@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?, subtitle: String? = null) {
    val c = Cartucho.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Box(Modifier.height(56.dp), contentAlignment = Alignment.CenterStart) {
            if (onBack != null) IconButton(R.drawable.ic_back, "Voltar", onBack, Modifier.offset(x = (-12).dp))
        }
        Text(title, style = Cartucho.type.display, color = c.text)
        if (subtitle != null) {
            Spacer(Modifier.height(6.dp))
            Text(subtitle, style = Cartucho.type.body, color = c.textSecondary)
        }
        Spacer(Modifier.height(8.dp))
    }
}

/**
 * Folha inferior com fundo escurecido. Acompanha o dedo 1:1, usa a velocidade da soltura para
 * decidir fechar ou voltar e anima com mola interrompível.
 */
@Composable
fun BottomSheet(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val c = Cartucho.colors
    AnimatedVisibility(visible = visible, enter = fadeIn(Motion.fade()), exit = fadeOut(Motion.fade())) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(c.scrim)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
            )
            SheetPanel(onDismiss, content)
        }
    }
}

@Composable
private fun BoxScope.SheetPanel(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val c = Cartucho.colors
    val density = LocalDensity.current
    val offset = remember { Animatable(with(density) { 400.dp.toPx() }) }
    val scope = rememberCoroutineScope()
    val sheetSpec = Cartucho.spec(Motion.sheet<Float>())
    LaunchedEffect(Unit) { offset.animateTo(0f, sheetSpec) }
    val dragState = rememberDraggableState { delta ->
        scope.launch {
            val next = offset.value + delta
            // Resistência elástica ao puxar para cima além do limite.
            offset.snapTo(if (next < 0f) next * 0.3f else next)
        }
    }
    Column(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .widthIn(max = 640.dp)
            .offset { IntOffset(0, offset.value.roundToInt()) }
            .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
            .background(c.surface)
            .border(1.dp, c.border, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
            .draggable(
                state = dragState,
                orientation = Orientation.Vertical,
                onDragStopped = { velocity ->
                    // Projeção de momento: decide pelo ponto de chegada, não pelo ponto de soltura.
                    val projected = offset.value + velocity * 0.2f
                    if (projected > with(density) { 160.dp.toPx() }) {
                        onDismiss()
                    } else {
                        offset.animateTo(0f, sheetSpec, initialVelocity = velocity)
                    }
                },
            )
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(bottom = 12.dp),
    ) {
        Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(width = 36.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(c.border))
        }
        content()
    }
}

@Composable
fun SheetAction(title: String, @DrawableRes icon: Int, onClick: () -> Unit, enabled: Boolean = true, danger: Boolean = false, subtitle: String? = null) {
    val c = Cartucho.colors
    val tint = when {
        !enabled -> c.textSecondary
        danger -> c.danger
        else -> c.text
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .pressable(enabled = enabled, shape = RoundedCornerShape(0.dp), onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CIcon(icon, tint = tint, size = 22.dp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = Cartucho.type.body, color = tint)
            if (subtitle != null) Text(subtitle, style = Cartucho.type.caption, color = c.textSecondary)
        }
    }
}
