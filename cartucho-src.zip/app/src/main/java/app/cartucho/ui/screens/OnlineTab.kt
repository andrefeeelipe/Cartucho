package app.cartucho.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.data.Game
import app.cartucho.data.Systems
import app.cartucho.net.RoomGuestActivity
import app.cartucho.net.Signaling
import app.cartucho.ui.MainActivity
import app.cartucho.ui.components.BottomSheet
import app.cartucho.ui.components.CIcon
import app.cartucho.ui.components.PrimaryButton
import app.cartucho.ui.components.ScreenHeader
import app.cartucho.ui.components.SearchBox
import app.cartucho.ui.components.SecondaryButton
import app.cartucho.ui.components.Toast
import app.cartucho.ui.components.pressable
import app.cartucho.ui.theme.Brand
import app.cartucho.ui.theme.Cartucho
import app.cartucho.ui.theme.Motion
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Aba Online: criar uma sala com um jogo da biblioteca, ou entrar na sala de um amigo. */
@Composable
fun OnlineScreen(activity: MainActivity) {
    val app = activity.application as CartuchoApp
    val c = Cartucho.colors
    var picked by remember { mutableStateOf<Game?>(null) }
    var picking by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(notice) {
        if (notice != null) {
            delay(3500)
            notice = null
        }
    }

    Box(Modifier.fillMaxSize().background(c.background).windowInsetsPadding(WindowInsets.safeDrawing)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            ScreenHeader("Jogar online", onBack = null, subtitle = "Jogue junto com amigos, no Wi-Fi ou nos dados móveis.")
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                OnlineCard("Criar sala") {
                    Row(
                        Modifier.fillMaxWidth().pressable(shape = RoundedCornerShape(12.dp)) { picking = true }
                            .background(c.surfaceRaised).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        val g = picked
                        val cover by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, g?.id) {
                            value = g?.let { withContext(Dispatchers.IO) { loadCover(app.covers.file(it.id)) } }
                        }
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(c.placeholder)) {
                            cover?.let { androidx.compose.foundation.Image(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Jogo", style = Cartucho.type.caption, color = c.textSecondary)
                            Text(g?.title ?: "Escolher da biblioteca", style = Cartucho.type.headline.copy(fontSize = 16.sp), color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        CIcon(R.drawable.ic_chevron, tint = c.textSecondary, size = 14.dp)
                    }
                    Text(
                        "O jogo abre com a sala pronta. Mande o código ou o QR para quem vai jogar com você.",
                        style = Cartucho.type.caption,
                        color = c.textSecondary,
                    )
                    PrimaryButton("Criar sala", {
                        val g = picked ?: return@PrimaryButton
                        activity.launchGame(g, openRoom = true)?.let { notice = it }
                    }, Modifier.fillMaxWidth(), enabled = picked != null)
                }

                OnlineCard("Entrar numa sala") {
                    CodeBoxes(code) { code = it }
                    val valid = Signaling.codeFromText(code)
                    SecondaryButton("Entrar", {
                        if (valid != null) RoomGuestActivity.open(activity, valid)
                    }, Modifier.fillMaxWidth(), enabled = valid != null)
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 44.dp).pressable(shape = RoundedCornerShape(12.dp)) {
                            runCatching {
                                GmsBarcodeScanning.getClient(
                                    activity,
                                    GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build(),
                                ).startScan()
                                    .addOnSuccessListener { b ->
                                        val found = Signaling.codeFromText(b.rawValue.orEmpty())
                                        if (found != null) RoomGuestActivity.open(activity, found) else notice = "Esse QR não é de uma sala do Cartucho."
                                    }
                                    .addOnFailureListener { notice = "Não foi possível abrir o leitor de QR. Digite o código." }
                            }.onFailure { notice = "Não foi possível abrir o leitor de QR. Digite o código." }
                        },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        CIcon(R.drawable.ic_qr, tint = c.accent, size = 18.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Ler o QR do amigo", style = Cartucho.type.label, color = c.accent)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }

        AnimatedVisibility(
            visible = notice != null,
            enter = fadeIn(Motion.fade()),
            exit = fadeOut(Motion.fade()),
            modifier = Modifier.align(Alignment.BottomCenter).padding(20.dp),
        ) { Toast(notice ?: "") }

        BottomSheet(visible = picking, onDismiss = { picking = false }) {
            GamePicker(app) { g ->
                picked = g
                picking = false
            }
        }
    }
}

@Composable
private fun OnlineCard(title: String, content: @Composable () -> Unit) {
    val c = Cartucho.colors
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surface)
            .border(1.dp, c.border, RoundedCornerShape(16.dp)).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(title, style = Cartucho.type.title, color = c.text)
        content()
    }
}

/** Seis caixas para o código da sala, com um campo só por baixo. */
@Composable
private fun CodeBoxes(value: String, onChange: (String) -> Unit) {
    val c = Cartucho.colors
    Box(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0 until 6) {
                val ch = value.getOrNull(i)?.toString() ?: ""
                Box(
                    Modifier.weight(1f).aspectRatio(0.85f).clip(RoundedCornerShape(12.dp)).background(c.surface)
                        .border(1.dp, if (i == value.length.coerceAtMost(5)) c.accent else Brand.line, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(ch.ifEmpty { "–" }, style = Cartucho.type.title, color = if (ch.isEmpty()) c.textSecondary else c.text)
                }
            }
        }
        // Campo transparente por cima: o teclado e o colar funcionam normalmente.
        BasicTextField(
            value = value,
            onValueChange = { t -> onChange(t.uppercase().filter { it.isLetterOrDigit() }.take(6)) },
            singleLine = true,
            textStyle = TextStyle(color = Color.Transparent, fontSize = 1.sp),
            cursorBrush = SolidColor(Color.Transparent),
            keyboardOptions = KeyboardOptions(autoCorrect = false, keyboardType = KeyboardType.Ascii, capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.matchParentSize(),
        )
    }
}

/** Lista de jogos da biblioteca para escolher (os jogados por último primeiro). */
@Composable
private fun GamePicker(app: CartuchoApp, onPick: (Game) -> Unit) {
    val c = Cartucho.colors
    val all by app.library.games.collectAsState()
    var query by remember { mutableStateOf("") }
    val list = remember(all, query) {
        all.filter { it.pack == 0 && it.systemKnown }
            .filter { query.isBlank() || it.title.contains(query.trim(), ignoreCase = true) }
            .sortedWith(compareByDescending<Game> { it.lastPlayed }.thenBy { it.title.lowercase() })
            .distinctBy { titleKey(it) }
    }
    Column(Modifier.padding(horizontal = 20.dp)) {
        Text("Escolher jogo", style = Cartucho.type.title, color = c.text)
        Spacer(Modifier.height(12.dp))
        SearchBox(query, { query = it }, "Buscar jogo", onClear = { query = "" })
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) {
            Text("Nenhum jogo na biblioteca ainda.", style = Cartucho.type.body, color = c.textSecondary, modifier = Modifier.padding(vertical = 16.dp))
        }
        LazyColumn(Modifier.heightIn(max = 420.dp)) {
            items(list, key = { it.id }) { g ->
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 52.dp).pressable(shape = RoundedCornerShape(12.dp)) { onPick(g) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(g.title, style = Cartucho.type.body, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(Systems.get(g.systemId)?.name ?: "", style = Cartucho.type.caption, color = c.textSecondary)
                    }
                }
            }
        }
    }
}
