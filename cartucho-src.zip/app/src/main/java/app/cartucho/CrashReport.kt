package app.cartucho

import android.app.ActivityManager
import android.app.AlertDialog
import android.app.ApplicationExitInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Quando o app ou o jogo fecha por erro, guarda o que aconteceu (só no celular) e mostra
 * na próxima abertura, para o usuário poder copiar e mandar. Nada é enviado sozinho.
 */
object CrashReport {
    private const val FILE = "ultimo-erro.txt"

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val text = buildString {
                    appendLine("Processo: ${processName()}")
                    appendLine("Thread: ${thread.name}")
                    appendLine("Versão: ${version(app)} · Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER} ${Build.MODEL}")
                    appendLine(android.util.Log.getStackTraceString(error).take(6000))
                }
                File(app.filesDir, FILE).writeText(text)
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Erros novos desde a última vez que mostramos (Java ou nativos, de qualquer processo do app). */
    fun pending(context: Context): String? {
        val prefs = context.getSharedPreferences("cartucho_erros", Context.MODE_PRIVATE)
        val shownUntil = prefs.getLong("ate", 0)
        val parts = ArrayList<String>()
        var newest = shownUntil
        val f = File(context.filesDir, FILE)
        if (f.exists() && f.lastModified() > shownUntil) {
            parts += f.readText()
            newest = maxOf(newest, f.lastModified())
        }
        // Relatório gravado pelo próprio Cartucho quando o núcleo desliga o do Android (Play!, PS2).
        val coreFault = File(File(context.filesDir, "system"), "ultimo-erro-nucleo.txt")
        if (coreFault.exists() && coreFault.lastModified() > shownUntil) {
            parts += coreFault.readText().take(3000)
            newest = maxOf(newest, coreFault.lastModified())
        }
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching {
                val am = context.getSystemService(ActivityManager::class.java)
                for (e in am.getHistoricalProcessExitReasons(context.packageName, 0, 5)) {
                    if (e.timestamp <= shownUntil) continue
                    val native = e.reason == ApplicationExitInfo.REASON_CRASH_NATIVE
                    val silent = silentEnd(e)
                    if (!native && e.reason != ApplicationExitInfo.REASON_ANR && silent == null) continue  // erros Java já estão no arquivo
                    newest = maxOf(newest, e.timestamp)
                    val when_ = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date(e.timestamp))
                    if (silent != null) {
                        parts += "$silent\nProcesso ${e.processName} às $when_ · memória usada: ${e.pss / 1024} MB (${e.description ?: "sem descrição"})"
                        continue
                    }
                    val head = "${if (native) "Erro nativo" else "Travou (ANR)"} em ${e.processName} às $when_ (${e.description ?: "sem descrição"})"
                    val trace = runCatching { e.traceInputStream?.use { it.readBytes() } }.getOrNull()
                    parts += head + "\n" + (trace?.let { summarize(it, native) } ?: "")
                }
            }
        }
        if (parts.isEmpty()) return null
        prefs.edit().putLong("ate", newest).apply()
        return "Cartucho ${version(context)} · Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER} ${Build.MODEL}\n\n" + parts.joinToString("\n\n")
    }

    /**
     * Fins que não deixam relatório de erro: o Android fechou o jogo (falta de memória, uso excessivo) ou o
     * emulador caiu desligando o relatório (o Play!, do PS2, faz isso). Nosso próprio "sair do jogo" é
     * SIGKILL (9) e fica de fora.
     */
    @android.annotation.TargetApi(30)
    private fun silentEnd(e: ApplicationExitInfo): String? = when (e.reason) {
        ApplicationExitInfo.REASON_LOW_MEMORY ->
            "O Android fechou o jogo por falta de memória (o aparelho precisou liberar espaço para outros apps)."
        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE ->
            "O Android fechou o jogo por usar recursos demais do aparelho."
        ApplicationExitInfo.REASON_SIGNALED -> when (e.status) {
            4, 6, 7, 8, 11 -> "O emulador fechou por um erro interno (sinal ${e.status}) sem gerar relatório."
            else -> null
        }
        ApplicationExitInfo.REASON_EXIT_SELF -> if (e.status != 0 && e.processName.endsWith(":game")) "O emulador encerrou sozinho (código ${e.status})." else null
        else -> null
    }

    /**
     * O "tombstone" do Android vem em protobuf (tombstone.proto do debuggerd): extrai o sinal,
     * a mensagem de abort, a pilha da thread que quebrou e as últimas linhas do log do processo.
     */
    private fun summarize(bytes: ByteArray, native: Boolean): String {
        if (!native) return String(bytes).lineSequence().take(60).joinToString("\n")
        return runCatching { Tombstone.parse(bytes) }.getOrNull() ?: "(não foi possível ler o relatório)"
    }

    fun show(activity: android.app.Activity, text: String) {
        AlertDialog.Builder(activity)
            .setTitle("O jogo fechou por um erro")
            .setMessage("Copie os detalhes e mande para quem mantém o app, para corrigir.\n\n" + text.take(4000))
            .setPositiveButton("Copiar detalhes") { _, _ ->
                val cm = activity.getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Erro do Cartucho", text))
            }
            .setNeutralButton("Compartilhar") { _, _ ->
                activity.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Enviar detalhes"))
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun processName(): String = if (Build.VERSION.SDK_INT >= 28) android.app.Application.getProcessName() else ""

    private fun version(context: Context): String =
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
}
