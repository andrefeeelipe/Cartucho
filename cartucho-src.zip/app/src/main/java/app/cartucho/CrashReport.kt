package app.cartucho

import android.app.ActivityManager
import android.app.AlertDialog
import android.app.ApplicationExitInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Quando o app ou o jogo fecha por erro, guarda o que aconteceu (só no celular) e mostra
 * na próxima abertura, para o usuário poder copiar e mandar. Nada é enviado sozinho.
 */
object CrashReport {
    private const val FILE = "ultimo-erro.txt"

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val text = buildString {
                    appendLine("Processo: ${processName()}")
                    appendLine("Thread: ${thread.name}")
                    appendLine("Versão: ${version(app)} · Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER} ${Build.MODEL}")
                    appendLine(android.util.Log.getStackTraceString(error).take(6000))
                }
                File(app.filesDir, FILE).writeText(text)
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Erros novos desde a última vez que mostramos (Java ou nativos, de qualquer processo do app). */
    fun pending(context: Context): String? {
        val prefs = context.getSharedPreferences("cartucho_erros", Context.MODE_PRIVATE)
        val shownUntil = prefs.getLong("ate", 0)
        val parts = ArrayList<String>()
        var newest = shownUntil
        val f = File(context.filesDir, FILE)
        if (f.exists() && f.lastModified() > shownUntil) {
            parts += f.readText()
            newest = maxOf(newest, f.lastModified())
        }
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching {
                val am = context.getSystemService(ActivityManager::class.java)
                for (e in am.getHistoricalProcessExitReasons(context.packageName, 0, 5)) {
                    if (e.timestamp <= shownUntil) continue
                    val native = e.reason == ApplicationExitInfo.REASON_CRASH_NATIVE
                    if (!native && e.reason != ApplicationExitInfo.REASON_ANR) continue  // erros Java já estão no arquivo
                    newest = maxOf(newest, e.timestamp)
                    val when_ = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date(e.timestamp))
                    val head = "${if (native) "Erro nativo" else "Travou (ANR)"} em ${e.processName} às $when_ (${e.description ?: "sem descrição"})"
                    val trace = runCatching { e.traceInputStream?.use { it.readBytes() } }.getOrNull()
                    parts += head + "\n" + (trace?.let { summarize(it, native) } ?: "")
                }
            }
        }
        if (parts.isEmpty()) return null
        prefs.edit().putLong("ate", newest).apply()
        return "Cartucho ${version(context)} · Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER} ${Build.MODEL}\n\n" + parts.joinToString("\n\n")
    }

    /** O "tombstone" do Android vem em binário: tira só os trechos legíveis (bibliotecas e funções). */
    private fun summarize(bytes: ByteArray, native: Boolean): String {
        if (!native) return String(bytes).lineSequence().take(60).joinToString("\n")
        val out = ArrayList<String>()
        val sb = StringBuilder()
        fun flush() {
            val t = sb.toString()
            if (t.length >= 5 && (t.contains(".so") || t.contains("::") || t.contains("Java_") || t.contains("Abort") ||
                    t.contains("signal") || t.contains("SIG") || t.contains("assert", true) || t.contains("Check failed") || t.contains("Fatal"))
            ) if (out.size < 80 && t !in out) out += t.take(240)
            sb.clear()
        }
        for (b in bytes) {
            val ch = b.toInt() and 0xff
            if (ch in 0x20..0x7e) sb.append(ch.toChar()) else flush()
        }
        flush()
        return out.joinToString("\n")
    }

    fun show(activity: android.app.Activity, text: String) {
        AlertDialog.Builder(activity)
            .setTitle("O jogo fechou por um erro")
            .setMessage("Copie os detalhes e mande para quem mantém o app, para corrigir.\n\n" + text.take(1500))
            .setPositiveButton("Copiar detalhes") { _, _ ->
                val cm = activity.getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Erro do Cartucho", text))
            }
            .setNeutralButton("Compartilhar") { _, _ ->
                activity.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Enviar detalhes"))
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun processName(): String = if (Build.VERSION.SDK_INT >= 28) android.app.Application.getProcessName() else ""

    private fun version(context: Context): String =
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
}
