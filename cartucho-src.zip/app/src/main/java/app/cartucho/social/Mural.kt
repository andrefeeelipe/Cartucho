package app.cartucho.social

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.achievements.RaGame
import app.cartucho.achievements.RaWeb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Um momento de alguém: jogando agora, zerou ou platinou um jogo (dados do RetroAchievements). */
data class Post(val id: String, val user: String, val avatar: String, val kind: String, val game: RaGame, val detail: String) {
    val verb: String
        get() = when (kind) {
            "jogando" -> "está jogando"
            "platinou" -> "platinou"
            "completou" -> "completou"
            else -> "zerou"
        }
}

/** Reação (emoji) ou comentário de alguém num momento. */
data class Interaction(
    val id: String,
    val post: String,
    val owner: String,
    val from: String,
    val type: String, // "r" reação · "c" comentário
    val value: String,
    val gameTitle: String,
    val at: Long,
)

/**
 * Mural dos amigos: os momentos vêm do RetroAchievements (quem você segue lá) e as curtidas,
 * reações e comentários viajam por tópicos públicos do ntfy.sh, um por pessoa.
 * Tudo que o app recebe fica guardado no celular; o ntfy guarda as mensagens por 12 horas,
 * então quem passa mais de 12 horas sem abrir o app pode perder alguma.
 */
class Mural(private val context: Context) {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val file = File(context.filesDir, "mural.json")
    private val prefs = context.getSharedPreferences("cartucho_mural", Context.MODE_PRIVATE)
    private val all = LinkedHashMap<String, Interaction>()
    private val _version = MutableStateFlow(0)
    /** Muda sempre que chega ou sai uma interação (para a tela se atualizar). */
    val version: StateFlow<Int> = _version

    init {
        load()
    }

    // ------------------------------------------------------------- feed

    /** Momentos seus e de quem você segue no RA, do mais recente para o mais antigo. */
    suspend fun feed(web: RaWeb, me: String, friends: List<String>): List<Post> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val posts = ArrayList<Post>()
        for (user in (listOf(me) + friends).distinctBy { it.lowercase() }.take(16)) {
            val activity = runCatching { web.recent(user) }.getOrNull()
            val avatar = activity?.avatarUrl.orEmpty()
            activity?.recent?.firstOrNull()?.takeIf { now - it.at < 30L * DAY }?.let { g ->
                posts += Post(postId(user, "jogando", g.id), activity.user, avatar, "jogando", g, activity.richPresence)
            }
            runCatching { web.completions(user) }.getOrNull()
                ?.filter { now - it.game.at < 180L * DAY }
                ?.take(3)
                ?.forEach { c -> posts += Post(postId(user, c.kind, c.game.id), activity?.user ?: user, avatar, c.kind, c.game, "") }
        }
        posts.sortedByDescending { it.game.at }
    }

    // ------------------------------------------------------- interações

    fun reactions(post: String): Map<String, List<String>> {
        // A última reação de cada pessoa vale (valor vazio = tirou a reação).
        val latest = HashMap<String, Interaction>()
        synchronized(all) {
            for (i in all.values) if (i.post == post && i.type == "r") {
                val k = i.from.lowercase()
                if ((latest[k]?.at ?: 0) <= i.at) latest[k] = i
            }
        }
        return latest.values.filter { it.value.isNotEmpty() }.groupBy({ it.value }, { it.from })
    }

    fun myReaction(post: String, me: String): String =
        synchronized(all) { all.values.filter { it.post == post && it.type == "r" && it.from.equals(me, true) }.maxByOrNull { it.at }?.value.orEmpty() }

    fun comments(post: String): List<Interaction> =
        synchronized(all) { all.values.filter { it.post == post && it.type == "c" }.sortedBy { it.at } }

    /** O que os outros fizeram nos seus momentos, do mais novo para o mais antigo. */
    fun news(me: String): List<Interaction> = synchronized(all) {
        all.values.filter { it.owner.equals(me, true) && !it.from.equals(me, true) && !(it.type == "r" && it.value.isEmpty()) }
            .sortedByDescending { it.at }
    }

    suspend fun react(post: Post, me: String, emoji: String) = send(post, me, "r", emoji)

    suspend fun comment(post: Post, me: String, text: String) {
        val t = text.trim().take(280)
        if (t.isNotEmpty()) send(post, me, "c", t)
    }

    private suspend fun send(post: Post, me: String, type: String, value: String) {
        val i = Interaction(UUID.randomUUID().toString(), post.id, post.user, me, type, value, post.game.title, System.currentTimeMillis())
        merge(listOf(i))
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put("v", 1).put("id", i.id).put("p", i.post).put("o", i.owner).put("u", i.from)
                .put("t", i.type).put("x", i.value).put("g", i.gameTitle).put("ts", i.at)
            val req = Request.Builder().url("$BASE/${topic(post.user)}")
                .post(body.toString().toRequestBody("text/plain; charset=utf-8".toMediaType()))
                .build()
            runCatching { http.newCall(req).execute().close() }
        }
    }

    /** Busca o que chegou (até 12 horas atrás) para essas pessoas. Devolve as interações novas. */
    suspend fun sync(users: Collection<String>): List<Interaction> = withContext(Dispatchers.IO) {
        val fresh = ArrayList<Interaction>()
        for (user in users.distinctBy { it.lowercase() }) {
            val req = Request.Builder().url("$BASE/${topic(user)}/json?poll=1&since=12h").build()
            val text = runCatching { http.newCall(req).execute().use { if (it.isSuccessful) it.body?.string() else null } }.getOrNull() ?: continue
            for (line in text.lineSequence()) {
                val o = runCatching { JSONObject(line) }.getOrNull() ?: continue
                if (o.optString("event") != "message") continue
                val m = runCatching { JSONObject(o.optString("message")) }.getOrNull() ?: continue
                val i = parse(m) ?: continue
                if (!i.owner.equals(user, true)) continue  // só vale o que foi mandado para o dono do momento
                fresh += i
            }
        }
        merge(fresh)
    }

    private fun parse(m: JSONObject): Interaction? {
        if (m.optInt("v") != 1) return null
        val id = m.optString("id").take(64)
        val post = m.optString("p").take(160)
        val from = m.optString("u").take(40)
        val type = m.optString("t")
        if (id.isEmpty() || post.isEmpty() || from.isEmpty() || (type != "r" && type != "c")) return null
        val value = m.optString("x").let { if (type == "r") (if (it.isEmpty() || it in EMOJIS) it else return null) else it.take(280) }
        return Interaction(id, post, m.optString("o").take(40), from, type, value, m.optString("g").take(120), m.optLong("ts"))
    }

    private fun merge(list: List<Interaction>): List<Interaction> {
        val added = ArrayList<Interaction>()
        synchronized(all) {
            for (i in list) if (all.put(i.id, i) == null) added += i
        }
        if (added.isNotEmpty()) {
            save()
            _version.value++
        }
        return added
    }

    private fun load() {
        val arr = runCatching { JSONArray(file.readText()) }.getOrNull() ?: return
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            val i = Interaction(o.optString("id"), o.optString("p"), o.optString("o"), o.optString("u"), o.optString("t"), o.optString("x"), o.optString("g"), o.optLong("ts"))
            all[i.id] = i
        }
    }

    private fun save() {
        val arr = JSONArray()
        synchronized(all) {
            // Guarda as 3.000 mais recentes.
            all.values.sortedByDescending { it.at }.take(3000).forEach { i ->
                arr.put(JSONObject().put("id", i.id).put("p", i.post).put("o", i.owner).put("u", i.from).put("t", i.type).put("x", i.value).put("g", i.gameTitle).put("ts", i.at))
            }
        }
        runCatching {
            val tmp = File(file.path + ".tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(file)
        }
    }

    // ----------------------------------------------------------- avisos

    var notifiedUntil: Long
        get() = prefs.getLong("notified", 0)
        set(v) = prefs.edit().putLong("notified", v).apply()

    fun notifyNews(me: String) {
        val since = notifiedUntil
        val list = news(me).filter { it.at > since }
        if (list.isEmpty()) return
        notifiedUntil = list.maxOf { it.at }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Amigos", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Curtidas, reações e comentários dos amigos"
            })
        }
        val open = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?.putExtra("abrir", "mural")
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = open?.let { PendingIntent.getActivity(context, 7, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
        val first = list.first()
        val title = if (list.size == 1) describe(first) else "${list.size} novidades dos amigos"
        val text = if (list.size == 1) (if (first.type == "c") first.value else first.gameTitle) else list.take(3).joinToString(" · ") { describe(it) }
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_users)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(list.take(6).joinToString("\n") { describe(it) + if (it.type == "c") ": ${it.value}" else "" }))
            .setAutoCancel(true)
            .apply { if (pi != null) setContentIntent(pi) }
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(4242, n) }
    }

    companion object {
        private const val BASE = "https://ntfy.sh"
        private const val CHANNEL = "amigos"
        private const val DAY = 24L * 3600 * 1000
        val EMOJIS = listOf("❤️", "🔥", "👏", "😂", "😮", "🏆")

        fun postId(user: String, kind: String, gameId: Int) = "${user.lowercase()}|$kind|$gameId"

        fun topic(user: String): String {
            val h = MessageDigest.getInstance("SHA-256").digest(("cartucho-mural:" + user.lowercase()).toByteArray())
            return "cartucho-mural-" + h.take(10).joinToString("") { "%02x".format(it) }
        }

        fun describe(i: Interaction): String = when (i.type) {
            "c" -> "${i.from} comentou no seu ${i.gameTitle}"
            else -> "${i.from} reagiu ${i.value} ao seu ${i.gameTitle}"
        }

        /** Confere de tempos em tempos (mínimo do Android: 15 min) se alguém interagiu, para avisar. */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<MuralWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(context.applicationContext)
                .enqueueUniquePeriodicWork("cartucho-mural", ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}

class MuralWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as CartuchoApp
        val me = app.prefs.current.raUser
        if (me.isEmpty()) return Result.success()
        runCatching {
            app.mural.sync(listOf(me))
            app.mural.notifyNews(me)
        }
        return Result.success()
    }
}
