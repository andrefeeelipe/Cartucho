package app.cartucho.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

data class Game(
    val id: String,
    val title: String,
    val fileName: String,
    val uri: String,
    val systemId: String,
    val size: Long,
    val addedAt: Long,
    val lastPlayed: Long = 0L,
    val treeUri: String? = null,
    val parentDocId: String? = null,
    /** Nomes das pastas até o arquivo (separados por "/"), usados como dica de sistema. */
    val folderPath: String = "",
    /** Patch ativo (nome do arquivo em patches/<id>/) ou vazio para o jogo original. */
    val patch: String = "",
    /** Nome oficial reconhecido pelo conteúdo do arquivo (No-Intro/Redump); "-" = não reconhecido. */
    val canonical: String = "",
    /** Jogo dividido em partes (.001/.002, .wbf1, volumes de RAR…): quantas. 1 = arquivo único. */
    val parts: Int = 1,
    /** Impressão digital do conteúdo ("crc:…" ou "s:<código do disco>"): cópias iguais viram um cartão só. */
    val fingerprint: String = "",
) {
    val folders: List<String> get() = if (folderPath.isEmpty()) emptyList() else folderPath.split('/')
    val systemKnown: Boolean get() = systemId.isNotEmpty()
}

data class LibraryFolder(val treeUri: String, val name: String)

class GameLibrary(context: Context) {
    private val file = File(context.filesDir, "library.json")
    private val _games = MutableStateFlow<List<Game>>(emptyList())
    private val _folders = MutableStateFlow<List<LibraryFolder>>(emptyList())
    val games: StateFlow<List<Game>> = _games.asStateFlow()
    val folders: StateFlow<List<LibraryFolder>> = _folders.asStateFlow()

    init {
        load()
    }

    fun find(id: String): Game? = _games.value.firstOrNull { it.id == id }

    @Synchronized
    fun upsert(game: Game) {
        val list = _games.value.toMutableList()
        val idx = list.indexOfFirst { it.id == game.id }
        if (idx >= 0) {
            val old = list[idx]
            list[idx] = game.copy(
                addedAt = old.addedAt, lastPlayed = old.lastPlayed, patch = old.patch,
                canonical = old.canonical.ifEmpty { game.canonical }, fingerprint = old.fingerprint.ifEmpty { game.fingerprint },
                title = if (old.canonical.length > 1 && game.canonical.isEmpty()) old.title else game.title,
            )
        } else {
            list.add(game)
        }
        _games.value = list
        save()
    }

    @Synchronized
    fun upsertAll(newGames: List<Game>) {
        val map = LinkedHashMap<String, Game>()
        _games.value.forEach { map[it.id] = it }
        newGames.forEach { g ->
            val old = map[g.id]
            map[g.id] = if (old != null) g.copy(
                addedAt = old.addedAt, lastPlayed = old.lastPlayed, systemId = old.systemId.ifEmpty { g.systemId }, patch = old.patch,
                canonical = old.canonical, fingerprint = old.fingerprint, title = if (old.canonical.length > 1) old.title else g.title,
            ) else g
        }
        _games.value = map.values.toList()
        save()
    }

    @Synchronized
    fun remove(id: String) {
        _games.value = _games.value.filterNot { it.id == id }
        save()
    }

    @Synchronized
    fun markPlayed(id: String) {
        _games.value = _games.value.map { if (it.id == id) it.copy(lastPlayed = System.currentTimeMillis()) else it }
        save()
    }

    @Synchronized
    fun setSystem(id: String, systemId: String) {
        _games.value = _games.value.map { if (it.id == id) it.copy(systemId = systemId) else it }
        save()
    }

    /** Grava o nome oficial reconhecido (e o título limpo e, se faltava, o sistema). */
    @Synchronized
    fun setIdentity(id: String, canonical: String, title: String?, systemId: String?, fingerprint: String? = null) {
        _games.value = _games.value.map {
            if (it.id == id) it.copy(
                canonical = canonical, title = title ?: it.title, systemId = it.systemId.ifEmpty { systemId.orEmpty() },
                fingerprint = fingerprint ?: it.fingerprint,
            ) else it
        }
        save()
    }

    @Synchronized
    fun setPatch(id: String, patch: String) {
        _games.value = _games.value.map { if (it.id == id) it.copy(patch = patch) else it }
        save()
    }

    /** Relê do disco (o processo do jogo pode ter alterado). */
    @Synchronized
    fun reload() {
        load()
    }

    @Synchronized
    fun addFolder(folder: LibraryFolder) {
        if (_folders.value.none { it.treeUri == folder.treeUri }) {
            _folders.value = _folders.value + folder
            save()
        }
    }

    @Synchronized
    fun removeFolder(treeUri: String) {
        _folders.value = _folders.value.filterNot { it.treeUri == treeUri }
        _games.value = _games.value.filterNot { it.treeUri == treeUri }
        save()
    }

    private fun load() {
        if (!file.exists()) return
        runCatching {
            val root = JSONObject(file.readText())
            val arr = root.optJSONArray("games") ?: JSONArray()
            val list = ArrayList<Game>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Game(
                        id = o.getString("id"),
                        title = o.getString("title"),
                        fileName = o.getString("fileName"),
                        uri = o.getString("uri"),
                        systemId = o.getString("systemId"),
                        size = o.optLong("size"),
                        addedAt = o.optLong("addedAt"),
                        lastPlayed = o.optLong("lastPlayed"),
                        treeUri = o.optString("treeUri").ifEmpty { null },
                        parentDocId = o.optString("parentDocId").ifEmpty { null },
                        folderPath = o.optString("folderPath"),
                        patch = o.optString("patch"),
                        canonical = o.optString("canonical"),
                        parts = o.optInt("parts", 1),
                        fingerprint = o.optString("fingerprint"),
                    )
                )
            }
            _games.value = list
            val fArr = root.optJSONArray("folders") ?: JSONArray()
            _folders.value = (0 until fArr.length()).map {
                val o = fArr.getJSONObject(it)
                LibraryFolder(o.getString("treeUri"), o.optString("name"))
            }
        }
    }

    private fun save() {
        val arr = JSONArray()
        _games.value.forEach { g ->
            arr.put(
                JSONObject()
                    .put("id", g.id).put("title", g.title).put("fileName", g.fileName).put("uri", g.uri)
                    .put("systemId", g.systemId).put("size", g.size).put("addedAt", g.addedAt)
                    .put("lastPlayed", g.lastPlayed).put("treeUri", g.treeUri ?: "")
                    .put("parentDocId", g.parentDocId ?: "")
                    .put("folderPath", g.folderPath)
                    .put("patch", g.patch)
                    .put("canonical", g.canonical)
                    .put("parts", g.parts)
                    .put("fingerprint", g.fingerprint)
            )
        }
        val fArr = JSONArray()
        _folders.value.forEach { fArr.put(JSONObject().put("treeUri", it.treeUri).put("name", it.name)) }
        val root = JSONObject().put("games", arr).put("folders", fArr)
        val tmp = File(file.parentFile, "library.json.tmp")
        tmp.writeText(root.toString())
        tmp.renameTo(file)
    }

    companion object {
        fun idFor(uri: String): String {
            val md = MessageDigest.getInstance("SHA-1").digest(uri.toByteArray())
            return md.joinToString("") { "%02x".format(it) }.take(16)
        }

        private val tagRegex = Regex("""\s*[\(\[][^\)\]]*[\)\]]""")

        fun titleFromFileName(name: String): String {
            val base = name.substringBeforeLast('.')
            val clean = base.replace(tagRegex, "").replace('_', ' ').trim()
            return clean.ifEmpty { base.ifEmpty { name } }
        }
    }
}
