package app.cartucho.data

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File

enum class Tier { LOW, MID, HIGH }

enum class Rating(val label: String) {
    GOOD("Roda bem"),
    MAY_STUTTER("Pode engasgar"),
    UNSUPPORTED("Não suportado neste aparelho"),
}

data class SystemRating(val rating: Rating, val reason: String? = null)

/** Perfil do aparelho, calculado uma vez, para avaliar cada sistema com honestidade. */
class DeviceProfile(private val context: Context) {
    val abis: List<String> = Build.SUPPORTED_ABIS.toList()
    val primaryAbi: String = abis.firstOrNull() ?: "desconhecido"
    val is64Bit: Boolean = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
    val cpuCores: Int = Runtime.getRuntime().availableProcessors()

    val ramGb: Double = run {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        info.totalMem / (1024.0 * 1024.0 * 1024.0)
    }

    val glesMajor: Int = run {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val version = am.deviceConfigurationInfo.reqGlEsVersion
        version shr 16
    }

    /** Vulkan 1.1 ou mais (Cemu e Xenia exigem). */
    val hasVulkan11: Boolean = runCatching {
        context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_VULKAN_HARDWARE_VERSION, 0x401000)
    }.getOrDefault(false)

    val tier: Tier = when {
        is64Bit && ramGb >= 5.5 && cpuCores >= 8 -> Tier.HIGH
        is64Bit && ramGb >= 2.8 -> Tier.MID
        else -> Tier.LOW
    }

    private val nativeDir: String = context.applicationInfo.nativeLibraryDir

    fun corePath(coreId: String): String = File(nativeDir, "libcore_$coreId.so").absolutePath

    fun coreAvailable(coreId: String): Boolean = File(corePath(coreId)).exists()

    fun rate(system: GameSystem): SystemRating {
        if (!coreAvailable(system.coreId)) {
            return SystemRating(Rating.UNSUPPORTED, "O emulador deste sistema não existe para a arquitetura $primaryAbi.")
        }
        if (system.needsVulkan && !hasVulkan11) {
            return SystemRating(Rating.UNSUPPORTED, "Exige Vulkan 1.1, que este aparelho não tem.")
        }
        if (system.needsGles3 && glesMajor < 3) {
            return SystemRating(Rating.UNSUPPORTED, "Exige OpenGL ES 3, e este aparelho tem a versão $glesMajor.")
        }
        return when (system.weight) {
            Weight.LIGHT -> SystemRating(Rating.GOOD)
            Weight.MEDIUM -> if (tier == Tier.LOW) SystemRating(Rating.MAY_STUTTER, "Aparelho de entrada: alguns jogos podem ficar lentos.") else SystemRating(Rating.GOOD)
            Weight.HEAVY -> when (tier) {
                Tier.HIGH -> SystemRating(Rating.GOOD)
                Tier.MID -> SystemRating(Rating.MAY_STUTTER, "Sistema pesado para este aparelho.")
                Tier.LOW -> SystemRating(Rating.MAY_STUTTER, "Sistema pesado; espere lentidão.")
            }
            Weight.VERY_HEAVY -> when (tier) {
                Tier.LOW -> SystemRating(Rating.UNSUPPORTED, "${system.short} exige um aparelho 64-bit com bastante memória.")
                else -> SystemRating(
                    Rating.MAY_STUTTER,
                    if (system.beta) "${system.name} ainda está em teste (beta): muitos jogos podem não abrir ou ficar lentos."
                    else "A emulação de ${system.short} no Android ainda é exigente; nem todo jogo roda bem.",
                )
            }
        }
    }

    /** Presets automáticos por tier: (multiplicador de resolução sugerido, frameskip). */
    fun suggestedResolution(): Int = when (tier) {
        Tier.HIGH -> 2
        else -> 1
    }
}
