package app.cartucho.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Uma tradução PT-BR do catálogo (dados do PO.B.R.E — romhackers.org). */
data class Translation(
    val systemId: String,
    val gameTitle: String,
    val name: String,
    val team: String,
    val author: String,
    val type: String,
    val url: String,
    val version: String,
    val progress: String,
    val released: String,
    val crcs: List<String>,
) {
    /** Quem fez, para mostrar e dar o crédito. */
    val credit: String
        get() = listOf(team, author).filter { it.isNotBlank() && !it.equals("Nenhum", true) }.distinct().joinToString(" · ").ifEmpty { "Comunidade BR" }
}

/**
 * Catálogo de traduções PT-BR da comunidade brasileira, publicado na página do Cartucho
 * (gerado a partir do banco de dados aberto do PO.B.R.E). O app só aponta para o arquivo
 * original de cada equipe; nada é hospedado aqui. Atualiza sozinho a cada 3 dias.
 */
class Translations(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cache = File(context.filesDir, "traducoes.json")
    private val asked = context.getSharedPreferences("cartucho_traducoes", Context.MODE_PRIVATE)
    @Volatile private var all: List<Translation> = emptyList()

    fun load() {
        scope.launch {
            if (cache.exists()) all = parse(cache.readText())
            val stale = !cache.exists() || System.currentTimeMillis() - cache.lastModified() > 3L * 24 * 3600 * 1000
            if (stale) {
                val text = runCatching {
                    val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
                    http.newCall(Request.Builder().url(URL).build()).execute().use { if (it.isSuccessful) it.body?.string() else null }
                }.getOrNull()
                if (text != null && text.contains("\"traducoes\"")) {
                    cache.writeText(text)
                    all = parse(text)
                }
            }
        }
    }

    /** Traduções do mesmo jogo (mesmo sistema, título equivalente), da mais completa para a menos. */
    fun find(game: Game): List<Translation> {
        if (all.isEmpty()) return emptyList()
        val title = game.title.ifEmpty { game.fileName.substringBeforeLast('.') }
        val key = Covers.tokens(title).joinToString("")
        return all.filter { t ->
            (!game.systemKnown || t.systemId == game.systemId || sameFamily(t.systemId, game.systemId)) &&
                (Covers.tokens(t.gameTitle).joinToString("") == key || Covers.similarity(title, t.gameTitle) >= 0.85)
        }.sortedWith(compareByDescending<Translation> { it.progress.contains("100") || it.progress.contains("Complet", true) }.thenByDescending { it.released.takeLast(4) })
    }

    /** Já perguntamos sobre a tradução deste jogo? */
    fun wasOffered(gameId: String): Boolean = asked.getBoolean(gameId, false)
    fun markOffered(gameId: String) = asked.edit().putBoolean(gameId, true).apply()

    private fun sameFamily(a: String, b: String) = setOf(a, b) == setOf("gb", "gbc")

    private fun parse(text: String): List<Translation> = runCatching {
        val arr = JSONObject(text).getJSONArray("traducoes")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val crcs = o.optJSONArray("c")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
            Translation(
                o.optString("s"), o.optString("g"), o.optString("n"), o.optString("t"), o.optString("a"),
                o.optString("y"), o.optString("u"), o.optString("v"), o.optString("p"), o.optString("d"), crcs,
            )
        }
    }.getOrDefault(emptyList())

    companion object {
        const val URL = "https://andrefeeelipe.github.io/Cartucho/traducoes.json"
    }
}
