package app.cartucho.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Guarda apenas o token do RetroAchievements, cifrado com uma chave do Android Keystore.
 * A senha do usuário nunca é armazenada.
 */
class SecureStore(context: Context) {
    private val prefs: SharedPreferences? = runCatching {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context,
            "ra_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }.getOrNull()

    var raToken: String
        get() = prefs?.getString("token", "") ?: ""
        set(value) {
            prefs?.edit()?.putString("token", value)?.apply()
        }

    fun clear() {
        prefs?.edit()?.clear()?.apply()
    }
}
