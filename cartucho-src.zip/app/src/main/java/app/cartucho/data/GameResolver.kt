package app.cartucho.data

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import java.io.File

/**
 * Descobre o sistema de um jogo e o transforma em um caminho que o emulador consegue abrir.
 *
 * - Arquivo local comum: link simbólico para /proc/self/fd/N (sem cópia).
 * - Arquivo em nuvem (Google Drive etc.), que o Android entrega como fluxo e não como arquivo:
 *   é copiado para o cache do app.
 * - Compactados (zip, 7z, rar, tar, gz...): copiados e extraídos para o cache; o arcade usa o .zip direto.
 * O cache guarda os jogos mais recentes para o segundo acesso ser imediato.
 */
class GameResolver(private val context: Context, private val detector: GameDetector) {
    private val importDir = File(context.cacheDir, "import")
    private val extractDir = File(context.cacheDir, "extracted")
    private val gamesDir = File(context.cacheDir, "games")
    private val scanner = GameScanner(context, detector)

    class Prepared(val path: String, private val descriptors: List<ParcelFileDescriptor>) {
        fun close() = descriptors.forEach { runCatching { it.close() } }
    }

    // ---------------------------------------------------------------- detecção

    fun detect(game: Game): Detection {
        if (Archives.isArchive(game.fileName)) return detectArchive(game)
        val uri = Uri.parse(game.uri)
        val tree = game.treeUri?.let { Uri.parse(it) }
        return detector.detect(uri, game.fileName, game.size, game.folders) { sibling ->
            if (tree != null && game.parentDocId != null) scanner.openSibling(tree, game.parentDocId, sibling) else null
        }
    }

    private fun detectArchive(game: Game): Detection {
        val local = try {
            localCopy(game)
        } catch (e: Exception) {
            return Detection(null, emptyList(), e.message ?: "Não foi possível ler o arquivo.")
        }
        val names = try {
            Archives.list(local)
        } catch (e: ArchiveException) {
            return Detection(null, emptyList(), e.message)
        }
        val arcade = Systems.get("arcade")!!
        // Partes dentro do compactado (jogo.iso.001, .002…) contam como o arquivo inteiro.
        val splitGroups = SplitParts.groups(names.map { it.substringAfterLast('/') }).filter { it.scheme != SplitParts.Scheme.RAR }
        val inParts = splitGroups.flatMap { it.parts }.toSet()
        val logicalNames = names.filter { it.substringAfterLast('/') !in inParts } + splitGroups.map { it.joinedName }
        val main = Archives.pickMain(logicalNames)
        val ext = main?.let { Archives.extensionOf(it) }.orEmpty()
        val candidates = Systems.candidatesForExtension(ext).filter { it.id != "arcade" }
        if (candidates.isEmpty()) {
            // Sem ROM de console reconhecível: um .zip é tratado como jogo de arcade.
            return if (Archives.extensionOf(game.fileName) == "zip") {
                // Pasta "Naomi"/"Atomiswave": o mesmo .zip vai para o Flycast.
                val hinted = Systems.hintFromFolders(game.folders)?.takeIf { it.id in Systems.ARCADE_LIKE }
                if (hinted != null) Detection(hinted, listOf(hinted, arcade).distinct()) else Detection(arcade, listOf(arcade))
            } else {
                Detection(null, emptyList(), "Não encontrei um jogo reconhecível dentro de ${game.fileName}.")
            }
        }
        if (candidates.size == 1) return Detection(candidates.first(), candidates)
        val hint = Systems.hintFromFolders(game.folders)?.takeIf { h -> candidates.any { it.id == h.id } }
        if (hint != null) return Detection(hint, listOf(hint) + candidates.filter { it.id != hint.id })
        // Ambíguo (.bin, .iso, .chd...): extrai e olha o cabeçalho.
        return try {
            val file = extracted(game, candidates.first())
            detector.detectFile(file, game.folders)
        } catch (e: Exception) {
            Detection(null, candidates, null)
        }
    }

    // ---------------------------------------------------------------- preparação

    /**
     * Deixa o jogo pronto para o emulador e devolve o caminho. Sempre trabalha com uma cópia real
     * no cache do app: o Android não permite reabrir arquivos de outras pastas por caminho
     * ("Permission denied"), e arquivos da nuvem nem são arquivos. A cópia fica guardada, então
     * da segunda vez em diante o jogo abre na hora.
     */
    fun prepare(game: Game, system: GameSystem, onProgress: (String) -> Unit = {}): Prepared {
        val fds = ArrayList<ParcelFileDescriptor>()
        // Arquivo já dentro do app (Loja, jogos inclusos): usa direto, sem copiar.
        val own = Uri.parse(game.uri).takeIf { it.scheme == "file" }?.path?.let { File(it) }?.takeIf { it.exists() && it.path.startsWith(context.filesDir.path) }
        val base: File = if (own != null && !Archives.isArchive(game.fileName)) {
            own
        } else if (Archives.isArchive(game.fileName) && system.id !in Systems.ARCADE_LIKE) {
            onProgress("Extraindo…")
            extracted(game, system)
        } else {
            cachedCopy(game, system, onProgress)
        }
        val patched = Patches.applyIfNeeded(context, game, system, base, onProgress)
        return Prepared(patched.absolutePath, fds)
    }

    private fun cachedCopy(game: Game, system: GameSystem, onProgress: (String) -> Unit): File {
        val dir = File(gamesDir, game.id)
        val marker = File(dir, ".ok")
        val main = File(dir, game.fileName)
        if (marker.exists() && main.exists()) {
            dir.setLastModified(System.currentTimeMillis())
            return main
        }
        dir.deleteRecursively()
        dir.mkdirs()
        val ext = Archives.extensionOf(game.fileName)
        materialize(game, main, onProgress)

        val tree = game.treeUri?.let { Uri.parse(it) }
        val parent = game.parentDocId
        val needsSiblings = system.id in Systems.ARCADE_LIKE || system.id in FOLDER_GAMES || ext in setOf("cue", "gdi", "m3u", "ccd", "toc")
        if (tree != null && parent != null && needsSiblings) {
            val siblings = scanner.listChildren(tree, parent).filter { !it.isDir }
            val wanted = HashSet<String>()
            if (system.id == "arcade") wanted.add("neogeo.zip")
            if (system.id == "naomi") wanted.addAll(listOf("naomi.zip", "awbios.zip"))
            // Jogos de PC em pasta (Doom, RPG Maker, ScummVM…): copia os arquivos soltos ao lado.
            if (system.id in FOLDER_GAMES) siblings.filter { it.size < 512L * 1024 * 1024 }.forEach { wanted.add(it.name.lowercase()) }
            wanted.addAll(referencedFiles(main).map { it.lowercase() })
            if (ext == "m3u") {
                for (name in wanted.toList()) {
                    val entry = siblings.firstOrNull { it.name.equals(name, true) } ?: continue
                    val f = File(dir, entry.name)
                    copyUri(DocumentsContract.buildDocumentUriUsingTree(tree, entry.docId), f, entry.size, entry.name, onProgress)
                    wanted.addAll(referencedFiles(f).map { it.lowercase() })
                }
            }
            if (ext == "ccd") {
                val stem = game.fileName.substringBeforeLast('.').lowercase()
                wanted.addAll(listOf("$stem.img", "$stem.sub"))
            }
            for (entry in siblings) {
                if (entry.name.lowercase() !in wanted) continue
                val target = File(dir, entry.name)
                if (!target.exists()) {
                    copyUri(DocumentsContract.buildDocumentUriUsingTree(tree, entry.docId), target, entry.size, entry.name, onProgress)
                }
            }
        }
        marker.writeText("ok")
        trimBySize(gamesDir, 6L * 1024 * 1024 * 1024)
        return main
    }

    /** Arquivos citados por .cue / .gdi / .m3u. */
    private fun referencedFiles(sheet: File): List<String> {
        val text = runCatching { sheet.readText(Charsets.ISO_8859_1) }.getOrDefault("")
        return when (Archives.extensionOf(sheet.name)) {
            "cue" -> Regex("""FILE\s+"([^"]+)"""", RegexOption.IGNORE_CASE).findAll(text).map { it.groupValues[1] }.toList() +
                Regex("""FILE\s+([^\s"]+)\s+\w+""", RegexOption.IGNORE_CASE).findAll(text).map { it.groupValues[1] }.toList()
            "gdi" -> text.lines().drop(1).mapNotNull { line ->
                Regex(""""([^"]+)"""").find(line)?.groupValues?.get(1)
                    ?: line.trim().split(Regex("""\s+""")).getOrNull(4)
            }
            "m3u" -> text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
            else -> emptyList()
        }.map { it.substringAfterLast('/').substringAfterLast('\\') }
    }

    private fun copyUri(uri: Uri, target: File, size: Long = 0L, label: String = target.name, onProgress: (String) -> Unit = {}) {
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, target.name + ".part")
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Não foi possível abrir o arquivo do jogo.")
        input.use { i ->
            tmp.outputStream().use { o ->
                val buf = ByteArray(1024 * 1024)
                var total = 0L
                var lastReport = 0L
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    o.write(buf, 0, r)
                    total += r
                    if (size > 4L * 1024 * 1024 && total - lastReport > 2L * 1024 * 1024) {
                        lastReport = total
                        onProgress("Copiando $label… ${(total * 100 / size).coerceAtMost(100)}%")
                    }
                }
            }
        }
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) throw IllegalStateException("Sem espaço para preparar o jogo.")
    }

    /** Cópia local do arquivo compactado (reaproveitada enquanto o tamanho bater). */
    fun localCopy(game: Game): File {
        val dir = File(importDir, game.id)
        val f = File(dir, game.fileName)
        if (f.exists() && (game.size <= 0 || f.length() == game.size)) {
            f.setLastModified(System.currentTimeMillis())
            return f
        }
        dir.deleteRecursively()
        dir.mkdirs()
        materialize(game, f) {}
        trim(importDir)
        return f
    }

    /**
     * Copia o jogo para [target]. Se ele estiver dividido em partes, junta tudo num arquivo só
     * (ou, nos volumes de RAR, copia todos para a mesma pasta, que o extrator lê em sequência).
     */
    private fun materialize(game: Game, target: File, onProgress: (String) -> Unit) {
        if (game.parts <= 1) {
            copyUri(Uri.parse(game.uri), target, game.size, game.fileName, onProgress)
            return
        }
        val tree = game.treeUri?.let { Uri.parse(it) }
        val parent = game.parentDocId
        if (tree == null || parent == null) throw IllegalStateException("Adicione a pasta do jogo de novo para o Cartucho achar todas as partes.")
        val siblings = scanner.listChildren(tree, parent).filter { !it.isDir }
        val group = SplitParts.partsOf(game.fileName, siblings.map { it.name })
            ?: throw IllegalStateException("Faltam partes de ${game.fileName}. Confira se todas estão na mesma pasta.")
        val entries = group.parts.map { name -> siblings.first { it.name == name } }
        if (group.scheme == SplitParts.Scheme.RAR) {
            entries.forEachIndexed { i, e ->
                onProgress("Copiando a parte ${i + 1} de ${entries.size}…")
                copyUri(DocumentsContract.buildDocumentUriUsingTree(tree, e.docId), File(target.parentFile, e.name), e.size, e.name)
            }
            return
        }
        // Lê cada parte direto da pasta e escreve em sequência (sem cópia intermediária: ISOs grandes ocupam o dobro).
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, target.name + ".juntando")
        val total = entries.sumOf { it.size }.coerceAtLeast(1)
        var done = 0L
        var last = -1
        tmp.outputStream().buffered(1 shl 20).use { out ->
            val buf = ByteArray(1 shl 20)
            entries.forEachIndexed { i, e ->
                val input = context.contentResolver.openInputStream(DocumentsContract.buildDocumentUriUsingTree(tree, e.docId))
                    ?: throw IllegalStateException("Não foi possível abrir a parte ${e.name}.")
                input.use { inp ->
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val pct = (done * 100 / total).toInt()
                        if (pct != last) { last = pct; onProgress("Juntando as partes (${i + 1} de ${entries.size})… $pct%") }
                    }
                }
            }
        }
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) throw IllegalStateException("Sem espaço para juntar as partes do jogo.")
    }

    /** Extrai o compactado (uma vez) e devolve o arquivo principal do jogo. */
    fun extracted(game: Game, system: GameSystem): File {
        val dir = File(extractDir, game.id)
        val marker = File(dir, ".ok")
        if (!marker.exists()) {
            dir.deleteRecursively()
            val archive = localCopy(game)
            Archives.extractAll(archive, dir)
            // Partes dentro do compactado (jogo.iso.001, .002…): junta antes de procurar o jogo.
            SplitParts.joinInDir(dir)
            marker.writeText("ok")
            trim(extractDir)
        }
        dir.setLastModified(System.currentTimeMillis())
        val names = dir.listFiles()?.filter { it.isFile && it.name != ".ok" }?.map { it.name }.orEmpty()
        val main = Archives.pickMain(names, system.extensions)
            ?: throw ArchiveException("O arquivo compactado está vazio.")
        return File(dir, main)
    }

    /** Remove os jogos menos usados até o cache caber no limite (o mais recente sempre fica). */
    private fun trimBySize(root: File, limit: Long) {
        val dirs = root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() }.orEmpty()
        var total = 0L
        dirs.forEachIndexed { i, d ->
            total += d.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            if (i > 0 && total > limit) d.deleteRecursively()
        }
    }

    /** Mantém só os 4 jogos mais recentes em cada cache. */
    private fun trim(root: File) {
        val dirs = root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() }.orEmpty()
        dirs.drop(4).forEach { it.deleteRecursively() }
    }
}

/** Sistemas cujo jogo é uma pasta de arquivos (o principal aponta para os outros). */
private val FOLDER_GAMES = setOf("rpgmaker", "scummvm", "doom", "quake", "wolf3d", "duke3d", "cavestory", "outrun", "mac", "pc98", "x68000")
