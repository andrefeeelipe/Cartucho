package app.cartucho.data

import java.io.File

/**
 * Jogos divididos em partes (comum em ISOs grandes e em compactados cortados para caber em pendrive
 * ou para subir na internet). O Cartucho reconhece as partes, mostra um jogo só e junta na hora de jogar.
 *
 * Formatos reconhecidos:
 * - "jogo.iso.001", "jogo.iso.002"…  (corte simples: 7-Zip, HJSplit, split) — também .7z.001, .zip.001, .bin.001
 * - "jogo.wbfs" + "jogo.wbf1", "jogo.wbf2"…  (Wii, cortado pelo USB Loader em pedaços de 4 GB)
 * - "ul.XXXXXXXX.SLUS_123.45.00", ".01"…  (PS2 no formato do OPL/USBExtreme)
 * - "jogo.part1.rar", "jogo.part2.rar"… e "jogo.rar" + "jogo.r00", "jogo.r01"…  (RAR em volumes)
 * - "drive-download-20240101T120000Z-1-001.zip", "-002.zip"…  (pasta baixada do Google Drive: o Drive
 *   divide em vários .zip completos, e as partes de um jogo podem cair em .zip diferentes)
 */
object SplitParts {
    enum class Scheme { NUMBERED, WBFS, OPL, RAR, BUNDLE }

    /** Uma parte: o nome do jogo inteiro, a posição (1 = primeira) e o tipo de corte. */
    data class Part(val joinedName: String, val index: Int, val scheme: Scheme)

    private val numbered = Regex("""^(.+\.[a-z0-9]{1,5})\.(\d{3})$""", RegexOption.IGNORE_CASE)
    private val wbf = Regex("""^(.+)\.wbf(\d)$""", RegexOption.IGNORE_CASE)
    private val opl = Regex("""^ul\.([0-9a-f]{8})\.(.+)\.(\d{2})$""", RegexOption.IGNORE_CASE)
    private val rarPart = Regex("""^(.+)\.part(\d+)\.rar$""", RegexOption.IGNORE_CASE)
    private val rarOld = Regex("""^(.+)\.r(\d{2})$""", RegexOption.IGNORE_CASE)
    private val driveBundle = Regex("""^(drive-download-\d{8}T\d{6}Z(?:-\d+)?)-(\d{3})\.zip$""", RegexOption.IGNORE_CASE)

    fun part(name: String): Part? {
        driveBundle.matchEntire(name)?.let { return Part(it.groupValues[1] + ".zip", it.groupValues[2].toInt(), Scheme.BUNDLE) }
        numbered.matchEntire(name)?.let { return Part(it.groupValues[1], it.groupValues[2].toInt(), Scheme.NUMBERED) }
        wbf.matchEntire(name)?.let { return Part(it.groupValues[1] + ".wbfs", it.groupValues[2].toInt() + 1, Scheme.WBFS) }
        if (name.endsWith(".wbfs", true)) return Part(name, 1, Scheme.WBFS)
        opl.matchEntire(name)?.let { return Part(it.groupValues[2] + ".iso", it.groupValues[3].toInt() + 1, Scheme.OPL) }
        rarPart.matchEntire(name)?.let { return Part(it.groupValues[1] + ".rar", it.groupValues[2].toInt(), Scheme.RAR) }
        rarOld.matchEntire(name)?.let { return Part(it.groupValues[1] + ".rar", it.groupValues[2].toInt() + 2, Scheme.RAR) }
        if (name.endsWith(".rar", true) && !rarPart.matches(name)) return Part(name, 1, Scheme.RAR)
        return null
    }

    /** Um jogo dividido: as partes em ordem (nomes como estão na pasta). */
    data class Group(val joinedName: String, val scheme: Scheme, val parts: List<String>) {
        /** Nome que o jogo usa na biblioteca: o do arquivo inteiro (no RAR, o do primeiro volume). */
        val displayName: String get() = if (scheme == Scheme.RAR || scheme == Scheme.BUNDLE) parts.first() else joinedName

        /** As partes são arquivos completos lidos juntos (RAR em volumes, pacotes do Drive), não pedaços a colar. */
        val separate: Boolean get() = scheme == Scheme.RAR || scheme == Scheme.BUNDLE
        val complete: Boolean get() = parts.isNotEmpty()
    }

    /**
     * Agrupa os nomes de uma pasta. Só vira grupo o que tem 2 ou mais partes (um .wbfs ou .rar sozinho é normal).
     * Devolve os grupos e o conjunto de nomes que pertencem a algum grupo.
     */
    fun groups(names: Collection<String>): List<Group> {
        val byKey = HashMap<Pair<String, Scheme>, MutableList<Pair<Int, String>>>()
        for (n in names) {
            val p = part(n) ?: continue
            byKey.getOrPut(p.joinedName.lowercase() to p.scheme) { ArrayList() }.add(p.index to n)
        }
        return byKey.mapNotNull { (key, list) ->
            if (list.size < 2) return@mapNotNull null
            val sorted = list.sortedBy { it.first }
            // Precisa começar na parte 1 e não pular nenhuma.
            if (sorted.first().first != 1 || sorted.zipWithNext().any { (a, b) -> b.first != a.first + 1 }) return@mapNotNull null
            val joined = part(sorted.first().second)!!.joinedName
            Group(joined, key.second, sorted.map { it.second })
        }
    }

    /** Partes de um jogo, procuradas entre os nomes da pasta (para juntar na hora de jogar). */
    fun partsOf(displayName: String, names: Collection<String>): Group? =
        groups(names).firstOrNull { it.displayName.equals(displayName, true) }

    /** Junta as partes num arquivo só (cópia byte a byte, na ordem). */
    fun concat(parts: List<File>, target: File, onProgress: (Int) -> Unit = {}) {
        val total = parts.sumOf { it.length() }.coerceAtLeast(1)
        val tmp = File(target.parentFile, target.name + ".juntando")
        var done = 0L
        var last = -1
        tmp.outputStream().buffered(1 shl 20).use { out ->
            val buf = ByteArray(1 shl 20)
            for (p in parts) {
                p.inputStream().use { input ->
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val pct = (done * 100 / total).toInt()
                        if (pct != last) { last = pct; onProgress(pct) }
                    }
                }
            }
        }
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) throw IllegalStateException("Sem espaço para juntar as partes do jogo.")
    }

    /** Dentro de uma pasta já extraída: junta as partes que estiverem lá e apaga os pedaços. */
    fun joinInDir(dir: File, onProgress: (String) -> Unit = {}) {
        val files = dir.listFiles()?.filter { it.isFile }.orEmpty()
        for (g in groups(files.map { it.name })) {
            if (g.separate) continue  // volumes de RAR e pacotes do Drive são lidos pelo extrator
            val parts = g.parts.map { File(dir, it) }
            concat(parts, File(dir, g.joinedName)) { onProgress("Juntando as partes… $it%") }
            parts.forEach { if (it.name != g.joinedName) it.delete() }
        }
    }
}
