package app.cartucho.data

import org.tukaani.xz.XZInputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.io.RandomAccessFile

/**
 * Patches de jogos de disco (PS1, PS2, PSP, Sega CD…), aplicados em arquivos grandes sem
 * carregar tudo na memória:
 * - PPF 1.0, 2.0 e 3.0 (comuns em traduções de PlayStation);
 * - xdelta3/VCDIFF (RFC 3284), com ou sem compressão secundária LZMA.
 */
object DiscPatches {

    /** Copia [source] para [out] e aplica o patch por cima. */
    fun apply(source: File, patch: File, type: String, out: File, onProgress: (Int) -> Unit) {
        when (type) {
            "ppf" -> {
                copy(source, out, onProgress)
                applyPpf(patch, out)
            }
            "xdelta", "vcdiff", "xd3" -> applyVcdiff(source, patch, out, onProgress)
            else -> throw PatchException("Formato de patch desconhecido.")
        }
    }

    private fun copy(source: File, out: File, onProgress: (Int) -> Unit) {
        val total = source.length().coerceAtLeast(1)
        var done = 0L
        source.inputStream().use { i ->
            out.outputStream().use { o ->
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    done += n
                    onProgress((done * 100 / total).toInt())
                }
            }
        }
    }

    // ------------------------------------------------------------------ PPF

    private fun applyPpf(patchFile: File, target: File) {
        val p = patchFile.readBytes()
        if (p.size < 56 || String(p, 0, 3, Charsets.ISO_8859_1) != "PPF") throw PatchException("Patch PPF inválido.")
        val version = p[5].toInt() and 0xff
        var pos: Int
        var offsetSize = 4
        var undo = false
        when (version) {
            0 -> pos = 56
            1 -> pos = 1084
            2 -> {
                val blockCheck = p[57].toInt() != 0
                undo = p[58].toInt() != 0
                pos = if (blockCheck) 1084 else 60
                offsetSize = 8
            }
            else -> throw PatchException("Versão de PPF desconhecida.")
        }
        RandomAccessFile(target, "rw").use { raf ->
            while (pos + offsetSize + 1 <= p.size) {
                if (String(p, pos, minOf(4, p.size - pos), Charsets.ISO_8859_1) == "@BEG") break  // FILE_ID.DIZ no fim
                var offset = 0L
                for (k in 0 until offsetSize) offset = offset or ((p[pos + k].toLong() and 0xff) shl (8 * k))
                pos += offsetSize
                val len = p[pos].toInt() and 0xff
                pos += 1
                if (pos + len > p.size) throw PatchException("Patch PPF incompleto.")
                raf.seek(offset)
                raf.write(p, pos, len)
                pos += len
                if (undo) pos += len
            }
        }
    }

    // --------------------------------------------------------------- VCDIFF

    private class Input(private val stream: InputStream) {
        var pos = 0L
        fun byte(): Int {
            val b = stream.read()
            if (b < 0) throw PatchException("Patch xdelta incompleto.")
            pos++
            return b
        }
        fun eof(): Boolean {
            if (!stream.markSupported()) return false
            stream.mark(1)
            val b = stream.read()
            stream.reset()
            return b < 0
        }
        fun varint(): Long {
            var r = 0L
            while (true) {
                val b = byte()
                r = (r shl 7) or (b and 0x7f).toLong()
                if (b and 0x80 == 0) return r
            }
        }
        fun bytes(n: Int): ByteArray {
            val out = ByteArray(n)
            var read = 0
            while (read < n) {
                val k = stream.read(out, read, n - read)
                if (k < 0) throw PatchException("Patch xdelta incompleto.")
                read += k
            }
            pos += n
            return out
        }
    }

    /** Leitura sequencial de uma seção (dados, instruções ou endereços) já descompactada. */
    private class Section(val data: ByteArray) {
        var pos = 0
        fun byte(): Int = data[pos++].toInt() and 0xff
        fun varint(): Long {
            var r = 0L
            while (true) {
                val b = byte()
                r = (r shl 7) or (b and 0x7f).toLong()
                if (b and 0x80 == 0) return r
            }
        }
    }

    private data class Inst(val type: Int, val size: Int, val mode: Int)
    private const val NOOP = 0
    private const val ADD = 1
    private const val RUN = 2
    private const val COPY = 3

    /** Tabela de códigos padrão do VCDIFF (RFC 3284, seção 5.6). */
    private val codeTable: Array<Pair<Inst, Inst>> by lazy {
        val t = ArrayList<Pair<Inst, Inst>>(256)
        val none = Inst(NOOP, 0, 0)
        t += Inst(RUN, 0, 0) to none
        t += Inst(ADD, 0, 0) to none
        for (s in 1..17) t += Inst(ADD, s, 0) to none
        for (mode in 0..8) {
            t += Inst(COPY, 0, mode) to none
            for (s in 4..18) t += Inst(COPY, s, mode) to none
        }
        for (mode in 0..5) for (addSize in 1..4) for (copySize in 4..6) t += Inst(ADD, addSize, 0) to Inst(COPY, copySize, mode)
        for (mode in 6..8) for (addSize in 1..4) t += Inst(ADD, addSize, 0) to Inst(COPY, 4, mode)
        for (mode in 0..8) t += Inst(COPY, 4, mode) to Inst(ADD, 1, 0)
        t.toTypedArray()
    }

    private fun applyVcdiff(sourceFile: File, patchFile: File, outFile: File, onProgress: (Int) -> Unit) {
        val stream = patchFile.inputStream().buffered(1 shl 20)
        val inp = Input(stream)
        val magic = inp.bytes(4)
        if ((magic[0].toInt() and 0xff) != 0xD6 || (magic[1].toInt() and 0xff) != 0xC3 || (magic[2].toInt() and 0xff) != 0xC4) {
            throw PatchException("Patch xdelta inválido.")
        }
        val hdr = inp.byte()
        var secondary = 0
        if (hdr and 0x01 != 0) secondary = inp.byte()
        if (hdr and 0x02 != 0) throw PatchException("Esse patch xdelta usa uma tabela de códigos própria, ainda não suportada.")
        if (hdr and 0x04 != 0) inp.bytes(inp.varint().toInt())  // cabeçalho do aplicativo (nome dos arquivos)
        if (secondary != 0 && secondary != 2) {
            throw PatchException("Esse patch xdelta foi feito com compressão DJW, ainda não suportada. Procure a versão sem compressão ou PPF.")
        }

        val patchLen = patchFile.length().coerceAtLeast(1)
        RandomAccessFile(sourceFile, "r").use { src ->
            RandomAccessFile(outFile, "rw").use { out ->
                out.setLength(0)
                var targetPos = 0L
                val near = LongArray(4)
                var nextNear = 0
                val same = LongArray(3 * 256)
                while (stream.available() > 0 || !inp.eof()) {
                    val winInd = runCatching { inp.byte() }.getOrNull() ?: break
                    var segLen = 0L
                    var segPos = 0L
                    val fromTarget = winInd and 0x02 != 0
                    if (winInd and 0x03 != 0) {
                        segLen = inp.varint()
                        segPos = inp.varint()
                    }
                    inp.varint()  // tamanho da codificação
                    val targetLen = inp.varint().toInt()
                    val deltaInd = inp.byte()
                    val dataLen = inp.varint().toInt()
                    val instLen = inp.varint().toInt()
                    val addrLen = inp.varint().toInt()
                    if (winInd and 0x04 != 0) inp.bytes(4)  // adler32 (xdelta3)
                    val data = section(inp.bytes(dataLen), deltaInd and 0x01 != 0)
                    val inst = section(inp.bytes(instLen), deltaInd and 0x02 != 0)
                    val addr = section(inp.bytes(addrLen), deltaInd and 0x04 != 0)

                    // Segmento de origem desta janela (do jogo original ou do que já foi gerado).
                    val segment = ByteArray(segLen.toInt())
                    if (segLen > 0) {
                        val raf = if (fromTarget) out else src
                        raf.seek(segPos)
                        raf.readFully(segment)
                    }
                    val target = ByteArray(targetLen)
                    var t = 0
                    near.fill(0); nextNear = 0; same.fill(0)
                    fun cacheUpdate(a: Long) {
                        near[nextNear] = a
                        nextNear = (nextNear + 1) % 4
                        same[(a % (3 * 256)).toInt()] = a
                    }
                    fun decodeAddr(here: Long, mode: Int): Long {
                        val a = when {
                            mode == 0 -> addr.varint()
                            mode == 1 -> here - addr.varint()
                            mode in 2..5 -> near[mode - 2] + addr.varint()
                            else -> same[(mode - 6) * 256 + addr.byte()]
                        }
                        cacheUpdate(a)
                        return a
                    }
                    fun run(i: Inst) {
                        if (i.type == NOOP) return
                        val size = if (i.size == 0) inst.varint().toInt() else i.size
                        when (i.type) {
                            ADD -> {
                                System.arraycopy(data.data, data.pos, target, t, size)
                                data.pos += size
                                t += size
                            }
                            RUN -> {
                                val b = data.data[data.pos++]
                                java.util.Arrays.fill(target, t, t + size, b)
                                t += size
                            }
                            COPY -> {
                                val here = segLen + t
                                var a = decodeAddr(here, i.mode)
                                for (k in 0 until size) {
                                    target[t + k] = if (a < segLen) segment[a.toInt()] else target[(a - segLen).toInt()]
                                    a++
                                }
                                t += size
                            }
                        }
                    }
                    while (inst.pos < inst.data.size) {
                        val (a, b) = codeTable[inst.byte()]
                        run(a)
                        run(b)
                    }
                    if (t != targetLen) throw PatchException("Patch xdelta não corresponde a este jogo.")
                    out.seek(targetPos)
                    out.write(target)
                    targetPos += targetLen
                    onProgress((inp.pos * 100 / patchLen).toInt().coerceIn(0, 100))
                }
                out.setLength(targetPos)
            }
        }
    }

    /** Seção com compressão secundária LZMA do xdelta3: [tamanho original][fluxo .xz]. */
    private fun section(raw: ByteArray, compressed: Boolean): Section {
        if (!compressed) return Section(raw)
        val s = Section(raw)
        val size = s.varint().toInt()
        val xz = XZInputStream(ByteArrayInputStream(raw, s.pos, raw.size - s.pos))
        val out = ByteArray(size)
        var read = 0
        while (read < size) {
            val n = xz.read(out, read, size - read)
            if (n < 0) break
            read += n
        }
        return Section(out)
    }
}
