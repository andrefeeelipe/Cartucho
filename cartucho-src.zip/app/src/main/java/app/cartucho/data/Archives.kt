package app.cartucho.data

import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.lzma.LZMACompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.util.zip.GZIPInputStream
import java.util.zip.ZipFile

class ArchiveException(message: String) : Exception(message)

/**
 * Lê arquivos compactados comuns em coleções de ROMs: zip, 7z, rar, tar e os compressores
 * gz, bz2, xz e lzma (sozinhos ou com tar). Trabalha sobre uma cópia local do arquivo.
 */
object Archives {
    private val compressors = setOf("gz", "bz2", "xz", "lzma")
    val extensions: Set<String> = setOf("zip", "7z", "rar", "tar", "tgz", "tbz", "tbz2", "txz") + compressors

    fun isArchive(name: String): Boolean = extensionOf(name) in extensions

    fun extensionOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    /** Nomes dos arquivos dentro do pacote (sem pastas). */
    fun list(file: File): List<String> {
        val ext = extensionOf(file.name)
        return guard {
            when (ext) {
                "zip" -> listZip(file)
                "7z" -> openSevenZ(file).use { z -> generateSequence { z.nextEntry }.filter { !it.isDirectory }.map { it.name }.toList() }
                "rar" -> listRar(file)
                else -> {
                    val tar = isTar(file.name)
                    if (tar) {
                        TarArchiveInputStream(decompress(file)).use { t ->
                            generateSequence { t.nextEntry }.filter { !it.isDirectory }.map { it.name }.toList()
                        }
                    } else {
                        listOf(file.name.substringBeforeLast('.'))
                    }
                }
            }
        }
    }

    /**
     * Extrai tudo para [dest] (pacotes de ROM costumam ter um jogo só; discos têm várias trilhas).
     * Retorna os arquivos extraídos.
     */
    fun extractAll(file: File, dest: File, onProgress: (Int) -> Unit = {}): List<File> {
        dest.mkdirs()
        val ext = extensionOf(file.name)
        val out = ArrayList<File>()
        val total = runCatching { unpackedSize(file) }.getOrDefault(0L)
        var written = 0L
        var lastPct = -1
        fun target(name: String): File {
            val clean = name.replace('\\', '/').substringAfterLast('/')
            return File(dest, clean.ifEmpty { "jogo.bin" })
        }
        // Cada arquivo extraído passa por aqui: conta os bytes para mostrar a porcentagem.
        fun File.outputStream(): java.io.OutputStream = object : java.io.FilterOutputStream(java.io.FileOutputStream(this).buffered(1 shl 20)) {
            override fun write(b: ByteArray, off: Int, len: Int) {
                this.out.write(b, off, len)
                written += len
                if (total > 0) {
                    val pct = (written * 100 / total).toInt().coerceAtMost(100)
                    if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                }
            }
        }
        guard {
            when (ext) {
                "zip" -> extractZip(file, ::target, out) { it.outputStream() }
                "7z" -> openSevenZ(file).use { z ->
                    while (true) {
                        val entry = z.nextEntry ?: break
                        if (entry.isDirectory) continue
                        val f = target(entry.name)
                        f.outputStream().use { os ->
                            val buf = ByteArray(256 * 1024)
                            while (true) {
                                val r = z.read(buf)
                                if (r < 0) break
                                os.write(buf, 0, r)
                            }
                        }
                        out.add(f)
                    }
                }
                "rar" -> extractRar(file, ::target, out) { it.outputStream() }
                else -> {
                    if (isTar(file.name)) {
                        TarArchiveInputStream(decompress(file)).use { t ->
                            while (true) {
                                val entry = t.nextEntry ?: break
                                if (entry.isDirectory) continue
                                val f = target(entry.name)
                                f.outputStream().use { t.copyTo(it) }
                                out.add(f)
                            }
                        }
                    } else {
                        val f = target(file.name.substringBeforeLast('.'))
                        decompress(file).use { input -> f.outputStream().use { input.copyTo(it) } }
                        out.add(f)
                    }
                }
            }
        }
        return out
    }

    /** Tamanho que o conteúdo ocupa depois de extraído (0 se o formato não disser). */
    fun unpackedSize(file: File): Long = when (extensionOf(file.name)) {
        "zip" -> openZip(file).use { z -> z.entries.asSequence().filter { !it.isDirectory }.sumOf { it.size.coerceAtLeast(0) } }
        "7z" -> openSevenZ(file).use { z -> z.entries.filter { !it.isDirectory }.sumOf { it.size.coerceAtLeast(0) } }
        "rar" -> com.github.junrar.Archive(file).use { a -> a.fileHeaders.filter { !it.isDirectory }.sumOf { it.fullUnpackSize.coerceAtLeast(0) } }
        else -> 0L
    }

    /** Pedaços de um zip dividido (jogo.z01, jogo.z02…) ao lado do [file] .zip, em ordem. */
    private fun zipSegments(file: File): List<File> {
        val base = file.name.substringBeforeLast('.').lowercase()
        val re = Regex("""\.z(\d{2,3})$""", RegexOption.IGNORE_CASE)
        return file.parentFile?.listFiles()
            ?.filter { it.name.substringBeforeLast('.').lowercase() == base && re.containsMatchIn(it.name) }
            ?.sortedBy { re.find(it.name)!!.groupValues[1].toInt() }
            .orEmpty()
    }

    /** Abre o zip pelo leitor completo (aceita Deflate64, LZMA… e zip dividido em .z01/.z02). */
    @Suppress("DEPRECATION")
    private fun openZip(file: File): org.apache.commons.compress.archivers.zip.ZipFile {
        val segments = zipSegments(file)
        if (segments.isEmpty()) return org.apache.commons.compress.archivers.zip.ZipFile(file)
        val split = org.apache.commons.compress.archivers.zip.ZipSplitReadOnlySeekableByteChannel.forFiles(*(segments + file).toTypedArray())
        return org.apache.commons.compress.archivers.zip.ZipFile(split)
    }

    /** Entre os arquivos de um pacote, qual é o jogo: playlist > folha de disco > imagem > maior arquivo com extensão conhecida. */
    fun pickMain(names: List<String>, preferredExtensions: Set<String> = emptySet()): String? {
        if (names.isEmpty()) return null
        fun ext(n: String) = extensionOf(n)
        val known = Systems.allRomExtensions
        names.firstOrNull { ext(it) == "m3u" }?.let { return it }
        names.firstOrNull { ext(it) in setOf("cue", "gdi", "ccd") }?.let { return it }
        if (preferredExtensions.isNotEmpty()) names.firstOrNull { ext(it) in preferredExtensions }?.let { return it }
        names.firstOrNull { ext(it) in known && ext(it) !in setOf("bin", "img") }?.let { return it }
        return names.firstOrNull { ext(it) in known } ?: names.first()
    }

    private fun isTar(name: String): Boolean {
        val lower = name.lowercase()
        return lower.endsWith(".tar") || lower.endsWith(".tgz") || lower.endsWith(".tbz") || lower.endsWith(".tbz2") ||
            lower.endsWith(".txz") || Regex("""\.tar\.(gz|bz2|xz|lzma)$""").containsMatchIn(lower)
    }

    private fun decompress(file: File): InputStream {
        val raw = BufferedInputStream(file.inputStream(), 256 * 1024)
        val lower = file.name.lowercase()
        return when {
            lower.endsWith(".gz") || lower.endsWith(".tgz") -> GZIPInputStream(raw, 256 * 1024)
            lower.endsWith(".bz2") || lower.endsWith(".tbz") || lower.endsWith(".tbz2") -> BZip2CompressorInputStream(raw)
            lower.endsWith(".xz") || lower.endsWith(".txz") -> XZCompressorInputStream(raw)
            lower.endsWith(".lzma") -> LZMACompressorInputStream(raw)
            else -> raw
        }
    }

    @Suppress("DEPRECATION")
    private fun openSevenZ(file: File): SevenZFile = SevenZFile(file)

    private fun listZip(file: File): List<String> = if (zipSegments(file).isNotEmpty()) {
        openZip(file).use { z -> z.entries.asSequence().filter { !it.isDirectory }.map { it.name }.toList() }
    } else try {
        ZipFile(file).use { z -> z.entries().asSequence().filter { !it.isDirectory }.map { it.name }.toList() }
    } catch (e: Exception) {
        @Suppress("DEPRECATION")
        org.apache.commons.compress.archivers.zip.ZipFile(file).use { z ->
            z.entries.asSequence().filter { !it.isDirectory }.map { it.name }.toList()
        }
    }

    private fun extractZip(file: File, target: (String) -> File, out: MutableList<File>, open: (File) -> java.io.OutputStream) {
        if (zipSegments(file).isNotEmpty()) {
            openZip(file).use { z ->
                for (entry in z.entries.asSequence().filter { !it.isDirectory }) {
                    val f = target(entry.name)
                    z.getInputStream(entry).use { input -> open(f).use { input.copyTo(it, 1 shl 20) } }
                    out.add(f)
                }
            }
            return
        }
        try {
            ZipFile(file).use { z ->
                for (entry in z.entries().asSequence().filter { !it.isDirectory }) {
                    val f = target(entry.name)
                    z.getInputStream(entry).use { input -> open(f).use { input.copyTo(it, 1 shl 20) } }
                    out.add(f)
                }
            }
        } catch (e: java.util.zip.ZipException) {
            // Métodos de compressão que o java.util.zip não conhece (Deflate64, BZip2, LZMA...).
            out.clear()
            @Suppress("DEPRECATION")
            org.apache.commons.compress.archivers.zip.ZipFile(file).use { z ->
                for (entry in z.entries.asSequence().filter { !it.isDirectory }) {
                    val f = target(entry.name)
                    z.getInputStream(entry).use { input -> open(f).use { input.copyTo(it, 1 shl 20) } }
                    out.add(f)
                }
            }
        }
    }

    private fun listRar(file: File): List<String> =
        com.github.junrar.Archive(file).use { a -> a.fileHeaders.filter { !it.isDirectory }.map { it.fileName } }

    private fun extractRar(file: File, target: (String) -> File, out: MutableList<File>, open: (File) -> java.io.OutputStream) {
        com.github.junrar.Archive(file).use { a ->
            for (h in a.fileHeaders) {
                if (h.isDirectory) continue
                val f = target(h.fileName)
                open(f).use { a.extractFile(h, it) }
                out.add(f)
            }
        }
    }

    /** Traduz falhas das bibliotecas em mensagens claras. */
    private inline fun <T> guard(block: () -> T): T = try {
        block()
    } catch (e: ArchiveException) {
        throw e
    } catch (e: Throwable) {
        val name = e.javaClass.simpleName
        val msg = when {
            name.contains("RarV5", ignoreCase = true) || (e.message ?: "").contains("rar5", ignoreCase = true) ->
                "Este .rar usa o formato RAR5, que ainda não dá para abrir no celular. Extraia ou recompacte em .zip ou .7z."
            name.contains("Password", ignoreCase = true) || (e.message ?: "").contains("password", ignoreCase = true) ->
                "O arquivo compactado tem senha."
            e is NoClassDefFoundError || e is NoSuchMethodError ->
                "Este tipo de arquivo compactado exige Android 8 ou mais novo. Use .zip ou extraia o jogo."
            else -> "Não foi possível abrir o arquivo compactado (${e.message ?: name})."
        }
        throw ArchiveException(msg)
    }
}
