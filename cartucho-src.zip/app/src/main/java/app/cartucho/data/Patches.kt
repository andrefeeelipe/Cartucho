package app.cartucho.data

import android.content.Context
import android.net.Uri
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.zip.CRC32

class PatchException(message: String) : Exception(message)

/**
 * Hacks e traduções aplicados como patch (IPS, UPS, BPS) sobre uma cópia do jogo.
 * O arquivo original nunca é alterado: o resultado fica no cache e é refeito se o patch mudar.
 */
object Patches {
    val extensions = setOf("ips", "ups", "bps")
    private val unsupported = setOf("xdelta", "vcdiff", "ppf", "aps", "ebp")

    fun dir(context: Context, gameId: String): File = File(context.filesDir, "patches/$gameId").apply { mkdirs() }

    fun list(context: Context, gameId: String): List<File> =
        dir(context, gameId).listFiles()?.filter { it.isFile && Archives.extensionOf(it.name) in extensions }
            ?.sortedBy { it.name.lowercase() }.orEmpty()

    fun remove(context: Context, gameId: String, name: String) {
        File(dir(context, gameId), name).delete()
    }

    /** Sistemas de cartucho: o patch se aplica ao arquivo inteiro. */
    fun supports(system: GameSystem): Boolean = system.multiFileExtensions.isEmpty() && system.id !in setOf("arcade", "psp", "ps2", "psx")

    /** Instala um patch vindo de um arquivo do aparelho (ou compactado com o patch dentro). */
    fun installFromUri(context: Context, gameId: String, uri: Uri, displayName: String): File {
        val tmpDir = File(context.cacheDir, "patch-in").apply { deleteRecursively(); mkdirs() }
        val tmp = File(tmpDir, displayName.ifEmpty { "patch.bin" })
        context.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { i.copyTo(it) } }
            ?: throw PatchException("Não foi possível ler o arquivo.")
        return installFile(context, gameId, tmp)
    }

    /** Baixa um patch por link (direto ou dentro de .zip/.7z/.rar). */
    fun installFromUrl(context: Context, gameId: String, url: String): File {
        val clean = url.trim()
        if (!clean.startsWith("https://") && !clean.startsWith("http://")) throw PatchException("Cole um link que comece com https://")
        val http = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()
        val tmpDir = File(context.cacheDir, "patch-in").apply { deleteRecursively(); mkdirs() }
        val req = Request.Builder().url(clean).header("User-Agent", "Cartucho/1.0 (Android)").build()
        val file = http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw PatchException("O site respondeu com erro ${resp.code}.")
            val fromHeader = resp.header("Content-Disposition")
                ?.let { Regex("""filename\*?=(?:UTF-8'')?"?([^";]+)"?""").find(it)?.groupValues?.get(1) }
            val fromUrl = Uri.decode(resp.request.url.pathSegments.lastOrNull().orEmpty())
            val name = (fromHeader ?: fromUrl).ifEmpty { "patch.bin" }.substringAfterLast('/')
            val f = File(tmpDir, name)
            val body = resp.body ?: throw PatchException("Download vazio.")
            if (body.contentLength() > 64L * 1024 * 1024) throw PatchException("Arquivo grande demais para um patch.")
            body.byteStream().use { i -> f.outputStream().use { i.copyTo(it) } }
            f
        }
        return installFile(context, gameId, file)
    }

    private fun installFile(context: Context, gameId: String, file: File): File {
        val ext = Archives.extensionOf(file.name)
        val candidate: File = when {
            ext in extensions -> file
            Archives.isArchive(file.name) -> {
                val out = File(file.parentFile, "x").apply { deleteRecursively(); mkdirs() }
                val files = Archives.extractAll(file, out)
                files.firstOrNull { Archives.extensionOf(it.name) in extensions }
                    ?: run {
                        val other = files.firstOrNull { Archives.extensionOf(it.name) in unsupported }
                        if (other != null) throw PatchException(unsupportedMessage(other.name))
                        throw PatchException("Não encontrei um patch .ips, .ups ou .bps dentro do arquivo.")
                    }
            }
            ext in unsupported -> throw PatchException(unsupportedMessage(file.name))
            else -> {
                // Sem extensão confiável: descobre pelo cabeçalho.
                val head = file.inputStream().use { i -> ByteArray(5).also { i.read(it) } }
                val magic = String(head, Charsets.ISO_8859_1)
                val real = when {
                    magic.startsWith("PATCH") -> "ips"
                    magic.startsWith("UPS1") -> "ups"
                    magic.startsWith("BPS1") -> "bps"
                    else -> throw PatchException("Esse arquivo não parece um patch de hack (.ips, .ups ou .bps).")
                }
                File(file.parentFile, file.name.substringBeforeLast('.') + ".$real").also { file.renameTo(it) }
            }
        }
        val dest = File(dir(context, gameId), candidate.name)
        candidate.copyTo(dest, overwrite = true)
        return dest
    }

    private fun unsupportedMessage(name: String) =
        "O formato .${Archives.extensionOf(name)} ainda não é suportado. Procure a versão .ips, .ups ou .bps do hack."

    /** Se o jogo tem um patch ativo, devolve a versão modificada (gerada uma vez e guardada). */
    fun applyIfNeeded(context: Context, game: Game, system: GameSystem, source: File, onProgress: (String) -> Unit): File {
        if (game.patch.isEmpty() || !supports(system)) return source
        val patch = File(dir(context, game.id), game.patch)
        if (!patch.exists()) return source
        val key = "${patch.length()}-${patch.lastModified()}-${source.length()}"
        val outDir = File(context.cacheDir, "patched/${game.id}/$key")
        val out = File(outDir, source.name)
        if (out.exists()) return out
        onProgress("Aplicando ${game.patch}…")
        File(context.cacheDir, "patched/${game.id}").deleteRecursively()
        outDir.mkdirs()
        val result = apply(source.readBytes(), patch.readBytes(), Archives.extensionOf(patch.name))
        out.writeBytes(result)
        return out
    }

    fun apply(source: ByteArray, patch: ByteArray, type: String): ByteArray = when (type) {
        "ips" -> applyIps(source, patch)
        "ups" -> applyUps(source, patch)
        "bps" -> applyBps(source, patch)
        else -> throw PatchException("Formato de patch desconhecido.")
    }

    // ---------------------------------------------------------------- IPS

    private fun applyIps(sourceIn: ByteArray, p: ByteArray): ByteArray {
        if (p.size < 8 || String(p, 0, 5, Charsets.ISO_8859_1) != "PATCH") throw PatchException("Patch IPS inválido.")
        var out = sourceIn.copyOf()
        var i = 5
        fun u8(at: Int) = p[at].toInt() and 0xff
        while (i + 3 <= p.size) {
            val offset = (u8(i) shl 16) or (u8(i + 1) shl 8) or u8(i + 2)
            if (offset == 0x454F46) {
                i += 3
                // Extensão opcional: tamanho final após o "EOF".
                if (i + 3 <= p.size) {
                    val truncate = (u8(i) shl 16) or (u8(i + 1) shl 8) or u8(i + 2)
                    if (truncate in 1 until out.size) out = out.copyOf(truncate)
                }
                return out
            }
            i += 3
            if (i + 2 > p.size) break
            val size = (u8(i) shl 8) or u8(i + 1)
            i += 2
            if (size == 0) {
                val count = (u8(i) shl 8) or u8(i + 1)
                val value = p[i + 2]
                i += 3
                if (offset + count > out.size) out = out.copyOf(offset + count)
                for (k in 0 until count) out[offset + k] = value
            } else {
                if (offset + size > out.size) out = out.copyOf(offset + size)
                System.arraycopy(p, i, out, offset, size)
                i += size
            }
        }
        throw PatchException("Patch IPS incompleto.")
    }

    // ---------------------------------------------------------------- UPS / BPS

    private class Reader(val data: ByteArray, var pos: Int) {
        fun byte(): Int = data[pos++].toInt() and 0xff
        fun number(): Long {
            var result = 0L
            var shift = 1L
            while (true) {
                val x = byte()
                result += (x and 0x7f) * shift
                if (x and 0x80 != 0) break
                shift = shift shl 7
                result += shift
            }
            return result
        }
    }

    private fun crc(data: ByteArray, len: Int = data.size): Long = CRC32().apply { update(data, 0, len) }.value

    private fun footerCrc(p: ByteArray, at: Int): Long =
        (p[at].toLong() and 0xff) or ((p[at + 1].toLong() and 0xff) shl 8) or
            ((p[at + 2].toLong() and 0xff) shl 16) or ((p[at + 3].toLong() and 0xff) shl 24)

    /** ROMs de SNES às vezes têm um cabeçalho de 512 bytes que o patch não espera. */
    private fun matchSource(source: ByteArray, expectedSize: Long, expectedCrc: Long): ByteArray {
        if (source.size.toLong() == expectedSize) return source
        if (source.size.toLong() == expectedSize + 512) {
            val stripped = source.copyOfRange(512, source.size)
            if (crc(stripped) == expectedCrc) return stripped
        }
        if (source.size.toLong() + 512 == expectedSize) return source
        throw PatchException("Este patch foi feito para outra versão do jogo (tamanho diferente). Procure o patch para a sua ROM.")
    }

    private fun applyUps(sourceIn: ByteArray, p: ByteArray): ByteArray {
        if (p.size < 18 || String(p, 0, 4, Charsets.ISO_8859_1) != "UPS1") throw PatchException("Patch UPS inválido.")
        val r = Reader(p, 4)
        val sourceSize = r.number()
        val targetSize = r.number()
        val source = matchSource(sourceIn, sourceSize, footerCrc(p, p.size - 12))
        val out = source.copyOf(targetSize.toInt())
        var pos = 0L
        val end = p.size - 12
        while (r.pos < end) {
            pos += r.number()
            while (r.pos < end) {
                val b = r.byte()
                if (pos < out.size) {
                    val orig = if (pos < source.size) source[pos.toInt()].toInt() else 0
                    out[pos.toInt()] = (orig xor b).toByte()
                }
                pos++
                if (b == 0) break
            }
        }
        return out
    }

    private fun applyBps(sourceIn: ByteArray, p: ByteArray): ByteArray {
        if (p.size < 19 || String(p, 0, 4, Charsets.ISO_8859_1) != "BPS1") throw PatchException("Patch BPS inválido.")
        val r = Reader(p, 4)
        val sourceSize = r.number()
        val targetSize = r.number()
        val metadataSize = r.number()
        r.pos += metadataSize.toInt()
        val source = matchSource(sourceIn, sourceSize, footerCrc(p, p.size - 12))
        val out = ByteArray(targetSize.toInt())
        var outOff = 0
        var srcRel = 0
        var tgtRel = 0
        val end = p.size - 12
        while (r.pos < end) {
            val data = r.number()
            val command = (data and 3).toInt()
            val length = ((data shr 2) + 1).toInt()
            when (command) {
                0 -> repeat(length) { out[outOff] = if (outOff < source.size) source[outOff] else 0; outOff++ }
                1 -> repeat(length) { out[outOff++] = p[r.pos++] }
                2 -> {
                    val d = r.number()
                    srcRel += (if (d and 1L != 0L) -1 else 1) * (d shr 1).toInt()
                    repeat(length) { out[outOff++] = source[srcRel++] }
                }
                else -> {
                    val d = r.number()
                    tgtRel += (if (d and 1L != 0L) -1 else 1) * (d shr 1).toInt()
                    repeat(length) { out[outOff++] = out[tgtRel++] }
                }
            }
        }
        return out
    }
}
