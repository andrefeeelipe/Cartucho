package app.cartucho.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.InputStream

/**
 * Indexa uma pasta escolhida pelo usuário (Storage Access Framework), sem permissão de armazenamento amplo.
 * Funciona com pastas locais e de provedores de nuvem (Google Drive, OneDrive...), que entregam a lista
 * aos poucos: a varredura espera o provedor terminar de carregar antes de concluir que a pasta está vazia.
 */
class GameScanner(private val context: Context, private val detector: GameDetector) {

    data class Entry(val docId: String, val name: String, val size: Long, val isDir: Boolean)

    private fun queryOnce(childrenUri: Uri): Pair<List<Entry>, Boolean> {
        val out = ArrayList<Entry>()
        var loading = false
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        runCatching {
            context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                loading = c.extras?.getBoolean(DocumentsContract.EXTRA_LOADING, false) ?: false
                while (c.moveToNext()) {
                    val mime = c.getString(3) ?: ""
                    out.add(
                        Entry(
                            docId = c.getString(0),
                            name = c.getString(1) ?: "",
                            size = if (c.isNull(2)) 0L else c.getLong(2),
                            isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR,
                        )
                    )
                }
            }
        }
        return out to loading
    }

    fun listChildren(treeUri: Uri, parentDocId: String): List<Entry> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        var (entries, loading) = queryOnce(childrenUri)
        // Provedores de nuvem respondem "carregando" e completam depois: tenta de novo por até ~20 s.
        var attempts = 0
        while ((loading || entries.isEmpty()) && attempts < 20) {
            if (!loading && attempts >= 3) break
            Thread.sleep(1000)
            val next = queryOnce(childrenUri)
            entries = next.first
            loading = next.second
            attempts++
        }
        return entries
    }

    fun openSibling(treeUri: Uri, parentDocId: String, name: String): InputStream? {
        val entry = listChildren(treeUri, parentDocId).firstOrNull { it.name.equals(name, ignoreCase = true) } ?: return null
        val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, entry.docId)
        return context.contentResolver.openInputStream(uri)
    }

    /** Varre a pasta recursivamente (até 8 níveis). */
    fun scan(treeUri: Uri, onProgress: (Int) -> Unit = {}): List<Game> {
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        val found = ArrayList<Game>()
        // Ler cabeçalhos de arquivos da nuvem obrigaria a baixar tudo; só fazemos isso em pastas locais.
        val local = treeUri.authority == "com.android.externalstorage.documents"
        val rootName = rootId.substringAfterLast(':').substringAfterLast('/')
        walk(treeUri, rootId, listOf(rootName), 0, local, found, onProgress)
        return found
    }

    private fun walk(
        treeUri: Uri,
        docId: String,
        folders: List<String>,
        depth: Int,
        local: Boolean,
        found: MutableList<Game>,
        onProgress: (Int) -> Unit,
    ) {
        if (depth > 8) return
        val children = listChildren(treeUri, docId)
        val files = children.filter { !it.isDir }
        val names = files.map { it.name.lowercase() }.toSet()
        val hasSheets = names.any { it.endsWith(".cue") || it.endsWith(".gdi") || it.endsWith(".m3u") || it.endsWith(".ccd") }

        // Discos listados em .m3u não aparecem separados.
        val inM3u = HashSet<String>()
        files.filter { it.name.lowercase().endsWith(".m3u") }.forEach { m3u ->
            runCatching {
                val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, m3u.docId)
                context.contentResolver.openInputStream(uri)?.use { s ->
                    s.bufferedReader().readLines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
                        .forEach { inM3u.add(it.substringAfterLast('/').lowercase()) }
                }
            }
        }

        for (f in files) {
            val lower = f.name.lowercase()
            val ext = lower.substringAfterLast('.', "")
            if (ext !in Systems.allExtensions) continue
            if (lower in inM3u) continue
            // Trilhas de .cue/.gdi não viram jogos próprios.
            if (hasSheets && (ext == "bin" || ext == "raw" || ext == "img" || ext == "sub")) continue
            val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, f.docId)
            val detection = detector.detect(uri, f.name, f.size, folders, sniff = local) { sibling ->
                openSibling(treeUri, docId, sibling)
            }
            if (detection.error != null) continue
            val system = when {
                detection.archive -> Systems.hintFromFolders(folders)?.takeIf { it.id !in Systems.ARCADE_LIKE || ext == "zip" }
                else -> detection.system ?: detection.candidates.singleOrNull()
            }
            val uriString = uri.toString()
            found.add(
                Game(
                    id = GameLibrary.idFor(uriString),
                    title = GameLibrary.titleFromFileName(f.name),
                    fileName = f.name,
                    uri = uriString,
                    // Vazio = identificar no primeiro toque (o app olha o conteúdo nessa hora).
                    systemId = system?.id ?: "",
                    size = f.size,
                    addedAt = System.currentTimeMillis(),
                    treeUri = treeUri.toString(),
                    parentDocId = docId,
                    folderPath = folders.joinToString("/"),
                )
            )
            onProgress(found.size)
        }
        children.filter { it.isDir }.forEach { walk(treeUri, it.docId, folders + it.name, depth + 1, local, found, onProgress) }
    }
}
