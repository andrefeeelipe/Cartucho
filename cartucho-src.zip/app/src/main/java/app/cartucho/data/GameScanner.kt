package app.cartucho.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.InputStream

/** Indexa uma pasta escolhida pelo usuário (Storage Access Framework), sem permissão de armazenamento amplo. */
class GameScanner(private val context: Context, private val detector: GameDetector) {

    data class Entry(val docId: String, val name: String, val size: Long, val isDir: Boolean)

    fun listChildren(treeUri: Uri, parentDocId: String): List<Entry> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val out = ArrayList<Entry>()
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        runCatching {
            context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val mime = c.getString(3) ?: ""
                    out.add(
                        Entry(
                            docId = c.getString(0),
                            name = c.getString(1) ?: "",
                            size = if (c.isNull(2)) 0L else c.getLong(2),
                            isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR,
                        )
                    )
                }
            }
        }
        return out
    }

    fun openSibling(treeUri: Uri, parentDocId: String, name: String): InputStream? {
        val entry = listChildren(treeUri, parentDocId).firstOrNull { it.name.equals(name, ignoreCase = true) } ?: return null
        val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, entry.docId)
        return context.contentResolver.openInputStream(uri)
    }

    /** Varre a pasta recursivamente (até 6 níveis). Retorna jogos e quantos ficaram ambíguos. */
    fun scan(treeUri: Uri, onProgress: (Int) -> Unit = {}): List<Game> {
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        val found = ArrayList<Game>()
        walk(treeUri, rootId, 0, found, onProgress)
        return found
    }

    private fun walk(treeUri: Uri, docId: String, depth: Int, found: MutableList<Game>, onProgress: (Int) -> Unit) {
        if (depth > 6) return
        val children = listChildren(treeUri, docId)
        val files = children.filter { !it.isDir }
        val names = files.map { it.name.lowercase() }.toSet()
        val hasSheets = names.any { it.endsWith(".cue") || it.endsWith(".gdi") || it.endsWith(".m3u") || it.endsWith(".ccd") }

        // Discos listados em .m3u não aparecem separados.
        val inM3u = HashSet<String>()
        files.filter { it.name.lowercase().endsWith(".m3u") }.forEach { m3u ->
            runCatching {
                val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, m3u.docId)
                context.contentResolver.openInputStream(uri)?.use { s ->
                    s.bufferedReader().readLines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
                        .forEach { inM3u.add(it.substringAfterLast('/').lowercase()) }
                }
            }
        }

        for (f in files) {
            val lower = f.name.lowercase()
            val ext = lower.substringAfterLast('.', "")
            if (ext !in Systems.allExtensions) continue
            if (lower in inM3u) continue
            // Trilhas de .cue/.gdi não viram jogos próprios.
            if (hasSheets && (ext == "bin" || ext == "raw" || ext == "img")) continue
            val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, f.docId)
            val detection = detector.detect(uri, f.name, f.size) { sibling ->
                openSibling(treeUri, docId, sibling)
            }
            val system = detection.system ?: detection.candidates.firstOrNull() ?: continue
            val uriString = uri.toString()
            found.add(
                Game(
                    id = GameLibrary.idFor(uriString),
                    title = GameLibrary.titleFromFileName(f.name),
                    fileName = f.name,
                    uri = uriString,
                    systemId = system.id,
                    size = f.size,
                    addedAt = System.currentTimeMillis(),
                    treeUri = treeUri.toString(),
                    parentDocId = docId,
                )
            )
            onProgress(found.size)
        }
        children.filter { it.isDir }.forEach { walk(treeUri, it.docId, depth + 1, found, onProgress) }
    }
}
