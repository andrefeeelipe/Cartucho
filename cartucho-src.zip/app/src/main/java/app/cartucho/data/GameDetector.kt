package app.cartucho.data

import android.content.Context
import android.net.Uri
import java.io.InputStream
import java.util.zip.ZipInputStream

data class Detection(
    val system: GameSystem?,
    val candidates: List<GameSystem>,
    val error: String? = null,
)

/**
 * Descobre o sistema de um arquivo pela extensão e, quando ambíguo, pelo cabeçalho.
 * [openSibling] abre arquivos da mesma pasta (necessário para .cue -> .bin); pode ser nulo.
 */
class GameDetector(private val context: Context) {

    fun detect(
        uri: Uri,
        fileName: String,
        size: Long,
        openSibling: ((String) -> InputStream?)? = null,
    ): Detection {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext == "7z") {
            return Detection(null, emptyList(), "Arquivos .7z não são suportados. Extraia o jogo ou compacte em .zip.")
        }
        if (ext == "zip") return detectZip(uri)

        val candidates = Systems.candidatesForExtension(ext)
        if (candidates.isEmpty()) return Detection(null, emptyList(), "Formato .$ext não reconhecido.")
        if (candidates.size == 1) return Detection(candidates.first(), candidates)

        val sniffed: String? = runCatching {
            when (ext) {
                "bin" -> open(uri)?.use { sniffBin(it, size) }
                "iso" -> open(uri)?.use { sniffIso(it, size) }
                "cue" -> sniffCue(uri, openSibling)
                "pbp" -> open(uri)?.use { sniffPbp(it) }
                "cso" -> if (size > 1_900_000_000L) "ps2" else "psp"
                "m3u" -> "psx"
                else -> null
            }
        }.getOrNull()

        val chosen = sniffed?.let { Systems.get(it) }
        // .chd e .cso continuam ambíguos de verdade: deixamos o usuário confirmar.
        val confident = chosen != null && ext !in setOf("chd", "cso", "m3u")
        return Detection(if (confident) chosen else null, orderWithFirst(candidates, chosen))
    }

    private fun orderWithFirst(list: List<GameSystem>, first: GameSystem?): List<GameSystem> =
        if (first == null) list else listOf(first) + list.filter { it.id != first.id }

    private fun open(uri: Uri): InputStream? = context.contentResolver.openInputStream(uri)

    private fun detectZip(uri: Uri): Detection {
        val arcade = Systems.get("arcade")!!
        val inner = runCatching {
            open(uri)?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var found: GameSystem? = null
                    var count = 0
                    while (count < 64) {
                        val entry = zip.nextEntry ?: break
                        count++
                        if (entry.isDirectory) continue
                        val e = entry.name.substringAfterLast('.', "").lowercase()
                        val cands = Systems.candidatesForExtension(e).filter { it.id != "arcade" }
                        if (cands.size == 1) { found = cands.first(); break }
                    }
                    found
                }
            }
        }.getOrNull()
        return if (inner != null) Detection(inner, listOf(inner, arcade)) else Detection(arcade, listOf(arcade))
    }

    private fun readBytes(input: InputStream, offset: Long, length: Int): ByteArray? {
        var toSkip = offset
        while (toSkip > 0) {
            val s = input.skip(toSkip)
            if (s <= 0) {
                if (input.read() < 0) return null
                toSkip -= 1
            } else {
                toSkip -= s
            }
        }
        val buf = ByteArray(length)
        var read = 0
        while (read < length) {
            val r = input.read(buf, read, length - read)
            if (r < 0) break
            read += r
        }
        return if (read == length) buf else null
    }

    private fun ascii(b: ByteArray, from: Int, len: Int): String =
        String(b, from, minOf(len, b.size - from), Charsets.ISO_8859_1)

    /** Lê até 0x9400 bytes cobrindo cabeçalho de cartucho, setor 0 de CD e o PVD do ISO9660. */
    private fun sniffBin(input: InputStream, size: Long): String? {
        val head = readBytes(input, 0, 0x9400) ?: return if (size in 1..65536) "atari2600" else null
        val isRawCd = head[0] == 0.toByte() && (1..10).all { head[it] == 0xFF.toByte() } && head[11] == 0.toByte()
        if (isRawCd) {
            val sector0 = ascii(head, 0x10, 16)
            if (sector0.startsWith("SEGADISCSYSTEM")) return "segacd"
            if (sector0.startsWith("SEGA SEGASATURN")) return "saturn"
            val pvd = 16 * 2352 + 0x18
            if (pvd + 40 <= head.size && ascii(head, pvd + 1, 5) == "CD001") {
                val sysId = ascii(head, pvd + 8, 32)
                if (sysId.contains("PLAYSTATION")) return "psx"
            }
            return "psx"
        }
        if (ascii(head, 0x100, 4) == "SEGA") return "megadrive"
        if (size in 1..65536) return "atari2600"
        return "megadrive"
    }

    private fun sniffIso(input: InputStream, size: Long): String? {
        val head = readBytes(input, 0, 0x8030) ?: return null
        val sector0 = ascii(head, 0, 16)
        if (sector0.startsWith("SEGADISCSYSTEM")) return "segacd"
        if (sector0.startsWith("SEGA SEGASATURN")) return "saturn"
        if (ascii(head, 0x8001, 5) == "CD001") {
            val sysId = ascii(head, 0x8008, 32)
            if (sysId.contains("PSP GAME")) return "psp"
            if (sysId.contains("PLAYSTATION")) return if (size > 800_000_000L) "ps2" else "psx"
        }
        return if (size > 800_000_000L) "ps2" else null
    }

    private fun sniffCue(uri: Uri, openSibling: ((String) -> InputStream?)?): String? {
        val text = open(uri)?.use { it.readBytes().toString(Charsets.ISO_8859_1) } ?: return null
        val binName = Regex("""FILE\s+"([^"]+)"""").find(text)?.groupValues?.get(1)
            ?: Regex("""FILE\s+(\S+)""").find(text)?.groupValues?.get(1)
            ?: return null
        val stream = openSibling?.invoke(binName) ?: return "psx"
        return stream.use { sniffBin(it, Long.MAX_VALUE) }
    }

    private fun sniffPbp(input: InputStream): String? {
        val header = readBytes(input, 0, 0x28) ?: return null
        if (ascii(header, 1, 3) != "PBP") return "psp"
        val psarOffset = (header[0x24].toLong() and 0xff) or
            ((header[0x25].toLong() and 0xff) shl 8) or
            ((header[0x26].toLong() and 0xff) shl 16) or
            ((header[0x27].toLong() and 0xff) shl 24)
        val psar = readBytes(input, psarOffset - 0x28, 12) ?: return "psp"
        val magic = ascii(psar, 0, 12)
        return if (magic.startsWith("PSISOIMG") || magic.startsWith("PSTITLEIMG")) "psx" else "psp"
    }
}
