package app.cartucho.data

import android.content.Context
import android.net.Uri
import java.io.InputStream

data class Detection(
    val system: GameSystem?,
    val candidates: List<GameSystem>,
    val error: String? = null,
    /** Arquivo compactado: precisa de cópia local para olhar o conteúdo (ver GameResolver). */
    val archive: Boolean = false,
    /** Arquivo de dentro do compactado que é o jogo (para dar nome a pacotes como "drive-download-…"). */
    val mainName: String? = null,
    /** Compactado com vários jogos: quantos foram para a biblioteca. */
    val pack: Int = 0,
)

/**
 * Descobre o sistema de um arquivo pela extensão e, quando ambíguo, pelo cabeçalho.
 * [openSibling] abre arquivos da mesma pasta (necessário para .cue -> .bin); pode ser nulo.
 */
class GameDetector(private val context: Context) {

    fun detect(
        uri: Uri,
        fileName: String,
        size: Long,
        folders: List<String> = emptyList(),
        sniff: Boolean = true,
        openSibling: ((String) -> InputStream?)? = null,
    ): Detection {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (Archives.isArchive(fileName)) {
            return Detection(null, emptyList(), archive = true)
        }

        val candidates = Systems.candidatesForExtension(ext)
        if (candidates.isEmpty()) return Detection(null, emptyList(), "Formato .$ext não reconhecido.")
        if (candidates.size == 1) return Detection(candidates.first(), candidates)

        val hint = Systems.hintFromFolders(folders)?.takeIf { h -> candidates.any { it.id == h.id } }
        if (!sniff) {
            return Detection(hint, orderWithFirst(candidates, hint))
        }

        val sniffed: String? = runCatching {
            when (ext) {
                "bin" -> open(uri)?.use { sniffBin(it, size) }
                "iso" -> open(uri)?.use { sniffIso(it, size) }
                "cue" -> sniffCue(uri, openSibling)
                "pbp" -> open(uri)?.use { sniffPbp(it) }
                "cso" -> if (size > 1_900_000_000L) "ps2" else "psp"
                "rvz", "wia" -> open(uri)?.use { sniffWia(it) }
                "m3u" -> "psx"
                else -> null
            }
        }.getOrNull()

        // Discos sem assinatura confiável (3DO, Neo Geo CD, PC-FX): a pasta manda.
        if (hint != null && hint.id in setOf("3do", "neogeocd", "pcfx") && sniffed !in setOf("gamecube", "wii")) {
            return Detection(hint, orderWithFirst(candidates, hint))
        }
        val sniffedSystem = sniffed?.let { Systems.get(it) }
        // .chd e .cso continuam ambíguos de verdade: a dica da pasta decide; senão, o usuário confirma.
        val confident = sniffedSystem != null && ext !in setOf("chd", "cso", "m3u")
        val chosen = when {
            confident -> sniffedSystem
            hint != null -> hint
            else -> null
        }
        return Detection(chosen, orderWithFirst(candidates, chosen ?: sniffedSystem))
    }

    /** Detecta um arquivo já disponível localmente (extraído ou copiado). */
    fun detectFile(file: java.io.File, folders: List<String> = emptyList()): Detection =
        detect(Uri.fromFile(file), file.name, file.length(), folders) { sibling ->
            java.io.File(file.parentFile, sibling).takeIf { it.exists() }?.inputStream()
        }

    private fun orderWithFirst(list: List<GameSystem>, first: GameSystem?): List<GameSystem> =
        if (first == null) list else listOf(first) + list.filter { it.id != first.id }

    private fun open(uri: Uri): InputStream? = context.contentResolver.openInputStream(uri)

    private fun readBytes(input: InputStream, offset: Long, length: Int): ByteArray? {
        var toSkip = offset
        while (toSkip > 0) {
            val s = input.skip(toSkip)
            if (s <= 0) {
                if (input.read() < 0) return null
                toSkip -= 1
            } else {
                toSkip -= s
            }
        }
        val buf = ByteArray(length)
        var read = 0
        while (read < length) {
            val r = input.read(buf, read, length - read)
            if (r < 0) break
            read += r
        }
        return if (read == length) buf else null
    }

    private fun ascii(b: ByteArray, from: Int, len: Int): String =
        String(b, from, minOf(len, b.size - from), Charsets.ISO_8859_1)

    /** Lê até 0x9400 bytes cobrindo cabeçalho de cartucho, setor 0 de CD e o PVD do ISO9660. */
    private fun sniffBin(input: InputStream, size: Long): String? {
        val head = readBytes(input, 0, 0x9400) ?: return if (size in 1..65536) "atari2600" else null
        val isRawCd = head[0] == 0.toByte() && (1..10).all { head[it] == 0xFF.toByte() } && head[11] == 0.toByte()
        if (isRawCd) {
            if (is3do(head, 0x10)) return "3do"
            val sector0 = ascii(head, 0x10, 16)
            if (sector0.startsWith("SEGADISCSYSTEM")) return "segacd"
            if (sector0.startsWith("SEGA SEGASATURN")) return "saturn"
            if (sector0.startsWith("SEGA SEGAKATANA")) return "dreamcast"
            val pvd = 16 * 2352 + 0x18
            if (pvd + 40 <= head.size && ascii(head, pvd + 1, 5) == "CD001") {
                val sysId = ascii(head, pvd + 8, 32)
                if (sysId.contains("PLAYSTATION")) return "psx"
            }
            return "psx"
        }
        if (is3do(head, 0)) return "3do"
        if (ascii(head, 0x100, 4) == "SEGA") return "megadrive"
        if (ascii(head, 0x8001, 5) == "CD001") {
            val sysId = ascii(head, 0x8008, 32)
            if (sysId.contains("PSP GAME")) return "psp"
            if (sysId.contains("PLAYSTATION")) return if (size > 800_000_000L) "ps2" else "psx"
        }
        if (size in 1..65536) return "atari2600"
        return "megadrive"
    }

    /** RVZ/WIA (Dolphin): o tipo de disco fica logo depois do primeiro cabeçalho (1 = GameCube, 2 = Wii). */
    private fun sniffWia(input: InputStream): String? {
        val head = readBytes(input, 0, 0x4C) ?: return null
        val type = ((head[0x48].toInt() and 0xff) shl 24) or ((head[0x49].toInt() and 0xff) shl 16) or
            ((head[0x4A].toInt() and 0xff) shl 8) or (head[0x4B].toInt() and 0xff)
        return when (type) { 1 -> "gamecube"; 2 -> "wii"; else -> null }
    }

    private fun gcWiiMagic(head: ByteArray): String? {
        if (head.size < 0x20) return null
        fun be(o: Int) = ((head[o].toLong() and 0xff) shl 24) or ((head[o + 1].toLong() and 0xff) shl 16) or
            ((head[o + 2].toLong() and 0xff) shl 8) or (head[o + 3].toLong() and 0xff)
        if (be(0x18) == 0x5D1C9EA3L) return "wii"
        if (be(0x1C) == 0xC2339F3DL) return "gamecube"
        return null
    }

    /** Disco 3DO: registro de volume Opera (0x01, cinco 0x5A, 0x01). */
    private fun is3do(head: ByteArray, at: Int): Boolean =
        head.size > at + 7 && head[at] == 1.toByte() && (1..5).all { head[at + it] == 0x5A.toByte() } && head[at + 6] == 1.toByte()

    private fun sniffIso(input: InputStream, size: Long): String? {
        val head = readBytes(input, 0, 0x8030) ?: return null
        gcWiiMagic(head)?.let { return it }
        if (is3do(head, 0)) return "3do"
        val sector0 = ascii(head, 0, 16)
        if (sector0.startsWith("SEGADISCSYSTEM")) return "segacd"
        if (sector0.startsWith("SEGA SEGASATURN")) return "saturn"
        if (ascii(head, 0x8001, 5) == "CD001") {
            val sysId = ascii(head, 0x8008, 32)
            if (sysId.contains("PSP GAME")) return "psp"
            if (sysId.contains("PLAYSTATION")) return if (size > 800_000_000L) "ps2" else "psx"
        }
        // Xbox 360 (XDVDFS): "MICROSOFT*XBOX*MEDIA" no setor 32 da partição do jogo.
        if (isXboxIso(input, head.size.toLong())) return "xbox360"
        return null
    }

    /**
     * Xbox 360 (XDVDFS): "MICROSOFT*XBOX*MEDIA" 64 KB depois do início da partição do jogo.
     * A partição começa em 0 (xiso), 0x2080000 (XGD3, redump) ou 0xFD90000 (XGD2, redump).
     */
    private fun isXboxIso(input: InputStream, alreadyRead: Long): Boolean {
        var pos = alreadyRead
        for (start in longArrayOf(0L, 0x2080000L, 0xFD90000L)) {
            val at = start + 0x10000L
            if (at < pos) continue
            val tag = readBytes(input, at - pos, 20) ?: return false
            pos = at + 20
            if (ascii(tag, 0, 20) == "MICROSOFT*XBOX*MEDIA") return true
        }
        return false
    }

    private fun sniffCue(uri: Uri, openSibling: ((String) -> InputStream?)?): String? {
        val text = open(uri)?.use { it.readBytes().toString(Charsets.ISO_8859_1) } ?: return null
        val binName = Regex("""FILE\s+"([^"]+)"""").find(text)?.groupValues?.get(1)
            ?: Regex("""FILE\s+(\S+)""").find(text)?.groupValues?.get(1)
            ?: return null
        val stream = openSibling?.invoke(binName) ?: return "psx"
        return stream.use { sniffBin(it, Long.MAX_VALUE) }
    }

    private fun sniffPbp(input: InputStream): String? {
        val header = readBytes(input, 0, 0x28) ?: return null
        if (ascii(header, 1, 3) != "PBP") return "psp"
        val psarOffset = (header[0x24].toLong() and 0xff) or
            ((header[0x25].toLong() and 0xff) shl 8) or
            ((header[0x26].toLong() and 0xff) shl 16) or
            ((header[0x27].toLong() and 0xff) shl 24)
        val psar = readBytes(input, psarOffset - 0x28, 12) ?: return "psp"
        val magic = ascii(psar, 0, 12)
        return if (magic.startsWith("PSISOIMG") || magic.startsWith("PSTITLEIMG")) "psx" else "psp"
    }
}
