package app.cartucho.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Capas automáticas a partir do acervo aberto libretro-thumbnails (GitHub).
 * Para cada sistema baixa uma vez o índice de nomes, encontra o título mais parecido
 * (ignorando região, versão e marcas de tradução) e salva a capa no aparelho.
 */
class Covers(private val context: Context) {
    private val dir = File(context.filesDir, "covers").apply { mkdirs() }
    private val indexDir = File(dir, "index").apply { mkdirs() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    private val indexCache = HashMap<String, List<String>>()

    private val _version = MutableStateFlow(0)
    /** Muda sempre que uma capa nova chega (a interface usa para redesenhar). */
    val version: StateFlow<Int> = _version.asStateFlow()

    private val repos: Map<String, List<String>> = mapOf(
        "atari2600" to listOf("Atari_-_2600"),
        "atari7800" to listOf("Atari_-_7800"),
        "lynx" to listOf("Atari_-_Lynx"),
        "nes" to listOf("Nintendo_-_Nintendo_Entertainment_System", "Nintendo_-_Family_Computer_Disk_System"),
        "snes" to listOf("Nintendo_-_Super_Nintendo_Entertainment_System"),
        "gb" to listOf("Nintendo_-_Game_Boy"),
        "gbc" to listOf("Nintendo_-_Game_Boy_Color"),
        "gba" to listOf("Nintendo_-_Game_Boy_Advance"),
        "mastersystem" to listOf("Sega_-_Master_System_-_Mark_III"),
        "gamegear" to listOf("Sega_-_Game_Gear"),
        "megadrive" to listOf("Sega_-_Mega_Drive_-_Genesis"),
        "segacd" to listOf("Sega_-_Mega-CD_-_Sega_CD"),
        "sega32x" to listOf("Sega_-_32X"),
        "pce" to listOf("NEC_-_PC_Engine_-_TurboGrafx_16", "NEC_-_PC_Engine_SuperGrafx"),
        "pcecd" to listOf("NEC_-_PC_Engine_CD_-_TurboGrafx-CD"),
        "ngp" to listOf("SNK_-_Neo_Geo_Pocket_Color", "SNK_-_Neo_Geo_Pocket"),
        "wswan" to listOf("Bandai_-_WonderSwan_Color", "Bandai_-_WonderSwan"),
        "arcade" to listOf("FBNeo_-_Arcade_Games", "MAME"),
        "n64" to listOf("Nintendo_-_Nintendo_64"),
        "nds" to listOf("Nintendo_-_Nintendo_DS"),
        "psx" to listOf("Sony_-_PlayStation"),
        "psp" to listOf("Sony_-_PlayStation_Portable"),
        "saturn" to listOf("Sega_-_Saturn"),
        "dreamcast" to listOf("Sega_-_Dreamcast"),
        "ps2" to listOf("Sony_-_PlayStation_2"),
    )

    fun file(gameId: String): File = File(dir, "$gameId.png")
    private fun missMarker(gameId: String): File = File(dir, "$gameId.none")

    fun hasCover(gameId: String): Boolean = file(gameId).exists()

    /** Procura capas para os jogos que ainda não têm (respeita uma pausa de 3 dias para quem não achou). */
    fun enqueue(games: List<Game>, enabled: Boolean) {
        if (!enabled) return
        val pending = games.filter { g ->
            g.systemKnown && !file(g.id).exists() &&
                missMarker(g.id).let { !it.exists() || System.currentTimeMillis() - it.lastModified() > 3L * 24 * 3600 * 1000 }
        }
        if (pending.isEmpty()) return
        scope.launch {
            mutex.withLock {
                for (g in pending) {
                    if (file(g.id).exists()) continue
                    val ok = runCatching { fetch(g) }.getOrDefault(false)
                    if (ok) _version.value = _version.value + 1 else missMarker(g.id).writeText("")
                }
            }
        }
    }

    fun clearMiss(gameId: String) {
        missMarker(gameId).delete()
    }

    private fun fetch(game: Game): Boolean {
        val systemRepos = repos[game.systemId] ?: return false
        val wanted = game.fileName.substringBeforeLast('.')
        for (repo in systemRepos) {
            val names = index(repo) ?: continue
            val best = bestMatch(wanted, names) ?: continue
            val url = "https://raw.githubusercontent.com/libretro-thumbnails/$repo/master/Named_Boxarts/${Uri.encode(best)}.png"
            val ok = http.newCall(Request.Builder().url(url).build()).execute().use { resp ->
                if (!resp.isSuccessful) return@use false
                val tmp = File(dir, "${game.id}.part")
                resp.body?.byteStream()?.use { i -> tmp.outputStream().use { i.copyTo(it) } } ?: return@use false
                tmp.renameTo(file(game.id))
            }
            if (ok) return true
        }
        return false
    }

    /** Nomes das capas disponíveis (sem extensão), guardados por 30 dias. */
    private fun index(repo: String): List<String>? {
        indexCache[repo]?.let { return it }
        val cacheFile = File(indexDir, "$repo.txt")
        if (cacheFile.exists() && System.currentTimeMillis() - cacheFile.lastModified() < 30L * 24 * 3600 * 1000) {
            return cacheFile.readLines().filter { it.isNotEmpty() }.also { indexCache[repo] = it }
        }
        for (branch in listOf("master", "main")) {
            val url = "https://api.github.com/repos/libretro-thumbnails/$repo/git/trees/$branch?recursive=1"
            val req = Request.Builder().url(url).header("Accept", "application/vnd.github+json").header("User-Agent", "Cartucho").build()
            val names = http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val json = JSONObject(resp.body?.string().orEmpty())
                val tree = json.optJSONArray("tree") ?: return@use null
                (0 until tree.length()).mapNotNull { i ->
                    val path = tree.getJSONObject(i).optString("path")
                    if (path.startsWith("Named_Boxarts/") && path.endsWith(".png")) {
                        path.removePrefix("Named_Boxarts/").removeSuffix(".png")
                    } else {
                        null
                    }
                }
            } ?: continue
            cacheFile.writeText(names.joinToString("\n"))
            indexCache[repo] = names
            return names
        }
        return null
    }

    companion object {
        private val tags = Regex("""[\(\[][^\)\]]*[\)\]]""")
        private val noise = Regex(
            """\b(br|pt|ptbr|pt-br|traduzido|traducao|tradução|translated|translation|hack|beta|proto|rev\s*\w+|v\d+(\.\d+)*)\b""",
            RegexOption.IGNORE_CASE,
        )

        /** Forma comparável de um título: sem tags, sem "The", sem pontuação. */
        fun normalize(name: String): String {
            var s = name.replace(tags, " ").replace('_', ' ')
            s = s.replace(noise, " ")
            s = s.replace("&", " and ").lowercase()
            s = s.replace(Regex("""\bthe\b"""), " ")
            s = s.replace(Regex("""[^a-z0-9]"""), "")
            return s
        }

        private val regionOrder = listOf("(usa", "(world", "(brazil", "(europe", "(japan, usa", "(japan")

        private fun regionScore(name: String): Int {
            val lower = name.lowercase()
            val idx = regionOrder.indexOfFirst { lower.contains(it) }
            return if (idx < 0) regionOrder.size else idx
        }

        fun bestMatch(fileStem: String, names: List<String>): String? {
            names.firstOrNull { it.equals(fileStem, ignoreCase = true) }?.let { return it }
            val target = normalize(fileStem)
            if (target.length < 2) return null
            val exact = names.filter { normalize(it) == target }
            if (exact.isNotEmpty()) return exact.minByOrNull { regionScore(it) }
            // Título com subtítulo a mais ou a menos ("Zelda" x "Zelda - A Link to the Past").
            val partial = names.filter {
                val n = normalize(it)
                n.length >= 4 && (n.startsWith(target) || target.startsWith(n)) && kotlin.math.abs(n.length - target.length) <= 12
            }
            return partial.minWithOrNull(compareBy({ kotlin.math.abs(normalize(it).length - target.length) }, { regionScore(it) }))
        }
    }
}
