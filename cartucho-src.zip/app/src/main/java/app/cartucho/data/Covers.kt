package app.cartucho.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Capas para todos os jogos, nesta ordem:
 * 1. acervo aberto libretro-thumbnails (GitHub): título mais parecido, ignorando região, versão e tradução;
 * 2. busca na Wikipédia (inglês e português): imagem principal do artigo do jogo, normalmente a capa;
 * 3. capa gerada no próprio aparelho, com o nome do jogo e do sistema — nenhum jogo fica sem capa.
 * Capas geradas são trocadas sozinhas quando uma capa real aparece; a escolhida pelo usuário nunca é trocada.
 */
class Covers(private val context: Context) {
    private val dir = File(context.filesDir, "covers").apply { mkdirs() }
    private val indexDir = File(dir, "index").apply { mkdirs() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    private val indexCache = HashMap<String, List<String>>()
    private val titleIndexCache = HashMap<String, List<String>>()

    private val _version = MutableStateFlow(0)
    /** Muda sempre que uma capa nova chega (a interface usa para redesenhar). */
    val version: StateFlow<Int> = _version.asStateFlow()

    private val repos: Map<String, List<String>> = mapOf(
        "atari2600" to listOf("Atari_-_2600"),
        "atari7800" to listOf("Atari_-_7800"),
        "lynx" to listOf("Atari_-_Lynx"),
        "nes" to listOf("Nintendo_-_Nintendo_Entertainment_System", "Nintendo_-_Family_Computer_Disk_System"),
        "snes" to listOf("Nintendo_-_Super_Nintendo_Entertainment_System", "Nintendo_-_Satellaview"),
        "gb" to listOf("Nintendo_-_Game_Boy", "Nintendo_-_Game_Boy_Color"),
        "gbc" to listOf("Nintendo_-_Game_Boy_Color", "Nintendo_-_Game_Boy"),
        "gba" to listOf("Nintendo_-_Game_Boy_Advance"),
        "mastersystem" to listOf("Sega_-_Master_System_-_Mark_III", "Sega_-_SG-1000"),
        "gamegear" to listOf("Sega_-_Game_Gear"),
        "megadrive" to listOf("Sega_-_Mega_Drive_-_Genesis"),
        "segacd" to listOf("Sega_-_Mega-CD_-_Sega_CD"),
        "sega32x" to listOf("Sega_-_32X"),
        "pce" to listOf("NEC_-_PC_Engine_-_TurboGrafx_16", "NEC_-_PC_Engine_SuperGrafx"),
        "pcecd" to listOf("NEC_-_PC_Engine_CD_-_TurboGrafx-CD"),
        "ngp" to listOf("SNK_-_Neo_Geo_Pocket_Color", "SNK_-_Neo_Geo_Pocket"),
        "wswan" to listOf("Bandai_-_WonderSwan_Color", "Bandai_-_WonderSwan"),
        "arcade" to listOf("FBNeo_-_Arcade_Games", "MAME"),
        "n64" to listOf("Nintendo_-_Nintendo_64"),
        "nds" to listOf("Nintendo_-_Nintendo_DS"),
        "3ds" to listOf("Nintendo_-_Nintendo_3DS"),
        "psx" to listOf("Sony_-_PlayStation"),
        "psp" to listOf("Sony_-_PlayStation_Portable"),
        "saturn" to listOf("Sega_-_Saturn"),
        "dreamcast" to listOf("Sega_-_Dreamcast"),
        "ps2" to listOf("Sony_-_PlayStation_2"),
        "gamecube" to listOf("Nintendo_-_GameCube"),
        "wii" to listOf("Nintendo_-_Wii", "Nintendo_-_Wii_(Digital)"),
        "3do" to listOf("The_3DO_Company_-_3DO"),
        "jaguar" to listOf("Atari_-_Jaguar"),
        "atari5200" to listOf("Atari_-_5200"),
        "atari800" to listOf("Atari_-_8-bit"),
        "vectrex" to listOf("GCE_-_Vectrex"),
        "virtualboy" to listOf("Nintendo_-_Virtual_Boy"),
        "neogeocd" to listOf("SNK_-_Neo_Geo_CD"),
        "pcfx" to listOf("NEC_-_PC-FX"),
        "colecovision" to listOf("Coleco_-_ColecoVision"),
        "intellivision" to listOf("Mattel_-_Intellivision"),
        "odyssey2" to listOf("Magnavox_-_Odyssey2"),
        "channelf" to listOf("Fairchild_-_Channel_F"),
        "msx" to listOf("Microsoft_-_MSX", "Microsoft_-_MSX2"),
        "zxspectrum" to listOf("Sinclair_-_ZX_Spectrum"),
        "amstradcpc" to listOf("Amstrad_-_CPC"),
        "c64" to listOf("Commodore_-_64"),
        "amiga" to listOf("Commodore_-_Amiga"),
        "dos" to listOf("DOS"),
        "pokemini" to listOf("Nintendo_-_Pokemon_Mini"),
        "supervision" to listOf("Watara_-_Supervision"),
        "arduboy" to listOf("Arduboy_Inc_-_Arduboy"),
        "gameandwatch" to listOf("Handheld_Electronic_Game"),
        "wiiu" to listOf("Nintendo_-_Wii_U"),
        "xbox360" to listOf("Microsoft_-_Xbox_360"),
    )

    fun file(gameId: String): File = File(dir, "$gameId.png")
    /** Marca de capa gerada no aparelho (será trocada quando uma capa real for encontrada). */
    private fun generatedMarker(gameId: String): File = File(dir, "$gameId.gen")
    /** Marca de capa escolhida pelo usuário (nunca é trocada). */
    private fun manualMarker(gameId: String): File = File(dir, "$gameId.manual")

    fun hasCover(gameId: String): Boolean = file(gameId).exists()
    fun isGenerated(gameId: String): Boolean = generatedMarker(gameId).exists()

    /**
     * Garante capa para todos os jogos: procura online (quando permitido) e, se não achar,
     * fica a capa gerada no aparelho. Capas geradas voltam a ser procuradas online a cada 3 dias.
     */
    fun enqueue(games: List<Game>, enabled: Boolean) {
        val now = System.currentTimeMillis()
        val pending = games.filter { g ->
            when {
                manualMarker(g.id).exists() -> false
                !file(g.id).exists() -> true
                // Capa gerada: procura de novo a cada 3 dias, ou já, se a busca ficou melhor desde então.
                else -> enabled && generatedMarker(g.id).let {
                    it.exists() && (now - it.lastModified() > RETRY_MS || runCatching { it.readText() }.getOrDefault("") != SEARCH_VERSION)
                }
            }
        }
        if (pending.isEmpty()) return
        scope.launch {
            mutex.withLock {
                // Primeiro uma capa gerada para quem não tem nada: a biblioteca nunca mostra cartão vazio.
                var generated = false
                for (g in pending) {
                    if (!file(g.id).exists() && runCatching { generate(g) }.isSuccess) generated = true
                }
                if (generated) _version.value = _version.value + 1
                if (!enabled) return@withLock
                for (g in pending) {
                    if (manualMarker(g.id).exists()) continue
                    if (runCatching { fetch(g) }.getOrDefault(false)) {
                        generatedMarker(g.id).delete()
                        _version.value = _version.value + 1
                    } else {
                        generatedMarker(g.id).let { if (it.exists()) it.writeText(SEARCH_VERSION) }
                    }
                }
            }
        }
    }

    /** Procura de novo agora, sem esperar a pausa de 3 dias (opção "Procurar capa de novo"). */
    fun retry(game: Game) {
        scope.launch {
            mutex.withLock {
                manualMarker(game.id).delete()
                if (runCatching { fetch(game) }.getOrDefault(false)) {
                    generatedMarker(game.id).delete()
                } else if (!file(game.id).exists()) {
                    runCatching { generate(game) }
                }
                _version.value = _version.value + 1
            }
        }
    }

    /** Usa uma imagem escolhida pelo usuário como capa. Bloqueante: chame fora da thread principal. */
    fun setManual(gameId: String, uri: Uri): Boolean {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        if (!saveImage(gameId, bytes)) return false
        generatedMarker(gameId).delete()
        manualMarker(gameId).writeText("")
        _version.value = _version.value + 1
        return true
    }

    fun clearMiss(gameId: String) {
        generatedMarker(gameId).let { if (it.exists()) it.setLastModified(0L) }
    }

    /** Capa (caixa) → Wikipédia → tela-título do jogo; só então fica a capa gerada. */
    private fun fetch(game: Game): Boolean =
        fetchLibretro(game, "Named_Boxarts") || fetchWikipedia(game) || fetchLibretro(game, "Named_Titles")

    /**
     * Acervos onde procurar: o do sistema do jogo; se o sistema ainda não é conhecido
     * (comum em .zip da nuvem), os sugeridos pela pasta e pela extensão e, por fim, todos.
     */
    private fun reposFor(game: Game): List<String> {
        repos[game.systemId]?.let { return it }
        val hinted = Systems.hintFromFolders(game.folders)?.id?.let { repos[it] }.orEmpty()
        val ext = game.fileName.substringAfterLast('.', "").lowercase()
        val byExt = Systems.candidatesForExtension(ext).flatMap { repos[it.id].orEmpty() }
        return (hinted + byExt + repos.values.flatten()).distinct()
    }

    private fun fetchLibretro(game: Game, kind: String): Boolean {
        val wanted = game.fileName.substringBeforeLast('.')
        val known = repos.containsKey(game.systemId)
        var bestRepo: String? = null
        var bestName: String? = null
        var bestScore = 0.0
        for (repo in reposFor(game)) {
            val names = (if (kind == "Named_Boxarts") index(repo) else titleIndex(repo)) ?: continue
            val match = bestMatch(wanted, names) ?: bestMatch(game.title, names) ?: continue
            val score = if (normalize(match) == normalize(wanted)) 1.0 else similarity(wanted, match)
            if (score > bestScore) {
                bestScore = score
                bestRepo = repo
                bestName = match
            }
            // Sistema conhecido: o primeiro acervo que tiver o jogo resolve.
            if (known || score >= 1.0) break
        }
        val repo = bestRepo ?: return false
        val name = bestName ?: return false
        val url = "https://raw.githubusercontent.com/libretro-thumbnails/$repo/master/$kind/${Uri.encode(name)}.png"
        val bytes = download(url) ?: return false
        return saveImage(game.id, bytes)
    }

    /** Wikipédia: busca o artigo do jogo e usa a imagem principal (normalmente a capa). */
    private fun fetchWikipedia(game: Game): Boolean {
        val title = game.title.ifEmpty { game.fileName.substringBeforeLast('.') }
        val systemName = Systems.get(game.systemId)?.name.orEmpty()
        val queries = listOf("$title $systemName video game", "$title video game", "$title jogo eletrônico", title).distinct()
        for (host in listOf("en.wikipedia.org", "pt.wikipedia.org")) {
            for (q in queries) {
                val url = "https://$host/w/api.php?action=query&format=json&redirects=1&generator=search" +
                    "&gsrnamespace=0&gsrlimit=6&gsrsearch=${Uri.encode(q)}&prop=pageimages&piprop=original&pilicense=any"
                val json = download(url)?.let { runCatching { JSONObject(String(it)) }.getOrNull() } ?: continue
                val pages = json.optJSONObject("query")?.optJSONObject("pages") ?: continue
                val candidates = pages.keys().asSequence().mapNotNull { k ->
                    val p = pages.getJSONObject(k)
                    val image = p.optJSONObject("original")?.optString("source").orEmpty()
                    if (image.isEmpty() || image.endsWith(".svg", ignoreCase = true)) {
                        null
                    } else {
                        Triple(p.optInt("index", 99), p.optString("title"), image)
                    }
                }.filter { similarity(title, it.second.substringBefore(" (")) >= 0.5 }
                    .sortedBy { it.first }
                    .toList()
                for (cand in candidates) {
                    val bytes = download(cand.third) ?: continue
                    if (saveImage(game.id, bytes)) return true
                }
            }
        }
        return false
    }

    private fun download(url: String): ByteArray? {
        val req = Request.Builder().url(url)
            .header("User-Agent", "Cartucho/1.0 (https://github.com/andrefeeelipe/Cartucho)")
            .build()
        return runCatching {
            http.newCall(req).execute().use { resp -> if (resp.isSuccessful) resp.body?.bytes() else null }
        }.getOrNull()
    }

    /** Decodifica, reduz para no máximo ~720 px e salva; recusa o que não for imagem. */
    private fun saveImage(gameId: String, bytes: ByteArray): Boolean {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 720) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return false
        val tmp = File(dir, "$gameId.part")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return tmp.renameTo(file(gameId))
    }

    /** Capa tipográfica feita no aparelho: sistema no topo e o nome do jogo grande embaixo. */
    private fun generate(game: Game) {
        val w = 512
        val h = 640
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val hue = ((game.systemId.hashCode() and 0x7fffffff) % 360).toFloat()
        val top = Color.HSVToColor(floatArrayOf(hue, 0.30f, 0.30f))
        val bottom = Color.HSVToColor(floatArrayOf(hue, 0.40f, 0.12f))
        val bg = Paint().apply { shader = LinearGradient(0f, 0f, 0f, h.toFloat(), top, bottom, Shader.TileMode.CLAMP) }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        val bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xB3FFFFFF.toInt()
            textSize = 28f
            letterSpacing = 0.12f
            typeface = bold
        }
        canvas.drawText((Systems.get(game.systemId)?.name ?: "Jogo").uppercase(), 40f, 70f, label)
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 58f
            typeface = bold
        }
        val text = game.title.ifEmpty { game.fileName.substringBeforeLast('.') }
        var layout = staticLayout(text, titlePaint, w - 80)
        while (layout.height > h - 200 && titlePaint.textSize > 28f) {
            titlePaint.textSize = titlePaint.textSize - 4f
            layout = staticLayout(text, titlePaint, w - 80)
        }
        canvas.save()
        canvas.translate(40f, (h - layout.height - 60).toFloat().coerceAtLeast(110f))
        layout.draw(canvas)
        canvas.restore()
        val tmp = File(dir, "${game.id}.part")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        if (tmp.renameTo(file(game.id))) generatedMarker(game.id).writeText("")  // ainda não procurada online
    }

    @Suppress("DEPRECATION")
    private fun staticLayout(text: String, paint: TextPaint, width: Int): StaticLayout =
        if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width).setMaxLines(8).build()
        } else {
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1f, 0f, false)
        }

    private fun titleIndex(repo: String): List<String>? {
        titleIndexCache[repo]?.let { return it }
        index(repo)
        return titleIndexCache[repo]
    }

    /** Nomes das capas e telas-título disponíveis (sem extensão), guardados por 30 dias. */
    private fun index(repo: String): List<String>? {
        indexCache[repo]?.let { return it }
        val cacheFile = File(indexDir, "$repo.txt")
        val titlesFile = File(indexDir, "$repo.titles.txt")
        if (cacheFile.exists() && titlesFile.exists() && System.currentTimeMillis() - cacheFile.lastModified() < 30L * 24 * 3600 * 1000) {
            titleIndexCache[repo] = titlesFile.readLines().filter { it.isNotEmpty() }
            return cacheFile.readLines().filter { it.isNotEmpty() }.also { indexCache[repo] = it }
        }
        for (branch in listOf("master", "main")) {
            val url = "https://api.github.com/repos/libretro-thumbnails/$repo/git/trees/$branch?recursive=1"
            val req = Request.Builder().url(url).header("Accept", "application/vnd.github+json").header("User-Agent", "Cartucho").build()
            val paths = runCatching {
                http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use null
                    val json = JSONObject(resp.body?.string().orEmpty())
                    val tree = json.optJSONArray("tree") ?: return@use null
                    (0 until tree.length()).map { i -> tree.getJSONObject(i).optString("path") }
                }
            }.getOrNull() ?: continue
            fun under(folder: String) = paths.filter { it.startsWith("$folder/") && it.endsWith(".png") }
                .map { it.removePrefix("$folder/").removeSuffix(".png") }
            val names = under("Named_Boxarts")
            val titles = under("Named_Titles")
            cacheFile.writeText(names.joinToString("\n"))
            titlesFile.writeText(titles.joinToString("\n"))
            indexCache[repo] = names
            titleIndexCache[repo] = titles
            return names
        }
        // Sem rede agora: usa o índice antigo, se houver.
        if (cacheFile.exists()) {
            if (titlesFile.exists()) titleIndexCache[repo] = titlesFile.readLines().filter { it.isNotEmpty() }
            return cacheFile.readLines().filter { it.isNotEmpty() }.also { indexCache[repo] = it }
        }
        return null
    }

    companion object {
        private const val RETRY_MS = 3L * 24 * 3600 * 1000
        /** Muda quando a busca melhora: capas provisórias de versões antigas são procuradas de novo. */
        private const val SEARCH_VERSION = "2"
        private val normCache = java.util.concurrent.ConcurrentHashMap<String, String>()
        private val tokenCache = java.util.concurrent.ConcurrentHashMap<String, List<String>>()
        private val tags = Regex("""[\(\[][^\)\]]*[\)\]]""")
        private val noise = Regex(
            """\b(br|pt|ptbr|pt-br|traduzido|traducao|tradução|translated|translation|hack|beta|proto|rev\s*\w+|v\d+(\.\d+)*)\b""",
            RegexOption.IGNORE_CASE,
        )
        private val nonWord = Regex("[^a-z0-9]+")
        private val romans = mapOf("ii" to "2", "iii" to "3", "iv" to "4", "vi" to "6", "vii" to "7", "viii" to "8", "ix" to "9")
        private val stopWords = setOf("the", "a", "an", "of", "and", "de", "do", "da", "o", "e")

        /** Forma comparável de um título: sem tags, sem "The", sem pontuação. */
        fun normalize(name: String): String = normCache.getOrPut(name) { normalizeRaw(name) }

        private fun normalizeRaw(name: String): String {
            var s = name.replace(tags, " ").replace('_', ' ')
            s = s.replace(noise, " ")
            s = s.replace("&", " and ").lowercase()
            s = s.replace(Regex("""\bthe\b"""), " ")
            s = s.replace(Regex("""[^a-z0-9]"""), "")
            return s
        }

        /** Palavras do título (sem tags), com algarismos romanos convertidos. */
        fun tokens(name: String): List<String> = tokenCache.getOrPut(name) { tokensRaw(name) }

        private fun tokensRaw(name: String): List<String> =
            name.replace(tags, " ").replace('_', ' ').replace(noise, " ").replace("&", " and ").lowercase()
                .split(nonWord).filter { it.isNotEmpty() && it !in stopWords }
                .map { romans[it] ?: it }

        /** Semelhança 0..1 entre títulos (Dice nas palavras); números diferentes = jogos diferentes. */
        fun similarity(a: String, b: String): Double {
            val ta = tokens(a)
            val tb = tokens(b)
            if (ta.isEmpty() || tb.isEmpty()) return 0.0
            val na = ta.filter { t -> t.all { it.isDigit() } }.toSet()
            val nb = tb.filter { t -> t.all { it.isDigit() } }.toSet()
            if (na != nb) return 0.0
            val sa = ta.toSet()
            val sb = tb.toSet()
            return 2.0 * sa.intersect(sb).size / (sa.size + sb.size)
        }

        private val regionOrder = listOf("(usa", "(world", "(brazil", "(europe", "(japan, usa", "(japan")

        private fun regionScore(name: String): Int {
            val lower = name.lowercase()
            val idx = regionOrder.indexOfFirst { lower.contains(it) }
            return if (idx < 0) regionOrder.size else idx
        }

        fun bestMatch(fileStem: String, names: List<String>): String? {
            names.firstOrNull { it.equals(fileStem, ignoreCase = true) }?.let { return it }
            val target = normalize(fileStem)
            if (target.length < 2) return null
            val exact = names.filter { normalize(it) == target }
            if (exact.isNotEmpty()) return exact.minByOrNull { regionScore(it) }
            // Título com subtítulo a mais ou a menos ("Zelda" x "Zelda - A Link to the Past").
            val partial = names.filter {
                val n = normalize(it)
                n.length >= 4 && (n.startsWith(target) || target.startsWith(n)) && kotlin.math.abs(n.length - target.length) <= 12
            }
            partial.minWithOrNull(compareBy({ kotlin.math.abs(normalize(it).length - target.length) }, { regionScore(it) }))?.let { return it }
            // Por palavras: tolera ordem diferente, pontuação e romanos ("Final Fantasy III" = "Final Fantasy 3").
            val scored = names.map { it to similarity(fileStem, it) }.filter { it.second >= 0.6 }
            val top = scored.maxOfOrNull { it.second } ?: return null
            return scored.filter { it.second >= top - 0.001 }.map { it.first }.minByOrNull { regionScore(it) }
        }
    }
}
