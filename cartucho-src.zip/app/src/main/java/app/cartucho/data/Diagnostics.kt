package app.cartucho.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Relatório de problemas: anota com hora os eventos de controle, de tela e de travamento
 * durante o jogo, para entender casos como a tela branca. Fica só no aparelho (no máximo ~200 KB)
 * e só sai dele quando a pessoa toca em "Enviar relatório".
 */
object Diagnostics {
    private const val MAX = 200 * 1024L
    private val fmt = SimpleDateFormat("dd/MM HH:mm:ss.SSS", Locale("pt", "BR"))

    fun file(context: Context) = File(context.filesDir, "diagnostico.log")

    @Synchronized
    fun log(context: Context, message: String) {
        runCatching {
            val f = file(context)
            if (f.exists() && f.length() > MAX) {
                // Guarda só a metade mais recente.
                val keep = f.readText().takeLast((MAX / 2).toInt())
                f.writeText(keep)
            }
            f.appendText("${fmt.format(Date())}  $message\n")
        }
    }

    /** Abre o compartilhar com o relatório (WhatsApp, e-mail…). */
    fun share(context: Context): Boolean = runCatching {
        val f = file(context)
        if (!f.exists() || f.length() == 0L) return false
        val out = File(context.cacheDir, "share").apply { mkdirs() }.let { File(it, "cartucho-relatorio.txt") }
        f.copyTo(out, overwrite = true)
        val uri = FileProvider.getUriForFile(context, "app.cartucho.files", out)
        val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_SUBJECT, "Relatório do Cartucho")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Enviar relatório").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    }.getOrDefault(false)
}
