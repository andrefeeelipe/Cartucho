package app.cartucho.data

import android.content.Context
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Ficha de colecionador de um jogo: lançamento, desenvolvedora, publicadora, gênero e série vêm da Wikidata
 * (dados abertos, domínio público); o resumo vem da Wikipédia (CC BY-SA), sempre com o crédito e o link.
 * Tudo fica guardado no aparelho depois da primeira busca.
 */
data class GameFacts(
    val found: Boolean,
    val year: String = "",
    val developers: List<String> = emptyList(),
    val publishers: List<String> = emptyList(),
    val genres: List<String> = emptyList(),
    val series: String = "",
    val summary: String = "",
    val sourceTitle: String = "",
    val sourceUrl: String = "",
    val sourceLang: String = "",
)

object GameFactsRepo {
    private const val UA = "Cartucho/1.0 (https://github.com/andrefeeelipe/Cartucho; emulador gratuito)"
    private const val VIDEO_GAME = "Q7889"
    private const val MAX_AGE = 60L * 24 * 3600 * 1000  // 60 dias
    private val http = OkHttpClient.Builder().connectTimeout(12, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()

    private fun cacheFile(context: Context, gameId: String) =
        File(context.filesDir, "colecao/${gameId.replace(Regex("[^A-Za-z0-9._-]"), "_")}.json").apply { parentFile?.mkdirs() }

    /** Lê do aparelho; se não tiver (ou estiver velho), busca na internet. Bloqueante: chame fora da thread principal. */
    fun load(context: Context, game: Game, systemName: String): GameFacts {
        val f = cacheFile(context, game.id)
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < MAX_AGE) {
            runCatching { return fromJson(JSONObject(f.readText())) }
        }
        val facts = runCatching { fetch(game.title, systemName) }.getOrNull() ?: return GameFacts(found = false)
        runCatching { f.writeText(toJson(facts).toString()) }
        return facts
    }

    private fun get(url: okhttp3.HttpUrl): JSONObject? {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Api-User-Agent", UA).build()
        return http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string()?.let { JSONObject(it) } else null }
    }

    private fun fetch(title: String, systemName: String): GameFacts {
        // Português primeiro; se o jogo não tiver página em português, inglês.
        for ((lang, hint) in listOf("pt" to "jogo eletrônico", "en" to "video game")) {
            val search = get(
                "https://$lang.wikipedia.org/w/api.php".toHttpUrl().newBuilder()
                    .addQueryParameter("action", "query").addQueryParameter("list", "search")
                    .addQueryParameter("srsearch", "$title $hint $systemName").addQueryParameter("srlimit", "5")
                    .addQueryParameter("format", "json").build(),
            ) ?: continue
            val hits = search.optJSONObject("query")?.optJSONArray("search") ?: continue
            for (i in 0 until hits.length()) {
                val pageTitle = hits.getJSONObject(i).optString("title")
                if (pageTitle.isBlank() || !similar(title, pageTitle)) continue
                val facts = page(lang, pageTitle) ?: continue
                return facts
            }
        }
        return GameFacts(found = false)
    }

    /** O nome da página precisa lembrar o do jogo (evita trazer a ficha de outro). */
    private fun similar(game: String, page: String): Boolean {
        fun norm(s: String) = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace(Regex("\\(.*?\\)"), " ").replace(Regex("[^a-z0-9 ]"), " ")
            .split(' ').filter { it.length > 1 && it !in setOf("the", "of", "and", "de", "do", "da", "o", "a") }.toSet()
        val g = norm(game)
        val p = norm(page)
        if (g.isEmpty() || p.isEmpty()) return false
        val common = g.intersect(p).size
        return common >= minOf(2, g.size) && common * 2 >= g.size
    }

    private fun page(lang: String, pageTitle: String): GameFacts? {
        val q = get(
            "https://$lang.wikipedia.org/w/api.php".toHttpUrl().newBuilder()
                .addQueryParameter("action", "query").addQueryParameter("prop", "pageprops|extracts")
                .addQueryParameter("ppprop", "wikibase_item").addQueryParameter("exintro", "1")
                .addQueryParameter("explaintext", "1").addQueryParameter("exsentences", "3")
                .addQueryParameter("redirects", "1").addQueryParameter("titles", pageTitle)
                .addQueryParameter("format", "json").build(),
        ) ?: return null
        val pages = q.optJSONObject("query")?.optJSONObject("pages") ?: return null
        val p = pages.keys().asSequence().mapNotNull { pages.optJSONObject(it) }.firstOrNull() ?: return null
        val qid = p.optJSONObject("pageprops")?.optString("wikibase_item").orEmpty()
        if (qid.isBlank()) return null
        val entity = get("https://www.wikidata.org/wiki/Special:EntityData/$qid.json".toHttpUrl())
            ?.optJSONObject("entities")?.optJSONObject(qid) ?: return null
        val claims = entity.optJSONObject("claims") ?: return null
        // Só aceita se a Wikidata disser que é um jogo eletrônico.
        if (VIDEO_GAME !in itemIds(claims, "P31")) return null
        val ids = (itemIds(claims, "P178") + itemIds(claims, "P123") + itemIds(claims, "P136") + itemIds(claims, "P179")).distinct().take(40)
        val labels = labels(ids)
        fun names(prop: String) = itemIds(claims, prop).mapNotNull { labels[it] }.distinct().take(3)
        val year = claims.optJSONArray("P577")?.let { arr ->
            (0 until arr.length()).mapNotNull {
                arr.getJSONObject(it).optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")?.optString("time")
            }.mapNotNull { Regex("""[+-](\d{4})""").find(it)?.groupValues?.get(1) }.minOrNull()
        }.orEmpty()
        val title = p.optString("title", pageTitle)
        return GameFacts(
            found = true,
            year = year,
            developers = names("P178"),
            publishers = names("P123"),
            genres = names("P136"),
            series = names("P179").firstOrNull().orEmpty(),
            summary = p.optString("extract").trim().take(600),
            sourceTitle = title,
            sourceUrl = "https://$lang.wikipedia.org/wiki/" + title.replace(' ', '_'),
            sourceLang = lang,
        )
    }

    private fun itemIds(claims: JSONObject, prop: String): List<String> {
        val arr = claims.optJSONArray(prop) ?: return emptyList()
        return (0 until arr.length()).mapNotNull {
            arr.getJSONObject(it).optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")?.optString("id")
        }.filter { it.startsWith("Q") }
    }

    private fun labels(ids: List<String>): Map<String, String> {
        if (ids.isEmpty()) return emptyMap()
        val r = get(
            "https://www.wikidata.org/w/api.php".toHttpUrl().newBuilder()
                .addQueryParameter("action", "wbgetentities").addQueryParameter("ids", ids.joinToString("|"))
                .addQueryParameter("props", "labels").addQueryParameter("languages", "pt-br|pt|en")
                .addQueryParameter("format", "json").build(),
        )?.optJSONObject("entities") ?: return emptyMap()
        val out = HashMap<String, String>()
        for (id in ids) {
            val l = r.optJSONObject(id)?.optJSONObject("labels") ?: continue
            val name = listOf("pt-br", "pt", "en").firstNotNullOfOrNull { l.optJSONObject(it)?.optString("value")?.takeIf { v -> v.isNotBlank() } }
            if (name != null) out[id] = name
        }
        return out
    }

    private fun toJson(f: GameFacts) = JSONObject()
        .put("found", f.found).put("year", f.year).put("developers", JSONArray(f.developers)).put("publishers", JSONArray(f.publishers))
        .put("genres", JSONArray(f.genres)).put("series", f.series).put("summary", f.summary)
        .put("sourceTitle", f.sourceTitle).put("sourceUrl", f.sourceUrl).put("sourceLang", f.sourceLang)

    private fun fromJson(o: JSONObject): GameFacts {
        fun list(k: String) = o.optJSONArray(k)?.let { a -> (0 until a.length()).map { a.optString(it) } }.orEmpty()
        return GameFacts(
            found = o.optBoolean("found"), year = o.optString("year"), developers = list("developers"), publishers = list("publishers"),
            genres = list("genres"), series = o.optString("series"), summary = o.optString("summary"),
            sourceTitle = o.optString("sourceTitle"), sourceUrl = o.optString("sourceUrl"), sourceLang = o.optString("sourceLang"),
        )
    }
}
