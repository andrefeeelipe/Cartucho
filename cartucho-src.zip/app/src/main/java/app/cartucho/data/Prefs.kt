package app.cartucho.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, DARK, LIGHT }
enum class AspectMode(val label: String) { ORIGINAL("Original"), FOUR_THREE("4:3"), WIDE("16:9"), STRETCH("Esticar") }
enum class Latency(val label: String) { LOW("Baixa"), NORMAL("Normal") }
enum class Frameskip(val label: String) { AUTO("Auto"), OFF("Desligado") }
enum class ControlMode(val label: String) { AUTO("Automático"), GAMEPAD("Controle"), TOUCH("Tela") }
enum class OrientationMode(val label: String) { AUTO("Auto"), PORTRAIT("Retrato"), LANDSCAPE("Paisagem") }

data class Settings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val onboardingDone: Boolean = false,
    // Áudio
    val volume: Float = 1f,
    val muted: Boolean = false,
    val latency: Latency = Latency.NORMAL,
    val audioSync: Boolean = true,
    // Vídeo
    val aspect: AspectMode = AspectMode.ORIGINAL,
    val integerScale: Boolean = false,
    val smoothFilter: Boolean = false,
    val crt: Boolean = false,
    val resolution: Int = 1,
    val frameskip: Frameskip = Frameskip.AUTO,
    val showFps: Boolean = false,
    val orientation: OrientationMode = OrientationMode.AUTO,
    // Controles
    val touchOpacity: Float = 0.55f,
    val touchScale: Float = 1f,
    val vibration: Boolean = true,
    val menuCombo: Boolean = true,
    val controlMode: ControlMode = ControlMode.AUTO,
    // Nuvem
    val driveEnabled: Boolean = false,
    val driveAccount: String = "",
    val driveFolderId: String = "",
    val driveFolderName: String = "",
    val driveWifiOnly: Boolean = true,
    val lastSync: Long = 0L,
    val lastSyncError: String = "",
    // RetroAchievements
    val raEnabled: Boolean = false,
    val raUser: String = "",
    val raHardcore: Boolean = false,
    val raScore: Int = 0,
)

class Prefs(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("cartucho_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(read())
    val settings: StateFlow<Settings> = _settings.asStateFlow()
    val current: Settings get() = _settings.value

    fun update(transform: (Settings) -> Settings) {
        val next = transform(_settings.value)
        _settings.value = next
        write(next)
    }

    /** Relê do disco (outro processo pode ter alterado). */
    fun reload() {
        _settings.value = read()
    }

    private inline fun <reified T : Enum<T>> enumOf(key: String, default: T): T =
        runCatching { enumValueOf<T>(sp.getString(key, default.name) ?: default.name) }.getOrDefault(default)

    private fun read(): Settings = Settings(
        theme = enumOf("theme", ThemeMode.SYSTEM),
        onboardingDone = sp.getBoolean("onboardingDone", false),
        volume = sp.getFloat("volume", 1f),
        muted = sp.getBoolean("muted", false),
        latency = enumOf("latency", Latency.NORMAL),
        audioSync = sp.getBoolean("audioSync", true),
        aspect = enumOf("aspect", AspectMode.ORIGINAL),
        integerScale = sp.getBoolean("integerScale", false),
        smoothFilter = sp.getBoolean("smoothFilter", false),
        crt = sp.getBoolean("crt", false),
        resolution = sp.getInt("resolution", 1),
        frameskip = enumOf("frameskip", Frameskip.AUTO),
        showFps = sp.getBoolean("showFps", false),
        orientation = enumOf("orientation", OrientationMode.AUTO),
        touchOpacity = sp.getFloat("touchOpacity", 0.55f),
        touchScale = sp.getFloat("touchScale", 1f),
        vibration = sp.getBoolean("vibration", true),
        menuCombo = sp.getBoolean("menuCombo", true),
        controlMode = enumOf("controlMode", ControlMode.AUTO),
        driveEnabled = sp.getBoolean("driveEnabled", false),
        driveAccount = sp.getString("driveAccount", "") ?: "",
        driveFolderId = sp.getString("driveFolderId", "") ?: "",
        driveFolderName = sp.getString("driveFolderName", "") ?: "",
        driveWifiOnly = sp.getBoolean("driveWifiOnly", true),
        lastSync = sp.getLong("lastSync", 0L),
        lastSyncError = sp.getString("lastSyncError", "") ?: "",
        raEnabled = sp.getBoolean("raEnabled", false),
        raUser = sp.getString("raUser", "") ?: "",
        raHardcore = sp.getBoolean("raHardcore", false),
        raScore = sp.getInt("raScore", 0),
    )

    private fun write(s: Settings) {
        sp.edit()
            .putString("theme", s.theme.name)
            .putBoolean("onboardingDone", s.onboardingDone)
            .putFloat("volume", s.volume)
            .putBoolean("muted", s.muted)
            .putString("latency", s.latency.name)
            .putBoolean("audioSync", s.audioSync)
            .putString("aspect", s.aspect.name)
            .putBoolean("integerScale", s.integerScale)
            .putBoolean("smoothFilter", s.smoothFilter)
            .putBoolean("crt", s.crt)
            .putInt("resolution", s.resolution)
            .putString("frameskip", s.frameskip.name)
            .putBoolean("showFps", s.showFps)
            .putString("orientation", s.orientation.name)
            .putFloat("touchOpacity", s.touchOpacity)
            .putFloat("touchScale", s.touchScale)
            .putBoolean("vibration", s.vibration)
            .putBoolean("menuCombo", s.menuCombo)
            .putString("controlMode", s.controlMode.name)
            .putBoolean("driveEnabled", s.driveEnabled)
            .putString("driveAccount", s.driveAccount)
            .putString("driveFolderId", s.driveFolderId)
            .putString("driveFolderName", s.driveFolderName)
            .putBoolean("driveWifiOnly", s.driveWifiOnly)
            .putLong("lastSync", s.lastSync)
            .putString("lastSyncError", s.lastSyncError)
            .putBoolean("raEnabled", s.raEnabled)
            .putString("raUser", s.raUser)
            .putBoolean("raHardcore", s.raHardcore)
            .putInt("raScore", s.raScore)
            .apply()
    }
}
