package app.cartucho.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import kotlin.math.floor
import kotlin.math.sqrt

/** Como a foto do perfil é escolhida. */
enum class AvatarKind { BUILTIN, PHOTO, RA }

data class ProfileData(
    val name: String = "",
    val avatar: AvatarKind = AvatarKind.BUILTIN,
    /** Qual dos avatares do Cartucho (0 até [Profile.AVATARS] - 1). */
    val builtin: Int = 0,
    /** Muda quando a foto é trocada (para recarregar a imagem). */
    val photoVersion: Long = 0,
)

/** Perfil do jogador: nome, foto (da galeria, do RetroAchievements ou um dos avatares do app). */
class Profile(private val context: Context) {
    private val sp = context.getSharedPreferences("cartucho_perfil", Context.MODE_PRIVATE)
    private val _data = MutableStateFlow(read())
    val data: StateFlow<ProfileData> = _data
    val photoFile: File get() = File(context.filesDir, "perfil.jpg")

    private fun read() = ProfileData(
        name = sp.getString("name", "") ?: "",
        avatar = runCatching { AvatarKind.valueOf(sp.getString("avatar", "BUILTIN") ?: "BUILTIN") }.getOrDefault(AvatarKind.BUILTIN),
        builtin = sp.getInt("builtin", (System.currentTimeMillis() % AVATARS).toInt().also { sp.edit().putInt("builtin", it).apply() }),
        photoVersion = sp.getLong("photoVersion", 0),
    )

    fun update(transform: (ProfileData) -> ProfileData) {
        val next = transform(_data.value)
        _data.value = next
        sp.edit()
            .putString("name", next.name)
            .putString("avatar", next.avatar.name)
            .putInt("builtin", next.builtin)
            .putLong("photoVersion", next.photoVersion)
            .apply()
    }

    /** Copia a foto escolhida, já reduzida e recortada em quadrado. */
    fun setPhoto(uri: Uri): Boolean {
        val bmp = context.contentResolver.openInputStream(uri)?.use { input ->
            val bytes = input.readBytes()
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return false
        val side = minOf(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(square, 512.coerceAtMost(side), 512.coerceAtMost(side), true)
        photoFile.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        update { it.copy(avatar = AvatarKind.PHOTO, photoVersion = System.currentTimeMillis()) }
        return true
    }

    companion object {
        const val AVATARS = 12

        /** Experiência: pontos do RetroAchievements + horas jogadas + jogos zerados. */
        fun xp(raPoints: Int, seconds: Long, beaten: Int): Int = raPoints + (seconds / 360).toInt() + beaten * 25

        /** Nível e quanto falta (0..1) para o próximo. Cada nível pede um pouco mais que o anterior. */
        fun level(xp: Int): Pair<Int, Float> {
            val raw = sqrt(xp.coerceAtLeast(0) / 40.0)
            val lvl = floor(raw).toInt() + 1
            return lvl to (raw - floor(raw)).toFloat()
        }
    }
}
