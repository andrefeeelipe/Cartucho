package app.cartucho.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Um jogo gratuito da Loja (homebrew publicado no Homebrew Hub). */
data class StoreGame(
    val slug: String,
    val title: String,
    val systemId: String,
    val type: String,
    val developer: String,
    val license: String,
    val description: String,
    val fileName: String,
    val screenshot: String,
    val tags: List<String>,
    val website: String,
    val year: String,
    /** Pasta do banco no servidor (ex.: database-gba). */
    val basePath: String = "",
) {
    /** Endereço do arquivo no Homebrew Hub (o mesmo que o site usa para baixar). O nome pode ter subpasta ("files/jogo.gbc"). */
    private fun entryFile(name: String): String {
        val path = name.split('/').joinToString("/") { Uri.encode(it) }
        return if (basePath.isNotEmpty()) "https://hh3.gbdev.io/static/${Uri.encode(basePath)}/entries/${Uri.encode(slug)}/$path"
        else "${Store.API}/entry/${Uri.encode(slug)}/$path"
    }
    /** Nome do arquivo no celular (sem a subpasta do servidor). */
    val localName: String get() = fileName.substringAfterLast('/')
    val fileUrl: String get() = entryFile(fileName)
    /** Se o primeiro endereço falhar, tenta o da API. */
    val fileUrlFallback: String get() = "${Store.API}/entry/${Uri.encode(slug)}/" + fileName.split('/').joinToString("/") { Uri.encode(it) }
    val screenshotUrl: String get() = if (screenshot.isEmpty()) "" else entryFile(screenshot)
    val pageUrl: String get() = "https://hh.gbdev.io/game/$slug"
    val isDemo: Boolean get() = type == "demo"
}

/**
 * Loja do Cartucho: só jogos que os autores publicam de graça (homebrew), com crédito e licença.
 * O catálogo vem junto com o app e é atualizado a cada versão publicada; os jogos são baixados
 * direto do Homebrew Hub (hh.gbdev.io). Nenhuma ROM comercial entra aqui.
 */
class Store(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    private val cache = File(context.filesDir, "loja.json")
    private val dir = File(context.filesDir, "loja")
    private val _games = MutableStateFlow<List<StoreGame>>(emptyList())
    val games: StateFlow<List<StoreGame>> = _games
    @Volatile var loaded = false
        private set

    fun load() {
        if (loaded) return
        scope.launch {
            // Catálogo salvo; se estiver vazio ou estragado, usa o que vem dentro do app.
            var list = if (cache.exists()) runCatching { parse(cache.readText()) }.getOrDefault(emptyList()) else emptyList()
            if (list.isEmpty()) {
                runCatching { cache.delete() }
                list = bundledCatalog()
            }
            _games.value = list
            loaded = true
            // Catálogo mais novo, publicado junto com cada versão do Cartucho (no máximo uma vez por semana).
            val stale = !cache.exists() || System.currentTimeMillis() - cache.lastModified() > 7L * 24 * 3600 * 1000
            if (stale) {
                val fresh = runCatching {
                    http.newCall(Request.Builder().url(LATEST).build()).execute().use { if (it.isSuccessful) it.body?.string() else null }
                }.getOrNull()
                if (fresh != null && fresh.contains("\"jogos\"")) {
                    val list = parse(fresh)
                    if (list.isNotEmpty()) {
                        cache.writeText(fresh)
                        _games.value = list
                    }
                }
            }
        }
    }

    /** Já baixado? Devolve o arquivo local. */
    fun localFile(game: StoreGame): File? = File(File(dir, game.slug), game.localName).takeIf { it.exists() && it.length() > 0 }

    /** Baixa o jogo e põe na biblioteca. Devolve o Game criado. */
    suspend fun install(game: StoreGame, library: GameLibrary, covers: Covers, onProgress: (Int) -> Unit): Game = withContext(Dispatchers.IO) {
        val folder = File(dir, game.slug).apply { mkdirs() }
        val target = File(folder, game.localName)
        if (!target.exists() || target.length() == 0L) {
            val part = File(folder, game.localName + ".part")
            var resp = http.newCall(Request.Builder().url(game.fileUrl).build()).execute()
            if (!resp.isSuccessful && game.fileUrl != game.fileUrlFallback) {
                resp.close()
                resp = http.newCall(Request.Builder().url(game.fileUrlFallback).build()).execute()
            }
            resp.use { resp ->
                if (!resp.isSuccessful) throw StoreException("O servidor do Homebrew Hub não respondeu (erro ${resp.code}). Tente de novo mais tarde.")
                val body = resp.body ?: throw StoreException("Download vazio.")
                val total = body.contentLength().coerceAtLeast(1)
                var done = 0L
                body.byteStream().use { input ->
                    part.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            onProgress((done * 100 / total).toInt().coerceIn(0, 100))
                        }
                    }
                }
            }
            if (part.length() == 0L) throw StoreException("Download vazio.")
            part.renameTo(target)
        }
        val uri = Uri.fromFile(target).toString()
        val id = GameLibrary.idFor(uri)
        val existing = library.find(id)
        val entry = existing ?: Game(
            id = id,
            title = game.title,
            fileName = target.name,
            uri = uri,
            systemId = game.systemId,
            size = target.length(),
            addedAt = System.currentTimeMillis(),
            folderPath = "Loja",
        )
        library.upsert(entry)
        // A captura de tela do jogo vira a capa (as capas oficiais não cobrem homebrew).
        if (game.screenshot.isNotEmpty() && !covers.hasCover(id)) {
            runCatching {
                val shot = File(folder, "capa-" + game.screenshot.substringAfterLast('/'))
                if (!shot.exists()) {
                    http.newCall(Request.Builder().url(game.screenshotUrl).build()).execute().use { r ->
                        if (r.isSuccessful) r.body?.bytes()?.let { shot.writeBytes(it) }
                    }
                }
                if (shot.exists()) covers.setManual(id, Uri.fromFile(shot))
            }
        }
        entry
    }

    /** Para o autoteste: lê o catálogo que vai dentro do app. */
    fun bundledCatalog(): List<StoreGame> =
        runCatching { context.assets.open("loja.json").bufferedReader().use { parse(it.readText()) } }.getOrDefault(emptyList())

    private fun parse(text: String): List<StoreGame> = runCatching {
        val arr = JSONObject(text).getJSONArray("jogos")
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val systemId = when (o.optString("p")) { "gb" -> "gb"; "gbc" -> "gbc"; "gba" -> "gba"; "nes" -> "nes"; else -> return@mapNotNull null }
            val tags = o.optJSONArray("g")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
            StoreGame(
                slug = o.optString("s"),
                title = o.optString("t"),
                systemId = systemId,
                type = o.optString("y"),
                developer = o.optString("d"),
                license = o.optString("l"),
                description = o.optString("x"),
                fileName = o.optString("f"),
                screenshot = o.optString("i"),
                tags = tags,
                website = o.optString("w"),
                year = o.optString("a"),
                basePath = o.optString("b"),
            )
        }.filter { it.slug.isNotEmpty() && it.fileName.isNotEmpty() }
    }.getOrDefault(emptyList())

    companion object {
        const val API = "https://hh3.gbdev.io/api"
        const val LATEST = "https://github.com/andrefeeelipe/Cartucho/releases/latest/download/loja.json"
    }
}

class StoreException(message: String) : Exception(message)
