package app.cartucho.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Primeira letra para o filtro A–Z (sem acento; "#" para números e símbolos). */
fun titleLetter(title: String): Char {
    val t = title.trimStart().removePrefix("The ").removePrefix("the ")
    val c = t.firstOrNull() ?: return '#'
    val base = java.text.Normalizer.normalize(c.toString(), java.text.Normalizer.Form.NFD).first().uppercaseChar()
    return if (base in 'A'..'Z') base else '#'
}

/** Um jogo gratuito da Loja (homebrew publicado no Homebrew Hub). */
data class StoreGame(
    val slug: String,
    val title: String,
    val systemId: String,
    val type: String,
    val developer: String,
    val license: String,
    val description: String,
    val fileName: String,
    val screenshot: String,
    val tags: List<String>,
    val website: String,
    val year: String,
    /** Pasta do banco no servidor (ex.: database-gba). */
    val basePath: String = "",
    /** Endereço completo do arquivo (ZX Spectrum, TIC-80); vazio = Homebrew Hub. */
    val url: String = "",
    /** Endereço completo da imagem. */
    val cover: String = "",
    /** Gêneros do Cartucho (Ação, Aventura, Plataforma…). */
    val genres: List<String> = emptyList(),
    /** Idioma do jogo (código de 2 letras: pt, en, es…), vazio quando não se sabe. */
    val language: String = "",
    /** Número de jogadores (0 = não informado). */
    val players: Int = 0,
    /** De onde vem (Homebrew Hub, Spectrum Computing, TIC-80). */
    val source: String = "Homebrew Hub",
) {
    /** Endereço do arquivo no Homebrew Hub (o mesmo que o site usa para baixar). O nome pode ter subpasta ("files/jogo.gbc"). */
    private fun entryFile(name: String): String {
        val path = name.split('/').joinToString("/") { Uri.encode(it) }
        return if (basePath.isNotEmpty()) "https://hh3.gbdev.io/static/${Uri.encode(basePath)}/entries/${Uri.encode(slug)}/$path"
        else "${Store.API}/entry/${Uri.encode(slug)}/$path"
    }
    /** Nome do arquivo no celular (sem a subpasta do servidor). */
    val localName: String get() = fileName.substringAfterLast('/')
    val fileUrl: String get() = url.ifEmpty { entryFile(fileName) }
    /** Se o primeiro endereço falhar, tenta o da API. */
    val fileUrlFallback: String get() = if (url.isNotEmpty()) url else "${Store.API}/entry/${Uri.encode(slug)}/" + fileName.split('/').joinToString("/") { Uri.encode(it) }
    val screenshotUrl: String get() = cover.ifEmpty { if (screenshot.isEmpty()) "" else entryFile(screenshot) }
    val pageUrl: String get() = website.ifEmpty { "https://hh.gbdev.io/game/$slug" }
    val yearInt: Int get() = year.toIntOrNull() ?: 0
    /** Primeira letra para o filtro A–Z ("#" para números e símbolos). */
    val letter: Char get() = titleLetter(title)
    val isDemo: Boolean get() = type == "demo"
}

/**
 * Loja do Cartucho: só jogos que os autores publicam de graça (homebrew), com crédito e licença.
 * O catálogo vem junto com o app e é atualizado a cada versão publicada; os jogos são baixados
 * direto do Homebrew Hub (hh.gbdev.io). Nenhuma ROM comercial entra aqui.
 */
class Store(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    private val cache = File(context.filesDir, "loja.json")
    private val dir = File(context.filesDir, "loja")
    private val _games = MutableStateFlow<List<StoreGame>>(emptyList())
    val games: StateFlow<List<StoreGame>> = _games
    @Volatile var loaded = false
        private set

    fun load() {
        if (loaded) return
        scope.launch {
            // Catálogo salvo; se estiver vazio ou estragado, usa o que vem dentro do app.
            // Usa o mais novo entre o salvo e o que veio com esta versão do app.
            val cached = if (cache.exists()) runCatching { cache.readText() }.getOrNull() else null
            val bundled = runCatching { context.assets.open("loja.json").bufferedReader().use { it.readText() } }.getOrNull()
            fun date(t: String?) = t?.let { Regex("\"gerado\":\"([0-9-]+)\"").find(it.take(400))?.groupValues?.get(1) }.orEmpty()
            var list = if (cached != null && date(cached) >= date(bundled)) parse(cached) else emptyList()
            if (list.isEmpty()) {
                runCatching { cache.delete() }
                list = bundled?.let { parse(it) }.orEmpty()
            }
            _games.value = list
            loaded = true
            // Catálogo mais novo, publicado junto com cada versão do Cartucho (no máximo uma vez por semana).
            val stale = !cache.exists() || System.currentTimeMillis() - cache.lastModified() > 7L * 24 * 3600 * 1000
            if (stale) {
                val fresh = runCatching {
                    http.newCall(Request.Builder().url(LATEST).build()).execute().use { if (it.isSuccessful) it.body?.string() else null }
                }.getOrNull()
                if (fresh != null && fresh.contains("\"jogos\"")) {
                    val list = parse(fresh)
                    if (list.isNotEmpty()) {
                        cache.writeText(fresh)
                        _games.value = list
                    }
                }
            }
        }
    }

    /** Já baixado? Devolve o arquivo local. */
    fun localFile(game: StoreGame): File? {
        val folder = File(dir, game.slug)
        File(folder, game.localName).takeIf { it.exists() && it.length() > 0 && !it.name.endsWith(".zip", true) }?.let { return it }
        // Jogos que vêm compactados (.zip): o arquivo de jogo extraído fica na mesma pasta.
        val exts = Systems.get(game.systemId)?.extensions.orEmpty()
        return folder.listFiles()?.firstOrNull { it.isFile && it.length() > 0 && it.extension.lowercase() in exts }
    }

    /** Baixa o jogo e põe na biblioteca. Devolve o Game criado. */
    suspend fun install(game: StoreGame, library: GameLibrary, covers: Covers, onProgress: (Int) -> Unit): Game = withContext(Dispatchers.IO) {
        val folder = File(dir, game.slug).apply { mkdirs() }
        var target = localFile(game) ?: File(folder, game.localName)
        if (!target.exists() || target.length() == 0L) {
            val part = File(folder, game.localName + ".part")
            var resp = http.newCall(Request.Builder().url(game.fileUrl).build()).execute()
            if (!resp.isSuccessful && game.fileUrl != game.fileUrlFallback) {
                resp.close()
                resp = http.newCall(Request.Builder().url(game.fileUrlFallback).build()).execute()
            }
            resp.use { resp ->
                if (!resp.isSuccessful) throw StoreException("O servidor do Homebrew Hub não respondeu (erro ${resp.code}). Tente de novo mais tarde.")
                val body = resp.body ?: throw StoreException("Download vazio.")
                val total = body.contentLength().coerceAtLeast(1)
                var done = 0L
                body.byteStream().use { input ->
                    part.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            onProgress((done * 100 / total).toInt().coerceIn(0, 100))
                        }
                    }
                }
            }
            if (part.length() == 0L) throw StoreException("Download vazio.")
            part.renameTo(target)
            if (target.name.endsWith(".zip", true)) target = unzipGame(target, game)
        }
        val uri = Uri.fromFile(target).toString()
        val id = GameLibrary.idFor(uri)
        val existing = library.find(id)
        val entry = existing ?: Game(
            id = id,
            title = game.title,
            fileName = target.name,
            uri = uri,
            systemId = game.systemId,
            size = target.length(),
            addedAt = System.currentTimeMillis(),
            folderPath = "Loja",
        )
        library.upsert(entry)
        // A captura de tela do jogo vira a capa (as capas oficiais não cobrem homebrew).
        if (game.screenshotUrl.isNotEmpty() && !covers.hasCover(id)) {
            runCatching {
                val shot = File(folder, "capa-" + Uri.decode(game.screenshotUrl.substringAfterLast('/')).replace(Regex("[^A-Za-z0-9._-]"), "_"))
                if (!shot.exists()) {
                    http.newCall(Request.Builder().url(game.screenshotUrl).build()).execute().use { r ->
                        if (r.isSuccessful) r.body?.bytes()?.let { shot.writeBytes(it) }
                    }
                }
                if (shot.exists()) covers.setManual(id, Uri.fromFile(shot))
            }
        }
        entry
    }

    /** Tira o jogo de dentro do .zip (ZX Spectrum) e apaga o .zip. */
    private fun unzipGame(zip: File, game: StoreGame): File {
        val exts = Systems.get(game.systemId)?.extensions.orEmpty()
        var out: File? = null
        java.util.zip.ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val name = e.name.substringAfterLast('/')
                if (e.isDirectory || name.isEmpty() || name.substringAfterLast('.', "").lowercase() !in exts) continue
                val f = File(zip.parentFile, name.replace(Regex("[^A-Za-z0-9._ ()-]"), "_"))
                f.outputStream().use { zin.copyTo(it) }
                out = f
                break
            }
        }
        zip.delete()
        return out ?: throw StoreException("O arquivo baixado não tem um jogo que o Cartucho reconheça.")
    }

    /** Para o autoteste: lê o catálogo que vai dentro do app. */
    fun bundledCatalog(): List<StoreGame> =
        runCatching { context.assets.open("loja.json").bufferedReader().use { parse(it.readText()) } }.getOrDefault(emptyList())

    private fun parse(text: String): List<StoreGame> = runCatching {
        val arr = JSONObject(text).getJSONArray("jogos")
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val systemId = o.optString("p").takeIf { Systems.get(it) != null } ?: return@mapNotNull null
            val tags = o.optJSONArray("g")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
            val genres = o.optJSONArray("k")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
            StoreGame(
                slug = o.optString("s"),
                title = o.optString("t"),
                systemId = systemId,
                type = o.optString("y"),
                developer = o.optString("d"),
                license = o.optString("l"),
                description = o.optString("x"),
                fileName = o.optString("f"),
                screenshot = o.optString("i"),
                tags = tags,
                website = o.optString("w"),
                year = o.optString("a"),
                basePath = o.optString("b"),
                url = o.optString("u"),
                cover = o.optString("c"),
                genres = genres,
                language = o.optString("n"),
                players = o.optInt("j", 0),
                source = o.optString("o").ifEmpty { "Homebrew Hub" },
            )
        }.filter { it.slug.isNotEmpty() && it.fileName.isNotEmpty() }
    }.getOrDefault(emptyList())

    companion object {
        /** Ordem dos gêneros nos filtros. */
        val GENRES = listOf("Ação", "Aventura", "Plataforma", "Tiro", "Corrida", "Esporte", "Luta", "Quebra-cabeça", "RPG",
            "Estratégia", "Simulação", "Labirinto", "Tabuleiro e cartas", "Educativo", "Casual", "Música")
        const val API = "https://hh3.gbdev.io/api"
        const val LATEST = "https://github.com/andrefeeelipe/Cartucho/releases/latest/download/loja.json"
    }
}

class StoreException(message: String) : Exception(message)
