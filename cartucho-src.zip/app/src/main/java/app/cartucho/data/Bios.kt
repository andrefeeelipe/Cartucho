package app.cartucho.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest

data class BiosEntry(
    val systemId: String,
    val fileName: String,
    val description: String,
    val required: Boolean,
    /** Caminhos relativos à pasta de sistema onde o core procura o arquivo. */
    val targets: List<String>,
    val knownMd5: Set<String> = emptySet(),
)

enum class BiosStatus { MISSING, RECOGNIZED, UNKNOWN }

/**
 * Lista de BIOS que alguns emuladores usam. O app não fornece nem indica onde obter esses arquivos:
 * o usuário seleciona os que já possui.
 */
object BiosCatalog {
    val entries: List<BiosEntry> = listOf(
        BiosEntry("psx", "scph5501.bin", "BIOS PlayStation (EUA) — opcional, melhora a compatibilidade", false, listOf("scph5501.bin"), setOf("490f666e1afb15b7362b406ed1cea246")),
        BiosEntry("psx", "scph1001.bin", "BIOS PlayStation (EUA, alternativa) — opcional", false, listOf("scph1001.bin"), setOf("924e392ed05558ffdb115408c263dccf")),
        BiosEntry("gba", "gba_bios.bin", "BIOS Game Boy Advance — opcional", false, listOf("gba_bios.bin"), setOf("a860e8c0b6d573d191e4ec7db1b1e4f6")),
        BiosEntry("segacd", "bios_CD_U.bin", "BIOS Sega CD (EUA) — necessária para Sega CD", true, listOf("bios_CD_U.bin")),
        BiosEntry("segacd", "bios_CD_E.bin", "BIOS Mega-CD (Europa)", false, listOf("bios_CD_E.bin")),
        BiosEntry("segacd", "bios_CD_J.bin", "BIOS Mega-CD (Japão)", false, listOf("bios_CD_J.bin")),
        BiosEntry("pcecd", "syscard3.pce", "System Card 3 — necessária para PC Engine CD", true, listOf("syscard3.pce")),
        BiosEntry("nds", "bios7.bin", "BIOS ARM7 do Nintendo DS — opcional", false, listOf("bios7.bin"), setOf("df692a80a5b1bc90728bc3dfc76cd948")),
        BiosEntry("nds", "bios9.bin", "BIOS ARM9 do Nintendo DS — opcional", false, listOf("bios9.bin"), setOf("a392174eb3e572fed6447e956bde4b25")),
        BiosEntry("nds", "firmware.bin", "Firmware do Nintendo DS — opcional", false, listOf("firmware.bin")),
        BiosEntry("dreamcast", "dc_boot.bin", "BIOS Dreamcast — recomendada", false, listOf("dc/dc_boot.bin", "dc_boot.bin"), setOf("e10c53c2f8b90bab96ead2d368858623")),
        BiosEntry("dreamcast", "dc_flash.bin", "Flash Dreamcast — recomendada", false, listOf("dc/dc_flash.bin", "dc_flash.bin")),
        BiosEntry("saturn", "saturn_bios.bin", "BIOS Saturn — opcional, melhora a compatibilidade", false, listOf("saturn_bios.bin"), setOf("af5828fdff51384f99b3c4926be27762")),
        BiosEntry("arcade", "neogeo.zip", "BIOS Neo Geo — necessária para jogos de Neo Geo", false, listOf("neogeo.zip", "fbneo/neogeo.zip")),
    )

    fun forSystem(systemId: String) = entries.filter { it.systemId == systemId }

    fun systemDir(context: Context): File = File(context.filesDir, "system").apply { mkdirs() }

    fun status(context: Context, entry: BiosEntry): BiosStatus {
        val f = File(systemDir(context), entry.targets.first())
        if (!f.exists()) return BiosStatus.MISSING
        if (entry.knownMd5.isEmpty()) return BiosStatus.RECOGNIZED
        return if (md5(f) in entry.knownMd5) BiosStatus.RECOGNIZED else BiosStatus.UNKNOWN
    }

    fun missingRequired(context: Context, systemId: String): List<BiosEntry> =
        forSystem(systemId).filter { it.required && !File(systemDir(context), it.targets.first()).exists() }

    /** Copia o arquivo escolhido pelo usuário para os caminhos esperados pelo core. */
    fun install(context: Context, entry: BiosEntry, source: Uri): BiosStatus {
        val dir = systemDir(context)
        val bytes = context.contentResolver.openInputStream(source)?.use { it.readBytes() } ?: return BiosStatus.MISSING
        entry.targets.forEach { rel ->
            val f = File(dir, rel)
            f.parentFile?.mkdirs()
            f.writeBytes(bytes)
        }
        return status(context, entry)
    }

    fun remove(context: Context, entry: BiosEntry) {
        entry.targets.forEach { File(systemDir(context), it).delete() }
    }

    private fun md5(f: File): String {
        val md = MessageDigest.getInstance("MD5")
        f.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val r = input.read(buf)
                if (r < 0) break
                md.update(buf, 0, r)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
