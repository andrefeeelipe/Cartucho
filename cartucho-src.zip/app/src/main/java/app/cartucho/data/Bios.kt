package app.cartucho.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest

data class BiosEntry(
    val systemId: String,
    val fileName: String,
    val description: String,
    val required: Boolean,
    /** Caminhos relativos à pasta de sistema onde o core procura o arquivo. */
    val targets: List<String>,
    val knownMd5: Set<String> = emptySet(),
)

enum class BiosStatus { MISSING, RECOGNIZED, UNKNOWN }

/**
 * Lista de BIOS que alguns emuladores usam. O app não fornece nem indica onde obter esses arquivos:
 * o usuário seleciona os que já possui.
 */
object BiosCatalog {
    val entries: List<BiosEntry> = listOf(
        BiosEntry("psx", "scph5501.bin", "BIOS PlayStation (EUA) — opcional, melhora a compatibilidade", false, listOf("scph5501.bin"), setOf("490f666e1afb15b7362b406ed1cea246")),
        BiosEntry("psx", "scph1001.bin", "BIOS PlayStation (EUA, alternativa) — opcional", false, listOf("scph1001.bin"), setOf("924e392ed05558ffdb115408c263dccf")),
        BiosEntry("gba", "gba_bios.bin", "BIOS Game Boy Advance — opcional", false, listOf("gba_bios.bin"), setOf("a860e8c0b6d573d191e4ec7db1b1e4f6")),
        BiosEntry("segacd", "bios_CD_U.bin", "BIOS Sega CD (EUA) — necessária para Sega CD", true, listOf("bios_CD_U.bin")),
        BiosEntry("segacd", "bios_CD_E.bin", "BIOS Mega-CD (Europa)", false, listOf("bios_CD_E.bin")),
        BiosEntry("segacd", "bios_CD_J.bin", "BIOS Mega-CD (Japão)", false, listOf("bios_CD_J.bin")),
        BiosEntry("pcecd", "syscard3.pce", "System Card 3 — necessária para PC Engine CD", true, listOf("syscard3.pce")),
        BiosEntry("nds", "bios7.bin", "BIOS ARM7 do Nintendo DS — opcional", false, listOf("bios7.bin"), setOf("df692a80a5b1bc90728bc3dfc76cd948")),
        BiosEntry("nds", "bios9.bin", "BIOS ARM9 do Nintendo DS — opcional", false, listOf("bios9.bin"), setOf("a392174eb3e572fed6447e956bde4b25")),
        BiosEntry("nds", "firmware.bin", "Firmware do Nintendo DS — opcional", false, listOf("firmware.bin")),
        BiosEntry("dreamcast", "dc_boot.bin", "BIOS Dreamcast — recomendada", false, listOf("dc/dc_boot.bin", "dc_boot.bin"), setOf("e10c53c2f8b90bab96ead2d368858623")),
        BiosEntry("dreamcast", "dc_flash.bin", "Flash Dreamcast — recomendada", false, listOf("dc/dc_flash.bin", "dc_flash.bin")),
        BiosEntry("saturn", "saturn_bios.bin", "BIOS Saturn — opcional, melhora a compatibilidade", false, listOf("saturn_bios.bin"), setOf("af5828fdff51384f99b3c4926be27762")),
        BiosEntry("3do", "panafz10.bin", "BIOS 3DO (Panasonic FZ-10) — necessária para 3DO", true, listOf("panafz10.bin"), setOf("51f2f43ae2f3508a14d9f56597e2d3ce")),
        BiosEntry("atari5200", "5200.rom", "BIOS Atari 5200 — necessária para Atari 5200", true, listOf("5200.rom"), setOf("281f20ea4320404ec820fb7ec0693b38")),
        BiosEntry("neogeocd", "neocd_f.rom", "BIOS Neo Geo CD (frontloader) — necessária para Neo Geo CD", true, listOf("neocd/neocd_f.rom", "neocd_f.rom")),
        BiosEntry("neogeocd", "000-lo.lo", "ROM 000-lo.lo do Neo Geo — necessária para Neo Geo CD", true, listOf("neocd/000-lo.lo", "000-lo.lo")),
        BiosEntry("pcfx", "pcfx.rom", "BIOS PC-FX — necessária para PC-FX", true, listOf("pcfx.rom"), setOf("08e36edbea28a017f79f8d4f7ff9b6d7")),
        BiosEntry("colecovision", "colecovision.rom", "BIOS ColecoVision — necessária para ColecoVision", true, listOf("colecovision.rom"), setOf("2c66f5911e5b42b8ebe113403548eee7")),
        BiosEntry("intellivision", "exec.bin", "Exec ROM do Intellivision — necessária", true, listOf("exec.bin"), setOf("62e761035cb657903761800f4437b8af")),
        BiosEntry("intellivision", "grom.bin", "GROM do Intellivision — necessária", true, listOf("grom.bin"), setOf("0cd5946c6473e42e8e4c2137785e427f")),
        BiosEntry("odyssey2", "o2rom.bin", "BIOS Odyssey² — necessária", true, listOf("o2rom.bin"), setOf("562d5ebf9e030a40d6fabfc2f33139fd")),
        BiosEntry("channelf", "sl31253.bin", "BIOS Channel F (sl31253) — necessária", true, listOf("sl31253.bin"), setOf("ac9804d4c0e9d07e33472e3726ed15c3")),
        BiosEntry("channelf", "sl31254.bin", "BIOS Channel F (sl31254) — necessária", true, listOf("sl31254.bin"), setOf("da98f4bb3242ab80d76629021bb27585")),
        BiosEntry("amiga", "kick34005.A500", "Kickstart 1.3 do Amiga — opcional (sem ela, usa o AROS livre)", false, listOf("kick34005.A500")),
        BiosEntry("wiiu", "keys.txt", "Chaves do Wii U (keys.txt) — só para imagens criptografadas .wud/.wux", false, listOf("Cemu/keys.txt")),
        BiosEntry("arcade", "neogeo.zip", "BIOS Neo Geo — necessária para jogos de Neo Geo", false, listOf("neogeo.zip", "fbneo/neogeo.zip")),
    )

    fun forSystem(systemId: String) = entries.filter { it.systemId == systemId }

    fun systemDir(context: Context): File = File(context.filesDir, "system").apply { mkdirs() }

    fun status(context: Context, entry: BiosEntry): BiosStatus {
        val f = File(systemDir(context), entry.targets.first())
        if (!f.exists()) return BiosStatus.MISSING
        if (entry.knownMd5.isEmpty()) return BiosStatus.RECOGNIZED
        return if (md5(f) in entry.knownMd5) BiosStatus.RECOGNIZED else BiosStatus.UNKNOWN
    }

    fun missingRequired(context: Context, systemId: String): List<BiosEntry> =
        forSystem(systemId).filter { it.required && !File(systemDir(context), it.targets.first()).exists() }

    /** Copia o arquivo escolhido pelo usuário para os caminhos esperados pelo core. */
    fun install(context: Context, entry: BiosEntry, source: Uri): BiosStatus {
        val dir = systemDir(context)
        val bytes = context.contentResolver.openInputStream(source)?.use { it.readBytes() } ?: return BiosStatus.MISSING
        entry.targets.forEach { rel ->
            val f = File(dir, rel)
            f.parentFile?.mkdirs()
            f.writeBytes(bytes)
        }
        return status(context, entry)
    }

    fun remove(context: Context, entry: BiosEntry) {
        entry.targets.forEach { File(systemDir(context), it).delete() }
    }

    private fun md5(f: File): String {
        val md = MessageDigest.getInstance("MD5")
        f.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val r = input.read(buf)
                if (r < 0) break
                md.update(buf, 0, r)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
