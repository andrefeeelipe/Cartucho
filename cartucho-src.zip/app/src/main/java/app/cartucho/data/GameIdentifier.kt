package app.cartucho.data

import android.content.Context
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.zip.CRC32
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/**
 * Reconhece o jogo pelo conteúdo do arquivo, não pelo nome: cartuchos pelo CRC32 e discos pelo
 * código de série (PS1/PS2/PSP pelo SYSTEM.CNF/UMD_DATA.BIN, GameCube/Wii pelo cabeçalho).
 * Os nomes oficiais vêm das listas No-Intro/Redump do libretro-database, embutidas no app
 * (assets/ids/<sistema>.tsv.gz). Com o nome oficial, o título fica certo e a capa é a exata.
 */
class GameIdentifier(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val maps = HashMap<String, Map<String, String>?>()
    private val _version = MutableStateFlow(0)
    /** Muda quando algum jogo foi renomeado. */
    val version: StateFlow<Int> = _version

    private val available: Set<String> by lazy {
        runCatching { context.assets.list("ids")?.map { it.removeSuffix(".tsv.gz") }?.toSet() }.getOrNull().orEmpty()
    }

    /** Reconhece em segundo plano os jogos ainda não verificados. */
    fun enqueue(library: GameLibrary, covers: Covers, games: List<Game>, coverDownload: Boolean) {
        val pending = games.filter { it.canonical.isEmpty() }
        if (pending.isEmpty() || available.isEmpty()) return
        scope.launch {
            mutex.withLock {
                var changed = 0
                for (g in pending) {
                    val current = library.find(g.id) ?: continue
                    if (current.canonical.isNotEmpty()) continue
                    val found = runCatching { identify(current) }.onFailure { Log.w(TAG, "falhou ${current.fileName}", it) }.getOrNull()
                    if (found == null) {
                        library.setIdentity(current.id, "-", null, null)
                        continue
                    }
                    val (systemId, name) = found
                    library.setIdentity(current.id, name, cleanTitle(name), systemId)
                    changed++
                    // Capa: com o nome oficial a busca acerta; troca a capa gerada (nunca a escolhida pelo usuário).
                    library.find(current.id)?.let { covers.onIdentified(it, coverDownload) }
                }
                if (changed > 0) _version.value = _version.value + 1
            }
        }
    }

    /** Sistema e nome oficial, ou null se não estiver nas listas. */
    fun identify(game: Game): Pair<String, String>? {
        val ext = game.fileName.substringAfterLast('.', "").lowercase()
        val uri = Uri.parse(game.uri)
        val systems = if (game.systemId.isNotEmpty()) listOf(game.systemId) else available.toList()
        val discOnly = ext in DISC_EXTS && ext != "bin" || game.systemId in DISC_SYSTEMS
        if (ext in DISC_EXTS || game.systemId in DISC_SYSTEMS) {
            val serial = runCatching { discSerial(uri, ext) }.getOrNull()
            if (serial != null) {
                for (sys in systems) map(sys)?.get("s:" + normSerial(serial.first))?.let { return sys to it }
                // GameCube/Wii: sem a lista, o próprio cabeçalho tem o nome do jogo.
                serial.second?.let { title -> if (title.isNotBlank()) return (game.systemId.ifEmpty { serial.third ?: "" }) to title }
                return null
            }
            if (discOnly) return null
        }
        for (crc in cartridgeCrcs(uri, ext)) {
            for (sys in systems) map(sys)?.get(crc)?.let { return sys to it }
        }
        return null
    }

    private fun map(systemId: String): Map<String, String>? {
        synchronized(maps) { if (maps.containsKey(systemId)) return maps[systemId] }
        val loaded = if (systemId !in available) null else runCatching {
            val m = HashMap<String, String>()
            GZIPInputStream(context.assets.open("ids/$systemId.tsv.gz")).bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val tab = line.indexOf('\t')
                    if (tab > 0) m[line.substring(0, tab)] = line.substring(tab + 1)
                }
            }
            m
        }.getOrNull()
        synchronized(maps) { maps[systemId] = loaded }
        return loaded
    }

    // ------------------------------------------------------------------ cartuchos

    /** CRC32 do arquivo (e sem o cabeçalho, quando o formato tem um), em hexadecimal minúsculo. */
    private fun cartridgeCrcs(uri: Uri, ext: String): List<String> {
        val resolver = context.contentResolver
        if (ext == "zip") {
            ZipInputStream(resolver.openInputStream(uri)?.buffered() ?: return emptyList()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    val inner = e.name.substringAfterLast('.', "").lowercase()
                    if (inner in setOf("txt", "nfo", "diz", "jpg", "png")) continue
                    // Lê o conteúdo: o CRC do cabeçalho local pode faltar (descritor de dados) e o cabeçalho do jogo precisa sair.
                    val localCrc = listOfNotNull(e.crc.takeIf { it >= 0 }?.let { hex(it) })
                    if (e.size > MAX_HASH) return localCrc
                    val data = zin.readNBytesCompat(MAX_HASH + 1)
                    if (data.size > MAX_HASH) return localCrc
                    return (crcs(data) + localCrc).distinct()
                }
            }
            return emptyList()
        }
        val data = resolver.openInputStream(uri)?.use { input ->
            val buf = input.readNBytesCompat(MAX_HASH + 1)
            if (buf.size > MAX_HASH) null else buf
        } ?: return emptyList()
        return crcs(data)
    }

    private fun crcs(data: ByteArray): List<String> {
        val out = ArrayList<String>(2)
        out.add(crcOf(data, 0))
        val header = when {
            data.size > 16 && data[0] == 'N'.code.toByte() && data[1] == 'E'.code.toByte() && data[2] == 'S'.code.toByte() && data[3] == 0x1A.toByte() -> 16
            data.size > 16 && data[0] == 'F'.code.toByte() && data[1] == 'D'.code.toByte() && data[2] == 'S'.code.toByte() && data[3] == 0x1A.toByte() -> 16
            data.size > 64 && String(data, 0, 4, Charsets.ISO_8859_1) == "LYNX" -> 64
            data.size > 128 && String(data, 1, 9, Charsets.ISO_8859_1) == "ATARI7800" -> 128
            data.size % 1024 == 512 && data.size > 512 -> 512  // cópia de SNES com cabeçalho de copiadora
            else -> 0
        }
        if (header > 0) out.add(crcOf(data, header))
        return out
    }

    private fun crcOf(data: ByteArray, from: Int): String {
        val c = CRC32()
        c.update(data, from, data.size - from)
        return hex(c.value)
    }

    private fun hex(v: Long) = "%08x".format(v and 0xffffffffL)

    // ------------------------------------------------------------------ discos

    /**
     * Código de série do disco: (série, título do cabeçalho se houver, sistema sugerido).
     * Lê o mínimo necessário do arquivo (sistema de arquivos ISO 9660).
     */
    private fun discSerial(uri: Uri, ext: String): Triple<String, String?, String?>? {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            FileInputStream(pfd.fileDescriptor).channel.use { ch ->
                val head = read(ch, 0, 0x60) ?: return null
                // GameCube / Wii: código de 6 letras no início e o nome em 0x20.
                val magicWii = be32(head, 0x18) == 0x5D1C9EA3L
                val magicGc = be32(head, 0x1C) == 0xC2339F3DL
                if (magicWii || magicGc) {
                    val id = String(head, 0, 6, Charsets.ISO_8859_1)
                    val title = read(ch, 0x20, 0x40)?.let { String(it, Charsets.UTF_8).substringBefore('\u0000').trim() }
                    return Triple(id, title, if (magicWii) "wii" else "gamecube")
                }
                val iso = Iso(ch) ?: return null
                iso.file("SYSTEM.CNF")?.let { cnf ->
                    val text = String(cnf, Charsets.ISO_8859_1)
                    val m = Regex("BOOT2?\\s*=\\s*cdrom0?:\\\\?([A-Z]{4})[_-]?(\\d{3})\\.?(\\d{2})", RegexOption.IGNORE_CASE).find(text)
                    if (m != null) return Triple(m.groupValues[1] + m.groupValues[2] + m.groupValues[3], null, null)
                }
                iso.file("UMD_DATA.BIN")?.let { umd ->
                    val serial = String(umd, Charsets.ISO_8859_1).substringBefore('|').trim()
                    if (serial.length >= 9) return Triple(serial, null, "psp")
                }
                return null
            }
        }
        return null
    }

    /** Leitor mínimo de ISO 9660 (setores de 2048 bytes ou imagem crua de 2352). */
    private inner class Iso(private val ch: FileChannel, private val sector: Int, private val offset: Int) {
        fun lba(n: Long): Long = n * sector + offset

        fun file(name: String): ByteArray? {
            val pvd = read(ch, lba(16), 2048) ?: return null
            val rootLba = le32(pvd, 156 + 2)
            val rootLen = le32(pvd, 156 + 10).coerceAtMost(64 * 1024)
            val dir = readExtent(rootLba, rootLen.toInt()) ?: return null
            var p = 0
            while (p < dir.size) {
                val len = dir[p].toInt() and 0xff
                if (len == 0) { p = ((p / 2048) + 1) * 2048; continue }
                val nameLen = dir[p + 32].toInt() and 0xff
                val n = String(dir, p + 33, nameLen, Charsets.ISO_8859_1).substringBefore(';')
                if (n.equals(name, ignoreCase = true)) {
                    val at = le32(dir, p + 2)
                    val size = le32(dir, p + 10).coerceAtMost(16 * 1024)
                    return readExtent(at, size.toInt())
                }
                p += len
            }
            return null
        }

        private fun readExtent(lba: Long, size: Int): ByteArray? {
            if (sector == 2048) return read(ch, lba(lba), size)
            val out = java.io.ByteArrayOutputStream()
            var left = size
            var n = lba
            while (left > 0) {
                val part = read(ch, lba(n), minOf(2048, left)) ?: return null
                out.write(part)
                left -= part.size
                n++
            }
            return out.toByteArray()
        }
    }

    private fun Iso(ch: FileChannel): Iso? {
        // 2048 (ISO), 2352 modo 1 (+16) e modo 2 (+24).
        for ((sector, offset) in listOf(2048 to 0, 2352 to 24, 2352 to 16)) {
            val pvd = read(ch, 16L * sector + offset, 8) ?: continue
            if (pvd[0].toInt() == 1 && String(pvd, 1, 5, Charsets.ISO_8859_1) == "CD001") return Iso(ch, sector, offset)
        }
        return null
    }

    private fun read(ch: FileChannel, at: Long, len: Int): ByteArray? {
        if (at < 0 || len <= 0) return null
        val buf = ByteBuffer.allocate(len)
        var pos = at
        while (buf.hasRemaining()) {
            val n = ch.read(buf, pos)
            if (n <= 0) break
            pos += n
        }
        return if (buf.position() == 0) null else buf.array().copyOf(buf.position())
    }

    private fun le32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xff) or ((b[o + 1].toLong() and 0xff) shl 8) or ((b[o + 2].toLong() and 0xff) shl 16) or ((b[o + 3].toLong() and 0xff) shl 24)

    private fun be32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xff) shl 24) or ((b[o + 1].toLong() and 0xff) shl 16) or ((b[o + 2].toLong() and 0xff) shl 8) or (b[o + 3].toLong() and 0xff)

    private fun java.io.InputStream.readNBytesCompat(max: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        var total = 0
        while (total < max) {
            val n = read(buf, 0, minOf(buf.size, max - total))
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toByteArray()
    }

    companion object {
        private const val TAG = "CartuchoNomes"
        /** Cartuchos até 64 MB (o maior de GBA/N64 é 64 MB). */
        private const val MAX_HASH = 64 * 1024 * 1024
        private val DISC_EXTS = setOf("iso", "bin", "img", "gcm", "rvz", "wbfs", "wia")
        private val DISC_SYSTEMS = setOf("psx", "ps2", "psp", "gamecube", "wii")

        fun normSerial(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

        /** "Legend of Zelda, The - A Link to the Past (USA) (Rev 1)" -> "The Legend of Zelda - A Link to the Past". */
        fun cleanTitle(name: String): String {
            var t = name.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), "").trim()
            val m = Regex("^(.*?), (The|A|An|O|A|Os|As|El|La|Le|Les|Der|Die|Das)( - .*)?$").find(t)
            if (m != null) t = m.groupValues[2] + " " + m.groupValues[1] + m.groupValues[3]
            return t.ifBlank { name }
        }
    }
}
