package app.cartucho.data

import android.content.Context
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.zip.CRC32
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/**
 * Reconhece o jogo pelo conteúdo do arquivo, não pelo nome: cartuchos pelo CRC32 e discos pelo
 * código de série (PS1/PS2/PSP pelo SYSTEM.CNF/UMD_DATA.BIN, GameCube/Wii pelo cabeçalho).
 * Os nomes oficiais vêm das listas No-Intro/Redump do libretro-database, embutidas no app
 * (assets/ids/<sistema>.tsv.gz). Com o nome oficial, o título fica certo e a capa é a exata.
 */
class GameIdentifier(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val maps = HashMap<String, Map<String, String>?>()
    private val _version = MutableStateFlow(0)
    /** Muda quando algum jogo foi renomeado. */
    val version: StateFlow<Int> = _version

    private val available: Set<String> by lazy {
        runCatching { context.assets.list("ids")?.map { it.removeSuffix(".tsv.gz") }?.toSet() }.getOrNull().orEmpty()
    }

    /** O que foi reconhecido: sistema, nome oficial e a "impressão digital" do conteúdo (CRC ou código do disco). */
    data class Found(val systemId: String, val name: String, val fingerprint: String)

    /** Abre um arquivo vizinho (as trilhas .bin de um .cue, os discos de um .m3u). Configurado pelo app. */
    var siblingUri: (Game, String) -> Uri? = { _, _ -> null }

    private val sp = context.getSharedPreferences("cartucho_nomes", Context.MODE_PRIVATE)

    /** Reconhece em segundo plano os jogos ainda não verificados. */
    fun enqueue(library: GameLibrary, covers: Covers, games: List<Game>, coverDownload: Boolean) {
        // Reconhecimento melhorou desde a última vez: tenta de novo os que não foram reconhecidos.
        val retry = sp.getInt("algo", 0) < ALGO
        val pending = games.filter { it.canonical.isEmpty() || (retry && it.canonical == "-") }
        if (available.isEmpty()) return
        if (pending.isEmpty()) { if (retry) sp.edit().putInt("algo", ALGO).apply(); return }
        scope.launch {
            mutex.withLock {
                var changed = 0
                for (g in pending) {
                    val current = library.find(g.id) ?: continue
                    if (current.canonical.length > 1) continue
                    if (applyFound(library, covers, current, coverDownload) { identify(current) }) changed++
                }
                if (retry) sp.edit().putInt("algo", ALGO).apply()
                if (changed > 0) _version.value = _version.value + 1
            }
        }
    }

    /**
     * Depois de preparar o jogo para abrir (extraído, partes juntadas): reconhece pelo arquivo de verdade.
     * Pega o que o reconhecimento em segundo plano não consegue ver (dentro de .7z/.rar, jogos em partes).
     */
    fun identifyPrepared(library: GameLibrary, covers: Covers, game: Game, file: java.io.File, coverDownload: Boolean) {
        if (game.canonical.length > 1 || available.isEmpty()) return
        scope.launch {
            mutex.withLock {
                val current = library.find(game.id) ?: return@withLock
                if (current.canonical.length > 1) return@withLock
                val asFile = current.copy(uri = Uri.fromFile(file).toString(), fileName = file.name, parts = 1, treeUri = null, parentDocId = null)
                if (applyFound(library, covers, current, coverDownload) { identify(asFile) }) _version.value = _version.value + 1
            }
        }
    }

    private inline fun applyFound(library: GameLibrary, covers: Covers, game: Game, coverDownload: Boolean, find: () -> Found?): Boolean {
        val found = runCatching { find() }.onFailure { Log.w(TAG, "falhou ${game.fileName}", it) }.getOrNull()
        if (found == null) {
            library.setIdentity(game.id, "-", null, null, null)
            return false
        }
        library.setIdentity(game.id, found.name, cleanTitle(found.name), found.systemId.ifEmpty { null }, found.fingerprint.ifEmpty { null })
        // Capa: com o nome oficial a busca acerta; troca a capa gerada (nunca a escolhida pelo usuário).
        library.find(game.id)?.let { covers.onIdentified(it, coverDownload) }
        return true
    }

    /** Reconhece pelo conteúdo e, se não der, pelo nome (comparando com a lista oficial do sistema). */
    fun identify(game: Game): Found? {
        runCatching { byContent(game) }.onFailure { Log.w(TAG, "conteúdo ilegível: ${game.fileName}", it) }.getOrNull()?.let { return it }
        // Traduções e hacks mudam o CRC, mas o cabeçalho do cartucho costuma manter o código e o nome do jogo.
        val ext = game.fileName.substringAfterLast('.', "").lowercase()
        val uri = Uri.parse(game.uri)
        val size = if (uri.scheme == "file") java.io.File(uri.path ?: "").length() else game.size
        val header = if (game.parts <= 1) runCatching { cartridgeHeader(uri, ext, size) }.getOrNull() else null
        if (header != null) {
            val sys = game.systemId.ifEmpty { header.third }
            header.first?.let { code -> map(sys)?.get("c:$code")?.let { return Found(sys, it, "c:$code") } }
            return byNames(sys, listOfNotNull(game.fileName.substringBeforeLast('.'), game.title, header.second))
        }
        return byName(game)
    }

    /**
     * Cabeçalho do cartucho: (código do jogo, nome interno, sistema). GBA e DS têm um código de 4 letras
     * (ex.: BPRE) que traduções mantêm; SNES, Game Boy e N64 têm o nome interno.
     */
    private fun cartridgeHeader(uri: Uri, ext: String, fileSize: Long): Triple<String?, String?, String>? {
        val head = context.contentResolver.openInputStream(uri)?.use { it.readNBytesCompat(0x10400) } ?: return null
        fun text(at: Int, len: Int): String? = if (head.size < at + len) null
            else String(head, at, len, Charsets.ISO_8859_1).substringBefore('\u0000').trim().takeIf { t -> t.length >= 2 && t.all { it.code in 32..126 } }
        fun code(at: Int): String? = text(at, 4)?.takeIf { it.length == 4 && it.all { c -> c.isLetterOrDigit() } }
        return when (ext) {
            "gba", "agb" -> Triple(code(0xAC), text(0xA0, 12), "gba")
            "nds", "dsi", "srl" -> Triple(code(0x0C), text(0x00, 12), "nds")
            "gb", "gbc", "sgb" -> Triple(null, text(0x134, 15), if (ext == "gbc") "gbc" else "gb")
            "n64", "z64", "v64" -> if (head.size > 0x40 && head[0] == 0x80.toByte()) Triple(code(0x3B), text(0x20, 20), "n64") else null
            "sfc", "smc", "fig", "swc" -> {
                val off = if (fileSize % 1024 == 512L) 512 else 0
                // Testa LoROM (0x7FC0) e HiROM (0xFFC0): o checksum e o complemento somam 0xFFFF.
                listOf(0x7FC0, 0xFFC0).map { it + off }.firstOrNull { b ->
                    head.size > b + 0x20 && (((head[b + 0x1C].toInt() and 0xff) or ((head[b + 0x1D].toInt() and 0xff) shl 8)) xor
                        ((head[b + 0x1E].toInt() and 0xff) or ((head[b + 0x1F].toInt() and 0xff) shl 8))) == 0xFFFF
                }?.let { b -> Triple(null, text(b, 21), "snes") }
            }
            else -> null
        }
    }

    private fun byContent(game: Game): Found? {
        val ext = game.fileName.substringAfterLast('.', "").lowercase()
        val uri = Uri.parse(game.uri)
        val systems = if (game.systemId.isNotEmpty()) listOf(game.systemId) else available.toList()
        // Folha de disco (.cue/.m3u/.gdi): o reconhecimento olha o disco ou a primeira trilha.
        if (ext in setOf("cue", "m3u", "gdi", "ccd") && game.parts <= 1) {
            val ref = sheetFirstFile(uri, ext) ?: return null
            val track = siblingUri(game, ref) ?: return null
            val inner = game.copy(uri = track.toString(), fileName = ref)
            return byContent(inner)
        }
        if (ext == "pbp") {
            val id = runCatching { pbpDiscId(uri) }.getOrNull() ?: return null
            for (sys in systems + "psx") map(sys)?.get("s:" + normSerial(id))?.let { return Found(sys, it, "s:" + normSerial(id)) }
            return null
        }
        if (ext == "zip" && game.parts <= 1) return zipEntries(uri, game, systems)
        val discOnly = ext in DISC_EXTS && ext != "bin" || game.systemId in DISC_SYSTEMS
        if (ext in DISC_EXTS || game.systemId in DISC_SYSTEMS) {
            val serial = runCatching { discSerial(uri, ext) }.getOrNull()
            if (serial != null) {
                val key = "s:" + normSerial(serial.first)
                for (sys in systems) map(sys)?.get(key)?.let { return Found(sys, it, key) }
                serial.third?.let { sys -> map(sys)?.get(key)?.let { return Found(sys, it, key) } }
                // GameCube/Wii: sem a lista, o próprio cabeçalho tem o nome do jogo.
                serial.second?.let { title -> if (title.isNotBlank()) return Found(game.systemId.ifEmpty { serial.third ?: "" }, title, key) }
                return null
            }
            if (discOnly) return null
        }
        if (game.parts > 1) return null  // cartucho em partes: reconhecido depois de juntar
        for (crc in cartridgeCrcs(uri, ext)) {
            for (sys in systems) map(sys)?.get(crc)?.let { return Found(sys, it, "crc:$crc") }
        }
        return null
    }

    /** .zip: lê só o índice do arquivo (nomes e CRCs), sem descompactar nada. */
    private fun zipEntries(uri: Uri, game: Game, systems: List<String>): Found? {
        val entries = runCatching { zipIndex(uri) }.getOrNull() ?: return null
        for ((_, crc) in entries) {
            if (crc == 0L) continue
            val key = hex(crc)
            for (sys in systems) map(sys)?.get(key)?.let { return Found(sys, it, "crc:$key") }
        }
        // Sem CRC conhecido (jogo em partes, disco, hack): tenta pelo nome do que está dentro.
        val names = entries.map { it.first.substringAfterLast('/') }
        val logical = SplitParts.groups(names).map { it.joinedName } + names.filter { SplitParts.part(it) == null }
        for (n in logical.sortedByDescending { it.length }) {
            byName(game.copy(fileName = n, title = GameLibrary.titleFromFileName(n)))?.let { return it }
        }
        return null
    }

    /**
     * Último recurso: o nome do arquivo (mesmo estranho, como "super_mario_world_usa_v1") comparado com
     * a lista oficial do sistema. Só aceita quando a semelhança é alta e não há empate.
     */
    private fun byName(game: Game): Found? = byNames(game.systemId, listOf(game.fileName.substringBeforeLast('.'), game.title))

    /**
     * Compara nomes (do arquivo, do título, do cabeçalho do jogo) com a lista oficial do sistema.
     * Um candidato vale quando todas as palavras dele aparecem no nome procurado e o nome procurado
     * não tem sobra demais (traduções e sites já saem antes). Entre os que valem, fica o mais completo.
     */
    private fun byNames(systemId: String, rawNames: List<String>): Found? {
        if (systemId.isEmpty()) return null
        val index = nameIndex(systemId) ?: return null
        val wanted = rawNames.map { stripSplit(it) }.filter { it.isNotBlank() }.distinct()
            .map { Covers.tokens(it).toSet() }.filter { it.isNotEmpty() }
        if (wanted.isEmpty()) return null
        // Só compara com os nomes que têm alguma palavra em comum (rápido mesmo com 14 mil jogos na lista).
        val candidates = HashSet<String>()
        for (w in wanted) for (t in w) index[t]?.let { if (it.size < 4000) candidates.addAll(it) }
        var best: String? = null
        var bestKey = -1.0
        for (candidate in candidates) {
            val c = Covers.tokens(candidate).toSet()
            if (c.isEmpty()) continue
            val cNums = c.filter { t -> t.all { it.isDigit() } }.toSet()
            for (w in wanted) {
                if (!w.containsAll(c)) continue
                // Números diferentes = jogos diferentes (Mega Man X vs Mega Man X3).
                if (w.filter { t -> t.all { it.isDigit() } }.toSet() != cNums) continue
                val precision = c.size.toDouble() / w.size
                if (precision < 0.6 && c.size < 3) continue
                if (precision < 0.4) continue
                // Mais palavras casadas primeiro; empate: a região preferida (EUA/mundo/Brasil/Europa).
                val key = c.size * 10.0 + precision - regionPenalty(candidate) * 0.01
                if (key > bestKey) { bestKey = key; best = candidate }
            }
        }
        return best?.let { Found(systemId, it, "") }
    }

    private fun regionPenalty(name: String): Int {
        val n = name.lowercase()
        return when {
            "(usa" in n || "(world" in n -> 0
            "(brazil" in n -> 1
            "(europe" in n -> 2
            "(japan" in n -> 4
            else -> 3
        } + (if ("(beta" in n || "(proto" in n || "(demo" in n || "(sample" in n) 10 else 0)
    }

    /** Para o autoteste: tamanho da lista do sistema e o melhor candidato pelo nome. */
    fun debugInfo(systemId: String, game: Game): String = runCatching {
        val idx = nameIndex(systemId)
        val wanted = listOf(game.fileName.substringBeforeLast('.'), game.title).map { stripSplit(it) }
        val toks = wanted.flatMap { Covers.tokens(it) }
        val cands = toks.flatMap { idx?.get(it).orEmpty() }.toSet()
        val best = cands.maxByOrNull { c -> wanted.maxOf { Covers.similarity(it, c) } }
        "lista=${idx?.size ?: -1} palavras=$toks candidatos=${cands.size} melhor=$best ${best?.let { b -> "%.2f".format(wanted.maxOf { Covers.similarity(it, b) }) }}"
    }.getOrElse { "erro: $it" }

    private fun stripSplit(n: String): String = n.replace(Regex("""\.(\d{3}|part\d+|wbf\d)$""", RegexOption.IGNORE_CASE), "")

    private val nameIndexes = HashMap<String, Map<String, List<String>>?>()

    /** Palavra -> nomes oficiais que a contêm, por sistema. */
    private fun nameIndex(systemId: String): Map<String, List<String>>? = synchronized(nameIndexes) {
        nameIndexes.getOrPut(systemId) {
            map(systemId)?.values?.distinct()?.let { names ->
                val idx = HashMap<String, MutableList<String>>()
                for (n in names) for (t in Covers.tokens(n).toSet()) idx.getOrPut(t) { ArrayList() }.add(n)
                idx
            }
        }
    }

    private fun map(systemId: String): Map<String, String>? {
        synchronized(maps) { if (maps.containsKey(systemId)) return maps[systemId] }
        val loaded = if (systemId !in available) null else runCatching {
            val m = HashMap<String, String>()
            GZIPInputStream(context.assets.open("ids/$systemId.tsv.gz")).bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val tab = line.indexOf('\t')
                    if (tab > 0) m[line.substring(0, tab)] = line.substring(tab + 1)
                }
            }
            m
        }.getOrNull()
        synchronized(maps) { maps[systemId] = loaded }
        return loaded
    }

    // ------------------------------------------------------------------ índices e folhas

    /** Primeiro arquivo citado numa folha .cue/.m3u/.gdi/.ccd. */
    private fun sheetFirstFile(uri: Uri, ext: String): String? {
        val text = context.contentResolver.openInputStream(uri)?.use { it.readNBytesCompat(256 * 1024) }?.toString(Charsets.ISO_8859_1) ?: return null
        val name = when (ext) {
            "cue" -> Regex("""FILE\s+"?([^"\r\n]+?)"?\s+(BINARY|MOTOROLA|WAVE|MP3|AIFF)""", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)
            "m3u" -> text.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() && !it.startsWith("#") }
            "gdi" -> text.lines().getOrNull(1)?.trim()?.split(Regex("""\s+"""))?.getOrNull(4)?.trim('"')
            "ccd" -> null
            else -> null
        } ?: return null
        return name.substringAfterLast('/').substringAfterLast('\\')
    }

    /** PS1 em .pbp (EBOOT): o código do disco fica no PARAM.SFO. */
    private fun pbpDiscId(uri: Uri): String? {
        val head = context.contentResolver.openInputStream(uri)?.use { it.readNBytesCompat(64 * 1024) } ?: return null
        if (head.size < 0x28 || head[1] != 'P'.code.toByte() || head[2] != 'B'.code.toByte()) return null
        val sfo = le32(head, 0x08).toInt()
        if (sfo <= 0 || sfo + 20 > head.size || String(head, sfo, 4, Charsets.ISO_8859_1) != "\u0000PSF") return null
        val keyTable = sfo + le32(head, sfo + 8).toInt()
        val dataTable = sfo + le32(head, sfo + 12).toInt()
        val count = le32(head, sfo + 16).toInt()
        for (i in 0 until count.coerceAtMost(64)) {
            val e = sfo + 20 + i * 16
            if (e + 16 > head.size) break
            val keyOff = keyTable + ((head[e].toInt() and 0xff) or ((head[e + 1].toInt() and 0xff) shl 8))
            val key = String(head, keyOff, 16.coerceAtMost(head.size - keyOff), Charsets.ISO_8859_1).substringBefore('\u0000')
            if (key == "DISC_ID") {
                val len = le32(head, e + 4).toInt()
                val off = dataTable + le32(head, e + 12).toInt()
                if (off + len <= head.size) return String(head, off, len, Charsets.ISO_8859_1).substringBefore('\u0000')
            }
        }
        return null
    }

    /** Índice de um .zip (nome e CRC de cada arquivo), lido do fim do arquivo. */
    private fun zipIndex(uri: Uri): List<Pair<String, Long>>? {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            FileInputStream(pfd.fileDescriptor).channel.use { ch ->
                val size = ch.size()
                val tailLen = minOf(size, 66_000L).toInt()
                val tail = read(ch, size - tailLen, tailLen) ?: return null
                var eocd = -1
                for (i in tail.size - 22 downTo 0) {
                    if (tail[i] == 0x50.toByte() && tail[i + 1] == 0x4b.toByte() && tail[i + 2] == 5.toByte() && tail[i + 3] == 6.toByte()) { eocd = i; break }
                }
                if (eocd < 0) return null
                val count = (tail[eocd + 10].toInt() and 0xff) or ((tail[eocd + 11].toInt() and 0xff) shl 8)
                val cdSize = le32(tail, eocd + 12)
                val cdOff = le32(tail, eocd + 16)
                if (cdSize <= 0 || cdSize > 16 * 1024 * 1024) return null
                val cd = read(ch, cdOff, cdSize.toInt()) ?: return null
                val out = ArrayList<Pair<String, Long>>()
                var p = 0
                repeat(count) {
                    if (p + 46 > cd.size || le32(cd, p) != 0x02014b50L) return out
                    val crc = le32(cd, p + 16)
                    val nameLen = (cd[p + 28].toInt() and 0xff) or ((cd[p + 29].toInt() and 0xff) shl 8)
                    val extraLen = (cd[p + 30].toInt() and 0xff) or ((cd[p + 31].toInt() and 0xff) shl 8)
                    val commentLen = (cd[p + 32].toInt() and 0xff) or ((cd[p + 33].toInt() and 0xff) shl 8)
                    val name = String(cd, p + 46, nameLen.coerceAtMost(cd.size - p - 46), Charsets.UTF_8)
                    if (!name.endsWith("/")) out.add(name to crc)
                    p += 46 + nameLen + extraLen + commentLen
                }
                return out
            }
        }
        return null
    }

    // ------------------------------------------------------------------ cartuchos

    /** CRC32 do arquivo (e sem o cabeçalho, quando o formato tem um), em hexadecimal minúsculo. */
    private fun cartridgeCrcs(uri: Uri, ext: String): List<String> {
        val resolver = context.contentResolver
        if (ext == "zip") {
            ZipInputStream(resolver.openInputStream(uri)?.buffered() ?: return emptyList()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    val inner = e.name.substringAfterLast('.', "").lowercase()
                    if (inner in setOf("txt", "nfo", "diz", "jpg", "png")) continue
                    // Lê o conteúdo: o CRC do cabeçalho local pode faltar (descritor de dados) e o cabeçalho do jogo precisa sair.
                    val localCrc = listOfNotNull(e.crc.takeIf { it >= 0 }?.let { hex(it) })
                    if (e.size > MAX_HASH) return localCrc
                    val data = zin.readNBytesCompat(MAX_HASH + 1)
                    if (data.size > MAX_HASH) return localCrc
                    return (crcs(data) + localCrc).distinct()
                }
            }
            return emptyList()
        }
        val data = resolver.openInputStream(uri)?.use { input ->
            val buf = input.readNBytesCompat(MAX_HASH + 1)
            if (buf.size > MAX_HASH) null else buf
        } ?: return emptyList()
        return crcs(data)
    }

    private fun crcs(data: ByteArray): List<String> {
        val out = ArrayList<String>(2)
        out.add(crcOf(data, 0))
        val header = when {
            data.size > 16 && data[0] == 'N'.code.toByte() && data[1] == 'E'.code.toByte() && data[2] == 'S'.code.toByte() && data[3] == 0x1A.toByte() -> 16
            data.size > 16 && data[0] == 'F'.code.toByte() && data[1] == 'D'.code.toByte() && data[2] == 'S'.code.toByte() && data[3] == 0x1A.toByte() -> 16
            data.size > 64 && String(data, 0, 4, Charsets.ISO_8859_1) == "LYNX" -> 64
            data.size > 128 && String(data, 1, 9, Charsets.ISO_8859_1) == "ATARI7800" -> 128
            data.size % 1024 == 512 && data.size > 512 -> 512  // cópia de SNES com cabeçalho de copiadora
            else -> 0
        }
        if (header > 0) out.add(crcOf(data, header))
        return out
    }

    private fun crcOf(data: ByteArray, from: Int): String {
        val c = CRC32()
        c.update(data, from, data.size - from)
        return hex(c.value)
    }

    private fun hex(v: Long) = "%08x".format(v and 0xffffffffL)

    // ------------------------------------------------------------------ discos

    /**
     * Código de série do disco: (série, título do cabeçalho se houver, sistema sugerido).
     * Lê o mínimo necessário do arquivo (sistema de arquivos ISO 9660).
     */
    private fun discSerial(uri: Uri, ext: String): Triple<String, String?, String?>? {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            FileInputStream(pfd.fileDescriptor).channel.use { ch ->
                val head = read(ch, 0, 0x60) ?: return null
                // GameCube / Wii: código de 6 letras no início e o nome em 0x20.
                val magicWii = be32(head, 0x18) == 0x5D1C9EA3L
                val magicGc = be32(head, 0x1C) == 0xC2339F3DL
                if (magicWii || magicGc) {
                    val id = String(head, 0, 6, Charsets.ISO_8859_1)
                    val title = read(ch, 0x20, 0x40)?.let { String(it, Charsets.UTF_8).substringBefore('\u0000').trim() }
                    return Triple(id, title, if (magicWii) "wii" else "gamecube")
                }
                // Saturn e Sega CD: cabeçalho no início do disco (ISO) ou depois dos 16 bytes de sincronia (BIN).
                for (base in listOf(0L, 16L)) {
                    val h = read(ch, base, 0x200) ?: continue
                    val sig = String(h, 0, 16, Charsets.ISO_8859_1)
                    if (sig.startsWith("SEGA SEGASATURN")) {
                        val product = String(h, 0x20, 10, Charsets.ISO_8859_1).trim()
                        if (product.isNotEmpty()) return Triple(product, null, "saturn")
                    }
                    if (sig.startsWith("SEGADISCSYSTEM") || sig.startsWith("SEGA SEGACD") || sig.startsWith("SEGA MEGA DRIVE")) {
                        val serial = String(h, 0x180, 14, Charsets.ISO_8859_1).trim().removePrefix("GM").trim().substringBefore(' ')
                        if (serial.length >= 4) return Triple(serial, null, "segacd")
                    }
                }
                val iso = Iso(ch) ?: return null
                iso.file("SYSTEM.CNF")?.let { cnf ->
                    val text = String(cnf, Charsets.ISO_8859_1)
                    val m = Regex("BOOT2?\\s*=\\s*cdrom0?:\\\\?([A-Z]{4})[_-]?(\\d{3})\\.?(\\d{2})", RegexOption.IGNORE_CASE).find(text)
                    if (m != null) return Triple(m.groupValues[1] + m.groupValues[2] + m.groupValues[3], null, null)
                }
                iso.file("UMD_DATA.BIN")?.let { umd ->
                    val serial = String(umd, Charsets.ISO_8859_1).substringBefore('|').trim()
                    if (serial.length >= 9) return Triple(serial, null, "psp")
                }
                return null
            }
        }
        return null
    }

    /** Leitor mínimo de ISO 9660 (setores de 2048 bytes ou imagem crua de 2352). */
    private inner class Iso(private val ch: FileChannel, private val sector: Int, private val offset: Int) {
        fun lba(n: Long): Long = n * sector + offset

        fun file(name: String): ByteArray? {
            val pvd = read(ch, lba(16), 2048) ?: return null
            val rootLba = le32(pvd, 156 + 2)
            val rootLen = le32(pvd, 156 + 10).coerceAtMost(64 * 1024)
            val dir = readExtent(rootLba, rootLen.toInt()) ?: return null
            var p = 0
            while (p < dir.size) {
                val len = dir[p].toInt() and 0xff
                if (len == 0) { p = ((p / 2048) + 1) * 2048; continue }
                val nameLen = dir[p + 32].toInt() and 0xff
                val n = String(dir, p + 33, nameLen, Charsets.ISO_8859_1).substringBefore(';')
                if (n.equals(name, ignoreCase = true)) {
                    val at = le32(dir, p + 2)
                    val size = le32(dir, p + 10).coerceAtMost(16 * 1024)
                    return readExtent(at, size.toInt())
                }
                p += len
            }
            return null
        }

        private fun readExtent(lba: Long, size: Int): ByteArray? {
            if (sector == 2048) return read(ch, lba(lba), size)
            val out = java.io.ByteArrayOutputStream()
            var left = size
            var n = lba
            while (left > 0) {
                val part = read(ch, lba(n), minOf(2048, left)) ?: return null
                out.write(part)
                left -= part.size
                n++
            }
            return out.toByteArray()
        }
    }

    private fun Iso(ch: FileChannel): Iso? {
        // 2048 (ISO), 2352 modo 1 (+16) e modo 2 (+24).
        for ((sector, offset) in listOf(2048 to 0, 2352 to 24, 2352 to 16)) {
            val pvd = read(ch, 16L * sector + offset, 8) ?: continue
            if (pvd[0].toInt() == 1 && String(pvd, 1, 5, Charsets.ISO_8859_1) == "CD001") return Iso(ch, sector, offset)
        }
        return null
    }

    private fun read(ch: FileChannel, at: Long, len: Int): ByteArray? {
        if (at < 0 || len <= 0) return null
        val buf = ByteBuffer.allocate(len)
        var pos = at
        while (buf.hasRemaining()) {
            val n = ch.read(buf, pos)
            if (n <= 0) break
            pos += n
        }
        return if (buf.position() == 0) null else buf.array().copyOf(buf.position())
    }

    private fun le32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xff) or ((b[o + 1].toLong() and 0xff) shl 8) or ((b[o + 2].toLong() and 0xff) shl 16) or ((b[o + 3].toLong() and 0xff) shl 24)

    private fun be32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xff) shl 24) or ((b[o + 1].toLong() and 0xff) shl 16) or ((b[o + 2].toLong() and 0xff) shl 8) or (b[o + 3].toLong() and 0xff)

    private fun java.io.InputStream.readNBytesCompat(max: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        var total = 0
        while (total < max) {
            val n = read(buf, 0, minOf(buf.size, max - total))
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toByteArray()
    }

    companion object {
        private const val TAG = "CartuchoNomes"
        /** Cartuchos até 64 MB (o maior de GBA/N64 é 64 MB). */
        private const val MAX_HASH = 64 * 1024 * 1024
        private val DISC_EXTS = setOf("iso", "bin", "img", "gcm", "rvz", "wbfs", "wia", "chd", "cso")
        private val DISC_SYSTEMS = setOf("psx", "ps2", "psp", "gamecube", "wii", "saturn", "segacd")
        /** Sobe quando o reconhecimento melhora: os jogos não reconhecidos são tentados de novo. */
        private const val ALGO = 2

        fun normSerial(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

        /** "Legend of Zelda, The - A Link to the Past (USA) (Rev 1)" -> "The Legend of Zelda - A Link to the Past". */
        fun cleanTitle(name: String): String {
            var t = name.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), "").trim()
            val m = Regex("^(.*?), (The|A|An|O|A|Os|As|El|La|Le|Les|Der|Die|Das)( - .*)?$").find(t)
            if (m != null) t = m.groupValues[2] + " " + m.groupValues[1] + m.groupValues[3]
            return t.ifBlank { name }
        }
    }
}
