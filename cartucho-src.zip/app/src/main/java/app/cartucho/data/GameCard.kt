package app.cartucho.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import app.cartucho.CartuchoApp
import app.cartucho.R
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

/**
 * Card do jogo em formato de celular (1080x1920, proporção de Stories) para compartilhar:
 * capa grande, status (jogando, zerado, platinado…), estrelas da nota, horas jogadas e um trecho da resenha.
 * Feito só com o Canvas do Android, funciona tanto na biblioteca quanto no menu do jogo.
 */
object GameCard {
    private const val W = 1080
    private const val H = 1920

    private const val MINT = 0xFF5EF0CF.toInt()
    private const val MINT_DIM = 0xFF2B7C6C.toInt()
    private const val INK = 0xFF0B1210.toInt()

    /**
     * Gera o card (inspirado em "resumos" de redes sociais): dois cartões inclinados no topo —
     * a capa do jogo na frente e um cartão pixelado do Cartucho atrás — e, embaixo, o resumo do jogo.
     * Bloqueante: chame fora da thread principal.
     */
    fun render(
        context: Context,
        game: Game,
        entry: CollectionEntry,
        seconds: Long,
        user: String,
        coverFile: File,
    ): File {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val heavy = runCatching { ResourcesCompat.getFont(context, R.font.geist_semibold) }.getOrNull() ?: Typeface.DEFAULT_BOLD
        val regular = runCatching { ResourcesCompat.getFont(context, R.font.geist_regular) }.getOrNull() ?: Typeface.DEFAULT
        val mono = runCatching { ResourcesCompat.getFont(context, R.font.geist_mono) }.getOrNull() ?: Typeface.MONOSPACE
        val cover = if (coverFile.exists()) BitmapFactory.decodeFile(coverFile.absolutePath) else null
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // Fundo escuro esverdeado com retícula (pontos que crescem para cima).
        canvas.drawPaint(Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, H.toFloat(), 0xFF16211E.toInt(), 0xFF070B0A.toInt(), Shader.TileMode.CLAMP)
        })
        p.color = 0x1FFFFFFF
        var dy = 0f
        while (dy < H * 0.62f) {
            val r = 3.2f * (1f - dy / (H * 0.62f))
            var dx = if (((dy / 18f).toInt()) % 2 == 0) 0f else 9f
            while (dx < W) { canvas.drawCircle(dx, dy, r, p); dx += 18f }
            dy += 18f
        }

        val status = when (entry.status) {
            PlayStatus.BEATEN -> "ZERADO"
            PlayStatus.PLATINUM -> "PLATINADO"
            PlayStatus.DROPPED -> "ABANDONADO"
            PlayStatus.WANT -> "NA LISTA"
            else -> "JOGANDO"
        }
        val system = Systems.get(game.systemId)
        val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)

        // Cartão de trás: pixels do Cartucho, inclinado para a direita.
        canvas.save()
        canvas.rotate(9f, 640f, 560f)
        val back = RectF(420f, 230f, 900f, 900f)
        p.color = 0x55000000; canvas.drawRect(back.left + 24f, back.top + 30f, back.right + 24f, back.bottom + 30f, p)
        p.color = MINT; canvas.drawRect(back, p)
        val inner = RectF(back.left + 22f, back.top + 22f, back.right - 22f, back.bottom - 22f)
        p.color = INK; canvas.drawRect(inner, p)
        val rnd = java.util.Random(game.id.hashCode().toLong())
        val cell = 22f
        var yy = inner.top
        while (yy < inner.bottom - 1) {
            var xx = inner.left
            while (xx < inner.right - 1) {
                if (rnd.nextFloat() < 0.42f) {
                    p.color = if (rnd.nextFloat() < 0.5f) 0xFF8A9A95.toInt() else 0xFFD8E2DF.toInt()
                    canvas.drawRect(xx + 3f, yy + 3f, minOf(xx + cell, inner.right) - 3f, minOf(yy + cell, inner.bottom) - 3f, p)
                }
                xx += cell
            }
            yy += cell
        }
        val badge = RectF(inner.centerX() - 90f, inner.centerY() - 60f, inner.centerX() + 90f, inner.centerY() + 60f)
        p.color = MINT; canvas.drawRect(badge, p)
        p.color = INK; p.typeface = heavy; p.textSize = 30f; p.textAlign = Paint.Align.CENTER
        canvas.drawText("CARTUCHO", badge.centerX(), badge.centerY() + 11f, p)
        p.textAlign = Paint.Align.LEFT
        canvas.restore()

        // Cartão da frente: capa do jogo, inclinado para a esquerda.
        canvas.save()
        canvas.rotate(-6f, 430f, 560f)
        val front = RectF(170f, 190f, 690f, 905f)
        p.color = 0x66000000; canvas.drawRect(front.left + 26f, front.top + 34f, front.right + 26f, front.bottom + 34f, p)
        p.color = MINT; canvas.drawRect(front, p)
        // Faixa do topo ("nível" = horas jogadas).
        p.color = INK
        for (i in 0 until 9) canvas.drawRect(front.left + 30f + i * 16f, front.top + 26f, front.left + 40f + i * 16f, front.top + 40f, p)
        p.typeface = mono; p.textSize = 22f
        canvas.drawText("LVL " + (seconds / 60).toString().padStart(6, '0'), front.left + 30f, front.top + 72f, p)
        val art = RectF(front.left + 30f, front.top + 92f, front.right - 30f, front.top + 92f + (front.width() - 60f) * 1.02f)
        p.color = 0xFF3FD1B1.toInt(); canvas.drawRect(art, p)
        if (cover != null) {
            val ratio = cover.width.toFloat() / cover.height
            val boxRatio = art.width() / art.height()
            val r = if (ratio > boxRatio) {
                val h = art.width() / ratio
                RectF(art.left, art.centerY() - h / 2, art.right, art.centerY() + h / 2)
            } else {
                val w = art.height() * ratio
                RectF(art.centerX() - w / 2, art.top, art.centerX() + w / 2, art.bottom)
            }
            canvas.drawBitmap(cover, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
        }
        p.color = INK; p.typeface = mono; p.textSize = 20f
        canvas.drawText("CARTUCHO $year · ${system?.short ?: "JOGO"}", front.left + 30f, art.bottom + 46f, p)
        p.textAlign = Paint.Align.RIGHT
        canvas.drawText(if (entry.rating > 0) "${entry.rating}/10" else status, front.right - 30f, art.bottom + 46f, p)
        p.textAlign = Paint.Align.LEFT
        val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = heavy; textSize = 46f; color = INK }
        val nameLayout = staticLayout(game.title, namePaint, (front.width() - 60f).toInt(), 1)
        canvas.save(); canvas.translate(front.left + 30f, art.bottom + 62f); nameLayout.draw(canvas); canvas.restore()
        canvas.restore()
        cover?.recycle()

        // Resumo embaixo.
        val left = 90f
        var y = 1080f
        drawFlag(canvas, left, y - 30f, 34f)
        p.typeface = heavy; p.textSize = 36f; p.color = MINT; p.letterSpacing = 0.04f
        canvas.drawText(if (entry.status == PlayStatus.NONE || entry.status == PlayStatus.PLAYING) "ESTOU JOGANDO" else "MEU RESULTADO", left + 56f, y, p)
        p.letterSpacing = 0f
        y += 150f
        val headPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = heavy; textSize = 170f; color = MINT; letterSpacing = -0.02f }
        while (headPaint.measureText("$status!") > W - 2 * left && headPaint.textSize > 90f) headPaint.textSize = headPaint.textSize - 6f
        canvas.drawText("$status!", left, y, headPaint)

        // Grade 2 colunas: rótulo com ícone + valor.
        val colX = floatArrayOf(left, W / 2f + 20f)
        val rows = listOf(
            listOf(Icon.CLOCK to "HORAS JOGADAS", Icon.STAR to "MINHA NOTA"),
            listOf(Icon.PAD to "JOGO", Icon.CHIP to "CONSOLE"),
            listOf(Icon.FLAG to if (entry.finishedAt > 0) "ZERADO EM" else "STATUS", Icon.USER to "JOGADOR"),
        )
        val values = listOf(
            listOf(if (seconds > 0) CollectionStore.formatHours(seconds) else "—", ""),
            listOf(game.title, system?.name ?: "—"),
            listOf(
                if (entry.finishedAt > 0) java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale("pt", "BR")).format(java.util.Date(entry.finishedAt)) else status.lowercase().replaceFirstChar { it.uppercase() },
                if (user.isNotEmpty()) "@$user" else "Cartucho",
            ),
        )
        y += 110f
        for (r in rows.indices) {
            for (c in 0..1) {
                val (icon, label) = rows[r][c]
                drawIcon(canvas, icon, colX[c], y - 30f, 34f)
                p.typeface = heavy; p.textSize = 32f; p.color = MINT; p.letterSpacing = 0.04f
                canvas.drawText(label, colX[c] + 54f, y, p)
                p.letterSpacing = 0f
                if (r == 0 && c == 1) {
                    if (entry.rating > 0) drawStars(canvas, colX[c], y + 28f, 52f, entry.rating, MINT)
                    else { p.typeface = regular; p.textSize = 54f; p.color = 0xFFDDF7F0.toInt(); canvas.drawText("—", colX[c], y + 78f, p) }
                } else {
                    val vp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = regular; textSize = 54f; color = 0xFFDDF7F0.toInt() }
                    val text = android.text.TextUtils.ellipsize(values[r][c], vp, W / 2f - 120f, android.text.TextUtils.TruncateAt.END).toString()
                    canvas.drawText(text, colX[c], y + 76f, vp)
                }
            }
            y += 170f
        }

        // Marca discreta no rodapé.
        p.typeface = mono; p.textSize = 26f; p.color = MINT_DIM; p.letterSpacing = 0.2f
        canvas.drawText("CARTUCHO · EMULADOR", left, H - 70f, p)

        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val out = File(dir, "card-${game.id.take(12)}.png")
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return out
    }

    private enum class Icon { CLOCK, STAR, PAD, CHIP, FLAG, USER }

    /** Ícones simples desenhados (sem fonte de ícones), na cor de destaque. */
    private fun drawIcon(canvas: Canvas, icon: Icon, x: Float, y: Float, s: Float) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = MINT }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = MINT; style = Paint.Style.STROKE; strokeWidth = s * 0.14f; strokeCap = Paint.Cap.ROUND }
        val cx = x + s / 2
        val cy = y + s / 2
        when (icon) {
            Icon.CLOCK -> {
                canvas.drawCircle(cx, cy, s * 0.42f, stroke)
                canvas.drawLine(cx, cy, cx, cy - s * 0.24f, stroke)
                canvas.drawLine(cx, cy, cx + s * 0.18f, cy + s * 0.08f, stroke)
            }
            Icon.STAR -> canvas.drawPath(starPath(cx, cy, s * 0.5f), fill)
            Icon.PAD -> {
                canvas.drawRoundRect(RectF(x, y + s * 0.2f, x + s, y + s * 0.85f), s * 0.3f, s * 0.3f, fill)
                val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = INK }
                canvas.drawRect(x + s * 0.18f, cy - s * 0.04f, x + s * 0.42f, cy + s * 0.06f, hole)
                canvas.drawRect(x + s * 0.25f, cy - s * 0.12f, x + s * 0.35f, cy + s * 0.14f, hole)
                canvas.drawCircle(x + s * 0.72f, cy, s * 0.07f, hole)
            }
            Icon.CHIP -> {
                canvas.drawRect(x + s * 0.2f, y + s * 0.2f, x + s * 0.8f, y + s * 0.8f, fill)
                for (i in 0..2) {
                    val t = y + s * (0.3f + i * 0.2f)
                    canvas.drawLine(x, t, x + s * 0.2f, t, stroke)
                    canvas.drawLine(x + s * 0.8f, t, x + s, t, stroke)
                }
            }
            Icon.FLAG -> drawFlag(canvas, x, y, s)
            Icon.USER -> {
                canvas.drawCircle(cx, y + s * 0.3f, s * 0.2f, fill)
                canvas.drawRoundRect(RectF(x + s * 0.12f, y + s * 0.58f, x + s * 0.88f, y + s), s * 0.3f, s * 0.3f, fill)
            }
        }
    }

    private fun drawFlag(canvas: Canvas, x: Float, y: Float, s: Float) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = MINT }
        canvas.drawRect(x + s * 0.08f, y, x + s * 0.2f, y + s, fill)
        canvas.drawRect(x + s * 0.2f, y + s * 0.04f, x + s * 0.95f, y + s * 0.55f, fill)
        val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = INK }
        canvas.drawRect(x + s * 0.45f, y + s * 0.15f, x + s * 0.65f, y + s * 0.3f, ink)
    }

    /** Monta o card com os dados da coleção e abre o compartilhar. Chame numa coroutine. */
    suspend fun shareGame(app: CartuchoApp, game: Game, entryOverride: CollectionEntry? = null): Boolean {
        val file = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val entry = entryOverride ?: app.collection.get(game.id)
                val seconds = app.collection.secondsByGame()[game.id] ?: 0L
                render(app, game, entry, seconds, app.prefs.current.raUser, app.covers.file(game.id))
            }.getOrNull()
        } ?: return false
        return runCatching { share(app, file) }.isSuccess
    }

    /** Abre o "Compartilhar" do Android com o card (Instagram, WhatsApp, X…). */
    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "app.cartucho.files", file)
        val intent = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Compartilhar card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** 5 estrelas desenhadas (sem depender de fonte), com meias estrelas. rating vai de 0 a 10. */
    private fun drawStars(canvas: Canvas, x: Float, y: Float, size: Float, rating: Int, color: Int) {
        val empty = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0x40FFFFFF }
        val full = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        for (i in 0 until 5) {
            val left = x + i * (size + 12f)
            val star = starPath(left + size / 2, y + size / 2, size / 2)
            canvas.drawPath(star, empty)
            val value = rating - i * 2
            if (value >= 2) {
                canvas.drawPath(star, full)
            } else if (value == 1) {
                canvas.save()
                canvas.clipRect(left, y, left + size / 2, y + size)
                canvas.drawPath(star, full)
                canvas.restore()
            }
        }
    }

    private fun starPath(cx: Float, cy: Float, r: Float): Path {
        val path = Path()
        val inner = r * 0.45f
        for (k in 0 until 10) {
            val radius = if (k % 2 == 0) r else inner
            val angle = Math.toRadians(-90.0 + k * 36.0)
            val px = cx + (radius * cos(angle)).toFloat()
            val py = cy + (radius * sin(angle)).toFloat()
            if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        return path
    }

    @Suppress("DEPRECATION")
    private fun staticLayout(text: String, paint: TextPaint, width: Int, maxLines: Int): StaticLayout =
        if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setMaxLines(maxLines)
                .setEllipsize(android.text.TextUtils.TruncateAt.END)
                .build()
        } else {
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1f, 0f, false)
        }
}
