package app.cartucho.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import app.cartucho.CartuchoApp
import app.cartucho.R
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

/**
 * Card do jogo em formato de celular (1080x1920, proporção de Stories) para compartilhar:
 * capa grande, status (jogando, zerado, platinado…), estrelas da nota, horas jogadas e um trecho da resenha.
 * Feito só com o Canvas do Android, funciona tanto na biblioteca quanto no menu do jogo.
 */
object GameCard {
    private const val W = 1080
    private const val H = 1920

    /** Gera o card e abre a tela de compartilhar do Android. Bloqueante na geração: chame fora da thread principal. */
    fun render(
        context: Context,
        game: Game,
        entry: CollectionEntry,
        seconds: Long,
        user: String,
        coverFile: File,
    ): File {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bold = runCatching { ResourcesCompat.getFont(context, R.font.geist_semibold) }.getOrNull() ?: Typeface.DEFAULT_BOLD
        val regular = runCatching { ResourcesCompat.getFont(context, R.font.geist_regular) }.getOrNull() ?: Typeface.DEFAULT
        val mono = runCatching { ResourcesCompat.getFont(context, R.font.geist_mono) }.getOrNull() ?: Typeface.MONOSPACE
        val cover = if (coverFile.exists()) BitmapFactory.decodeFile(coverFile.absolutePath) else null

        // Fundo: a própria capa, ampliada e escurecida (ou um degradê neutro).
        canvas.drawColor(0xFF111111.toInt())
        if (cover != null) {
            val scale = maxOf(W.toFloat() / cover.width, H.toFloat() / cover.height) * 1.15f
            val bw = cover.width * scale
            val bh = cover.height * scale
            val small = Bitmap.createScaledBitmap(cover, 24, (24f * cover.height / cover.width).toInt().coerceAtLeast(8), true)
            canvas.drawBitmap(small, null, RectF((W - bw) / 2, (H - bh) / 2, (W + bw) / 2, (H + bh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            small.recycle()
        }
        canvas.drawRect(
            0f, 0f, W.toFloat(), H.toFloat(),
            Paint().apply { shader = LinearGradient(0f, 0f, 0f, H.toFloat(), 0x99111111.toInt(), 0xF2111111.toInt(), Shader.TileMode.CLAMP) },
        )

        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // Topo: marca e status.
        p.typeface = mono; p.textSize = 34f; p.color = 0xCCF2F2F0.toInt(); p.letterSpacing = 0.18f
        canvas.drawText("CARTUCHO", 90f, 150f, p)
        p.letterSpacing = 0f
        val status = when (entry.status) {
            PlayStatus.BEATEN -> "ZERADO"
            PlayStatus.PLATINUM -> "PLATINADO"
            PlayStatus.DROPPED -> "ABANDONADO"
            PlayStatus.WANT -> "QUERO JOGAR"
            else -> "JOGANDO AGORA"
        }
        val accent = when (entry.status) {
            PlayStatus.PLATINUM -> 0xFFE8C46A.toInt()
            PlayStatus.BEATEN -> 0xFF8FD6A0.toInt()
            PlayStatus.DROPPED -> 0xFFE58A8A.toInt()
            else -> 0xFF9DB8FF.toInt()
        }
        p.typeface = bold; p.textSize = 34f; p.letterSpacing = 0.08f
        val pillW = p.measureText(status) + 60f
        val pill = RectF(W - 90f - pillW, 100f, W - 90f, 168f)
        p.color = accent
        canvas.drawRoundRect(pill, 34f, 34f, p)
        p.color = 0xFF111111.toInt()
        canvas.drawText(status, pill.left + 30f, 146f, p)
        p.letterSpacing = 0f

        // Capa.
        val coverRect = RectF(150f, 250f, W - 150f, 250f + (W - 300f) * 1.25f)
        if (cover != null) {
            val ratio = cover.width.toFloat() / cover.height
            val boxRatio = coverRect.width() / coverRect.height()
            val r = if (ratio > boxRatio) {
                val h = coverRect.width() / ratio
                RectF(coverRect.left, coverRect.centerY() - h / 2, coverRect.right, coverRect.centerY() + h / 2)
            } else {
                val w = coverRect.height() * ratio
                RectF(coverRect.centerX() - w / 2, coverRect.top, coverRect.centerX() + w / 2, coverRect.bottom)
            }
            p.color = 0x66000000
            canvas.drawRoundRect(RectF(r.left + 10f, r.top + 24f, r.right + 10f, r.bottom + 24f), 36f, 36f, p)
            canvas.save()
            canvas.clipPath(Path().apply { addRoundRect(r, 36f, 36f, Path.Direction.CW) })
            canvas.drawBitmap(cover, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
            cover.recycle()
        }

        // Título e sistema.
        var y = coverRect.bottom + 120f
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = bold; textSize = 76f; color = 0xFFF2F2F0.toInt() }
        var layout = staticLayout(game.title, titlePaint, W - 180, 2)
        while (layout.lineCount > 2 && titlePaint.textSize > 48f) {
            titlePaint.textSize = titlePaint.textSize - 4f
            layout = staticLayout(game.title, titlePaint, W - 180, 2)
        }
        canvas.save(); canvas.translate(90f, y - titlePaint.textSize); layout.draw(canvas); canvas.restore()
        y += layout.height - titlePaint.textSize + 70f
        p.typeface = regular; p.textSize = 38f; p.color = 0xFF9A9A96.toInt()
        val sys = Systems.get(game.systemId)?.name.orEmpty()
        val hours = if (seconds > 0) CollectionStore.formatHours(seconds) + " jogadas" else ""
        canvas.drawText(listOf(sys, hours).filter { it.isNotEmpty() }.joinToString("  ·  "), 90f, y, p)

        // Estrelas (meias estrelas): mostram o quanto gostou.
        y += 110f
        if (entry.rating > 0) {
            drawStars(canvas, 90f, y - 60f, 74f, entry.rating, accent)
            p.typeface = bold; p.textSize = 44f; p.color = 0xFFF2F2F0.toInt()
            val label = String.format(java.util.Locale("pt", "BR"), "%.1f", entry.rating / 2.0)
            canvas.drawText(label, 90f + 5 * 86f + 20f, y, p)
        } else {
            p.typeface = regular; p.textSize = 38f; p.color = 0xFF9A9A96.toInt()
            canvas.drawText("Ainda sem nota", 90f, y, p)
        }

        // Trecho da resenha.
        if (entry.review.isNotBlank()) {
            y += 90f
            val reviewPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = regular; textSize = 40f; color = 0xFFD6D6D2.toInt() }
            val text = "“" + entry.review.trim().let { if (it.length > 180) it.take(177).trimEnd() + "…" else it } + "”"
            val rl = staticLayout(text, reviewPaint, W - 180, 4)
            canvas.save(); canvas.translate(90f, y - 40f); rl.draw(canvas); canvas.restore()
        }

        // Rodapé.
        p.typeface = regular; p.textSize = 34f; p.color = 0xFF8A8A86.toInt()
        canvas.drawText(if (user.isNotEmpty()) "@$user" else "Jogado no Cartucho", 90f, H - 110f, p)

        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val out = File(dir, "card-${game.id.take(12)}.png")
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return out
    }

    /** Monta o card com os dados da coleção e abre o compartilhar. Chame numa coroutine. */
    suspend fun shareGame(app: CartuchoApp, game: Game, entryOverride: CollectionEntry? = null): Boolean {
        val file = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val entry = entryOverride ?: app.collection.get(game.id)
                val seconds = app.collection.secondsByGame()[game.id] ?: 0L
                render(app, game, entry, seconds, app.prefs.current.raUser, app.covers.file(game.id))
            }.getOrNull()
        } ?: return false
        return runCatching { share(app, file) }.isSuccess
    }

    /** Abre o "Compartilhar" do Android com o card (Instagram, WhatsApp, X…). */
    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "app.cartucho.files", file)
        val intent = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Compartilhar card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** 5 estrelas desenhadas (sem depender de fonte), com meias estrelas. rating vai de 0 a 10. */
    private fun drawStars(canvas: Canvas, x: Float, y: Float, size: Float, rating: Int, color: Int) {
        val empty = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0x40FFFFFF }
        val full = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        for (i in 0 until 5) {
            val left = x + i * (size + 12f)
            val star = starPath(left + size / 2, y + size / 2, size / 2)
            canvas.drawPath(star, empty)
            val value = rating - i * 2
            if (value >= 2) {
                canvas.drawPath(star, full)
            } else if (value == 1) {
                canvas.save()
                canvas.clipRect(left, y, left + size / 2, y + size)
                canvas.drawPath(star, full)
                canvas.restore()
            }
        }
    }

    private fun starPath(cx: Float, cy: Float, r: Float): Path {
        val path = Path()
        val inner = r * 0.45f
        for (k in 0 until 10) {
            val radius = if (k % 2 == 0) r else inner
            val angle = Math.toRadians(-90.0 + k * 36.0)
            val px = cx + (radius * cos(angle)).toFloat()
            val py = cy + (radius * sin(angle)).toFloat()
            if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        return path
    }

    @Suppress("DEPRECATION")
    private fun staticLayout(text: String, paint: TextPaint, width: Int, maxLines: Int): StaticLayout =
        if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setMaxLines(maxLines)
                .setEllipsize(android.text.TextUtils.TruncateAt.END)
                .build()
        } else {
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1f, 0f, false)
        }
}
