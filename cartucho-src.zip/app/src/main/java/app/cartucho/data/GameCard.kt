package app.cartucho.data

import app.cartucho.achievements.RetroAchievements

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import app.cartucho.CartuchoApp
import app.cartucho.R
import app.cartucho.achievements.AchievementCache
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Formatos do card do jogador. Story é o do celular, Feed o do tablet, Link o do computador. */
enum class CardFormat(val width: Int, val height: Int, val label: String) {
    STORY(1080, 1920, "Story"),
    FEED(1080, 1080, "Feed"),
    LINK(1200, 630, "Link"),
}

/** Tudo o que o card mostra, já resolvido (texto pronto, sem acesso a disco ao desenhar). */
data class CardData(
    val title: String,
    val console: String,
    val finished: Boolean,
    val platinum: Boolean,
    val rating: Int,
    val seconds: Long,
    val player: String,
    val date: Long,
    val comment: String,
    val level: Int,
    val achievementsTotal: Int,
    val achievementsUnlocked: Int,
    /** Até 4 conquistas desbloqueadas (título, pontos), das que valem mais. */
    val highlights: List<Pair<String, Int>>,
    val coverFile: File?,
)

/**
 * Card do jogador para compartilhar, no visual do design system do Cartucho:
 * fundo cinza console, placa do cartucho com a capa do jogo, selo, status em roxo,
 * conquistas, números, comentário e as três listras. Desenhado só com o Canvas do Android.
 */
object GameCard {
    // Tokens do design system.
    private const val SURFACE = 0xFFE3E3EA.toInt()
    private const val CARD = 0xFFFFFFFF.toInt()
    private const val LINE = 0xFFCACAD3.toInt()
    private const val LINE_SOFT = 0xFFE1E1E8.toInt()
    private const val INK = 0xFF1E1E24.toInt()
    private const val MUTED2 = 0xFF55556A.toInt()
    private const val PURPLE = 0xFF4F43AE.toInt()
    private const val PURPLE_DARK = 0xFF3A3088.toInt()
    private const val LAVENDER = 0xFFC9C6EE.toInt()
    private const val LAVENDER_MID = 0xFF8F86D6.toInt()
    private const val LAVENDER_SOFT = 0xFFE6E4F8.toInt()
    private const val LAVENDER_INK = 0xFF2A2366.toInt()
    private const val RED = 0xFFD3262F.toInt()
    private const val YELLOW = 0xFFF0BE1E.toInt()
    private const val YELLOW_INK = 0xFF2A2410.toInt()
    private const val GREEN = 0xFF23965A.toInt()
    private const val BLUE = 0xFF2A5DB8.toInt()
    private const val PLATE = 0xFFD2D2DB.toInt()
    private const val PLATE_HI = 0xFFEDEDF2.toInt()
    private const val PLATE_SHADE = 0xFFB9B9C4.toInt()
    private const val PAD = 0xFFBDBDC8.toInt()
    private const val PAD_HI = 0xFFD9D9E1.toInt()
    private val DOTS = intArrayOf(RED, YELLOW, GREEN, BLUE)

    /** Fontes do card (Inter e Space Grotesk), carregadas uma vez por render. */
    private class Fonts(private val context: Context) {
        private fun load(id: Int, fallback: Typeface) = runCatching { ResourcesCompat.getFont(context, id) }.getOrNull() ?: fallback
        val regular = load(R.font.inter_regular, Typeface.DEFAULT)
        val medium = load(R.font.inter_medium, Typeface.DEFAULT)
        val semibold = load(R.font.inter_semibold, Typeface.DEFAULT_BOLD)
        val bold = load(R.font.inter_bold, Typeface.DEFAULT_BOLD)
        val display = load(R.font.space_grotesk_bold, Typeface.DEFAULT_BOLD)
    }

    /** Formato padrão do aparelho: Story no celular, Feed no tablet. */
    fun defaultFormat(context: Context): CardFormat =
        if (context.resources.configuration.smallestScreenWidthDp >= 600) CardFormat.FEED else CardFormat.STORY

    // ---------------------------------------------------------------- dados

    /** Junta os dados do jogo, da coleção, do perfil e das conquistas. Bloqueante: chame fora da thread principal. */
    fun buildData(app: CartuchoApp, game: Game, comment: String? = null, entryOverride: CollectionEntry? = null): CardData {
        val entry = entryOverride ?: app.collection.get(game.id)
        val sessions = app.collection.sessions()
        val seconds = sessions.filter { it.gameId == game.id }.sumOf { it.seconds }
        val finished = entry.status == PlayStatus.BEATEN || entry.status == PlayStatus.PLATINUM
        val firstPlay = sessions.filter { it.gameId == game.id }.minOfOrNull { it.start }?.takeIf { it > 0 }
        val date = when {
            finished && entry.finishedAt > 0 -> entry.finishedAt
            firstPlay != null -> firstPlay
            game.lastPlayed > 0 -> game.lastPlayed
            else -> System.currentTimeMillis()
        }
        val settings = app.prefs.current
        val profileName = runCatching { app.profile.data.value.name }.getOrDefault("")
        val player = when {
            settings.raUser.isNotBlank() -> "@" + settings.raUser
            profileName.isNotBlank() -> profileName
            else -> "Jogador"
        }
        val beaten = app.collection.entries.value.values.count { it.status == PlayStatus.BEATEN || it.status == PlayStatus.PLATINUM }
        val level = Profile.level(Profile.xp(settings.raScore, sessions.sumOf { it.seconds }, beaten)).first

        // Conquistas: as do jogo aberto (processo do jogo) ou a última cópia guardada para este jogo.
        val live = runCatching {
            val ra = RetroAchievements.get()
            if (ra.state.value.total > 0) ra.achievements() else emptyList()
        }.getOrDefault(emptyList())
        if (live.isNotEmpty()) AchievementCache.save(app, game.id, live)
        val list = live.ifEmpty { AchievementCache.load(app, game.id) }
        val unlocked = list.filter { it.unlocked }
        val highlights = unlocked.sortedByDescending { it.points }.take(4).sortedBy { it.points }.map { it.title to it.points }

        // A mesma capa que aparece na biblioteca (a encontrada online ou, sem ela, a gerada no aparelho).
        val cover = app.covers.file(game.id).takeIf { it.exists() && it.length() > 0 }
        return CardData(
            title = game.title,
            console = Systems.get(game.systemId)?.short ?: "",
            finished = finished,
            platinum = entry.status == PlayStatus.PLATINUM,
            rating = entry.rating,
            seconds = seconds,
            player = player,
            date = date,
            comment = (comment ?: entry.review).trim().take(120),
            level = level,
            achievementsTotal = list.size,
            achievementsUnlocked = unlocked.size,
            highlights = highlights,
            coverFile = cover,
        )
    }

    // ---------------------------------------------------------------- desenho

    /** Desenha o card no formato pedido. Bloqueante. */
    private fun render(context: Context, data: CardData, format: CardFormat): Bitmap {
        val bmp = Bitmap.createBitmap(format.width, format.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val f = Fonts(context)
        val cover: Bitmap? = data.coverFile?.let { loadCover(it) }  // sem capa, entra o cartucho desenhado
        canvas.drawColor(SURFACE)
        when (format) {
            CardFormat.FEED -> drawFeed(canvas, f, data, cover)
            CardFormat.STORY -> drawStory(canvas, f, data, cover)
            CardFormat.LINK -> drawLink(canvas, f, data, cover)
        }
        cover?.recycle()
        return bmp
    }

    private fun statusText(d: CardData) = when {
        d.platinum -> "PLATINADO!"
        d.finished -> "ZERADO!"
        else -> "JOGANDO AGORA"
    }

    private fun statusLabel(d: CardData) = if (d.finished) "Meu resultado" else "No meu cartucho"

    private fun dateLabel(d: CardData) = when {
        d.platinum -> "Platinado em"
        d.finished -> "Zerado em"
        else -> "Jogando desde"
    }

    private fun dateText(d: CardData) = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(d.date))

    private fun hoursText(seconds: Long): String {
        if (seconds < 60) return "—"
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        return when {
            h == 0L -> "${m}min"
            m == 0L -> "${h}h"
            else -> "${h}h ${m}min"
        }
    }

    /** Uma informação do card: rótulo com ponto colorido e valor (texto ou estrelas). */
    private class Stat(val label: String, val dot: Int, val value: String?, val stars: Int = -1)

    private fun stats(d: CardData, kinds: List<String>): List<Stat> = kinds.map { k ->
        when (k) {
            "horas" -> Stat("Horas jogadas", RED, hoursText(d.seconds))
            "nota" -> if (d.rating > 0) Stat("Minha nota", YELLOW, null, d.rating) else Stat("Minha nota", YELLOW, "Sem nota")
            "jogo" -> Stat("Jogo", GREEN, d.title)
            "console" -> Stat("Console", BLUE, d.console.ifBlank { "—" })
            "jogador" -> Stat("Jogador", RED, d.player)
            else -> Stat(dateLabel(d), YELLOW, dateText(d))
        }
    }

    /** Tamanho do título no modelo: "ZERADO!" grande, "JOGANDO AGORA" menor (cabe na coluna). */
    private fun titleSize(d: CardData, big: Float, small: Float) = if (d.finished) big else small

    // ---- Feed 1080 × 1080 (tablet). Coordenadas do modelo "Card do jogador · feed".

    private fun drawFeed(c: Canvas, f: Fonts, d: CardData, cover: Bitmap?) {
        val left = 72f
        val right = 1008f
        val colX = 424f
        val colW = right - colX
        drawPlate(c, f, left, 69f, 300f, d, cover)
        drawSelo(c, f, colX, 64f, right, icon = 34f, name = 20f, dot = 8f, pill = 16f)
        drawStatusLabel(c, f, colX, 120f, 18f, 9f, statusLabel(d))
        val ts = fitSize(statusText(d), f.display, titleSize(d, 104f, 64f), 40f, colW, -0.04f)
        drawTitleCentered(c, f, statusText(d), colX, 204f, ts)
        if (d.achievementsTotal > 0) {
            drawAchievementBox(c, f, d, colX, 277f, colW, 97f, pad = 18f, label = 14f, count = 15f, pct = 25f, segH = 14f, segments = 16)
        }
        // Grade 3 × 2: rótulos em 434 e 522, valores em 461 e 549; colunas de 290 com 33 de vão.
        val grid = stats(d, listOf("horas", "nota", "jogo", "console", "jogador", "data"))
        grid.forEachIndexed { i, st ->
            val x = left + (i % 3) * (290f + 33f)
            val ly = if (i < 3) 434f else 522f
            drawStat(c, f, st, x, ly, ly + 27f, 290f, label = 15f, value = 30f, dot = 9f, star = 29f)
        }
        var y = 632f
        if (d.highlights.isNotEmpty()) {
            drawTiles(c, f, d.highlights, left, y, right - left, 167f, 16f, 46f, 16f, 12f)
            y += 167f + 20f
        }
        if (d.comment.isNotBlank()) drawQuote(c, f, d.comment, left, y, right - left, 20f, 40f, 20f, maxLines = 2)
        drawFooter(c, f, left, 1005f, right, 14f, 8f)
        drawStripes(c, 1080f, 1080f, 14f)
    }

    // ---- Story 1080 × 1920 (celular). Nada importante nos 250 px de cima e de baixo.

    private fun drawStory(c: Canvas, f: Fonts, d: CardData, cover: Bitmap?) {
        val left = 96f
        val right = 984f
        val w = right - left
        val hasAch = d.achievementsTotal > 0
        val hasTiles = d.highlights.isNotEmpty()
        val hasQuote = d.comment.isNotBlank()
        val quoteH = if (hasQuote) quoteHeight(f, d.comment, w, 24f, 23f, maxLines = 3) else 0f
        // Sem conquistas ou sem comentário, o conteúdo sobe; o que sobra é dividido em cima e embaixo.
        var bottom = 1013f
        if (hasAch) bottom += 142f + 16f
        if (hasTiles) bottom += 186f
        bottom += if (hasAch) 40f else 0f
        bottom += 63f
        if (hasQuote) bottom += 36f + quoteH
        bottom += 42f + 20f
        val shift = ((1670f - bottom) / 2f).coerceAtLeast(0f)
        c.save()
        c.translate(0f, shift)

        drawSelo(c, f, left, 250f, right, icon = 44f, name = 26f, dot = 11f, pill = 20f)
        drawPlate(c, f, left, 346f, 380f, d, cover)
        // Ao lado da placa: jogo, console e jogador.
        stats(d, listOf("jogo", "console", "jogador")).forEachIndexed { i, st ->
            val ly = 405f + i * 97f
            drawStat(c, f, st, 532f, ly, ly + 29f, right - 532f, label = 17f, value = 34f, dot = 9f, star = 32f)
        }
        drawStatusLabel(c, f, left, 790f, 26f, 13f, statusLabel(d))
        val ts = fitSize(statusText(d), f.display, titleSize(d, 150f, 93f), 60f, w, -0.04f)
        drawTitleCentered(c, f, statusText(d), left, 913f, ts)
        var y = 1013f
        if (hasAch) {
            drawAchievementBox(c, f, d, left, y, w, 142f, pad = 28f, label = 20f, count = 22f, pct = 36f, segH = 18f, segments = 20)
            y += 142f + 16f
            if (hasTiles) {
                drawTiles(c, f, d.highlights, left, y, w, 186f, 16f, 50f, 18f, 13f)
                y += 186f
            }
            y += 40f
        }
        // Linha de números: horas, nota e data (colunas a cada 307 px).
        stats(d, listOf("horas", "nota", "data")).forEachIndexed { i, st ->
            drawStat(c, f, st, left + i * 307f, y, y + 28f, 290f, label = 16f, value = 30f, dot = 9f, star = 30f)
        }
        y += 63f
        if (hasQuote) {
            y += 36f
            drawQuote(c, f, d.comment, left, y, w, 24f, 46f, 23f, maxLines = 3)
            y += quoteH
        }
        drawFooter(c, f, left, y + 42f, right, 16f, 9f)
        c.restore()
        drawStripes(c, 1080f, 1920f, 16f)
    }

    // ---- Link 1200 × 630 (computador e prévia de link)

    private fun drawLink(c: Canvas, f: Fonts, d: CardData, cover: Bitmap?) {
        val x = 440f
        val right = 1136f
        val w = right - x
        drawPlate(c, f, 64f, 157f, 320f, d, cover)
        drawSelo(c, f, x, 50f, right, icon = 32f, name = 19f, dot = 8f, pill = 15f)
        drawStatusLabel(c, f, x, 100f, 15f, 8f, statusLabel(d))
        val ts = fitSize(statusText(d), f.display, titleSize(d, 88f, 55f), 32f, w, -0.04f)
        drawTitleCentered(c, f, statusText(d), x, 171f, ts)
        var y = 254f
        if (d.achievementsTotal > 0) {
            drawAchievementBox(c, f, d, x, 234f, w, 83f, pad = 17f, label = 12f, count = 14f, pct = 22f, segH = 12f, segments = 16)
            y = 336f
        }
        stats(d, listOf("horas", "nota", "jogo", "jogador")).forEachIndexed { i, st ->
            val sx = x + (i % 2) * 360f
            val ly = y + (i / 2) * 67f
            drawStat(c, f, st, sx, ly, ly + 23f, 336f, label = 13f, value = 22f, dot = 8f, star = 21f)
        }
        drawFooter(c, f, x, 568f, right, 13f, 7f)
        drawStripes(c, 1200f, 630f, 12f)
    }

    // ---------------------------------------------------------------- peças

    private fun paint(tf: Typeface, size: Float, color: Int, ls: Float = 0f) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = tf; textSize = size; this.color = color; letterSpacing = ls
    }

    /** Maior tamanho (até max) em que o texto cabe numa linha da largura dada. */
    private fun fitSize(text: String, tf: Typeface, max: Float, min: Float, width: Float, ls: Float): Float {
        var s = max
        val p = paint(tf, s, 0, ls)
        while (s > min && p.measureText(text) > width) {
            s -= 2f
            p.textSize = s
        }
        return s
    }

    /** Escreve uma linha com o topo da caixa de texto em y (como o top de um elemento no HTML). */
    private fun drawTextTop(c: Canvas, text: String, x: Float, y: Float, p: Paint) {
        val fm = p.fontMetrics
        val lineH = fm.descent - fm.ascent
        val box = p.textSize * 1.2f
        c.drawText(text, x, y + (box - lineH) / 2f - fm.ascent, p)
    }

    private fun ellipsize(text: String, p: TextPaint, width: Float) = TextUtils.ellipsize(text, p, width, TextUtils.TruncateAt.END).toString()

    private fun dots(c: Canvas, x: Float, cy: Float, size: Float, gap: Float): Float {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var cx = x
        DOTS.forEach { col ->
            p.color = col
            c.drawCircle(cx + size / 2f, cy, size / 2f, p)
            cx += size + gap
        }
        return cx - gap - x
    }

    /** Selo: ícone + "Cartucho" + quatro pontos; à direita, a pílula do console. y = topo do ícone. */
    private fun drawSelo(c: Canvas, f: Fonts, x: Float, y: Float, right: Float, icon: Float, name: Float, dot: Float, pill: Float) {
        c.save()
        val r = RectF(x, y, x + icon, y + icon)
        c.clipPath(Path().apply { addRoundRect(r, icon * 0.24f, icon * 0.24f, Path.Direction.CW) })
        brandIcon?.let { c.drawBitmap(it, null, r, Paint(Paint.FILTER_BITMAP_FLAG)) } ?: run {
            c.drawRect(r, Paint().apply { color = 0xFF8C8C8C.toInt() })
        }
        c.restore()
        val np = paint(f.display, name, INK, -0.02f)
        val nx = x + icon + icon * 0.29f
        val cy = y + icon / 2f
        c.drawText("Cartucho", nx, cy - (np.fontMetrics.ascent + np.fontMetrics.descent) / 2f, np)
        dots(c, nx + np.measureText("Cartucho") + dot * 1.3f, cy, dot, dot * 0.5f)
        currentConsole?.takeIf { it.isNotBlank() }?.let { text ->
            val pp = paint(f.semibold, pill, PURPLE_DARK)
            val pw = pp.measureText(text) + pill * 1.62f
            val ph = pill * 1.95f
            val pr = RectF(right - pw, cy - ph / 2f, right, cy + ph / 2f)
            c.drawRoundRect(pr, ph / 2f, ph / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LAVENDER_SOFT })
            c.drawText(text, pr.left + pill * 0.81f, cy - (pp.fontMetrics.ascent + pp.fontMetrics.descent) / 2f, pp)
        }
    }

    /** Quatro pontos + rótulo em caixa alta. y = topo da caixa do texto. */
    private fun drawStatusLabel(c: Canvas, f: Fonts, x: Float, y: Float, size: Float, dot: Float, text: String) {
        val p = paint(f.bold, size, MUTED2, 0.08f)
        val w = dots(c, x, y + size * 0.6f, dot, dot * 0.55f)
        drawTextTop(c, text.uppercase(), x + w + size * 0.55f, y, p)
    }

    /** Título em roxo com o meio das letras na altura dada (igual para ZERADO! e JOGANDO AGORA). */
    private fun drawTitleCentered(c: Canvas, f: Fonts, text: String, x: Float, centerY: Float, size: Float) {
        val p = paint(f.display, size, PURPLE, -0.04f)
        val b = android.graphics.Rect()
        p.getTextBounds("H", 0, 1, b)
        c.drawText(text, x - size * 0.03f, centerY + b.height() / 2f, p)
    }

    /** Placa do cartucho: quadrado cinza com luz em cima, sombra embaixo, a capa no centro e o controle no canto. */
    private fun drawPlate(c: Canvas, f: Fonts, x: Float, y: Float, s: Float, d: CardData, cover: Bitmap?) {
        val k = s / 300f
        val radius = s * 0.133f
        val rect = RectF(x, y, x + s, y + s)
        // Sombra longa e suave (0 40 80 -36).
        val sh = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x80282838.toInt()
            maskFilter = BlurMaskFilter(40f * k, BlurMaskFilter.Blur.NORMAL)
        }
        c.drawRoundRect(RectF(x + 36f * k, y + 76f * k, x + s - 36f * k, y + s + 4f * k), radius, radius, sh)
        // Placa com luz interna em cima (3 px) e sombra interna embaixo (6 px).
        val platePath = Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
        c.save()
        c.clipPath(platePath)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = PLATE_HI; c.drawRect(rect, p)
        p.color = PLATE_SHADE; c.drawRoundRect(RectF(rect.left, rect.top + 3f * k, rect.right, rect.bottom + 3f * k), radius, radius, p)
        val mid = Path().apply { addRoundRect(RectF(rect.left, rect.top + 3f * k, rect.right, rect.bottom + 3f * k), radius, radius, Path.Direction.CW) }
        mid.op(Path().apply { addRoundRect(RectF(rect.left, rect.top - 6f * k, rect.right, rect.bottom - 6f * k), radius, radius, Path.Direction.CW) }, Path.Op.INTERSECT)
        p.color = PLATE; c.drawPath(mid, p)
        c.restore()

        // A capa do jogo dentro da placa; sem capa, o cartucho desenhado com o nome do jogo.
        if (cover != null) drawCover(c, cover, RectF(x + 28f * k, y + 28f * k, x + s - 28f * k, y + s - 28f * k), k)
        else drawCartridge(c, f, x + 51f * k, y + 61f * k, k, d.title)

        // Pílula de nível no canto de cima.
        val lp = paint(f.semibold, 14f * k, PURPLE_DARK)
        val lvl = "LVL %06d".format(d.level.coerceIn(0, 999999))
        val lw = lp.measureText(lvl) + 22f * k
        val lh = 27f * k
        val lr = RectF(x + 21f * k, y + 18f * k, x + 21f * k + lw, y + 18f * k + lh)
        c.drawRoundRect(lr, lh / 2f, lh / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = CARD })
        c.drawText(lvl, lr.left + 11f * k, lr.centerY() - (lp.fontMetrics.ascent + lp.fontMetrics.descent) / 2f, lp)

        // Controle de quatro botões saindo pelo canto de baixo.
        val dd = s / 3f
        val px = x + s - dd + 18f * k
        val py = y + s - dd + 18f * k
        val pc = Paint(Paint.ANTI_ALIAS_FLAG)
        pc.color = PAD_HI; c.drawCircle(px + dd / 2f, py + dd / 2f, dd / 2f, pc)
        pc.color = PAD; c.drawCircle(px + dd / 2f, py + dd / 2f + 2f * k, dd / 2f - 0.5f * k, pc)
        val b = dd * 0.27f
        listOf(
            Triple(0.37f, 0.08f, BLUE), Triple(0.65f, 0.37f, RED),
            Triple(0.37f, 0.65f, YELLOW), Triple(0.08f, 0.37f, GREEN),
        ).forEach { (bx, by, col) ->
            pc.color = col
            c.drawCircle(px + dd * bx + b / 2f, py + dd * by + b / 2f, b / 2f, pc)
        }
    }

    /** Cartucho desenhado (198 × 178 na placa de 300), com o nome do jogo na etiqueta. */
    private fun drawCartridge(c: Canvas, f: Fonts, x: Float, y: Float, k: Float, title: String) {
        val w = 198f * k
        val h = 178f * k
        val box = RectF(x, y, x + w, y + h)
        val r = 16f * k
        // Sombra (0 14 30 -12).
        c.drawRoundRect(
            RectF(x + 12f * k, y + 26f * k, x + w - 12f * k, y + h + 2f * k), r, r,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x8C1E1E28.toInt()
                maskFilter = BlurMaskFilter(15f * k, BlurMaskFilter.Blur.NORMAL)
            },
        )
        c.save()
        c.clipPath(Path().apply { addRoundRect(box, r, r, Path.Direction.CW) })
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFF8C8C8C.toInt(); c.drawRect(box, p)
        // Ranhuras de encaixe dos dois lados.
        val rib = 32f * k
        for (side in 0..1) {
            val rx = if (side == 0) x else x + w - rib
            p.color = 0xFF9F9F9F.toInt(); c.drawRect(rx, y, rx + rib, y + h, p)
            p.color = 0xFF777777.toInt()
            var ly = y + 22.4f * k
            while (ly < y + h) {
                c.drawRect(rx, ly, rx + rib, ly + 3f * k, p)
                ly += 25.4f * k
            }
        }
        // Etiqueta escura com o nome do jogo e a área de baixo.
        val mx0 = x + rib + 6f * k
        val mx1 = x + w - rib - 6f * k
        val labelH = 78f * k
        val label = Path().apply {
            addRoundRect(RectF(mx0, y, mx1, y + labelH), floatArrayOf(0f, 0f, 0f, 0f, 6f * k, 6f * k, 6f * k, 6f * k), Path.Direction.CW)
        }
        p.color = 0xFF595959.toInt(); c.drawPath(label, p)
        val lower = Path().apply {
            addRoundRect(RectF(mx0, y + labelH + 10f * k, mx1, y + h), floatArrayOf(6f * k, 6f * k, 6f * k, 6f * k, 0f, 0f, 0f, 0f), Path.Direction.CW)
        }
        p.color = 0xFFA3A3A3.toInt(); c.drawPath(lower, p)
        // Duas travas claras.
        p.color = 0xFFDBDBDB.toInt()
        c.drawCircle(x + 16f * k, y + 130f * k, 5f * k, p)
        c.drawCircle(x + w - 16f * k, y + 130f * k, 5f * k, p)
        c.restore()
        // Nome do jogo em caixa alta, centralizado na etiqueta, em até 2 linhas equilibradas (como o text-wrap: balance).
        val maxW = mx1 - mx0 - 16f * k
        val tp = paint(f.display, 18f * k, 0xFFEDEDED.toInt(), -0.01f)
        val words = title.uppercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        fun lines(): List<String> {
            val one = words.joinToString(" ")
            if (tp.measureText(one) <= maxW || words.size < 2) return listOf(one)
            return (1 until words.size).map { i -> listOf(words.take(i).joinToString(" "), words.drop(i).joinToString(" ")) }
                .minByOrNull { l -> l.maxOf { tp.measureText(it) } }!!
        }
        var ls = lines()
        while (tp.textSize > 10f * k && ls.any { tp.measureText(it) > maxW }) {
            tp.textSize -= 1f * k
            ls = lines()
        }
        val lh = tp.textSize * 1.0f
        val fm = tp.fontMetrics
        var ty = y + (labelH - lh * ls.size) / 2f
        ls.forEach { line ->
            val lw = tp.measureText(line)
            c.drawText(line, (mx0 + mx1 - lw) / 2f, ty + (lh - (fm.descent - fm.ascent)) / 2f - fm.ascent, tp)
            ty += lh
        }
    }

    /** Caixa branca de conquistas: rótulo, "N de M", porcentagem e barra em segmentos. */
    private fun drawAchievementBox(
        c: Canvas, f: Fonts, d: CardData, x: Float, y: Float, w: Float, h: Float,
        pad: Float, label: Float, count: Float, pct: Float, segH: Float, segments: Int,
    ) {
        val box = RectF(x, y, x + w, y + h)
        c.drawRoundRect(box, 22f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = CARD })
        c.drawRoundRect(RectF(box.left + 0.5f, box.top + 0.5f, box.right - 0.5f, box.bottom - 0.5f), 22f, 22f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LINE_SOFT; style = Paint.Style.STROKE; strokeWidth = 1f })
        val ratio = if (d.achievementsTotal > 0) d.achievementsUnlocked.toFloat() / d.achievementsTotal else 0f
        val barY = box.bottom - pad - segH
        // Linha de cima alinhada pela base: o "%" grande e os textos pequenos na mesma linha.
        val pp = paint(f.display, pct, INK, -0.02f)
        val base = y + pad + pct * 0.92f
        c.drawText("CONQUISTAS", x + pad, base, paint(f.bold, label, MUTED2, 0.08f))
        val pctText = "${(ratio * 100).roundToInt()}%"
        val pw = pp.measureText(pctText)
        c.drawText(pctText, box.right - pad - pw, base, pp)
        val cp = paint(f.regular, count, MUTED2)
        val ct = "${d.achievementsUnlocked} de ${d.achievementsTotal}"
        c.drawText(ct, box.right - pad - pw - count * 0.6f - cp.measureText(ct), base, cp)
        val gap = 4f
        val segW = (w - 2 * pad - gap * (segments - 1)) / segments
        val filled = (ratio * segments).roundToInt().let { if (d.achievementsUnlocked > 0) it.coerceAtLeast(1) else it }
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until segments) {
            sp.color = if (i < filled) PURPLE else LAVENDER_SOFT
            val sx = x + pad + i * (segW + gap)
            c.drawRoundRect(RectF(sx, barY, sx + segW, barY + segH), segH / 2f, segH / 2f, sp)
        }
    }

    /** Uma informação: ponto + rótulo em caixa alta (topo em labelY) e o valor (topo em valueY). */
    private fun drawStat(c: Canvas, f: Fonts, s: Stat, x: Float, labelY: Float, valueY: Float, w: Float, label: Float, value: Float, dot: Float, star: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = s.dot }
        c.drawCircle(x + dot / 2f, labelY + label * 0.6f, dot / 2f, p)
        drawTextTop(c, s.label.uppercase(), x + dot + label * 0.6f, labelY, paint(f.bold, label, MUTED2, 0.08f))
        if (s.stars >= 0) {
            drawStars(c, x, valueY + (value * 1.17f - star) / 2f, star, s.stars)
        } else {
            val vp = paint(f.semibold, value, if (s.value == "Sem nota") MUTED2 else INK)
            drawTextTop(c, ellipsize(s.value ?: "", vp, w), x, valueY, vp)
        }
    }

    /** Até 4 conquistas em cards brancos, com ícone colorido e pontos. */
    private fun drawTiles(c: Canvas, f: Fonts, list: List<Pair<String, Int>>, x: Float, y: Float, w: Float, h: Float, gap: Float, icon: Float, title: Float, pts: Float) {
        val tw = (w - gap * 3) / 4f
        val colors = intArrayOf(PURPLE, RED, YELLOW, GREEN)
        list.take(4).forEachIndexed { i, (name, points) ->
            val tx = x + i * (tw + gap)
            val r = RectF(tx, y, tx + tw, y + h)
            c.drawRoundRect(r, 22f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = CARD })
            c.drawRoundRect(RectF(r.left + 0.5f, r.top + 0.5f, r.right - 0.5f, r.bottom - 0.5f), 22f, 22f,
                Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LINE_SOFT; style = Paint.Style.STROKE; strokeWidth = 1f })
            val pad = 19f
            val ir = RectF(tx + pad, y + pad, tx + pad + icon, y + pad + icon)
            c.drawRoundRect(ir, 12f, 12f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colors[i] })
            drawTileIcon(c, i, ir, if (colors[i] == YELLOW) YELLOW_INK else CARD)
            val tp = paint(f.semibold, title, INK)
            val l = staticLayout(name, tp, (tw - 2 * pad).toInt(), 2, spacing = 1.03f)
            c.save(); c.translate(tx + pad, ir.bottom + title * 0.7f); l.draw(c); c.restore()
            val pp = paint(f.semibold, pts, PURPLE_DARK)
            val label = "$points pts"
            val pw = pp.measureText(label) + pts * 1.6f
            val ph = pts * 2f
            val pr = RectF(tx + pad, r.bottom - pad - ph, tx + pad + pw, r.bottom - pad)
            c.drawRoundRect(pr, ph / 2f, ph / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LAVENDER_SOFT })
            c.drawText(label, pr.left + pts * 0.8f, pr.centerY() - (pp.fontMetrics.ascent + pp.fontMetrics.descent) / 2f, pp)
        }
    }

    /** Ícones de traço (estrela, raio, taça, bandeira) no quadrado colorido. */
    private fun drawTileIcon(c: Canvas, kind: Int, r: RectF, color: Int) {
        val s = r.width() / 2f / 24f
        val ox = r.centerX() - 12f * s
        val oy = r.centerY() - 12f * s
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; style = Paint.Style.STROKE; strokeWidth = 2f * s
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        fun pt(px: Float, py: Float) = floatArrayOf(ox + px * s, oy + py * s)
        val path = Path()
        fun poly(vararg xy: Float, close: Boolean = false) {
            for (i in xy.indices step 2) {
                val (a, b) = pt(xy[i], xy[i + 1]).let { it[0] to it[1] }
                if (i == 0) path.moveTo(a, b) else path.lineTo(a, b)
            }
            if (close) path.close()
        }
        when (kind) {
            0 -> poly(12f, 3f, 14.6f, 8.6f, 20.6f, 9.3f, 16.1f, 13.4f, 17.3f, 19.4f, 12f, 16.4f, 6.7f, 19.4f, 7.9f, 13.4f, 3.4f, 9.3f, 9.4f, 8.6f, close = true)
            1 -> poly(13f, 2f, 4f, 14f, 11f, 14f, 10f, 22f, 19f, 10f, 12f, 10f, close = true)
            2 -> {
                poly(8f, 21f, 16f, 21f); poly(12f, 17f, 12f, 21f)
                path.moveTo(ox + 7f * s, oy + 4f * s); path.lineTo(ox + 17f * s, oy + 4f * s); path.lineTo(ox + 17f * s, oy + 9f * s)
                path.arcTo(RectF(ox + 7f * s, oy + 4f * s, ox + 17f * s, oy + 14f * s), 0f, 180f); path.close()
                poly(17f, 5f, 20f, 5f, 20f, 7f, 17f, 10f); poly(7f, 5f, 4f, 5f, 4f, 7f, 7f, 10f)
            }
            else -> { poly(5f, 21f, 5f, 4f); poly(5f, 4f, 17f, 4f, 15f, 8f, 17f, 12f, 5f, 12f) }
        }
        c.drawPath(path, p)
    }

    private fun quoteHeight(f: Fonts, text: String, w: Float, pad: Float, size: Float, maxLines: Int): Float {
        val l = staticLayout(text, paint(f.medium, size, LAVENDER_INK), (w - 2 * pad - size * 1.7f).toInt(), maxLines, spacing = 1.4f)
        return l.height + 2 * pad
    }

    /** Comentário do jogador em lavanda, com aspas roxas. */
    private fun drawQuote(c: Canvas, f: Fonts, text: String, x: Float, y: Float, w: Float, pad: Float, mark: Float, size: Float, maxLines: Int) {
        val tp = paint(f.medium, size, LAVENDER_INK)
        val l = staticLayout(text, tp, (w - 2 * pad - size * 1.7f).toInt(), maxLines, spacing = 1.4f)
        val h = l.height + 2 * pad
        c.drawRoundRect(RectF(x, y, x + w, y + h), 22f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LAVENDER })
        val mp = paint(f.display, mark, PURPLE)
        c.drawText("“", x + pad, y + pad - mp.fontMetrics.ascent * 0.72f, mp)
        c.save(); c.translate(x + pad + size * 1.7f, y + pad); l.draw(c); c.restore()
    }

    private fun drawFooter(c: Canvas, f: Fonts, x: Float, y: Float, right: Float, size: Float, dot: Float) {
        drawTextTop(c, "CARTUCHO · EMULADOR", x, y, paint(f.semibold, size, MUTED2, 0.08f))
        val w = 4 * dot + 3 * dot * 0.5f
        dots(c, right - w, y + size * 0.6f, dot, dot * 0.5f)
    }

    /** As três listras no rodapé (roxo, lavanda média, lavanda). */
    private fun drawStripes(c: Canvas, w: Float, h: Float, height: Float) {
        val p = Paint()
        listOf(PURPLE, LAVENDER_MID, LAVENDER).forEachIndexed { i, col ->
            p.color = col
            c.drawRect(w * i / 3f, h - height, w * (i + 1) / 3f, h, p)
        }
    }

    private fun drawStars(c: Canvas, x: Float, y: Float, size: Float, rating: Int) {
        val empty = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LINE }
        val full = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = PURPLE }
        for (i in 0 until 5) {
            val left = x + i * (size + size * 0.14f)
            val star = starPath(left + size / 2, y + size / 2, size / 2)
            c.drawPath(star, empty)
            val value = rating - i * 2
            if (value >= 2) {
                c.drawPath(star, full)
            } else if (value == 1) {
                c.save(); c.clipRect(left, y, left + size / 2, y + size); c.drawPath(star, full); c.restore()
            }
        }
    }

    private fun starPath(cx: Float, cy: Float, r: Float): Path {
        val path = Path()
        val inner = r * 0.45f
        for (k in 0 until 10) {
            val radius = if (k % 2 == 0) r else inner
            val angle = Math.toRadians(-90.0 + k * 36.0)
            val px = cx + (radius * cos(angle)).toFloat()
            val py = cy + (radius * sin(angle)).toFloat()
            if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        return path
    }

    /** Capa inteira (sem cortar) centralizada na área, com cantos arredondados e sombra leve. */
    private fun drawCover(c: Canvas, cover: Bitmap, area: RectF, k: Float) {
        val scale = min(area.width() / cover.width, area.height() / cover.height)
        val w = cover.width * scale
        val h = cover.height * scale
        val r = RectF(area.centerX() - w / 2, area.centerY() - h / 2, area.centerX() + w / 2, area.centerY() + h / 2)
        val radius = 14f * k
        c.drawRoundRect(RectF(r.left, r.top + 6f * k, r.right, r.bottom + 6f * k), radius, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x55282838
            maskFilter = BlurMaskFilter(14f * k, BlurMaskFilter.Blur.NORMAL)
        })
        c.save()
        c.clipPath(Path().apply { addRoundRect(r, radius, radius, Path.Direction.CW) })
        c.drawBitmap(cover, null, r, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        c.restore()
    }

    /** Lê a capa já reduzida para o tamanho do card. */
    private fun loadCover(file: File): Bitmap? = runCatching {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, o)
        var sample = 1
        while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= 600) sample *= 2
        BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()

    private fun centerCrop(src: Bitmap, dst: RectF): RectF {
        val scale = maxOf(dst.width() / src.width, dst.height() / src.height)
        val w = src.width * scale
        val h = src.height * scale
        return RectF(dst.centerX() - w / 2, dst.centerY() - h / 2, dst.centerX() + w / 2, dst.centerY() + h / 2)
    }

    @Suppress("DEPRECATION")
    private fun staticLayout(text: String, paint: TextPaint, width: Int, maxLines: Int, center: Boolean = false, spacing: Float = 1.25f): StaticLayout {
        val align = if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL
        return if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(1))
                .setAlignment(align)
                .setLineSpacing(0f, spacing)
                .setMaxLines(maxLines)
                .setEllipsize(TextUtils.TruncateAt.END)
                .build()
        } else {
            StaticLayout(text, paint, width.coerceAtLeast(1), align, spacing, 0f, false)
        }
    }

    // O selo precisa do ícone e da pílula do console; guardados durante um render.
    private var brandIcon: Bitmap? = null
    private var currentConsole: String? = null

    /** Render completo com o ícone da marca carregado. */
    fun renderCard(context: Context, data: CardData, format: CardFormat): Bitmap = synchronized(this) {
        brandIcon = runCatching { BitmapFactory.decodeResource(context.resources, R.drawable.brand_icon) }.getOrNull()
        currentConsole = data.console
        try {
            render(context, data, format)
        } finally {
            brandIcon?.recycle()
            brandIcon = null
            currentConsole = null
        }
    }

    // ---------------------------------------------------------------- saída

    /** Grava o card em PNG no cache (para compartilhar). */
    fun writeCache(context: Context, bmp: Bitmap, name: String): File {
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val out = File(dir, "card-${name.take(24).replace(Regex("[^A-Za-z0-9_-]"), "")}.png")
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return out
    }

    /** Salva o card na galeria (Imagens/Cartucho). Retorna true se deu certo. */
    fun saveToGallery(context: Context, bmp: Bitmap, title: String): Boolean = runCatching {
        val name = "Cartucho - ${title.take(40).replace(Regex("[\\\\/:*?\"<>|]"), "")} - ${System.currentTimeMillis() / 1000}.png"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Cartucho")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            context.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: return false
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Cartucho").apply { mkdirs() }
            File(dir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        true
    }.getOrDefault(false)

    /** Gera o card no formato do aparelho e abre o compartilhar. Chame numa coroutine. */
    suspend fun shareGame(app: CartuchoApp, game: Game, entryOverride: CollectionEntry? = null, format: CardFormat? = null, comment: String? = null): Boolean {
        val file = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val data = buildData(app, game, comment, entryOverride)
                val bmp = renderCard(app, data, format ?: defaultFormat(app))
                writeCache(app, bmp, game.id).also { bmp.recycle() }
            }.getOrNull()
        } ?: return false
        return runCatching { share(app, file) }.isSuccess
    }

    /** Abre o "Compartilhar" do Android com o card (Instagram, WhatsApp, X…). */
    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "app.cartucho.files", file)
        val intent = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Compartilhar card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @Suppress("unused")
    private fun clamp(v: Float, lo: Float, hi: Float) = min(maxOf(v, lo), hi)
}
