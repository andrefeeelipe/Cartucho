package app.cartucho.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import app.cartucho.CartuchoApp
import app.cartucho.R
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

/**
 * Card do jogo em formato de celular (1080x1920, proporção de Stories) para compartilhar:
 * capa grande, status (jogando, zerado, platinado…), estrelas da nota, horas jogadas e um trecho da resenha.
 * Feito só com o Canvas do Android, funciona tanto na biblioteca quanto no menu do jogo.
 */
object GameCard {
    private const val W = 1080
    private const val H = 1920

    // Paleta: monocromático escuro e quente; a única cor vem da própria capa.
    private const val BG = 0xFF111111.toInt()
    private const val TEXT = 0xFFF2F2F0.toInt()
    private const val MUTED = 0xFF8A8A86.toInt()
    private const val HAIRLINE = 0x1FFFFFFF

    // Zonas seguras de Stories/Reels: nada importante nos 260 px de cima nem nos 340 px de baixo.
    private const val SAFE_TOP = 260f

    /**
     * Card minimalista no formato de Stories (1080x1920): dois cartões levemente inclinados —
     * a capa do jogo na frente e um cartão com o tom da capa atrás — e, abaixo, status, título,
     * estrelas e três números. Respeita as faixas que o Instagram/WhatsApp cobrem com a interface.
     * Bloqueante: chame fora da thread principal.
     */
    fun render(
        context: Context,
        game: Game,
        entry: CollectionEntry,
        seconds: Long,
        user: String,
        coverFile: File,
    ): File {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val semibold = runCatching { ResourcesCompat.getFont(context, R.font.geist_semibold) }.getOrNull() ?: Typeface.DEFAULT_BOLD
        val regular = runCatching { ResourcesCompat.getFont(context, R.font.geist_regular) }.getOrNull() ?: Typeface.DEFAULT
        val mono = runCatching { ResourcesCompat.getFont(context, R.font.geist_mono) }.getOrNull() ?: Typeface.MONOSPACE
        val cover = if (coverFile.exists()) BitmapFactory.decodeFile(coverFile.absolutePath) else null
        val tint = cover?.let { dominant(it) } ?: 0xFF9DB8FF.toInt()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // Fundo: grafite com uma luz suave na cor da capa, atrás dos cartões.
        canvas.drawColor(BG)
        canvas.drawPaint(Paint().apply {
            shader = android.graphics.RadialGradient(
                W / 2f, 640f, 760f,
                intArrayOf(withAlpha(tint, 0x38), withAlpha(tint, 0x00)),
                null, Shader.TileMode.CLAMP,
            )
        })

        // Cartões: o de trás com o tom da capa; o da frente é a própria capa.
        val cardW = 460f
        val cardH = if (cover != null) (cardW * cover.height / cover.width).coerceIn(cardW * 0.7f, cardW * 1.35f) else cardW * 1.3f
        val cx = W / 2f
        // Centraliza o conjunto (cartões + textos ≈ 500 px) entre as zonas seguras.
        val block = cardH + 110f + 500f
        val top = SAFE_TOP + ((H - 340f - SAFE_TOP) - block).coerceAtLeast(0f) / 2f
        val cy = top + 30f + cardH / 2f
        fun shadow(r: RectF) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x66000000
                maskFilter = android.graphics.BlurMaskFilter(48f, android.graphics.BlurMaskFilter.Blur.NORMAL)
            }
            canvas.drawRoundRect(RectF(r.left, r.top + 30f, r.right, r.bottom + 40f), 40f, 40f, sp)
        }
        canvas.save()
        canvas.rotate(7f, cx + 60f, cy)
        val back = RectF(cx - cardW / 2 + 90f, cy - cardH / 2, cx + cardW / 2 + 90f, cy + cardH / 2)
        shadow(back)
        p.color = mix(tint, BG, 0.55f)
        canvas.drawRoundRect(back, 36f, 36f, p)
        p.color = withAlpha(TEXT, 0x30); p.typeface = mono; p.textSize = 26f; p.letterSpacing = 0.3f
        canvas.drawText("CARTUCHO", back.left + 40f, back.bottom - 44f, p)
        p.letterSpacing = 0f
        canvas.restore()

        canvas.save()
        canvas.rotate(-4f, cx, cy)
        val front = RectF(cx - cardW / 2 - 40f, cy - cardH / 2, cx + cardW / 2 - 40f, cy + cardH / 2)
        shadow(front)
        canvas.save()
        canvas.clipPath(Path().apply { addRoundRect(front, 36f, 36f, Path.Direction.CW) })
        if (cover != null) {
            canvas.drawBitmap(cover, null, centerCrop(cover, front), Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            p.color = 0xFF222222.toInt(); canvas.drawRect(front, p)
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = semibold; textSize = 52f; color = TEXT }
            val l = staticLayout(game.title, tp, (front.width() - 80f).toInt(), 5)
            canvas.save(); canvas.translate(front.left + 40f, front.bottom - 40f - l.height); l.draw(canvas); canvas.restore()
        }
        canvas.restore()
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x24FFFFFF
        canvas.drawRoundRect(front, 36f, 36f, p)
        p.style = Paint.Style.FILL
        canvas.restore()
        cover?.recycle()

        // Texto: margens de 96 px, alinhado à esquerda, hierarquia por tamanho e cor.
        val left = 96f
        var y = cy + cardH / 2 + 140f

        // Selo de status.
        val status = when (entry.status) {
            PlayStatus.BEATEN -> "ZERADO"
            PlayStatus.PLATINUM -> "PLATINADO"
            PlayStatus.DROPPED -> "ABANDONADO"
            PlayStatus.WANT -> "NA LISTA"
            else -> "JOGANDO AGORA"
        }
        val when_ = if (entry.finishedAt > 0 && (entry.status == PlayStatus.BEATEN || entry.status == PlayStatus.PLATINUM)) {
            java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale("pt", "BR")).format(java.util.Date(entry.finishedAt)).uppercase()
        } else ""
        p.typeface = mono; p.textSize = 28f; p.letterSpacing = 0.14f
        val pillText = status
        val pw = p.measureText(pillText) + 48f
        p.color = withAlpha(tint, 0x33)
        canvas.drawRoundRect(RectF(left, y - 46f, left + pw, y + 10f), 28f, 28f, p)
        p.color = mix(tint, TEXT, 0.35f)
        canvas.drawText(pillText, left + 24f, y - 8f, p)
        if (when_.isNotEmpty()) {
            p.color = MUTED
            canvas.drawText(when_, left + pw + 24f, y - 8f, p)
        }
        p.letterSpacing = 0f

        // Título.
        y += 40f
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = semibold; textSize = 92f; color = TEXT; letterSpacing = -0.025f }
        var tl = staticLayout(game.title, titlePaint, (W - 2 * left).toInt(), 2)
        while (tl.lineCount >= 2 && titlePaint.textSize > 64f && tl.getEllipsisCount(tl.lineCount - 1) > 0) {
            titlePaint.textSize = titlePaint.textSize - 6f
            tl = staticLayout(game.title, titlePaint, (W - 2 * left).toInt(), 2)
        }
        canvas.save(); canvas.translate(left, y); tl.draw(canvas); canvas.restore()
        y += tl.height + 36f

        // Estrelas.
        if (entry.rating > 0) {
            drawStars(canvas, left, y, 46f, entry.rating, TEXT)
            p.typeface = regular; p.textSize = 40f; p.color = MUTED
            canvas.drawText(String.format(java.util.Locale("pt", "BR"), "%.1f", entry.rating / 2.0), left + 5 * 58f + 16f, y + 40f, p)
            y += 46f + 56f
        } else {
            y += 10f
        }

        // Linha fina e três números.
        p.color = HAIRLINE
        canvas.drawRect(left, y, W - left, y + 2f, p)
        y += 64f
        val colW = (W - 2 * left) / 3f
        val stats = listOf(
            (if (seconds > 0) CollectionStore.formatHours(seconds) else "—") to "jogadas",
            (Systems.get(game.systemId)?.short ?: "—") to "console",
            (if (user.isNotEmpty()) "@$user" else "Cartucho") to "jogador",
        )
        stats.forEachIndexed { i, (value, label) ->
            val x = left + i * colW
            val vp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = semibold; textSize = 44f; color = TEXT }
            canvas.drawText(android.text.TextUtils.ellipsize(value, vp, colW - 24f, android.text.TextUtils.TruncateAt.END).toString(), x, y, vp)
            p.typeface = regular; p.textSize = 30f; p.color = MUTED
            canvas.drawText(label, x, y + 46f, p)
        }

        // Assinatura discreta (pode ficar sob a interface da rede social, não é essencial).
        p.typeface = mono; p.textSize = 24f; p.color = withAlpha(TEXT, 0x55); p.letterSpacing = 0.3f
        canvas.drawText("CARTUCHO", left, H - 280f, p)
        p.letterSpacing = 0f

        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val out = File(dir, "card-${game.id.take(12)}.png")
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return out
    }

    private fun centerCrop(src: Bitmap, dst: RectF): RectF {
        val scale = maxOf(dst.width() / src.width, dst.height() / src.height)
        val w = src.width * scale
        val h = src.height * scale
        return RectF(dst.centerX() - w / 2, dst.centerY() - h / 2, dst.centerX() + w / 2, dst.centerY() + h / 2)
    }

    /** Cor média da capa, levemente saturada (dá o tom do fundo e do selo). */
    private fun dominant(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 16, 16, true)
        var r = 0L; var g = 0L; var bl = 0L
        for (y in 0 until 16) for (x in 0 until 16) {
            val c = s.getPixel(x, y)
            r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; bl += c and 0xFF
        }
        s.recycle()
        val hsv = FloatArray(3)
        android.graphics.Color.RGBToHSV((r / 256).toInt(), (g / 256).toInt(), (bl / 256).toInt(), hsv)
        hsv[1] = (hsv[1] * 1.3f).coerceIn(0.25f, 0.8f)
        hsv[2] = hsv[2].coerceIn(0.55f, 0.95f)
        return android.graphics.Color.HSVToColor(hsv)
    }

    private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, sh: Int) = (x shr sh) and 0xFF
        fun m(sh: Int) = (ch(a, sh) * (1 - t) + ch(b, sh) * t).toInt()
        return (0xFF shl 24) or (m(16) shl 16) or (m(8) shl 8) or m(0)
    }

    /** Monta o card com os dados da coleção e abre o compartilhar. Chame numa coroutine. */
    suspend fun shareGame(app: CartuchoApp, game: Game, entryOverride: CollectionEntry? = null): Boolean {
        val file = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val entry = entryOverride ?: app.collection.get(game.id)
                val seconds = app.collection.secondsByGame()[game.id] ?: 0L
                render(app, game, entry, seconds, app.prefs.current.raUser, app.covers.file(game.id))
            }.getOrNull()
        } ?: return false
        return runCatching { share(app, file) }.isSuccess
    }

    /** Abre o "Compartilhar" do Android com o card (Instagram, WhatsApp, X…). */
    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "app.cartucho.files", file)
        val intent = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Compartilhar card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** 5 estrelas desenhadas (sem depender de fonte), com meias estrelas. rating vai de 0 a 10. */
    private fun drawStars(canvas: Canvas, x: Float, y: Float, size: Float, rating: Int, color: Int) {
        val empty = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0x40FFFFFF }
        val full = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        for (i in 0 until 5) {
            val left = x + i * (size + 12f)
            val star = starPath(left + size / 2, y + size / 2, size / 2)
            canvas.drawPath(star, empty)
            val value = rating - i * 2
            if (value >= 2) {
                canvas.drawPath(star, full)
            } else if (value == 1) {
                canvas.save()
                canvas.clipRect(left, y, left + size / 2, y + size)
                canvas.drawPath(star, full)
                canvas.restore()
            }
        }
    }

    private fun starPath(cx: Float, cy: Float, r: Float): Path {
        val path = Path()
        val inner = r * 0.45f
        for (k in 0 until 10) {
            val radius = if (k % 2 == 0) r else inner
            val angle = Math.toRadians(-90.0 + k * 36.0)
            val px = cx + (radius * cos(angle)).toFloat()
            val py = cy + (radius * sin(angle)).toFloat()
            if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        return path
    }

    @Suppress("DEPRECATION")
    private fun staticLayout(text: String, paint: TextPaint, width: Int, maxLines: Int): StaticLayout =
        if (Build.VERSION.SDK_INT >= 23) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setMaxLines(maxLines)
                .setEllipsize(android.text.TextUtils.TruncateAt.END)
                .build()
        } else {
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1f, 0f, false)
        }
}
