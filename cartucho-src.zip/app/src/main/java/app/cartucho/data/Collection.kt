package app.cartucho.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File

enum class PlayStatus(val label: String) {
    NONE("Sem status"),
    WANT("Quero jogar"),
    PLAYING("Jogando"),
    BEATEN("Zerado"),
    PLATINUM("Platinado"),
    DROPPED("Abandonado"),
}

/** Registro do jogador para um jogo, no estilo Letterboxd: status, nota, resenha e data. */
data class CollectionEntry(
    val status: PlayStatus = PlayStatus.NONE,
    /** Nota de 0 a 10 (meias estrelas: 7 = 3,5 estrelas). 0 = sem nota. */
    val rating: Int = 0,
    val review: String = "",
    val favorite: Boolean = false,
    val finishedAt: Long = 0L,
    val updatedAt: Long = 0L,
)

data class PlaySession(val gameId: String, val start: Long, val seconds: Long)

/**
 * Coleção pessoal. As anotações ficam em collection.json (escritas só pela biblioteca);
 * o tempo de jogo fica em playtime/sessions.tsv (escrito pelo processo do jogo, uma linha por sessão).
 */
class CollectionStore(context: Context) {
    private val file = File(context.filesDir, "collection.json")
    private val sessionsFile = File(context.filesDir, "playtime/sessions.tsv")
    private val _entries = MutableStateFlow<Map<String, CollectionEntry>>(emptyMap())
    val entries: StateFlow<Map<String, CollectionEntry>> = _entries.asStateFlow()

    init {
        load()
    }

    fun get(id: String): CollectionEntry = _entries.value[id] ?: CollectionEntry()

    @Synchronized
    fun update(id: String, transform: (CollectionEntry) -> CollectionEntry) {
        val old = get(id)
        var next = transform(old).copy(updatedAt = System.currentTimeMillis())
        val finished = next.status == PlayStatus.BEATEN || next.status == PlayStatus.PLATINUM
        if (finished && next.finishedAt == 0L) next = next.copy(finishedAt = System.currentTimeMillis())
        if (!finished) next = next.copy(finishedAt = 0L)
        _entries.value = _entries.value + (id to next)
        save()
    }

    private fun load() {
        if (!file.exists()) return
        runCatching {
            val root = JSONObject(file.readText())
            val map = HashMap<String, CollectionEntry>()
            root.keys().forEach { id ->
                val o = root.getJSONObject(id)
                map[id] = CollectionEntry(
                    status = runCatching { PlayStatus.valueOf(o.optString("status", "NONE")) }.getOrDefault(PlayStatus.NONE),
                    rating = o.optInt("rating"),
                    review = o.optString("review"),
                    favorite = o.optBoolean("favorite"),
                    finishedAt = o.optLong("finishedAt"),
                    updatedAt = o.optLong("updatedAt"),
                )
            }
            _entries.value = map
        }
    }

    private fun save() {
        val root = JSONObject()
        _entries.value.forEach { (id, e) ->
            root.put(
                id,
                JSONObject().put("status", e.status.name).put("rating", e.rating).put("review", e.review)
                    .put("favorite", e.favorite).put("finishedAt", e.finishedAt).put("updatedAt", e.updatedAt)
            )
        }
        val tmp = File(file.parentFile, "collection.json.tmp")
        tmp.writeText(root.toString())
        tmp.renameTo(file)
    }

    /** Todas as sessões de jogo registradas (mais recentes primeiro). */
    fun sessions(): List<PlaySession> {
        if (!sessionsFile.exists()) return emptyList()
        return sessionsFile.readLines().mapNotNull { line ->
            val p = line.split('\t')
            if (p.size < 3) null else runCatching { PlaySession(p[0], p[1].toLong(), p[2].toLong()) }.getOrNull()
        }.sortedByDescending { it.start }
    }

    fun secondsByGame(): Map<String, Long> = sessions().groupBy { it.gameId }.mapValues { (_, l) -> l.sumOf { it.seconds } }

    companion object {
        /** Chamado pelo processo do jogo ao pausar ou sair: acrescenta uma sessão. */
        fun appendSession(context: Context, gameId: String, start: Long, seconds: Long) {
            if (seconds < 10) return
            val f = File(context.filesDir, "playtime/sessions.tsv")
            f.parentFile?.mkdirs()
            f.appendText("$gameId\t$start\t$seconds\n")
        }

        fun formatHours(seconds: Long): String {
            val h = seconds / 3600
            val m = (seconds % 3600) / 60
            return when {
                h == 0L -> "${m}min"
                m == 0L -> "${h}h"
                else -> "${h}h${"%02d".format(m)}"
            }
        }
    }
}
