package app.cartucho.data

/** Peso de emulação, usado para avaliar se o aparelho dá conta. */
enum class Weight { LIGHT, MEDIUM, HEAVY, VERY_HEAVY }

/** Layout dos controles na tela. */
enum class PadLayout { TWO_BUTTONS, GBA, SNES, GENESIS, ARCADE, N64, PLAYSTATION, PSP, DS, DREAMCAST, SATURN }

data class GameSystem(
    val id: String,
    val name: String,
    val short: String,
    val coreId: String,
    val extensions: Set<String>,
    val raConsoleId: Int,
    val weight: Weight,
    val layout: PadLayout,
    val needsGles3: Boolean = false,
    val multiFileExtensions: Set<String> = emptySet(),
)

object Systems {
    private val discMulti = setOf("cue", "gdi", "m3u", "ccd", "toc")

    val all: List<GameSystem> = listOf(
        GameSystem("atari2600", "Atari 2600", "2600", "stella", setOf("a26"), 25, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("atari7800", "Atari 7800", "7800", "prosystem", setOf("a78"), 51, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("lynx", "Atari Lynx", "LYNX", "handy", setOf("lnx"), 13, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("nes", "NES / Famicom", "NES", "fceumm", setOf("nes", "fds", "unf", "unif"), 7, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("snes", "Super Nintendo", "SNES", "snes9x", setOf("sfc", "smc", "fig", "swc"), 3, Weight.LIGHT, PadLayout.SNES),
        GameSystem("gb", "Game Boy", "GB", "gambatte", setOf("gb"), 4, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("gbc", "Game Boy Color", "GBC", "gambatte", setOf("gbc"), 6, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("gba", "Game Boy Advance", "GBA", "mgba", setOf("gba"), 5, Weight.LIGHT, PadLayout.GBA),
        GameSystem("mastersystem", "Master System", "SMS", "genesis_plus_gx", setOf("sms"), 11, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("gamegear", "Game Gear", "GG", "genesis_plus_gx", setOf("gg"), 15, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("megadrive", "Mega Drive", "MD", "genesis_plus_gx", setOf("md", "gen", "smd"), 1, Weight.LIGHT, PadLayout.GENESIS),
        GameSystem("segacd", "Sega CD", "SCD", "genesis_plus_gx", setOf("cue", "chd", "iso"), 9, Weight.LIGHT, PadLayout.GENESIS, multiFileExtensions = discMulti),
        GameSystem("sega32x", "Sega 32X", "32X", "picodrive", setOf("32x"), 10, Weight.LIGHT, PadLayout.GENESIS),
        GameSystem("pce", "PC Engine", "PCE", "pce_fast", setOf("pce", "sgx"), 8, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("pcecd", "PC Engine CD", "PCECD", "pce_fast", setOf("cue", "chd"), 76, Weight.LIGHT, PadLayout.TWO_BUTTONS, multiFileExtensions = discMulti),
        GameSystem("ngp", "Neo Geo Pocket", "NGP", "ngp", setOf("ngp", "ngc"), 14, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("wswan", "WonderSwan", "WS", "wswan", setOf("ws", "wsc"), 53, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("arcade", "Arcade", "ARC", "fbneo", setOf("zip"), 27, Weight.LIGHT, PadLayout.ARCADE),
        GameSystem("n64", "Nintendo 64", "N64", "mupen64plus", setOf("n64", "z64", "v64"), 2, Weight.MEDIUM, PadLayout.N64, needsGles3 = true),
        GameSystem("nds", "Nintendo DS", "NDS", "melonds", setOf("nds"), 18, Weight.MEDIUM, PadLayout.DS),
        GameSystem("psx", "PlayStation", "PS1", "pcsx_rearmed", setOf("cue", "chd", "pbp", "iso", "m3u", "bin"), 12, Weight.MEDIUM, PadLayout.PLAYSTATION, multiFileExtensions = discMulti),
        GameSystem("psp", "PSP", "PSP", "ppsspp", setOf("iso", "cso", "pbp"), 41, Weight.HEAVY, PadLayout.PSP, needsGles3 = true),
        GameSystem("saturn", "Sega Saturn", "SAT", "yabause", setOf("cue", "chd", "iso"), 39, Weight.HEAVY, PadLayout.SATURN, multiFileExtensions = discMulti),
        GameSystem("dreamcast", "Dreamcast", "DC", "flycast", setOf("gdi", "chd", "cdi"), 40, Weight.HEAVY, PadLayout.DREAMCAST, needsGles3 = true, multiFileExtensions = discMulti),
        GameSystem("ps2", "PlayStation 2", "PS2", "play", setOf("iso", "chd", "cso", "isz"), 21, Weight.VERY_HEAVY, PadLayout.PLAYSTATION, needsGles3 = true),
    )

    private val byId = all.associateBy { it.id }

    fun get(id: String?): GameSystem? = id?.let { byId[it] }

    /** Extensões aceitas por qualquer sistema (para o seletor e a indexação de pastas). */
    val allExtensions: Set<String> = all.flatMap { it.extensions }.toSet() + setOf("zip", "7z")

    fun candidatesForExtension(ext: String): List<GameSystem> = all.filter { ext.lowercase() in it.extensions }
}
