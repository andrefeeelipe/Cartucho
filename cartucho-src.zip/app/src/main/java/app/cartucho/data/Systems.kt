package app.cartucho.data

/** Peso de emulação, usado para avaliar se o aparelho dá conta. */
enum class Weight { LIGHT, MEDIUM, HEAVY, VERY_HEAVY }

/** Layout dos controles na tela. */
enum class PadLayout { TWO_BUTTONS, GBA, SNES, GENESIS, ARCADE, N64, PLAYSTATION, PSP, DS, DREAMCAST, SATURN }

data class GameSystem(
    val id: String,
    val name: String,
    val short: String,
    val coreId: String,
    val extensions: Set<String>,
    val raConsoleId: Int,
    val weight: Weight,
    val layout: PadLayout,
    val needsGles3: Boolean = false,
    val multiFileExtensions: Set<String> = emptySet(),
)

object Systems {
    private val discMulti = setOf("cue", "gdi", "m3u", "ccd", "toc")

    val all: List<GameSystem> = listOf(
        GameSystem("atari2600", "Atari 2600", "2600", "stella", setOf("a26", "bin"), 25, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("atari7800", "Atari 7800", "7800", "prosystem", setOf("a78"), 51, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("lynx", "Atari Lynx", "LYNX", "handy", setOf("lnx"), 13, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("nes", "NES / Famicom", "NES", "fceumm", setOf("nes", "fds", "unf", "unif", "nez"), 7, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("snes", "Super Nintendo", "SNES", "snes9x", setOf("sfc", "smc", "fig", "swc", "bs", "st", "gd3", "gd7", "dx2", "mgd"), 3, Weight.LIGHT, PadLayout.SNES),
        GameSystem("gb", "Game Boy", "GB", "gambatte", setOf("gb", "sgb", "dmg"), 4, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("gbc", "Game Boy Color", "GBC", "gambatte", setOf("gbc", "cgb"), 6, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("gba", "Game Boy Advance", "GBA", "mgba", setOf("gba", "agb", "mb"), 5, Weight.LIGHT, PadLayout.GBA),
        GameSystem("mastersystem", "Master System", "SMS", "genesis_plus_gx", setOf("sms", "sg", "sc", "mv"), 11, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("gamegear", "Game Gear", "GG", "genesis_plus_gx", setOf("gg"), 15, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("megadrive", "Mega Drive", "MD", "genesis_plus_gx", setOf("md", "gen", "smd", "bin", "mdx", "68k", "sgd"), 1, Weight.LIGHT, PadLayout.GENESIS),
        GameSystem("segacd", "Sega CD", "SCD", "genesis_plus_gx", setOf("cue", "chd", "iso", "bin", "img"), 9, Weight.LIGHT, PadLayout.GENESIS, multiFileExtensions = discMulti),
        GameSystem("sega32x", "Sega 32X", "32X", "picodrive", setOf("32x"), 10, Weight.LIGHT, PadLayout.GENESIS),
        GameSystem("pce", "PC Engine", "PCE", "pce_fast", setOf("pce", "sgx", "tg16"), 8, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("pcecd", "PC Engine CD", "PCECD", "pce_fast", setOf("cue", "chd"), 76, Weight.LIGHT, PadLayout.TWO_BUTTONS, multiFileExtensions = discMulti),
        GameSystem("ngp", "Neo Geo Pocket", "NGP", "ngp", setOf("ngp", "ngc", "npc"), 14, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("wswan", "WonderSwan", "WS", "wswan", setOf("ws", "wsc", "pc2"), 53, Weight.LIGHT, PadLayout.TWO_BUTTONS),
        GameSystem("arcade", "Arcade", "ARC", "fbneo", setOf("zip"), 27, Weight.LIGHT, PadLayout.ARCADE),
        GameSystem("n64", "Nintendo 64", "N64", "mupen64plus", setOf("n64", "z64", "v64", "u1", "ndd"), 2, Weight.MEDIUM, PadLayout.N64, needsGles3 = true),
        GameSystem("nds", "Nintendo DS", "NDS", "melonds", setOf("nds", "dsi", "ids", "srl"), 18, Weight.MEDIUM, PadLayout.DS),
        GameSystem("psx", "PlayStation", "PS1", "pcsx_rearmed", setOf("cue", "chd", "pbp", "iso", "m3u", "bin", "img", "ccd", "mds"), 12, Weight.MEDIUM, PadLayout.PLAYSTATION, multiFileExtensions = discMulti),
        GameSystem("psp", "PSP", "PSP", "ppsspp", setOf("iso", "cso", "pbp", "elf", "prx"), 41, Weight.HEAVY, PadLayout.PSP, needsGles3 = true),
        GameSystem("saturn", "Sega Saturn", "SAT", "yabause", setOf("cue", "chd", "iso", "ccd", "mds"), 39, Weight.HEAVY, PadLayout.SATURN, multiFileExtensions = discMulti),
        GameSystem("dreamcast", "Dreamcast", "DC", "flycast", setOf("gdi", "chd", "cdi", "cue"), 40, Weight.HEAVY, PadLayout.DREAMCAST, needsGles3 = true, multiFileExtensions = discMulti),
        GameSystem("ps2", "PlayStation 2", "PS2", "play", setOf("iso", "chd", "cso", "isz", "bin", "elf", "zso"), 21, Weight.VERY_HEAVY, PadLayout.PLAYSTATION, needsGles3 = true),
    )

    private val byId = all.associateBy { it.id }

    fun get(id: String?): GameSystem? = id?.let { byId[it] }

    /** Extensões de ROM/disco conhecidas (sem contar compactados). */
    val allRomExtensions: Set<String> = all.flatMap { it.extensions }.toSet()

    /** Tudo que a indexação de pastas considera: ROMs + arquivos compactados. */
    val allExtensions: Set<String> = allRomExtensions + Archives.extensions

    /** O arcade (FinalBurn Neo) lê o .zip diretamente; nunca entra como candidato por extensão de ROM. */
    fun candidatesForExtension(ext: String): List<GameSystem> = all.filter { ext.lowercase() in it.extensions }

    // Dicas pelo nome das pastas ("SNES", "Playstation 2", "Mega Drive"...). Ordem importa.
    private val hints: List<Pair<Regex, String>> = listOf(
        "super ?nintendo|super ?famicom|\\bsnes\\b|\\bsfc\\b" to "snes",
        "game ?boy ?advance|\\bgba\\b" to "gba",
        "game ?boy ?colou?r|\\bgbc\\b" to "gbc",
        "game ?boy|\\bgb\\b" to "gb",
        "nintendo ?64|\\bn64\\b" to "n64",
        "nintendo ?ds|\\bnds\\b|\\bds\\b" to "nds",
        "famicom|\\bnes\\b|nintendo entertainment" to "nes",
        "playstation ?2|\\bps2\\b" to "ps2",
        "\\bpsp\\b|playstation portable" to "psp",
        "playstation ?1|playstation|\\bpsx\\b|\\bps1\\b|\\bpsone\\b" to "psx",
        "sega ?cd|mega ?cd" to "segacd",
        "\\b32x\\b" to "sega32x",
        "mega ?drive|genesis|\\bmd\\b" to "megadrive",
        "master ?system|\\bsms\\b" to "mastersystem",
        "game ?gear|\\bgg\\b" to "gamegear",
        "saturn" to "saturn",
        "dreamcast|\\bdc\\b" to "dreamcast",
        "pc ?engine ?cd|turbografx ?cd|pce ?cd" to "pcecd",
        "pc ?engine|turbografx|\\bpce\\b|\\btg16\\b" to "pce",
        "neo ?geo ?pocket|\\bngpc?\\b" to "ngp",
        "wonder ?swan|\\bwsc?\\b" to "wswan",
        "arcade|\\bmame\\b|fbneo|\\bfba\\b|neo ?geo|\\bcps[123]?\\b" to "arcade",
        "atari ?2600|\\b2600\\b" to "atari2600",
        "atari ?7800|\\b7800\\b" to "atari7800",
        "lynx" to "lynx",
    ).map { (pattern, id) -> Regex(pattern, RegexOption.IGNORE_CASE) to id }

    /** Sistema sugerido pelo caminho de pastas (da mais próxima para a mais distante). */
    fun hintFromFolders(folders: List<String>): GameSystem? {
        for (folder in folders.asReversed()) {
            val name = folder.replace('_', ' ').replace('-', ' ')
            hints.firstOrNull { it.first.containsMatchIn(name) }?.let { return get(it.second) }
        }
        return null
    }
}
