package app.cartucho

/** Leitor mínimo de protobuf para o tombstone do Android (system/core/debuggerd/proto/tombstone.proto). */
internal object Tombstone {
    private class Reader(val b: ByteArray, var pos: Int = 0, val end: Int = b.size) {
        fun more() = pos < end
        fun varint(): Long {
            var r = 0L
            var shift = 0
            while (true) {
                val x = b[pos++].toInt() and 0xff
                r = r or ((x and 0x7f).toLong() shl shift)
                if (x and 0x80 == 0) return r
                shift += 7
            }
        }
        /** Devolve (campo, tipo, valor numérico ou faixa [ini, fim) para bytes). */
        fun next(): Triple<Int, Int, LongArray> {
            val key = varint()
            val field = (key ushr 3).toInt()
            val type = (key and 7).toInt()
            return when (type) {
                0 -> Triple(field, type, longArrayOf(varint()))
                1 -> { pos += 8; Triple(field, type, longArrayOf(0)) }
                5 -> { pos += 4; Triple(field, type, longArrayOf(0)) }
                2 -> { val len = varint().toInt(); val s = pos; pos += len; Triple(field, type, longArrayOf(s.toLong(), pos.toLong())) }
                else -> throw IllegalStateException("tipo $type")
            }
        }
        fun sub(r: LongArray) = Reader(b, r[0].toInt(), r[1].toInt())
        fun str(r: LongArray) = String(b, r[0].toInt(), (r[1] - r[0]).toInt())
    }

    fun parse(bytes: ByteArray): String {
        val r = Reader(bytes)
        var tid = 0L
        var abort = ""
        var signal = ""
        val threads = HashMap<Long, Pair<String, List<String>>>()
        val logs = ArrayList<String>()
        while (r.more()) {
            val (f, t, v) = r.next()
            when {
                f == 6 && t == 0 -> tid = v[0]
                f == 14 && t == 2 -> abort = r.str(v)
                f == 10 && t == 2 -> signal = signalInfo(r.sub(v))
                f == 16 && t == 2 -> {  // map<uint32, Thread>: entrada com key=1, value=2
                    val e = r.sub(v)
                    var key = -1L
                    var th: Pair<String, List<String>>? = null
                    while (e.more()) {
                        val (ef, et, ev) = e.next()
                        if (ef == 1 && et == 0) key = ev[0]
                        if (ef == 2 && et == 2) th = thread(e.sub(ev))
                    }
                    if (th != null) threads[key] = th
                }
                f == 18 && t == 2 -> logBuffer(r.sub(v), logs)
            }
        }
        val crashed = threads[tid]
        return buildString {
            if (signal.isNotEmpty()) appendLine("Sinal: $signal")
            if (abort.isNotEmpty()) appendLine("Mensagem: $abort")
            appendLine("Thread que quebrou: ${crashed?.first ?: "?"} (tid $tid)")
            crashed?.second?.take(28)?.forEachIndexed { i, fr -> appendLine("#%02d %s".format(i, fr)) }
            val tail = logs.takeLast(25)
            if (tail.isNotEmpty()) {
                appendLine()
                appendLine("Últimas linhas do log:")
                tail.forEach { appendLine(it) }
            }
        }
    }

    private fun signalInfo(r: Reader): String {
        var name = ""
        var code = ""
        while (r.more()) {
            val (f, t, v) = r.next()
            if (f == 2 && t == 2) name = r.str(v)
            if (f == 4 && t == 2) code = r.str(v)
        }
        return listOf(name, code).filter { it.isNotEmpty() }.joinToString(" / ")
    }

    private fun thread(r: Reader): Pair<String, List<String>> {
        var name = ""
        val frames = ArrayList<String>()
        while (r.more()) {
            val (f, t, v) = r.next()
            if (f == 2 && t == 2) name = r.str(v)
            if (f == 4 && t == 2) {
                val fr = r.sub(v)
                var fn = ""
                var off = 0L
                var file = ""
                var rel = 0L
                while (fr.more()) {
                    val (ff, ft, fv) = fr.next()
                    when {
                        ff == 1 && ft == 0 -> rel = fv[0]
                        ff == 4 && ft == 2 -> fn = fr.str(fv)
                        ff == 5 && ft == 0 -> off = fv[0]
                        ff == 6 && ft == 2 -> file = fr.str(fv)
                    }
                }
                frames += "${file.substringAfterLast('/')} +0x${rel.toString(16)}" + if (fn.isNotEmpty()) " ($fn+$off)" else ""
            }
        }
        return name to frames
    }

    private fun logBuffer(r: Reader, out: MutableList<String>) {
        while (r.more()) {
            val (f, t, v) = r.next()
            if (f == 2 && t == 2) {
                val m = r.sub(v)
                var prio = 0L
                var tag = ""
                var msg = ""
                while (m.more()) {
                    val (mf, mt, mv) = m.next()
                    when {
                        mf == 4 && mt == 0 -> prio = mv[0]
                        mf == 5 && mt == 2 -> tag = m.str(mv)
                        mf == 6 && mt == 2 -> msg = m.str(mv)
                    }
                }
                if (prio >= 4) out += "${"VDIWEF".getOrElse(prio.toInt() - 2) { '?' }} $tag: ${msg.take(300)}"
            }
        }
    }
}
