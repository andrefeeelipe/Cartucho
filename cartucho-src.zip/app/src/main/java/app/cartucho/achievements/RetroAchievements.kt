package app.cartucho.achievements

import app.cartucho.CartuchoApp
import app.cartucho.emu.NativeBridge
import app.cartucho.emu.RaNativeListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import java.util.concurrent.TimeUnit

data class RaState(
    val busy: Boolean = false,
    val loggedIn: Boolean = false,
    val user: String = "",
    val score: Int = 0,
    val message: String? = null,
    val gameTitle: String? = null,
    val total: Int = 0,
    val unlocked: Int = 0,
)

data class RaToast(val title: String, val subtitle: String)

data class Achievement(
    val title: String,
    val description: String,
    val points: Int,
    val unlocked: Boolean,
    val progress: String,
)

/**
 * Lado Kotlin do RetroAchievements: faz as requisições HTTP pedidas pelo rcheevos
 * e transforma eventos em estado para a interface. Uma instância por processo.
 */
class RetroAchievements private constructor(private val app: CartuchoApp) : RaNativeListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private var created = false
    private var userAgent = "Cartucho/1.0"
    private var afterLogin: ((Boolean) -> Unit)? = null

    private val _state = MutableStateFlow(RaState())
    val state: StateFlow<RaState> = _state.asStateFlow()
    private val _toasts = MutableSharedFlow<RaToast>(extraBufferCapacity = 16)
    val toasts: SharedFlow<RaToast> = _toasts.asSharedFlow()

    @Synchronized
    private fun ensureClient() {
        if (created) return
        NativeBridge.raListener = this
        NativeBridge.raCreate(app.prefs.current.raHardcore)
        val clause = NativeBridge.raUserAgentClause().orEmpty()
        userAgent = "Cartucho/1.0 $clause".trim()
        created = true
    }

    fun loginWithPassword(user: String, password: String, done: (Boolean) -> Unit = {}) {
        ensureClient()
        _state.value = _state.value.copy(busy = true, message = null)
        afterLogin = done
        NativeBridge.raLoginPassword(user.trim(), password)
    }

    fun loginWithSavedToken(done: (Boolean) -> Unit) {
        val user = app.prefs.current.raUser
        val token = app.secure.raToken
        if (user.isEmpty() || token.isEmpty()) {
            done(false)
            return
        }
        ensureClient()
        afterLogin = done
        NativeBridge.raLoginToken(user, token)
    }

    fun setHardcore(enabled: Boolean) {
        app.prefs.update { it.copy(raHardcore = enabled) }
        if (created) NativeBridge.raSetHardcore(enabled)
    }

    fun logout() {
        if (created) NativeBridge.raLogout()
        app.secure.clear()
        app.prefs.update { it.copy(raEnabled = false, raUser = "", raScore = 0) }
        _state.value = RaState()
    }

    /** Usado no processo do jogo: entra com o token salvo e identifica o jogo pelo hash. */
    fun startForGame(consoleId: Int, path: String) {
        val s = app.prefs.current
        if (!s.raEnabled || s.raUser.isEmpty()) return
        loginWithSavedToken { ok ->
            // Fora do callback nativo, para não reentrar no rc_client.
            if (ok) scope.launch { NativeBridge.raLoadGame(consoleId, path) }
        }
    }

    fun achievements(): List<Achievement> {
        val json = NativeBridge.raAchievementsJson() ?: return emptyList()
        return runCatching {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Achievement(
                    title = o.optString("title"),
                    description = o.optString("description"),
                    points = o.optInt("points"),
                    unlocked = o.optBoolean("unlocked"),
                    progress = o.optString("progress"),
                )
            }
        }.getOrDefault(emptyList())
    }

    // ---- RaNativeListener ----

    override fun onRequest(id: Int, url: String, postData: String?, contentType: String?) {
        scope.launch {
            try {
                val builder = Request.Builder().url(url).header("User-Agent", userAgent)
                if (postData != null) {
                    val type = (contentType ?: "application/x-www-form-urlencoded").toMediaTypeOrNull()
                    builder.post(postData.toRequestBody(type))
                }
                http.newCall(builder.build()).execute().use { resp ->
                    val body = resp.body?.bytes()
                    NativeBridge.raHttpResponse(id, resp.code, body)
                }
            } catch (e: Exception) {
                // -2: erro de rede que pode ser repetido; o rcheevos reenvia depois.
                NativeBridge.raHttpResponse(id, -2, null)
            }
        }
    }

    override fun onLogin(success: Boolean, message: String?, username: String?, token: String?, score: Int) {
        if (success && username != null && token != null) {
            app.secure.raToken = token
            app.prefs.update { it.copy(raEnabled = true, raUser = username, raScore = score) }
            _state.value = _state.value.copy(busy = false, loggedIn = true, user = username, score = score, message = null)
        } else {
            _state.value = _state.value.copy(
                busy = false,
                loggedIn = false,
                message = message ?: "Não foi possível entrar. Confira usuário e senha.",
            )
        }
        val cb = afterLogin
        afterLogin = null
        cb?.invoke(success)
    }

    override fun onGameLoaded(success: Boolean, message: String?, title: String?, total: Int, unlocked: Int) {
        _state.value = _state.value.copy(gameTitle = title, total = total, unlocked = unlocked)
        if (success && total > 0) {
            _toasts.tryEmit(RaToast("RetroAchievements", "$unlocked de $total conquistas"))
        }
    }

    override fun onEvent(type: Int, title: String?, description: String?, points: Int) {
        when (type) {
            1 -> {
                _toasts.tryEmit(RaToast(title ?: "Conquista", "${description.orEmpty()}  ·  $points pts"))
                _state.value = _state.value.copy(unlocked = _state.value.unlocked + 1)
            }
            2 -> _toasts.tryEmit(RaToast("Jogo concluído", "Todas as conquistas desbloqueadas"))
            3 -> _toasts.tryEmit(RaToast("Sem conexão", "As conquistas serão enviadas depois"))
            4 -> _toasts.tryEmit(RaToast("Conectado", "Conquistas pendentes enviadas"))
        }
    }

    companion object {
        @Volatile private var instance: RetroAchievements? = null

        fun get(): RetroAchievements =
            instance ?: synchronized(this) {
                instance ?: RetroAchievements(CartuchoApp.instance).also { instance = it }
            }
    }
}
