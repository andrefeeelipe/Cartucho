package app.cartucho.achievements

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Cópia das conquistas de cada jogo, guardada quando o jogo está aberto.
 * Assim o card do jogador mostra as conquistas também quando é feito pela biblioteca.
 */
object AchievementCache {
    private fun file(context: Context, gameId: String) =
        File(context.filesDir, "achievements/${gameId.replace(Regex("[^A-Za-z0-9_-]"), "_")}.json")

    fun save(context: Context, gameId: String, list: List<Achievement>) {
        if (list.isEmpty()) return
        runCatching {
            val arr = JSONArray()
            list.forEach { a ->
                arr.put(JSONObject().put("title", a.title).put("description", a.description).put("points", a.points).put("unlocked", a.unlocked))
            }
            val f = file(context, gameId)
            f.parentFile?.mkdirs()
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(f)
        }
    }

    fun load(context: Context, gameId: String): List<Achievement> = runCatching {
        val f = file(context, gameId)
        if (!f.exists()) return emptyList()
        val arr = JSONArray(f.readText())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Achievement(o.optString("title"), o.optString("description"), o.optInt("points"), o.optBoolean("unlocked"), "")
        }
    }.getOrDefault(emptyList())
}
