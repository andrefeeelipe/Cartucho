package app.cartucho.achievements

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class RaProfile(
    val user: String,
    val avatarUrl: String,
    val points: Int,
    val softcorePoints: Int,
    val motto: String,
    val richPresence: String,
)

data class RaAwards(val masteries: Int, val beaten: Int, val total: Int)

data class RaFriend(val user: String, val points: Int, val followsMe: Boolean)

class RaWebException(message: String) : Exception(message)

/**
 * Cliente da Web API pública do RetroAchievements (retroachievements.org/API).
 * Usa o usuário e a "Web API Key" do próprio jogador, disponível nas configurações do site.
 */
class RaWeb(private val user: String, private val apiKey: String) {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()

    private fun get(endpoint: String, params: Map<String, String> = emptyMap()): String {
        val url = "https://retroachievements.org/API/$endpoint".toHttpUrl().newBuilder()
            .addQueryParameter("z", user)
            .addQueryParameter("y", apiKey)
            .apply { params.forEach { (k, v) -> addQueryParameter(k, v) } }
            .build()
        val req = Request.Builder().url(url).header("User-Agent", "Cartucho/1.0").build()
        http.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            when {
                resp.code == 401 || resp.code == 403 -> throw RaWebException("Usuário ou Web API Key inválidos.")
                !resp.isSuccessful -> throw RaWebException("RetroAchievements respondeu ${resp.code}.")
            }
            return body
        }
    }

    fun profile(of: String = user): RaProfile {
        val o = JSONObject(get("API_GetUserProfile.php", mapOf("u" to of)))
        val pic = o.optString("UserPic")
        return RaProfile(
            user = o.optString("User", of),
            avatarUrl = if (pic.isEmpty()) "" else "https://retroachievements.org$pic",
            points = o.optInt("TotalPoints"),
            softcorePoints = o.optInt("TotalSoftcorePoints"),
            motto = o.optString("Motto"),
            richPresence = o.optString("RichPresenceMsg"),
        )
    }

    fun awards(of: String = user): RaAwards {
        val o = JSONObject(get("API_GetUserAwards.php", mapOf("u" to of)))
        return RaAwards(
            masteries = o.optInt("MasteryAwardsCount") + o.optInt("CompletionAwardsCount"),
            beaten = o.optInt("BeatenHardcoreAwardsCount") + o.optInt("BeatenSoftcoreAwardsCount"),
            total = o.optInt("TotalAwardsCount"),
        )
    }

    /** Pessoas que o jogador segue no RetroAchievements. */
    fun following(): List<RaFriend> {
        val o = JSONObject(get("API_GetUsersIFollow.php", mapOf("c" to "100")))
        val arr = o.optJSONArray("Results") ?: JSONArray()
        return (0 until arr.length()).map {
            val f = arr.getJSONObject(it)
            RaFriend(f.optString("User"), f.optInt("Points"), f.optBoolean("IsFollowingMe"))
        }
    }
}
