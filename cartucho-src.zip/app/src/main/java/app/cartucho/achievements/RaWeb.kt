package app.cartucho.achievements

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class RaProfile(
    val user: String,
    val avatarUrl: String,
    val points: Int,
    val softcorePoints: Int,
    val motto: String,
    val richPresence: String,
)

data class RaAwards(val masteries: Int, val beaten: Int, val total: Int)

data class RaFriend(val user: String, val points: Int, val followsMe: Boolean)

data class RaGame(val id: Int, val title: String, val console: String, val icon: String, val at: Long)

data class RaActivity(val user: String, val avatarUrl: String, val richPresence: String, val recent: List<RaGame>)

/** kind: "zerou", "completou" (softcore) ou "platinou" (hardcore). */
data class RaCompletion(val game: RaGame, val kind: String)

data class RaComment(val user: String, val text: String, val at: Long)

class RaWebException(message: String) : Exception(message)

/**
 * Cliente da Web API pública do RetroAchievements (retroachievements.org/API).
 * Usa o usuário e a "Web API Key" do próprio jogador, disponível nas configurações do site.
 */
class RaWeb(private val user: String, private val apiKey: String) {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()

    private fun get(endpoint: String, params: Map<String, String> = emptyMap()): String {
        val url = "https://retroachievements.org/API/$endpoint".toHttpUrl().newBuilder()
            .addQueryParameter("z", user)
            .addQueryParameter("y", apiKey)
            .apply { params.forEach { (k, v) -> addQueryParameter(k, v) } }
            .build()
        val req = Request.Builder().url(url).header("User-Agent", "Cartucho/1.0").build()
        http.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            when {
                resp.code == 401 || resp.code == 403 -> throw RaWebException("Usuário ou Web API Key inválidos.")
                !resp.isSuccessful -> throw RaWebException("RetroAchievements respondeu ${resp.code}.")
            }
            return body
        }
    }

    fun profile(of: String = user): RaProfile {
        val o = JSONObject(get("API_GetUserProfile.php", mapOf("u" to of)))
        val pic = o.optString("UserPic")
        return RaProfile(
            user = o.optString("User", of),
            avatarUrl = if (pic.isEmpty()) "" else "https://retroachievements.org$pic",
            points = o.optInt("TotalPoints"),
            softcorePoints = o.optInt("TotalSoftcorePoints"),
            motto = o.optString("Motto"),
            richPresence = o.optString("RichPresenceMsg"),
        )
    }

    fun awards(of: String = user): RaAwards {
        val o = JSONObject(get("API_GetUserAwards.php", mapOf("u" to of)))
        return RaAwards(
            masteries = o.optInt("MasteryAwardsCount") + o.optInt("CompletionAwardsCount"),
            beaten = o.optInt("BeatenHardcoreAwardsCount") + o.optInt("BeatenSoftcoreAwardsCount"),
            total = o.optInt("TotalAwardsCount"),
        )
    }

    /** O que a pessoa jogou por último (com a "presença", ex.: "Fase 3, 2 vidas"). */
    fun recent(of: String): RaActivity {
        val o = JSONObject(get("API_GetUserSummary.php", mapOf("u" to of, "g" to "3", "a" to "0")))
        val arr = o.optJSONArray("RecentlyPlayed") ?: JSONArray()
        val games = (0 until arr.length()).map {
            val g = arr.getJSONObject(it)
            RaGame(
                id = g.optInt("GameID"),
                title = g.optString("Title"),
                console = g.optString("ConsoleName"),
                icon = media(g.optString("ImageIcon")),
                at = parseDate(g.optString("LastPlayed")),
            )
        }
        val pic = o.optString("UserPic")
        return RaActivity(
            user = o.optString("User", of),
            avatarUrl = if (pic.isEmpty()) "" else "https://media.retroachievements.org$pic",
            richPresence = o.optString("RichPresenceMsg"),
            recent = games,
        )
    }

    /** Jogos zerados e platinados (selos), do mais recente para o mais antigo. */
    fun completions(of: String): List<RaCompletion> {
        val o = JSONObject(get("API_GetUserAwards.php", mapOf("u" to of)))
        val arr = o.optJSONArray("VisibleUserAwards") ?: JSONArray()
        return (0 until arr.length()).mapNotNull {
            val a = arr.getJSONObject(it)
            val kind = when (a.optString("AwardType")) {
                "Mastery/Completion" -> if (a.optInt("AwardDataExtra") == 1) "platinou" else "completou"
                "Game Beaten" -> "zerou"
                else -> return@mapNotNull null
            }
            RaCompletion(
                game = RaGame(a.optInt("AwardData"), a.optString("Title"), a.optString("ConsoleName"), media(a.optString("ImageIcon")), parseDate(a.optString("AwardedAt"))),
                kind = kind,
            )
        }.sortedByDescending { it.game.at }
    }

    /** Recados deixados no mural da pessoa no site do RetroAchievements. */
    fun wall(of: String, count: Int = 20): List<RaComment> {
        val o = JSONObject(get("API_GetComments.php", mapOf("i" to of, "t" to "3", "c" to count.toString(), "sort" to "-submitted")))
        val arr = o.optJSONArray("Results") ?: JSONArray()
        return (0 until arr.length()).map {
            val c = arr.getJSONObject(it)
            RaComment(c.optString("User"), c.optString("CommentText"), parseDate(c.optString("Submitted")))
        }.sortedByDescending { it.at }
    }

    private fun media(path: String) = if (path.isEmpty()) "" else "https://media.retroachievements.org$path"

    private fun parseDate(text: String): Long {
        if (text.isBlank()) return 0
        val formats = listOf("yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss'Z'")
        for (f in formats) {
            val df = java.text.SimpleDateFormat(f, java.util.Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
            val d = runCatching { df.parse(text) }.getOrNull()
            if (d != null) return d.time
        }
        return 0
    }

    /** Pessoas que o jogador segue no RetroAchievements. */
    fun following(): List<RaFriend> {
        val o = JSONObject(get("API_GetUsersIFollow.php", mapOf("c" to "100")))
        val arr = o.optJSONArray("Results") ?: JSONArray()
        return (0 until arr.length()).map {
            val f = arr.getJSONObject(it)
            RaFriend(f.optString("User"), f.optInt("Points"), f.optBoolean("IsFollowingMe"))
        }
    }
}
