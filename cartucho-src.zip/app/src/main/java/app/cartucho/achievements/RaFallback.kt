package app.cartucho.achievements

import android.content.Context
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.concurrent.TimeUnit

/**
 * Jogos traduzidos (ou com hack de tradução) mudam o "hash" do arquivo, e o RetroAchievements
 * não os reconhece quando a tradução não foi cadastrada. Aqui o jogo é procurado pelo nome
 * na lista de jogos do console (o mesmo pedido "gameslist" do rcheevos) para usar a versão oficial.
 */
object RaFallback {
    private const val BASE = "https://retroachievements.org/dorequest.php"
    private const val MAX_AGE = 7L * 24 * 3600 * 1000
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    /**
     * Procura pelo nome o número (GameID) e o título do jogo oficial no RetroAchievements.
     * Bloqueante: chame fora da thread principal.
     */
    fun findGameId(context: Context, consoleId: Int, names: List<String>, userAgent: String): Pair<Int, String>? {
        val games = gameList(context, consoleId, userAgent)
        if (games.isEmpty()) return null
        val wanted = names.map { normalize(it) }.filter { it.length >= 3 }.distinct()
        if (wanted.isEmpty()) return null
        // Versões oficiais primeiro: títulos com "~" no RA são hacks, demos, protótipos e homebrews.
        val official = games.filterValues { !it.trimStart().startsWith("~") }
        fun pick(pool: Map<Int, String>): Pair<Int, String>? {
            val norm = pool.mapValues { normalize(it.value) }
            for (w in wanted) norm.entries.firstOrNull { it.value == w }?.let { return it.key to pool.getValue(it.key) }
            // Nome parecido: um contém o outro (subtítulos, "The", pontuação).
            for (w in wanted) {
                norm.entries
                    .filter { (it.value.length >= 5 && w.contains(it.value)) || (w.length >= 5 && it.value.contains(w)) }
                    .minByOrNull { kotlin.math.abs(it.value.length - w.length) }
                    ?.let { return it.key to pool.getValue(it.key) }
            }
            return null
        }
        return pick(official) ?: pick(games)
    }

    /** Nome comparável: sem região, tradução, versão, acentos, pontuação ou artigos. */
    fun normalize(raw: String): String {
        var t = raw.substringBeforeLast('.').let { if (it.length < raw.length - 5) raw else it }
        t = t.replace(Regex("""[\(\[][^\)\]]*[\)\]]"""), " ")
            .replace(Regex("""~[^~]*~"""), " ")
            .replace("&", " and ")
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        t = t.lowercase()
            .replace(Regex("""\b(the|a|an|o|os|as)\b"""), " ")
            .replace(Regex("""\b(pt[-_ ]?br|traduzido|traducao|translated|translation|portugues|br|v\d+(\.\d+)*)\b"""), " ")
        return t.replace(Regex("[^a-z0-9]"), "")
    }

    private fun cacheFile(context: Context, name: String) = File(context.filesDir, "ra/$name").apply { parentFile?.mkdirs() }

    /** Pede ao servidor por POST (como o rcheevos) e guarda a resposta por 7 dias. */
    private fun fetch(context: Context, cacheName: String, form: String, userAgent: String): String? {
        val f = cacheFile(context, cacheName)
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < MAX_AGE && f.length() > 0) return f.readText()
        val body = runCatching {
            val req = Request.Builder()
                .url(BASE)
                .header("User-Agent", userAgent.ifBlank { "Cartucho/1.0" })
                .post(form.toRequestBody("application/x-www-form-urlencoded".toMediaTypeOrNull()))
                .build()
            http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
        }.getOrNull()
        if (body != null && body.contains("\"Success\":true")) {
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(body)
            tmp.renameTo(f)
            return body
        }
        return if (f.exists()) f.readText() else null
    }

    /** id → título dos jogos com conquistas do console. */
    private fun gameList(context: Context, consoleId: Int, userAgent: String): Map<Int, String> {
        val body = fetch(context, "games-$consoleId.json", "r=gameslist&c=$consoleId", userAgent) ?: return emptyMap()
        return runCatching {
            val resp = JSONObject(body).getJSONObject("Response")
            resp.keys().asSequence().mapNotNull { k -> k.toIntOrNull()?.let { it to resp.optString(k) } }.toMap()
        }.getOrDefault(emptyMap())
    }
}
