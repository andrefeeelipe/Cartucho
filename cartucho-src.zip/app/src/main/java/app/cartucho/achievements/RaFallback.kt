package app.cartucho.achievements

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.concurrent.TimeUnit

/**
 * Jogos traduzidos (ou com hack de tradução) mudam o "hash" do arquivo e o RetroAchievements
 * não os reconhece quando a tradução não foi cadastrada. Aqui o jogo é procurado pelo nome
 * na lista pública do console e carregado pelo hash da versão oficial (internacional).
 * Usa os mesmos endereços públicos do RetroArch: lista de jogos e lista de hashes do console.
 */
object RaFallback {
    private const val BASE = "https://retroachievements.org/dorequest.php"
    private const val MAX_AGE = 7L * 24 * 3600 * 1000
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    /** "&u=usuário&t=token" do login, quando houver. */
    @Volatile private var auth = ""

    data class Match(val gameId: Int, val title: String, val hash: String)

    /** Procura o jogo pelo nome. Bloqueante: chame fora da thread principal. */
    fun find(context: Context, consoleId: Int, names: List<String>, userAgent: String, auth: String = ""): Match? {
        this.auth = auth
        val games = gameList(context, consoleId, userAgent)
        if (games.isEmpty()) return null
        val wanted = names.map { normalize(it) }.filter { it.length >= 3 }.distinct()
        if (wanted.isEmpty()) return null
        // Versões oficiais primeiro: títulos com "~" no RA são hacks, demos, protótipos e homebrews.
        val official = games.filterValues { !it.trimStart().startsWith("~") }
        fun pick(pool: Map<Int, String>): Pair<Int, String>? {
            val norm = pool.mapValues { normalize(it.value) }
            for (w in wanted) norm.entries.firstOrNull { it.value == w }?.let { return it.key to pool.getValue(it.key) }
            // Nome parecido: um contém o outro (subtítulos, "The", pontuação).
            for (w in wanted) {
                norm.entries
                    .filter { (it.value.length >= 5 && w.contains(it.value)) || (w.length >= 5 && it.value.contains(w)) }
                    .minByOrNull { kotlin.math.abs(it.value.length - w.length) }
                    ?.let { return it.key to pool.getValue(it.key) }
            }
            return null
        }
        val (id, title) = pick(official) ?: pick(games) ?: return null
        val hash = hashesFor(context, consoleId, id, userAgent).firstOrNull() ?: return null
        return Match(id, title, hash)
    }

    /** Nome comparável: sem região, tradução, versão, acentos, pontuação ou artigos. */
    fun normalize(raw: String): String {
        var t = raw.substringBeforeLast('.').let { if (it.length < raw.length - 5) raw else it }
        t = t.replace(Regex("""[\(\[][^\)\]]*[\)\]]"""), " ")
            .replace(Regex("""~[^~]*~"""), " ")
            .replace("&", " and ")
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        t = t.lowercase()
            .replace(Regex("""\b(the|a|an|o|os|as)\b"""), " ")
            .replace(Regex("""\b(pt[-_ ]?br|traduzido|traducao|translated|translation|portugues|br|v\d+(\.\d+)*)\b"""), " ")
        return t.replace(Regex("[^a-z0-9]"), "")
    }

    private fun cacheFile(context: Context, name: String) = File(context.filesDir, "ra/$name").apply { parentFile?.mkdirs() }

    private fun fetch(context: Context, cacheName: String, query: String, userAgent: String): String? {
        val f = cacheFile(context, cacheName)
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < MAX_AGE && f.length() > 0) return f.readText()
        val body = runCatching {
            val req = Request.Builder().url("$BASE?$query$auth").header("User-Agent", userAgent.ifBlank { "Cartucho/1.0" }).build()
            http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
        }.getOrNull()
        if (body != null && body.contains("\"Success\":true")) {
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(body)
            tmp.renameTo(f)
            return body
        }
        return if (f.exists()) f.readText() else null
    }

    /** id → título dos jogos com conquistas do console. */
    private fun gameList(context: Context, consoleId: Int, userAgent: String): Map<Int, String> {
        val body = fetch(context, "games-$consoleId.json", "r=gameslist&c=$consoleId", userAgent) ?: return emptyMap()
        return runCatching {
            val resp = JSONObject(body).getJSONObject("Response")
            resp.keys().asSequence().mapNotNull { k -> k.toIntOrNull()?.let { it to resp.optString(k) } }.toMap()
        }.getOrDefault(emptyMap())
    }

    /** Hashes cadastrados para o jogo (qualquer um carrega o mesmo conjunto de conquistas). */
    private fun hashesFor(context: Context, consoleId: Int, gameId: Int, userAgent: String): List<String> {
        val body = fetch(context, "hashes-$consoleId.json", "r=hashlibrary&c=$consoleId", userAgent) ?: return emptyList()
        return runCatching {
            val list = JSONObject(body).getJSONObject("MD5List")
            list.keys().asSequence().filter { list.optInt(it) == gameId }.toList()
        }.getOrDefault(emptyList())
    }
}
