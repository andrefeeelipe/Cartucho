package app.cartucho.cloud

import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class DriveAuthException(message: String, val recoverIntent: Intent? = null) : Exception(message)

object DriveAuth {
    const val SCOPE = "https://www.googleapis.com/auth/drive"

    fun client(context: Context): GoogleSignInClient {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(SCOPE))
            .build()
        return GoogleSignIn.getClient(context, options)
    }

    fun account(context: Context): GoogleSignInAccount? = GoogleSignIn.getLastSignedInAccount(context)

    /** Traduz o resultado do login em conta ou mensagem clara. */
    fun parseResult(data: Intent?): Result<GoogleSignInAccount> = try {
        val account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException::class.java)
        Result.success(account)
    } catch (e: ApiException) {
        val msg = when (e.statusCode) {
            10 -> "O login Google ainda não foi configurado para este app. Siga a seção \"Google Drive\" do README (registrar o SHA-1)."
            12501 -> "Login cancelado."
            7 -> "Sem conexão com a internet."
            else -> "Não foi possível entrar (código ${e.statusCode})."
        }
        Result.failure(DriveAuthException(msg))
    }

    /** Obtém um token de acesso. Bloqueante: chame fora da thread principal. */
    fun token(context: Context): String {
        val account = account(context)?.account ?: throw DriveAuthException("Entre com sua conta Google em Ajustes > Nuvem.")
        return try {
            GoogleAuthUtil.getToken(context, account, "oauth2:$SCOPE")
        } catch (e: UserRecoverableAuthException) {
            throw DriveAuthException("O Google pediu para confirmar o acesso. Abra Ajustes > Nuvem.", e.intent)
        }
    }

    fun signOut(context: Context) {
        client(context).signOut()
    }
}

data class DriveFile(
    val id: String,
    val name: String,
    val isFolder: Boolean,
    val modified: Long,
    val localMtime: Long?,
)

/** Cliente mínimo da Drive API v3 (REST). */
class DriveApi(private val token: String) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()
    private val folderMime = "application/vnd.google-apps.folder"

    private fun request(url: String) = Request.Builder().url(url).header("Authorization", "Bearer $token")

    private fun execJson(req: Request): JSONObject {
        http.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                if (resp.code == 401) throw DriveAuthException("Sessão do Google expirou. Entre novamente em Ajustes > Nuvem.")
                throw IOException("Drive respondeu ${resp.code}: ${body.take(200)}")
            }
            return if (body.isEmpty()) JSONObject() else JSONObject(body)
        }
    }

    private fun parse(o: JSONObject): DriveFile = DriveFile(
        id = o.getString("id"),
        name = o.optString("name"),
        isFolder = o.optString("mimeType") == folderMime,
        modified = parseTime(o.optString("modifiedTime")),
        localMtime = o.optJSONObject("appProperties")?.optString("cartuchoMtime")?.toLongOrNull(),
    )

    private fun list(query: String): List<DriveFile> {
        val out = ArrayList<DriveFile>()
        var pageToken: String? = null
        do {
            val url = "https://www.googleapis.com/drive/v3/files".toHttpUrl().newBuilder()
                .addQueryParameter("q", query)
                .addQueryParameter("fields", "nextPageToken,files(id,name,mimeType,modifiedTime,appProperties)")
                .addQueryParameter("pageSize", "1000")
                .addQueryParameter("orderBy", "name")
                .apply { pageToken?.let { addQueryParameter("pageToken", it) } }
                .build()
            val json = execJson(Request.Builder().url(url).header("Authorization", "Bearer $token").build())
            val files = json.optJSONArray("files") ?: JSONArray()
            for (i in 0 until files.length()) out.add(parse(files.getJSONObject(i)))
            pageToken = json.optString("nextPageToken").ifEmpty { null }
        } while (pageToken != null)
        return out
    }

    private fun escape(s: String) = s.replace("\\", "\\\\").replace("'", "\\'")

    fun listFolders(parentId: String): List<DriveFile> =
        list("'${escape(parentId)}' in parents and mimeType='$folderMime' and trashed=false")

    fun listChildren(parentId: String): List<DriveFile> =
        list("'${escape(parentId)}' in parents and trashed=false")

    fun createFolder(name: String, parentId: String): DriveFile {
        val meta = JSONObject().put("name", name).put("mimeType", folderMime).put("parents", JSONArray().put(parentId))
        val req = request("https://www.googleapis.com/drive/v3/files?fields=id,name,mimeType,modifiedTime,appProperties")
            .post(meta.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        return parse(execJson(req))
    }

    fun findOrCreateFolder(name: String, parentId: String, known: List<DriveFile>? = null): String {
        val existing = (known ?: listFolders(parentId)).firstOrNull { it.isFolder && it.name == name }
        return existing?.id ?: createFolder(name, parentId).id
    }

    fun upload(file: File, parentId: String, existingId: String?): DriveFile {
        val meta = JSONObject()
            .put("name", file.name)
            .put("appProperties", JSONObject().put("cartuchoMtime", file.lastModified().toString()))
        if (existingId == null) meta.put("parents", JSONArray().put(parentId))
        val metaPart: RequestBody = meta.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val filePart: RequestBody = file.asRequestBody("application/octet-stream".toMediaType())
        val body = MultipartBody.Builder()
            .setType("multipart/related".toMediaType())
            .addPart(metaPart)
            .addPart(filePart)
            .build()
        val fields = "fields=id,name,mimeType,modifiedTime,appProperties"
        val req = if (existingId == null) {
            request("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&$fields").post(body).build()
        } else {
            request("https://www.googleapis.com/upload/drive/v3/files/$existingId?uploadType=multipart&$fields").patch(body).build()
        }
        return parse(execJson(req))
    }

    fun download(fileId: String, dest: File) {
        val req = request("https://www.googleapis.com/drive/v3/files/$fileId?alt=media").build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Falha ao baixar (${resp.code})")
            dest.parentFile?.mkdirs()
            val tmp = File(dest.parentFile, dest.name + ".download")
            resp.body?.byteStream()?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            if (!tmp.renameTo(dest)) {
                tmp.copyTo(dest, overwrite = true)
                tmp.delete()
            }
        }
    }

    companion object {
        private val formats = listOf("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")

        fun parseTime(s: String): Long {
            if (s.isEmpty()) return 0L
            for (f in formats) {
                runCatching {
                    val fmt = SimpleDateFormat(f, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                    return fmt.parse(s)?.time ?: 0L
                }
            }
            return 0L
        }
    }
}
