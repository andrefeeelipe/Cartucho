package app.cartucho.cloud

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import app.cartucho.CartuchoApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Espelha as pastas locais saves/ e states/ em <pasta escolhida>/Cartucho/ no Drive.
 * Regra de conflito: o mais recente vence; a versão local substituída vai para backups/ (5 por arquivo).
 */
class SyncEngine(private val context: Context) {
    private val filesDir = context.filesDir
    private val backupDir = File(filesDir, "backups")

    data class Report(val uploaded: Int, val downloaded: Int)

    fun sync(folderId: String): Report {
        val api = DriveApi(DriveAuth.token(context))
        val rootFolders = api.listFolders(folderId)
        val root = api.findOrCreateFolder("Cartucho", folderId, rootFolders)
        var up = 0
        var down = 0
        val rootChildren = api.listFolders(root)
        for (top in listOf("saves", "states")) {
            val local = File(filesDir, top).apply { mkdirs() }
            val remote = api.findOrCreateFolder(top, root, rootChildren)
            val r = syncDir(api, local, remote, top)
            up += r.uploaded
            down += r.downloaded
        }
        return Report(up, down)
    }

    private fun syncDir(api: DriveApi, local: File, remoteId: String, relative: String): Report {
        var up = 0
        var down = 0
        val remote = api.listChildren(remoteId)
        val remoteByName = remote.associateBy { it.name }
        val localFiles = local.listFiles()?.toList().orEmpty()

        for (f in localFiles) {
            if (f.isDirectory) {
                val childId = remoteByName[f.name]?.takeIf { it.isFolder }?.id ?: api.createFolder(f.name, remoteId).id
                val r = syncDir(api, f, childId, "$relative/${f.name}")
                up += r.uploaded
                down += r.downloaded
                continue
            }
            if (f.name.endsWith(".tmp") || f.name.endsWith(".download")) continue
            val r = remoteByName[f.name]
            val localTime = f.lastModified()
            if (r == null) {
                api.upload(f, remoteId, null)
                up++
            } else if (!r.isFolder) {
                val remoteTime = r.localMtime ?: r.modified
                when {
                    localTime > remoteTime + 2000 -> { api.upload(f, remoteId, r.id); up++ }
                    remoteTime > localTime + 2000 -> {
                        backup(f, "$relative/${f.name}")
                        api.download(r.id, f)
                        f.setLastModified(remoteTime)
                        down++
                    }
                }
            }
        }

        val localNames = localFiles.map { it.name }.toSet()
        for (r in remote) {
            if (r.name in localNames) continue
            val dest = File(local, r.name)
            if (r.isFolder) {
                dest.mkdirs()
                val rr = syncDir(api, dest, r.id, "$relative/${r.name}")
                up += rr.uploaded
                down += rr.downloaded
            } else {
                api.download(r.id, dest)
                dest.setLastModified(r.localMtime ?: r.modified)
                down++
            }
        }
        return Report(up, down)
    }

    private fun backup(file: File, relative: String) {
        val target = File(backupDir, relative)
        target.parentFile?.mkdirs()
        file.copyTo(File(target.parentFile, "${file.name}.${System.currentTimeMillis()}"), overwrite = true)
        val old = target.parentFile?.listFiles { f -> f.name.startsWith(file.name + ".") }?.sortedByDescending { it.lastModified() }.orEmpty()
        old.drop(5).forEach { it.delete() }
    }
}

class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext as CartuchoApp
        val s = app.prefs.current
        if (!s.driveEnabled || s.driveFolderId.isEmpty()) return@withContext Result.success()
        try {
            SyncEngine(app).sync(s.driveFolderId)
            app.prefs.update { it.copy(lastSync = System.currentTimeMillis(), lastSyncError = "") }
            Result.success()
        } catch (e: DriveAuthException) {
            app.prefs.update { it.copy(lastSyncError = e.message ?: "Erro de autenticação") }
            Result.failure()
        } catch (e: Exception) {
            app.prefs.update { it.copy(lastSyncError = e.message ?: "Erro ao sincronizar") }
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}

object SyncScheduler {
    fun enqueue(context: Context) {
        val app = context.applicationContext as CartuchoApp
        val s = app.prefs.current
        if (!s.driveEnabled || s.driveFolderId.isEmpty()) return
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (s.driveWifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
            .build()
        val request = OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(constraints).build()
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork("cartucho-sync", ExistingWorkPolicy.REPLACE, request)
    }
}
