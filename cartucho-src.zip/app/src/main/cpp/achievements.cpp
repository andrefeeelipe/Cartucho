// Integração com RetroAchievements via rcheevos (rc_client).
// As requisições HTTP são feitas no lado Kotlin (OkHttp) e devolvidas aqui.

#include "achievements.h"

#include <android/log.h>

#include <atomic>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#include "libretro.h"

extern "C" {
#include "rc_client.h"
#include "rc_consoles.h"
#include "rc_hash.h"
}

#define RA_TAG "CartuchoRA"
#define RALOG(...) __android_log_print(ANDROID_LOG_INFO, RA_TAG, __VA_ARGS__)

static JavaVM* g_vm = nullptr;
static jclass g_bridge = nullptr;
static jmethodID g_onRequest = nullptr;
static jmethodID g_onLogin = nullptr;
static jmethodID g_onGameLoaded = nullptr;
static jmethodID g_onEvent = nullptr;

static rc_client_t* g_client = nullptr;
static std::mutex g_reqMutex;
struct PendingRequest {
    rc_client_server_callback_t callback;
    void* data;
};
static std::map<int, PendingRequest> g_requests;
static int g_nextRequest = 1;
static std::atomic<bool> g_resetRequested{false};
static std::atomic<bool> g_gameReady{false};
static uint32_t g_consoleId = 0;

// ---------------------------------------------------------------------------
// JNI helpers

static JNIEnv* currentEnv(bool* attached) {
    *attached = false;
    JNIEnv* env = nullptr;
    if (!g_vm) return nullptr;
    if (g_vm->GetEnv((void**)&env, JNI_VERSION_1_6) == JNI_OK) return env;
#ifdef __ANDROID__
    jint rc = g_vm->AttachCurrentThread(&env, nullptr);  // Android: JNIEnv**
#else
    jint rc = g_vm->AttachCurrentThread((void**)&env, nullptr);
#endif
    if (rc == JNI_OK) {
        *attached = true;
        return env;
    }
    return nullptr;
}

static void releaseEnv(bool attached) {
    if (attached && g_vm) g_vm->DetachCurrentThread();
}

static jclass g_stringClass = nullptr;
static jmethodID g_stringCtor = nullptr;
static jstring g_utf8Name = nullptr;

// NewStringUTF exige "modified UTF-8"; títulos com emoji quebrariam. Decodifica pelo Java.
static jstring jniString(JNIEnv* env, const char* s) {
    if (!s) return nullptr;
    if (!g_stringClass || !g_stringCtor || !g_utf8Name) return env->NewStringUTF(s);
    jsize len = (jsize)strlen(s);
    jbyteArray bytes = env->NewByteArray(len);
    if (!bytes) return nullptr;
    env->SetByteArrayRegion(bytes, 0, len, (const jbyte*)s);
    jstring out = (jstring)env->NewObject(g_stringClass, g_stringCtor, bytes, g_utf8Name);
    env->DeleteLocalRef(bytes);
    if (env->ExceptionCheck()) { env->ExceptionClear(); return nullptr; }
    return out;
}

void ra_jni_init(JavaVM* vm, JNIEnv* env) {
    g_vm = vm;
    jclass str = env->FindClass("java/lang/String");
    if (str) {
        g_stringClass = (jclass)env->NewGlobalRef(str);
        g_stringCtor = env->GetMethodID(g_stringClass, "<init>", "([BLjava/lang/String;)V");
        jstring name = env->NewStringUTF("UTF-8");
        g_utf8Name = (jstring)env->NewGlobalRef(name);
        env->DeleteLocalRef(name);
        env->DeleteLocalRef(str);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    jclass local = env->FindClass("app/cartucho/emu/NativeBridge");
    if (!local) {
        env->ExceptionClear();
        return;
    }
    g_bridge = (jclass)env->NewGlobalRef(local);
    env->DeleteLocalRef(local);
    g_onRequest = env->GetStaticMethodID(g_bridge, "onRaRequest", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
    g_onLogin = env->GetStaticMethodID(g_bridge, "onRaLogin", "(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V");
    g_onGameLoaded = env->GetStaticMethodID(g_bridge, "onRaGameLoaded", "(ZLjava/lang/String;Ljava/lang/String;II)V");
    g_onEvent = env->GetStaticMethodID(g_bridge, "onRaEvent", "(ILjava/lang/String;Ljava/lang/String;I)V");
    if (env->ExceptionCheck()) env->ExceptionClear();
}

// ---------------------------------------------------------------------------
// Mapa de memória (endereços do RetroAchievements -> memória do core)

struct RaRegion {
    uint32_t start;
    uint32_t end;
    uint8_t* ptr;
};
static std::vector<RaRegion> g_regions;
static bool g_regionsBuilt = false;

static void buildRegions() {
    g_regions.clear();
    g_regionsBuilt = true;
    size_t sysSize = 0, saveSize = 0;
    uint8_t* sys = (uint8_t*)cartucho_get_memory_data(RETRO_MEMORY_SYSTEM_RAM, &sysSize);
    uint8_t* save = (uint8_t*)cartucho_get_memory_data(RETRO_MEMORY_SAVE_RAM, &saveSize);
    const struct retro_memory_descriptor* descs = nullptr;
    int numDescs = cartucho_get_memory_descriptors(&descs);

    const rc_memory_regions_t* regions = rc_console_memory_regions(g_consoleId);
    if (!regions || regions->num_regions == 0) {
        if (sys && sysSize) g_regions.push_back({0, (uint32_t)(sysSize - 1), sys});
        if (save && saveSize) g_regions.push_back({(uint32_t)sysSize, (uint32_t)(sysSize + saveSize - 1), save});
        return;
    }

    size_t sysUsed = 0, saveUsed = 0;
    for (uint32_t i = 0; i < regions->num_regions; i++) {
        const rc_memory_region_t& r = regions->region[i];
        size_t len = (size_t)r.end_address - r.start_address + 1;
        uint8_t* ptr = nullptr;

        for (int d = 0; d < numDescs && !ptr; d++) {
            const struct retro_memory_descriptor& desc = descs[d];
            if (!desc.ptr || desc.len == 0) continue;
            if (r.real_address >= desc.start && r.real_address < desc.start + desc.len) {
                size_t off = r.real_address - desc.start;
                ptr = (uint8_t*)desc.ptr + desc.offset + off;
                size_t avail = desc.len - off;
                if (avail < len) len = avail;
            }
        }
        if (!ptr && r.type == RC_MEMORY_TYPE_SYSTEM_RAM && sys && sysUsed < sysSize) {
            ptr = sys + sysUsed;
            size_t avail = sysSize - sysUsed;
            if (avail < len) len = avail;
            sysUsed += len;
        } else if (!ptr && r.type == RC_MEMORY_TYPE_SAVE_RAM && save && saveUsed < saveSize) {
            ptr = save + saveUsed;
            size_t avail = saveSize - saveUsed;
            if (avail < len) len = avail;
            saveUsed += len;
        }
        if (ptr && len > 0) g_regions.push_back({r.start_address, (uint32_t)(r.start_address + len - 1), ptr});
    }
}

static uint32_t RC_CCONV readMemory(uint32_t address, uint8_t* buffer, uint32_t numBytes, rc_client_t*) {
    if (!g_regionsBuilt || g_regions.empty()) buildRegions();
    uint32_t done = 0;
    while (done < numBytes) {
        uint32_t addr = address + done;
        const RaRegion* found = nullptr;
        for (const RaRegion& r : g_regions) {
            if (addr >= r.start && addr <= r.end) {
                found = &r;
                break;
            }
        }
        if (!found) break;
        uint32_t chunk = found->end - addr + 1;
        if (chunk > numBytes - done) chunk = numBytes - done;
        memcpy(buffer + done, found->ptr + (addr - found->start), chunk);
        done += chunk;
    }
    return done;
}

// ---------------------------------------------------------------------------
// Rede

static void RC_CCONV serverCall(const rc_api_request_t* request, rc_client_server_callback_t callback,
                               void* callbackData, rc_client_t*) {
    int id;
    {
        std::lock_guard<std::mutex> lock(g_reqMutex);
        id = g_nextRequest++;
        g_requests[id] = {callback, callbackData};
    }
    bool attached;
    JNIEnv* env = currentEnv(&attached);
    if (!env || !g_bridge || !g_onRequest) {
        releaseEnv(attached);
        return;
    }
    jstring url = jniString(env, request->url);
    jstring post = jniString(env, request->post_data);
    jstring ct = jniString(env, request->content_type);
    env->CallStaticVoidMethod(g_bridge, g_onRequest, id, url, post, ct);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (url) env->DeleteLocalRef(url);
    if (post) env->DeleteLocalRef(post);
    if (ct) env->DeleteLocalRef(ct);
    releaseEnv(attached);
}

// ---------------------------------------------------------------------------
// Callbacks do rc_client

static void callLogin(bool ok, const char* message) {
    bool attached;
    JNIEnv* env = currentEnv(&attached);
    if (!env || !g_onLogin) { releaseEnv(attached); return; }
    const rc_client_user_t* user = (ok && g_client) ? rc_client_get_user_info(g_client) : nullptr;
    jstring msg = jniString(env, message);
    jstring name = jniString(env, user ? user->username : nullptr);
    jstring token = jniString(env, user ? user->token : nullptr);
    jint score = user ? (jint)user->score : 0;
    env->CallStaticVoidMethod(g_bridge, g_onLogin, (jboolean)(ok ? JNI_TRUE : JNI_FALSE), msg, name, token, score);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (msg) env->DeleteLocalRef(msg);
    if (name) env->DeleteLocalRef(name);
    if (token) env->DeleteLocalRef(token);
    releaseEnv(attached);
}

static void RC_CCONV loginCallback(int result, const char* errorMessage, rc_client_t*, void*) {
    callLogin(result == RC_OK, errorMessage);
}

static void RC_CCONV loadGameCallback(int result, const char* errorMessage, rc_client_t* client, void*) {
    bool ok = result == RC_OK;
    g_gameReady = ok;
    g_regionsBuilt = false;
    bool attached;
    JNIEnv* env = currentEnv(&attached);
    if (!env || !g_onGameLoaded) { releaseEnv(attached); return; }
    const rc_client_game_t* game = ok ? rc_client_get_game_info(client) : nullptr;
    rc_client_user_game_summary_t summary;
    memset(&summary, 0, sizeof(summary));
    if (ok) rc_client_get_user_game_summary(client, &summary);
    jstring msg = jniString(env, errorMessage);
    jstring title = jniString(env, game ? game->title : nullptr);
    env->CallStaticVoidMethod(g_bridge, g_onGameLoaded, (jboolean)(ok ? JNI_TRUE : JNI_FALSE), msg, title,
                              (jint)summary.num_core_achievements, (jint)summary.num_unlocked_achievements);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (msg) env->DeleteLocalRef(msg);
    if (title) env->DeleteLocalRef(title);
    releaseEnv(attached);
}

static void sendEvent(int type, const char* title, const char* description, int points) {
    bool attached;
    JNIEnv* env = currentEnv(&attached);
    if (!env || !g_onEvent) { releaseEnv(attached); return; }
    jstring t = jniString(env, title);
    jstring d = jniString(env, description);
    env->CallStaticVoidMethod(g_bridge, g_onEvent, (jint)type, t, d, (jint)points);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (t) env->DeleteLocalRef(t);
    if (d) env->DeleteLocalRef(d);
    releaseEnv(attached);
}

static void RC_CCONV eventHandler(const rc_client_event_t* event, rc_client_t*) {
    switch (event->type) {
        case RC_CLIENT_EVENT_ACHIEVEMENT_TRIGGERED:
            if (event->achievement)
                sendEvent(1, event->achievement->title, event->achievement->description, (int)event->achievement->points);
            break;
        case RC_CLIENT_EVENT_GAME_COMPLETED:
            sendEvent(2, nullptr, nullptr, 0);
            break;
        case RC_CLIENT_EVENT_DISCONNECTED:
            sendEvent(3, nullptr, nullptr, 0);
            break;
        case RC_CLIENT_EVENT_RECONNECTED:
            sendEvent(4, nullptr, nullptr, 0);
            break;
        case RC_CLIENT_EVENT_RESET:
            g_resetRequested = true;
            break;
        case RC_CLIENT_EVENT_SERVER_ERROR:
            sendEvent(5, nullptr, nullptr, 0);
            break;
        default:
            break;
    }
}

// ---------------------------------------------------------------------------
// Ganchos chamados pelo host

void ra_do_frame() {
    if (g_client && g_gameReady) rc_client_do_frame(g_client);
}

bool ra_consume_reset_request() { return g_resetRequested.exchange(false); }

void ra_on_reset() {
    if (g_client && g_gameReady) rc_client_reset(g_client);
}

void ra_on_state_loaded() {
    // Sem dados de progresso no state: reinicia a avaliação para evitar desbloqueios indevidos.
    if (g_client && g_gameReady) rc_client_reset(g_client);
}

void ra_unload_game() {
    if (g_client && g_gameReady) rc_client_unload_game(g_client);
    g_gameReady = false;
    g_regions.clear();
    g_regionsBuilt = false;
}

// ---------------------------------------------------------------------------
// JNI

#define RA_FN(name) Java_app_cartucho_emu_NativeBridge_##name

static std::string jstr(JNIEnv* env, jstring s) {
    if (!s) return std::string();
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

static void jsonEscape(std::string& out, const char* s) {
    out.push_back('"');
    if (s) {
        for (const char* p = s; *p; p++) {
            unsigned char c = (unsigned char)*p;
            if (c == '"' || c == '\\') { out.push_back('\\'); out.push_back((char)c); }
            else if (c == '\n') out += "\\n";
            else if (c < 0x20) out.push_back(' ');
            else out.push_back((char)c);
        }
    }
    out.push_back('"');
}

extern "C" {

JNIEXPORT void JNICALL RA_FN(raCreate)(JNIEnv*, jclass, jboolean hardcore) {
    if (!g_client) {
        rc_hash_init_default_cdreader();
        g_client = rc_client_create(readMemory, serverCall);
        if (!g_client) return;
        rc_client_set_event_handler(g_client, eventHandler);
    }
    rc_client_set_hardcore_enabled(g_client, hardcore ? 1 : 0);
}

JNIEXPORT jstring JNICALL RA_FN(raUserAgentClause)(JNIEnv* env, jclass) {
    char buf[128];
    buf[0] = '\0';
    if (g_client) rc_client_get_user_agent_clause(g_client, buf, sizeof(buf));
    return jniString(env, buf);
}

JNIEXPORT void JNICALL RA_FN(raSetHardcore)(JNIEnv*, jclass, jboolean hardcore) {
    if (g_client) rc_client_set_hardcore_enabled(g_client, hardcore ? 1 : 0);
}

JNIEXPORT void JNICALL RA_FN(raLoginPassword)(JNIEnv* env, jclass, jstring user, jstring password) {
    if (!g_client) return;
    std::string u = jstr(env, user);
    std::string p = jstr(env, password);
    rc_client_begin_login_with_password(g_client, u.c_str(), p.c_str(), loginCallback, nullptr);
}

JNIEXPORT void JNICALL RA_FN(raLoginToken)(JNIEnv* env, jclass, jstring user, jstring token) {
    if (!g_client) return;
    std::string u = jstr(env, user);
    std::string t = jstr(env, token);
    rc_client_begin_login_with_token(g_client, u.c_str(), t.c_str(), loginCallback, nullptr);
}

JNIEXPORT void JNICALL RA_FN(raLogout)(JNIEnv*, jclass) {
    if (g_client) rc_client_logout(g_client);
}

JNIEXPORT void JNICALL RA_FN(raLoadGame)(JNIEnv* env, jclass, jint consoleId, jstring path) {
    if (!g_client) return;
    g_consoleId = (uint32_t)consoleId;
    std::string p = jstr(env, path);
    rc_client_begin_identify_and_load_game(g_client, (uint32_t)consoleId, p.c_str(), nullptr, 0,
                                           loadGameCallback, nullptr);
}

JNIEXPORT void JNICALL RA_FN(raHttpResponse)(JNIEnv* env, jclass, jint id, jint status, jbyteArray body) {
    PendingRequest req;
    {
        std::lock_guard<std::mutex> lock(g_reqMutex);
        auto it = g_requests.find(id);
        if (it == g_requests.end()) return;
        req = it->second;
        g_requests.erase(it);
    }
    std::vector<char> data;
    if (body) {
        jsize len = env->GetArrayLength(body);
        data.resize((size_t)len + 1);
        if (len > 0) env->GetByteArrayRegion(body, 0, len, (jbyte*)data.data());
        data[(size_t)len] = '\0';
    } else {
        data.push_back('\0');
    }
    rc_api_server_response_t response;
    memset(&response, 0, sizeof(response));
    response.body = data.data();
    response.body_length = data.size() - 1;
    response.http_status_code = status;
    req.callback(&response, req.data);
}

JNIEXPORT void JNICALL RA_FN(raIdle)(JNIEnv*, jclass) {
    if (g_client) rc_client_idle(g_client);
}

JNIEXPORT jstring JNICALL RA_FN(raAchievementsJson)(JNIEnv* env, jclass) {
    std::string out = "[";
    if (g_client && g_gameReady) {
        rc_client_achievement_list_t* list = rc_client_create_achievement_list(
            g_client, RC_CLIENT_ACHIEVEMENT_CATEGORY_CORE, RC_CLIENT_ACHIEVEMENT_LIST_GROUPING_LOCK_STATE);
        if (list) {
            bool first = true;
            for (uint32_t b = 0; b < list->num_buckets; b++) {
                const rc_client_achievement_bucket_t& bucket = list->buckets[b];
                for (uint32_t a = 0; a < bucket.num_achievements; a++) {
                    const rc_client_achievement_t* ach = bucket.achievements[a];
                    if (!first) out.push_back(',');
                    first = false;
                    out += "{\"title\":";
                    jsonEscape(out, ach->title);
                    out += ",\"description\":";
                    jsonEscape(out, ach->description);
                    out += ",\"points\":" + std::to_string(ach->points);
                    out += ",\"unlocked\":";
                    out += ach->unlocked ? "true" : "false";
                    out += ",\"progress\":";
                    jsonEscape(out, ach->measured_progress);
                    out += "}";
                }
            }
            rc_client_destroy_achievement_list(list);
        }
    }
    out += "]";
    return jniString(env, out.c_str());
}

}  // extern "C"
