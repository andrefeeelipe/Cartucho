cmake_minimum_required(VERSION 3.22.1)
project(cartucho C CXX)

# Dependências baixadas pelo script scripts/fetch-deps.sh (ou pelo GitHub Actions):
#   third_party/libretro/libretro.h
#   third_party/rcheevos/
set(THIRD_PARTY ${CMAKE_CURRENT_SOURCE_DIR}/third_party)
set(RC_DIR ${THIRD_PARTY}/rcheevos)

if(NOT EXISTS ${THIRD_PARTY}/libretro/libretro.h)
    message(FATAL_ERROR "libretro.h ausente. Rode scripts/fetch-deps.sh antes de compilar.")
endif()
if(NOT EXISTS ${RC_DIR}/include/rc_client.h)
    message(FATAL_ERROR "rcheevos ausente. Rode scripts/fetch-deps.sh antes de compilar.")
endif()

file(GLOB_RECURSE RC_SOURCES ${RC_DIR}/src/*.c)
list(FILTER RC_SOURCES EXCLUDE REGEX ".*rc_libretro\\.c$")
list(FILTER RC_SOURCES EXCLUDE REGEX ".*raintegration.*")

add_library(rcheevos STATIC ${RC_SOURCES})
target_include_directories(rcheevos PUBLIC ${RC_DIR}/include PRIVATE ${RC_DIR}/src)
target_compile_definitions(rcheevos PUBLIC RC_DISABLE_LUA RC_CLIENT_SUPPORTS_HASH)
target_compile_options(rcheevos PRIVATE -w)

add_library(cartucho SHARED cartucho_native.cpp achievements.cpp vk_bridge.cpp)
target_include_directories(cartucho PRIVATE ${THIRD_PARTY}/libretro ${RC_DIR}/include)
set_target_properties(cartucho PROPERTIES CXX_STANDARD 17 CXX_STANDARD_REQUIRED ON)
target_compile_options(cartucho PRIVATE -Wall -Wno-unused-function -Wno-unused-variable)
target_link_libraries(cartucho rcheevos GLESv3 EGL log android)
