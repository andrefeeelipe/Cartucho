// Cartucho — ponte Vulkan para cores libretro que só desenham em Vulkan (Xenia, Cemu no Android, RPCS3...).
// O Cartucho cria o dispositivo Vulkan, entrega ao core a interface que o libretro pede e, a cada quadro,
// copia a imagem final para a memória (XRGB8888) para ser mostrada pelo mesmo caminho dos outros jogos.
// Usado igual no Windows e no Android.
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace vkb {

/** O core pediu Vulkan? (guardar a interface de negociação que ele mandar). */
void setNegotiation(const void* negotiationInterface);

/** Cria instância e dispositivo. Chamar depois do retro_load_game e antes do context_reset. */
bool init(std::string& error);

/** Ponteiro para struct retro_hw_render_interface_vulkan (para RETRO_ENVIRONMENT_GET_HW_RENDER_INTERFACE). */
const void* renderInterface();

/** Copia o último quadro entregue pelo core para [out] em XRGB8888 (w * h * 4 bytes). */
bool readFrame(unsigned w, unsigned h, std::vector<uint8_t>& out);

bool ready();
void shutdown();

}  // namespace vkb
