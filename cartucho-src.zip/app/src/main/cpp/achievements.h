#pragma once

#include <jni.h>
#include <stddef.h>

struct retro_memory_descriptor;

// Implementado em cartucho_native.cpp
int cartucho_get_memory_descriptors(const struct retro_memory_descriptor** out);
void* cartucho_get_memory_data(unsigned id, size_t* size);

// Implementado em achievements.cpp
void ra_jni_init(JavaVM* vm, JNIEnv* env);
void ra_do_frame();
bool ra_consume_reset_request();
void ra_on_reset();
void ra_on_state_loaded();
void ra_unload_game();
