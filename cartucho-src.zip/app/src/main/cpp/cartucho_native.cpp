// Cartucho — host libretro mínimo para Android.
// Carrega um core (.so), entrega vídeo via OpenGL ES, áudio por ring buffer
// lido pelo lado Kotlin (AudioTrack) e entrada por bitmask atômica.
// Todas as chamadas ao core acontecem na thread do GLSurfaceView.

#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <time.h>

#include <atomic>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#include "libretro.h"
#include "achievements.h"

#define TAG "CartuchoNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ---------------------------------------------------------------------------
// Core

struct Core {
    void* handle = nullptr;
    void (*init)(void) = nullptr;
    void (*deinit)(void) = nullptr;
    void (*get_system_info)(struct retro_system_info*) = nullptr;
    void (*get_system_av_info)(struct retro_system_av_info*) = nullptr;
    void (*set_environment)(retro_environment_t) = nullptr;
    void (*set_video_refresh)(retro_video_refresh_t) = nullptr;
    void (*set_audio_sample)(retro_audio_sample_t) = nullptr;
    void (*set_audio_sample_batch)(retro_audio_sample_batch_t) = nullptr;
    void (*set_input_poll)(retro_input_poll_t) = nullptr;
    void (*set_input_state)(retro_input_state_t) = nullptr;
    void (*set_controller_port_device)(unsigned, unsigned) = nullptr;
    void (*reset)(void) = nullptr;
    void (*run)(void) = nullptr;
    size_t (*serialize_size)(void) = nullptr;
    bool (*serialize)(void*, size_t) = nullptr;
    bool (*unserialize)(const void*, size_t) = nullptr;
    bool (*load_game)(const struct retro_game_info*) = nullptr;
    void (*unload_game)(void) = nullptr;
    void* (*get_memory_data)(unsigned) = nullptr;
    size_t (*get_memory_size)(unsigned) = nullptr;
};

static Core g_core;
static bool g_coreInitialized = false;
static bool g_gameLoaded = false;
static std::string g_systemDir;
static std::string g_saveDir;
static std::string g_corePath;
static std::vector<uint8_t> g_gameData;  // usado quando need_fullpath == false
static struct retro_system_av_info g_av;
static std::atomic<bool> g_avChanged{false};
static std::atomic<bool> g_shutdownRequested{false};
static std::atomic<bool> g_fastForward{false};
static unsigned g_rotation = 0;

// ---------------------------------------------------------------------------
// Opções de core

struct CoreOption {
    std::vector<std::string> values;
    int defaultIndex = 0;
};
static std::map<std::string, CoreOption> g_optionDefs;
static std::map<std::string, std::string> g_optionValues;
static std::map<std::string, std::string> g_optionOverrides;  // vindas do Kotlin
static std::atomic<bool> g_variablesDirty{true};
static int g_resolutionMultiplier = 1;
static int g_frameskipMode = 0;  // 0 = auto, 1 = desligado

static const char* kResolutionKeys[] = {
    "mupen64plus-43screensize", "mupen64plus-169screensize", "ppsspp_internal_resolution",
    "flycast_internal_resolution", "reicast_internal_resolution", "play_res_multi",
    "melonds_screen_resolution", "yabause_resolution_mode", "pcsx_rearmed_neon_enhancement_enable",
    nullptr};

static bool isResolutionKey(const std::string& key) {
    for (int i = 0; kResolutionKeys[i]; i++) {
        if (key == kResolutionKeys[i]) return true;
    }
    return false;
}

static bool endsWith(const std::string& s, const std::string& suffix) {
    return s.size() >= suffix.size() && s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0;
}

static int indexOfValue(const CoreOption& opt, const char* candidate) {
    for (size_t i = 0; i < opt.values.size(); i++) {
        if (opt.values[i] == candidate) return (int)i;
    }
    return -1;
}

static void resolveOption(const std::string& key) {
    auto defIt = g_optionDefs.find(key);
    if (defIt == g_optionDefs.end()) return;
    const CoreOption& opt = defIt->second;
    if (opt.values.empty()) return;

    auto ov = g_optionOverrides.find(key);
    if (ov != g_optionOverrides.end()) {
        g_optionValues[key] = ov->second;
        return;
    }
    int idx = opt.defaultIndex;
    if (isResolutionKey(key) && key != "pcsx_rearmed_neon_enhancement_enable") {
        idx = opt.defaultIndex + (g_resolutionMultiplier - 1);
        if (idx >= (int)opt.values.size()) idx = (int)opt.values.size() - 1;
        if (idx < 0) idx = 0;
    } else if (key == "pcsx_rearmed_neon_enhancement_enable") {
        int want = indexOfValue(opt, g_resolutionMultiplier > 1 ? "enabled" : "disabled");
        if (want >= 0) idx = want;
    } else if (endsWith(key, "_frameskip") || endsWith(key, "-frameskip")) {
        int want = indexOfValue(opt, g_frameskipMode == 0 ? "auto" : "disabled");
        if (want < 0 && g_frameskipMode == 1) want = indexOfValue(opt, "0");
        if (want >= 0) idx = want;
    }
    g_optionValues[key] = opt.values[idx];
}

static void resolveAllOptions() {
    for (auto& kv : g_optionDefs) resolveOption(kv.first);
    g_variablesDirty = true;
}

static void registerOption(const char* key, const std::vector<std::string>& values, int defaultIndex) {
    if (!key || values.empty()) return;
    CoreOption opt;
    opt.values = values;
    opt.defaultIndex = (defaultIndex >= 0 && defaultIndex < (int)values.size()) ? defaultIndex : 0;
    g_optionDefs[key] = opt;
    resolveOption(key);
}

static void registerOptionsV1(const struct retro_core_option_definition* defs) {
    if (!defs) return;
    for (const struct retro_core_option_definition* d = defs; d->key; d++) {
        std::vector<std::string> vals;
        int def = 0;
        for (int i = 0; i < RETRO_NUM_CORE_OPTION_VALUES_MAX && d->values[i].value; i++) {
            vals.emplace_back(d->values[i].value);
            if (d->default_value && strcmp(d->values[i].value, d->default_value) == 0) def = i;
        }
        registerOption(d->key, vals, def);
    }
    g_variablesDirty = true;
}

static void registerOptionsV2(const struct retro_core_options_v2* opts) {
    if (!opts || !opts->definitions) return;
    for (const struct retro_core_option_v2_definition* d = opts->definitions; d->key; d++) {
        std::vector<std::string> vals;
        int def = 0;
        for (int i = 0; i < RETRO_NUM_CORE_OPTION_VALUES_MAX && d->values[i].value; i++) {
            vals.emplace_back(d->values[i].value);
            if (d->default_value && strcmp(d->values[i].value, d->default_value) == 0) def = i;
        }
        registerOption(d->key, vals, def);
    }
    g_variablesDirty = true;
}

static void registerVariablesLegacy(const struct retro_variable* vars) {
    if (!vars) return;
    for (const struct retro_variable* v = vars; v->key; v++) {
        if (!v->value) continue;
        // Formato: "Descrição; valor1|valor2|valor3" (o primeiro é o padrão)
        const char* semi = strchr(v->value, ';');
        if (!semi) continue;
        const char* p = semi + 1;
        while (*p == ' ') p++;
        std::vector<std::string> vals;
        std::string cur;
        for (; *p; p++) {
            if (*p == '|') {
                vals.push_back(cur);
                cur.clear();
            } else {
                cur.push_back(*p);
            }
        }
        if (!cur.empty()) vals.push_back(cur);
        registerOption(v->key, vals, 0);
    }
    g_variablesDirty = true;
}

// ---------------------------------------------------------------------------
// Vídeo

static bool g_glES3 = true;
static GLuint g_program = 0;
static GLint g_locPos = -1, g_locTex = -1, g_locSampler = -1, g_locSwizzle = -1, g_locScan = -1,
             g_locTexSize = -1;
static GLuint g_vbo = 0;
static GLuint g_swTexture = 0;
static int g_swTexW = 0, g_swTexH = 0;
static int g_frameW = 0, g_frameH = 0;  // tamanho útil do último quadro
static enum retro_pixel_format g_pixelFormat = RETRO_PIXEL_FORMAT_0RGB1555;
static std::vector<uint16_t> g_convertBuffer;
static std::vector<uint8_t> g_rowBuffer;

static bool g_hwRender = false;
static struct retro_hw_render_callback g_hw;
static GLuint g_fbo = 0, g_fboTexture = 0, g_fboDepth = 0;
static int g_fboW = 0, g_fboH = 0;
static bool g_hwContextReady = false;
static bool g_lastFrameIsHw = false;

static int g_surfaceW = 1, g_surfaceH = 1;
static int g_aspectMode = 0;      // 0 original, 1 4:3, 2 16:9, 3 esticar
static bool g_integerScale = false;
static bool g_linearFilter = false;
static bool g_scanlines = false;
static int g_destX = 0, g_destY = 0, g_destW = 0, g_destH = 0;

static const char* kVertexShader =
    "attribute vec2 aPos;\n"
    "attribute vec2 aTex;\n"
    "varying vec2 vTex;\n"
    "void main() {\n"
    "  vTex = aTex;\n"
    "  gl_Position = vec4(aPos, 0.0, 1.0);\n"
    "}\n";

static const char* kFragmentShader =
    "precision mediump float;\n"
    "varying vec2 vTex;\n"
    "uniform sampler2D uTex;\n"
    "uniform float uSwizzle;\n"
    "uniform float uScan;\n"
    "uniform vec2 uTexSize;\n"
    "void main() {\n"
    "  vec4 c = texture2D(uTex, vTex);\n"
    "  vec3 rgb = mix(c.rgb, c.bgr, uSwizzle);\n"
    "  if (uScan > 0.5) {\n"
    "    float line = fract(vTex.y * uTexSize.y);\n"
    "    float shade = 0.72 + 0.28 * sin(line * 3.14159);\n"
    "    rgb *= shade;\n"
    "  }\n"
    "  gl_FragColor = vec4(rgb, 1.0);\n"
    "}\n";

static GLuint compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512];
        glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGE("Shader: %s", log);
    }
    return s;
}

static void createProgram() {
    GLuint vs = compileShader(GL_VERTEX_SHADER, kVertexShader);
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, kFragmentShader);
    g_program = glCreateProgram();
    glAttachShader(g_program, vs);
    glAttachShader(g_program, fs);
    glBindAttribLocation(g_program, 0, "aPos");
    glBindAttribLocation(g_program, 1, "aTex");
    glLinkProgram(g_program);
    glDeleteShader(vs);
    glDeleteShader(fs);
    g_locPos = 0;
    g_locTex = 1;
    g_locSampler = glGetUniformLocation(g_program, "uTex");
    g_locSwizzle = glGetUniformLocation(g_program, "uSwizzle");
    g_locScan = glGetUniformLocation(g_program, "uScan");
    g_locTexSize = glGetUniformLocation(g_program, "uTexSize");
    glGenBuffers(1, &g_vbo);
    glGenTextures(1, &g_swTexture);
    g_swTexW = g_swTexH = 0;
}

static void ensureSoftwareTexture(int w, int h, GLenum internalFormat, GLenum format, GLenum type) {
    glBindTexture(GL_TEXTURE_2D, g_swTexture);
    if (w != g_swTexW || h != g_swTexH) {
        glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, w, h, 0, format, type, nullptr);
        g_swTexW = w;
        g_swTexH = h;
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
}

static GLenum s_lastSwFormat = 0;

static void uploadSoftwareFrame(const void* data, unsigned width, unsigned height, size_t pitch) {
    if (!data || width == 0 || height == 0) return;
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    if (g_glES3) glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);

    if (g_pixelFormat == RETRO_PIXEL_FORMAT_XRGB8888) {
        if (s_lastSwFormat != GL_RGBA) { g_swTexW = g_swTexH = 0; s_lastSwFormat = GL_RGBA; }
        ensureSoftwareTexture(width, height, GL_RGBA, GL_RGBA, GL_UNSIGNED_BYTE);
        if (pitch == width * 4) {
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, data);
        } else if (g_glES3) {
            glPixelStorei(GL_UNPACK_ROW_LENGTH, (GLint)(pitch / 4));
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, data);
            glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
        } else {
            g_rowBuffer.resize((size_t)width * height * 4);
            for (unsigned y = 0; y < height; y++) {
                memcpy(&g_rowBuffer[(size_t)y * width * 4], (const uint8_t*)data + y * pitch, width * 4);
            }
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, g_rowBuffer.data());
        }
    } else {
        // RGB565 direto; 0RGB1555 convertido para 565.
        if (s_lastSwFormat != GL_RGB) { g_swTexW = g_swTexH = 0; s_lastSwFormat = GL_RGB; }
        ensureSoftwareTexture(width, height, GL_RGB, GL_RGB, GL_UNSIGNED_SHORT_5_6_5);
        const uint8_t* src = (const uint8_t*)data;
        if (g_pixelFormat == RETRO_PIXEL_FORMAT_RGB565 && pitch == width * 2) {
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, data);
        } else if (g_pixelFormat == RETRO_PIXEL_FORMAT_RGB565 && g_glES3) {
            glPixelStorei(GL_UNPACK_ROW_LENGTH, (GLint)(pitch / 2));
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, data);
            glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
        } else {
            g_convertBuffer.resize((size_t)width * height);
            for (unsigned y = 0; y < height; y++) {
                const uint16_t* row = (const uint16_t*)(src + y * pitch);
                uint16_t* out = &g_convertBuffer[(size_t)y * width];
                if (g_pixelFormat == RETRO_PIXEL_FORMAT_RGB565) {
                    memcpy(out, row, width * 2);
                } else {
                    for (unsigned x = 0; x < width; x++) {
                        uint16_t p = row[x];
                        uint16_t r = (p >> 10) & 0x1f;
                        uint16_t g = (p >> 5) & 0x1f;
                        uint16_t b = p & 0x1f;
                        uint16_t g6 = (uint16_t)((g << 1) | (g >> 4));
                        out[x] = (uint16_t)((r << 11) | (g6 << 5) | b);
                    }
                }
            }
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGB, GL_UNSIGNED_SHORT_5_6_5,
                            g_convertBuffer.data());
        }
    }
}

static uintptr_t RETRO_CALLCONV hwGetCurrentFramebuffer(void) { return (uintptr_t)g_fbo; }

static retro_proc_address_t RETRO_CALLCONV hwGetProcAddress(const char* sym) {
    static void* gles3 = dlopen("libGLESv3.so", RTLD_NOW | RTLD_LOCAL);
    static void* gles2 = dlopen("libGLESv2.so", RTLD_NOW | RTLD_LOCAL);
    void* p = nullptr;
    if (gles3) p = dlsym(gles3, sym);
    if (!p && gles2) p = dlsym(gles2, sym);
    if (!p) p = (void*)eglGetProcAddress(sym);
    return (retro_proc_address_t)p;
}

static void destroyFbo() {
    if (g_fbo) glDeleteFramebuffers(1, &g_fbo);
    if (g_fboTexture) glDeleteTextures(1, &g_fboTexture);
    if (g_fboDepth) glDeleteRenderbuffers(1, &g_fboDepth);
    g_fbo = g_fboTexture = g_fboDepth = 0;
}

static void createFbo() {
    destroyFbo();
    int w = (int)g_av.geometry.max_width;
    int h = (int)g_av.geometry.max_height;
    if (w <= 0) w = 640;
    if (h <= 0) h = 480;
    // Multiplicador de resolução pode exceder o max informado no load; reserva folga.
    GLint maxTex = 4096;
    glGetIntegerv(GL_MAX_TEXTURE_SIZE, &maxTex);
    if (w > maxTex) w = maxTex;
    if (h > maxTex) h = maxTex;
    g_fboW = w;
    g_fboH = h;

    glGenTextures(1, &g_fboTexture);
    glBindTexture(GL_TEXTURE_2D, g_fboTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    glGenFramebuffers(1, &g_fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, g_fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_fboTexture, 0);

    if (g_hw.depth) {
        glGenRenderbuffers(1, &g_fboDepth);
        glBindRenderbuffer(GL_RENDERBUFFER, g_fboDepth);
        if (g_hw.stencil) {
            glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, w, h);
            glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, g_fboDepth);
        } else {
            glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, w, h);
            glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, g_fboDepth);
        }
    }
    GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    if (status != GL_FRAMEBUFFER_COMPLETE) LOGE("FBO incompleto: 0x%x", status);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

static void computeDestRect() {
    int fw = g_frameW > 0 ? g_frameW : (int)g_av.geometry.base_width;
    int fh = g_frameH > 0 ? g_frameH : (int)g_av.geometry.base_height;
    if (fw <= 0 || fh <= 0) { fw = 4; fh = 3; }
    float aspect;
    switch (g_aspectMode) {
        case 1: aspect = 4.0f / 3.0f; break;
        case 2: aspect = 16.0f / 9.0f; break;
        case 3: aspect = (float)g_surfaceW / (float)g_surfaceH; break;
        default:
            aspect = g_av.geometry.aspect_ratio > 0.0f ? g_av.geometry.aspect_ratio : (float)fw / (float)fh;
            break;
    }
    if (g_rotation == 1 || g_rotation == 3) aspect = 1.0f / aspect;

    int w, h;
    if ((float)g_surfaceW / (float)g_surfaceH > aspect) {
        h = g_surfaceH;
        w = (int)(h * aspect + 0.5f);
    } else {
        w = g_surfaceW;
        h = (int)(w / aspect + 0.5f);
    }
    if (g_integerScale && g_aspectMode != 3) {
        int baseH = (g_rotation == 1 || g_rotation == 3) ? fw : fh;
        int scale = h / (baseH > 0 ? baseH : 1);
        if (scale >= 1) {
            int nh = baseH * scale;
            int nw = (int)(nh * aspect + 0.5f);
            if (nw <= g_surfaceW) { w = nw; h = nh; }
        }
    }
    g_destW = w;
    g_destH = h;
    g_destX = (g_surfaceW - w) / 2;
    g_destY = (g_surfaceH - h) / 2;
}

static void drawFrame() {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (g_glES3) glBindVertexArray(0);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_STENCIL_TEST);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_BLEND);
    glDisable(GL_CULL_FACE);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glViewport(0, 0, g_surfaceW, g_surfaceH);
    glClearColor(0.f, 0.f, 0.f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);

    GLuint tex;
    float texW, texH;
    bool flip;
    float swizzle = 0.f;
    if (g_lastFrameIsHw) {
        tex = g_fboTexture;
        texW = (float)g_fboW;
        texH = (float)g_fboH;
        flip = g_hw.bottom_left_origin;
    } else {
        tex = g_swTexture;
        texW = (float)g_swTexW;
        texH = (float)g_swTexH;
        flip = false;
        swizzle = (g_pixelFormat == RETRO_PIXEL_FORMAT_XRGB8888) ? 1.f : 0.f;
    }
    if (!tex || texW <= 0 || texH <= 0 || g_frameW <= 0 || g_frameH <= 0) return;

    computeDestRect();
    float x0 = (float)g_destX / g_surfaceW * 2.f - 1.f;
    float x1 = (float)(g_destX + g_destW) / g_surfaceW * 2.f - 1.f;
    float y0 = (float)g_destY / g_surfaceH * 2.f - 1.f;
    float y1 = (float)(g_destY + g_destH) / g_surfaceH * 2.f - 1.f;
    float u = (float)g_frameW / texW;
    float v = (float)g_frameH / texH;
    float vt = flip ? v : 0.f;  // coordenada de textura no topo da tela
    float vb = flip ? 0.f : v;  // coordenada de textura na base

    // Cantos na ordem: base-esquerda, base-direita, topo-esquerda, topo-direita
    float corners[4][2] = {{0.f, vb}, {u, vb}, {0.f, vt}, {u, vt}};
    // Rotação do core (0, 90, 180, 270 graus anti-horário)
    for (unsigned r = 0; r < g_rotation; r++) {
        float t[4][2];
        // 90 graus anti-horário: tl<-tr, tr<-br, br<-bl, bl<-tl (0=bl 1=br 2=tl 3=tr)
        memcpy(t, corners, sizeof(t));
        corners[2][0] = t[3][0]; corners[2][1] = t[3][1];
        corners[3][0] = t[1][0]; corners[3][1] = t[1][1];
        corners[1][0] = t[0][0]; corners[1][1] = t[0][1];
        corners[0][0] = t[2][0]; corners[0][1] = t[2][1];
    }
    float verts[16] = {
        x0, y0, corners[0][0], corners[0][1],
        x1, y0, corners[1][0], corners[1][1],
        x0, y1, corners[2][0], corners[2][1],
        x1, y1, corners[3][0], corners[3][1],
    };

    glUseProgram(g_program);
    glBindBuffer(GL_ARRAY_BUFFER, g_vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STREAM_DRAW);
    glEnableVertexAttribArray(g_locPos);
    glVertexAttribPointer(g_locPos, 2, GL_FLOAT, GL_FALSE, 16, (const void*)0);
    glEnableVertexAttribArray(g_locTex);
    glVertexAttribPointer(g_locTex, 2, GL_FLOAT, GL_FALSE, 16, (const void*)8);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex);
    GLint filter = g_linearFilter ? GL_LINEAR : GL_NEAREST;
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
    glUniform1i(g_locSampler, 0);
    glUniform1f(g_locSwizzle, swizzle);
    glUniform1f(g_locScan, g_scanlines ? 1.f : 0.f);
    glUniform2f(g_locTexSize, texW, texH);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

static void RETRO_CALLCONV videoRefresh(const void* data, unsigned width, unsigned height, size_t pitch) {
    if (width == 0 || height == 0) return;
    if (data == RETRO_HW_FRAME_BUFFER_VALID) {
        g_lastFrameIsHw = true;
        g_frameW = (int)width;
        g_frameH = (int)height;
        return;
    }
    if (!data) return;  // quadro duplicado
    g_lastFrameIsHw = false;
    g_frameW = (int)width;
    g_frameH = (int)height;
    uploadSoftwareFrame(data, width, height, pitch);
}

// ---------------------------------------------------------------------------
// Áudio (ring buffer de quadros estéreo int16)

static std::mutex g_audioMutex;
static std::vector<int16_t> g_audioRing;
static size_t g_audioHead = 0, g_audioTail = 0, g_audioCount = 0;  // em amostras
static std::atomic<bool> g_audioMuteRun{false};

static void audioResize(double sampleRate) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    size_t frames = (size_t)(sampleRate > 0 ? sampleRate : 48000) / 2;  // 0,5 s
    g_audioRing.assign(frames * 2, 0);
    g_audioHead = g_audioTail = g_audioCount = 0;
}

static void audioPush(const int16_t* data, size_t frames) {
    if (g_audioMuteRun.load()) return;
    std::lock_guard<std::mutex> lock(g_audioMutex);
    size_t cap = g_audioRing.size();
    if (cap == 0) return;
    size_t samples = frames * 2;
    for (size_t i = 0; i < samples; i++) {
        g_audioRing[g_audioHead] = data[i];
        g_audioHead = (g_audioHead + 1) % cap;
        if (g_audioCount < cap) {
            g_audioCount++;
        } else {
            g_audioTail = (g_audioTail + 1) % cap;  // descarta o mais antigo
        }
    }
}

static void RETRO_CALLCONV audioSample(int16_t left, int16_t right) {
    int16_t f[2] = {left, right};
    audioPush(f, 1);
}

static size_t RETRO_CALLCONV audioSampleBatch(const int16_t* data, size_t frames) {
    audioPush(data, frames);
    return frames;
}

// ---------------------------------------------------------------------------
// Entrada

static std::atomic<uint32_t> g_buttons[4];
static std::atomic<int32_t> g_analog[4][2][2];  // porta, stick (0 esq, 1 dir), eixo (0 x, 1 y)

static void RETRO_CALLCONV inputPoll(void) {}

static int16_t RETRO_CALLCONV inputState(unsigned port, unsigned device, unsigned index, unsigned id) {
    if (port >= 4) return 0;
    unsigned base = device & RETRO_DEVICE_MASK;
    uint32_t mask = g_buttons[port].load();
    if (base == RETRO_DEVICE_JOYPAD) {
        if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return (int16_t)(mask & 0xffff);
        if (id > 15) return 0;
        return (mask >> id) & 1 ? 1 : 0;
    }
    if (base == RETRO_DEVICE_ANALOG) {
        if (index == RETRO_DEVICE_INDEX_ANALOG_BUTTON) {
            if (id > 15) return 0;
            return (mask >> id) & 1 ? 0x7fff : 0;
        }
        if (index > 1 || id > 1) return 0;
        return (int16_t)g_analog[port][index][id].load();
    }
    return 0;
}

// ---------------------------------------------------------------------------
// Log / perf

static std::mutex g_errorMutex;
static std::string g_lastError;

static void setLastError(const std::string& msg) {
    std::lock_guard<std::mutex> lock(g_errorMutex);
    g_lastError = msg;
}

static void RETRO_CALLCONV coreLog(enum retro_log_level level, const char* fmt, ...) {
    if (level >= RETRO_LOG_WARN) {
        char buf[512];
        va_list copy;
        va_start(copy, fmt);
        vsnprintf(buf, sizeof(buf), fmt, copy);
        va_end(copy);
        std::string msg(buf);
        while (!msg.empty() && (msg.back() == '\n' || msg.back() == '\r')) msg.pop_back();
        if (!msg.empty()) setLastError(msg);
    }
    va_list ap;
    va_start(ap, fmt);
    int prio = ANDROID_LOG_INFO;
    if (level == RETRO_LOG_WARN) prio = ANDROID_LOG_WARN;
    else if (level == RETRO_LOG_ERROR) prio = ANDROID_LOG_ERROR;
    else if (level == RETRO_LOG_DEBUG) prio = ANDROID_LOG_DEBUG;
    __android_log_vprint(prio, "CartuchoCore", fmt, ap);
    va_end(ap);
}

static retro_time_t RETRO_CALLCONV perfGetTimeUsec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (retro_time_t)ts.tv_sec * 1000000 + ts.tv_nsec / 1000;
}
static uint64_t RETRO_CALLCONV perfGetCpuFeatures(void) {
#if defined(__aarch64__)
    return RETRO_SIMD_NEON;
#elif defined(__arm__)
    return RETRO_SIMD_NEON;
#else
    return RETRO_SIMD_SSE | RETRO_SIMD_SSE2;
#endif
}
static retro_perf_tick_t RETRO_CALLCONV perfGetCounter(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (retro_perf_tick_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}
static void RETRO_CALLCONV perfRegister(struct retro_perf_counter* counter) { if (counter) counter->registered = true; }
static void RETRO_CALLCONV perfStart(struct retro_perf_counter* counter) {
    if (counter) counter->start = perfGetCounter();
}
static void RETRO_CALLCONV perfStop(struct retro_perf_counter* counter) {
    if (counter) { counter->total += perfGetCounter() - counter->start; counter->call_cnt++; }
}
static void RETRO_CALLCONV perfLog(void) {}

// ---------------------------------------------------------------------------
// Memória (para RetroAchievements)

static std::vector<struct retro_memory_descriptor> g_memDescriptors;

int cartucho_get_memory_descriptors(const struct retro_memory_descriptor** out) {
    *out = g_memDescriptors.empty() ? nullptr : g_memDescriptors.data();
    return (int)g_memDescriptors.size();
}

void* cartucho_get_memory_data(unsigned id, size_t* size) {
    if (!g_gameLoaded || !g_core.get_memory_data || !g_core.get_memory_size) {
        *size = 0;
        return nullptr;
    }
    *size = g_core.get_memory_size(id);
    return g_core.get_memory_data(id);
}

// ---------------------------------------------------------------------------
// Environment

static bool RETRO_CALLCONV environment(unsigned cmd, void* data) {
    switch (cmd) {
        case RETRO_ENVIRONMENT_GET_CAN_DUPE:
            if (data) *(bool*)data = true;
            return true;
        case RETRO_ENVIRONMENT_SET_ROTATION:
            if (data) g_rotation = (*(const unsigned*)data) % 4;
            return true;
        case RETRO_ENVIRONMENT_GET_OVERSCAN:
            if (data) *(bool*)data = false;
            return true;
        case RETRO_ENVIRONMENT_SET_MESSAGE: {
            const struct retro_message* msg = (const struct retro_message*)data;
            if (msg && msg->msg) LOGI("Core: %s", msg->msg);
            return true;
        }
        case RETRO_ENVIRONMENT_SHUTDOWN:
            g_shutdownRequested = true;
            return true;
        case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
            return true;
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
            if (data) *(const char**)data = g_systemDir.c_str();
            return true;
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
            if (data) *(const char**)data = g_saveDir.c_str();
            return true;
        case RETRO_ENVIRONMENT_GET_CORE_ASSETS_DIRECTORY:
            if (data) *(const char**)data = g_systemDir.c_str();
            return true;
        case RETRO_ENVIRONMENT_GET_LIBRETRO_PATH:
            if (data) *(const char**)data = g_corePath.c_str();
            return true;
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
            if (!data) return false;
            enum retro_pixel_format fmt = *(const enum retro_pixel_format*)data;
            if (fmt == RETRO_PIXEL_FORMAT_0RGB1555 || fmt == RETRO_PIXEL_FORMAT_XRGB8888 ||
                fmt == RETRO_PIXEL_FORMAT_RGB565) {
                g_pixelFormat = fmt;
                return true;
            }
            return false;
        }
        case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
        case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
        case RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO:
        case RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS:
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY:
        case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
            return true;
        case RETRO_ENVIRONMENT_SET_HW_RENDER: {
            if (!data) return false;
            struct retro_hw_render_callback* cb = (struct retro_hw_render_callback*)data;
            bool accepted = cb->context_type == RETRO_HW_CONTEXT_OPENGLES2 ||
                            cb->context_type == RETRO_HW_CONTEXT_OPENGLES3 ||
                            cb->context_type == RETRO_HW_CONTEXT_OPENGLES_VERSION;
            if (!accepted || !g_glES3) {
                LOGW("Contexto HW recusado: %d", (int)cb->context_type);
                return false;
            }
            cb->get_current_framebuffer = hwGetCurrentFramebuffer;
            cb->get_proc_address = hwGetProcAddress;
            g_hw = *cb;
            g_hwRender = true;
            return true;
        }
        case RETRO_ENVIRONMENT_GET_PREFERRED_HW_RENDER:
            if (data) *(unsigned*)data = RETRO_HW_CONTEXT_OPENGLES3;
            return true;
        case RETRO_ENVIRONMENT_GET_VARIABLE: {
            struct retro_variable* var = (struct retro_variable*)data;
            if (!var || !var->key) return false;
            auto it = g_optionValues.find(var->key);
            if (it == g_optionValues.end()) {
                auto ov = g_optionOverrides.find(var->key);
                if (ov == g_optionOverrides.end()) { var->value = nullptr; return false; }
                var->value = ov->second.c_str();
                return true;
            }
            var->value = it->second.c_str();
            return true;
        }
        case RETRO_ENVIRONMENT_SET_VARIABLES:
            registerVariablesLegacy((const struct retro_variable*)data);
            return true;
        case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
            if (data) *(bool*)data = g_variablesDirty.exchange(false);
            return true;
        case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
            if (data) *(unsigned*)data = 2;
            return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS:
            registerOptionsV1((const struct retro_core_option_definition*)data);
            return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL: {
            const struct retro_core_options_intl* intl = (const struct retro_core_options_intl*)data;
            if (intl) registerOptionsV1(intl->us);
            return true;
        }
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2:
            registerOptionsV2((const struct retro_core_options_v2*)data);
            return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL: {
            const struct retro_core_options_v2_intl* intl = (const struct retro_core_options_v2_intl*)data;
            if (intl) registerOptionsV2(intl->us);
            return true;
        }
        case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: {
            struct retro_log_callback* cb = (struct retro_log_callback*)data;
            if (cb) cb->log = coreLog;
            return true;
        }
        case RETRO_ENVIRONMENT_GET_PERF_INTERFACE: {
            struct retro_perf_callback* cb = (struct retro_perf_callback*)data;
            if (!cb) return false;
            cb->get_time_usec = perfGetTimeUsec;
            cb->get_cpu_features = perfGetCpuFeatures;
            cb->get_perf_counter = perfGetCounter;
            cb->perf_register = perfRegister;
            cb->perf_start = perfStart;
            cb->perf_stop = perfStop;
            cb->perf_log = perfLog;
            return true;
        }
        case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: {
            const struct retro_system_av_info* info = (const struct retro_system_av_info*)data;
            if (!info) return false;
            g_av = *info;
            g_avChanged = true;
            if (g_hwRender && g_hwContextReady &&
                ((int)g_av.geometry.max_width > g_fboW || (int)g_av.geometry.max_height > g_fboH)) {
                createFbo();
            }
            return true;
        }
        case RETRO_ENVIRONMENT_SET_GEOMETRY: {
            const struct retro_game_geometry* geo = (const struct retro_game_geometry*)data;
            if (!geo) return false;
            g_av.geometry.base_width = geo->base_width;
            g_av.geometry.base_height = geo->base_height;
            g_av.geometry.aspect_ratio = geo->aspect_ratio;
            return true;
        }
        case RETRO_ENVIRONMENT_SET_MEMORY_MAPS: {
            const struct retro_memory_map* map = (const struct retro_memory_map*)data;
            g_memDescriptors.clear();
            if (map && map->descriptors) {
                for (unsigned i = 0; i < map->num_descriptors; i++) g_memDescriptors.push_back(map->descriptors[i]);
            }
            return true;
        }
        case RETRO_ENVIRONMENT_GET_USERNAME:
            if (data) *(const char**)data = "Cartucho";
            return true;
        case RETRO_ENVIRONMENT_GET_LANGUAGE:
            if (data) *(unsigned*)data = RETRO_LANGUAGE_PORTUGUESE_BRAZIL;
            return true;
        case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS:
            return true;
        case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE:
            if (data) *(int*)data = 3;
            return true;
        case RETRO_ENVIRONMENT_GET_FASTFORWARDING:
            if (data) *(bool*)data = g_fastForward.load();
            return true;
        case RETRO_ENVIRONMENT_GET_TARGET_REFRESH_RATE:
            if (data) *(float*)data = 60.0f;
            return true;
        case RETRO_ENVIRONMENT_GET_INPUT_MAX_USERS:
            if (data) *(unsigned*)data = 4;
            return true;
        case RETRO_ENVIRONMENT_GET_MESSAGE_INTERFACE_VERSION:
            if (data) *(unsigned*)data = 0;
            return true;
        default:
            return false;
    }
}

// ---------------------------------------------------------------------------
// Carregamento

template <typename T>
static bool loadSym(T& target, const char* name) {
    target = (T)dlsym(g_core.handle, name);
    if (!target) LOGE("Símbolo ausente: %s", name);
    return target != nullptr;
}

static bool loadCoreLibrary(const char* path) {
    g_core = Core();
    g_core.handle = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (!g_core.handle) {
        LOGE("dlopen falhou: %s", dlerror());
        return false;
    }
    bool ok = true;
    ok &= loadSym(g_core.init, "retro_init");
    ok &= loadSym(g_core.deinit, "retro_deinit");
    ok &= loadSym(g_core.get_system_info, "retro_get_system_info");
    ok &= loadSym(g_core.get_system_av_info, "retro_get_system_av_info");
    ok &= loadSym(g_core.set_environment, "retro_set_environment");
    ok &= loadSym(g_core.set_video_refresh, "retro_set_video_refresh");
    ok &= loadSym(g_core.set_audio_sample, "retro_set_audio_sample");
    ok &= loadSym(g_core.set_audio_sample_batch, "retro_set_audio_sample_batch");
    ok &= loadSym(g_core.set_input_poll, "retro_set_input_poll");
    ok &= loadSym(g_core.set_input_state, "retro_set_input_state");
    ok &= loadSym(g_core.set_controller_port_device, "retro_set_controller_port_device");
    ok &= loadSym(g_core.reset, "retro_reset");
    ok &= loadSym(g_core.run, "retro_run");
    ok &= loadSym(g_core.serialize_size, "retro_serialize_size");
    ok &= loadSym(g_core.serialize, "retro_serialize");
    ok &= loadSym(g_core.unserialize, "retro_unserialize");
    ok &= loadSym(g_core.load_game, "retro_load_game");
    ok &= loadSym(g_core.unload_game, "retro_unload_game");
    ok &= loadSym(g_core.get_memory_data, "retro_get_memory_data");
    ok &= loadSym(g_core.get_memory_size, "retro_get_memory_size");
    return ok;
}

static bool readWholeFile(const char* path, std::vector<uint8_t>& out) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (size < 0) { fclose(f); return false; }
    out.resize((size_t)size);
    size_t read = size > 0 ? fread(out.data(), 1, (size_t)size, f) : 0;
    fclose(f);
    return read == (size_t)size;
}

static bool writeWholeFile(const char* path, const void* data, size_t size) {
    std::string tmp = std::string(path) + ".tmp";
    FILE* f = fopen(tmp.c_str(), "wb");
    if (!f) return false;
    size_t written = fwrite(data, 1, size, f);
    fflush(f);
    fclose(f);
    if (written != size) { remove(tmp.c_str()); return false; }
    return rename(tmp.c_str(), path) == 0;
}

// ---------------------------------------------------------------------------
// JNI

static std::string jstr(JNIEnv* env, jstring s) {
    if (!s) return std::string();
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

#define JNI_FN(name) Java_app_cartucho_emu_NativeBridge_##name

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;
    ra_jni_init(vm, env);
    for (int p = 0; p < 4; p++) {
        g_buttons[p] = 0;
        for (int s = 0; s < 2; s++)
            for (int a = 0; a < 2; a++) g_analog[p][s][a] = 0;
    }
    return JNI_VERSION_1_6;
}

JNIEXPORT jstring JNICALL JNI_FN(getLastError)(JNIEnv* env, jclass) {
    std::lock_guard<std::mutex> lock(g_errorMutex);
    // Mantém só ASCII imprimível para NewStringUTF ser sempre seguro.
    std::string clean;
    for (char ch : g_lastError) clean.push_back((ch >= 0x20 && ch < 0x7f) ? ch : '?');
    return env->NewStringUTF(clean.c_str());
}

JNIEXPORT void JNICALL JNI_FN(setGlesVersion)(JNIEnv*, jclass, jint major) { g_glES3 = major >= 3; }

JNIEXPORT jboolean JNICALL JNI_FN(loadCore)(JNIEnv* env, jclass, jstring corePath, jstring systemDir,
                                             jstring saveDir) {
    g_corePath = jstr(env, corePath);
    g_systemDir = jstr(env, systemDir);
    g_saveDir = jstr(env, saveDir);
    if (!loadCoreLibrary(g_corePath.c_str())) return JNI_FALSE;
    g_core.set_environment(environment);
    g_core.set_video_refresh(videoRefresh);
    g_core.set_audio_sample(audioSample);
    g_core.set_audio_sample_batch(audioSampleBatch);
    g_core.set_input_poll(inputPoll);
    g_core.set_input_state(inputState);
    g_core.init();
    g_coreInitialized = true;
    return JNI_TRUE;
}

JNIEXPORT void JNICALL JNI_FN(setOption)(JNIEnv* env, jclass, jstring key, jstring value) {
    std::string k = jstr(env, key);
    std::string v = jstr(env, value);
    if (v.empty()) g_optionOverrides.erase(k);
    else g_optionOverrides[k] = v;
    resolveOption(k);
    g_variablesDirty = true;
}

JNIEXPORT void JNICALL JNI_FN(setPerformance)(JNIEnv*, jclass, jint resolutionMultiplier, jint frameskipMode) {
    g_resolutionMultiplier = resolutionMultiplier < 1 ? 1 : resolutionMultiplier;
    g_frameskipMode = frameskipMode;
    resolveAllOptions();
}

JNIEXPORT jboolean JNICALL JNI_FN(loadGame)(JNIEnv* env, jclass, jstring gamePath) {
    if (!g_coreInitialized) return JNI_FALSE;
    std::string path = jstr(env, gamePath);
    struct retro_system_info sys;
    memset(&sys, 0, sizeof(sys));
    g_core.get_system_info(&sys);

    struct retro_game_info info;
    memset(&info, 0, sizeof(info));
    info.path = path.c_str();
    if (!sys.need_fullpath) {
        if (!readWholeFile(path.c_str(), g_gameData)) {
            setLastError(std::string("Falha ao ler o arquivo: ") + strerror(errno));
            LOGE("Não foi possível ler o jogo");
            return JNI_FALSE;
        }
        info.data = g_gameData.data();
        info.size = g_gameData.size();
    }
    if (!g_core.load_game(&info)) {
        {
            std::lock_guard<std::mutex> lock(g_errorMutex);
            if (g_lastError.empty()) g_lastError = "O emulador recusou o arquivo (retro_load_game).";
        }
        LOGE("retro_load_game falhou");
        return JNI_FALSE;
    }
    g_gameLoaded = true;
    memset(&g_av, 0, sizeof(g_av));
    g_core.get_system_av_info(&g_av);
    audioResize(g_av.timing.sample_rate);
    for (unsigned p = 0; p < 4; p++) g_core.set_controller_port_device(p, RETRO_DEVICE_JOYPAD);
    if (g_hwRender) {
        createFbo();
        g_hwContextReady = true;
        if (g_hw.context_reset) g_hw.context_reset();
    }
    return JNI_TRUE;
}

// Chamado em onSurfaceCreated (inclusive após perda de contexto).
JNIEXPORT void JNICALL JNI_FN(onSurfaceCreated)(JNIEnv*, jclass) {
    createProgram();
    if (g_gameLoaded && g_hwRender) {
        createFbo();
        g_hwContextReady = true;
        if (g_hw.context_reset) g_hw.context_reset();
    }
}

JNIEXPORT void JNICALL JNI_FN(onSurfaceChanged)(JNIEnv*, jclass, jint w, jint h) {
    g_surfaceW = w > 0 ? w : 1;
    g_surfaceH = h > 0 ? h : 1;
}

JNIEXPORT void JNICALL JNI_FN(setVideoOptions)(JNIEnv*, jclass, jint aspectMode, jboolean integerScale,
                                               jboolean linear, jboolean scanlines) {
    g_aspectMode = aspectMode;
    g_integerScale = integerScale;
    g_linearFilter = linear;
    g_scanlines = scanlines;
}

JNIEXPORT void JNICALL JNI_FN(runFrame)(JNIEnv*, jclass, jboolean muteAudio) {
    if (!g_gameLoaded) return;
    g_audioMuteRun = muteAudio;
    if (g_hwRender) glBindFramebuffer(GL_FRAMEBUFFER, g_fbo);
    g_core.run();
    g_audioMuteRun = false;
    ra_do_frame();
    if (ra_consume_reset_request()) g_core.reset();
}

JNIEXPORT void JNICALL JNI_FN(render)(JNIEnv*, jclass) { drawFrame(); }

JNIEXPORT void JNICALL JNI_FN(setFastForward)(JNIEnv*, jclass, jboolean ff) { g_fastForward = ff; }

JNIEXPORT jdoubleArray JNICALL JNI_FN(getAvInfo)(JNIEnv* env, jclass) {
    jdouble vals[6] = {g_av.timing.fps, g_av.timing.sample_rate, (double)g_av.geometry.base_width,
                       (double)g_av.geometry.base_height, (double)g_av.geometry.aspect_ratio,
                       g_avChanged.exchange(false) ? 1.0 : 0.0};
    jdoubleArray arr = env->NewDoubleArray(6);
    env->SetDoubleArrayRegion(arr, 0, 6, vals);
    return arr;
}

JNIEXPORT jboolean JNICALL JNI_FN(consumeShutdownRequest)(JNIEnv*, jclass) {
    return g_shutdownRequested.exchange(false) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL JNI_FN(setButtons)(JNIEnv*, jclass, jint port, jint mask) {
    if (port >= 0 && port < 4) g_buttons[port] = (uint32_t)mask;
}

JNIEXPORT void JNICALL JNI_FN(setAnalog)(JNIEnv*, jclass, jint port, jint stick, jint x, jint y) {
    if (port < 0 || port >= 4 || stick < 0 || stick > 1) return;
    g_analog[port][stick][0] = x;
    g_analog[port][stick][1] = y;
}

JNIEXPORT jint JNICALL JNI_FN(readAudio)(JNIEnv* env, jclass, jshortArray out) {
    jsize len = env->GetArrayLength(out);
    std::vector<int16_t> tmp;
    {
        std::lock_guard<std::mutex> lock(g_audioMutex);
        size_t cap = g_audioRing.size();
        size_t n = g_audioCount < (size_t)len ? g_audioCount : (size_t)len;
        n -= n % 2;
        tmp.resize(n);
        for (size_t i = 0; i < n; i++) {
            tmp[i] = g_audioRing[g_audioTail];
            g_audioTail = (g_audioTail + 1) % cap;
        }
        g_audioCount -= n;
    }
    if (!tmp.empty()) env->SetShortArrayRegion(out, 0, (jsize)tmp.size(), tmp.data());
    return (jint)tmp.size();
}

JNIEXPORT jint JNICALL JNI_FN(audioBufferedFrames)(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(g_audioMutex);
    return (jint)(g_audioCount / 2);
}

JNIEXPORT jboolean JNICALL JNI_FN(saveState)(JNIEnv* env, jclass, jstring path) {
    if (!g_gameLoaded) return JNI_FALSE;
    size_t size = g_core.serialize_size();
    if (size == 0) return JNI_FALSE;
    std::vector<uint8_t> buf(size);
    if (!g_core.serialize(buf.data(), size)) return JNI_FALSE;
    std::string p = jstr(env, path);
    return writeWholeFile(p.c_str(), buf.data(), size) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL JNI_FN(loadState)(JNIEnv* env, jclass, jstring path) {
    if (!g_gameLoaded) return JNI_FALSE;
    std::string p = jstr(env, path);
    std::vector<uint8_t> buf;
    if (!readWholeFile(p.c_str(), buf) || buf.empty()) return JNI_FALSE;
    bool ok = g_core.unserialize(buf.data(), buf.size());
    if (ok) ra_on_state_loaded();
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL JNI_FN(saveSram)(JNIEnv* env, jclass, jstring path) {
    if (!g_gameLoaded) return JNI_FALSE;
    size_t size = g_core.get_memory_size(RETRO_MEMORY_SAVE_RAM);
    void* data = g_core.get_memory_data(RETRO_MEMORY_SAVE_RAM);
    if (!data || size == 0) return JNI_FALSE;
    std::string p = jstr(env, path);
    // Evita reescrever arquivo idêntico (preserva a data de modificação para a sincronização).
    std::vector<uint8_t> existing;
    if (readWholeFile(p.c_str(), existing) && existing.size() == size && memcmp(existing.data(), data, size) == 0) {
        return JNI_TRUE;
    }
    return writeWholeFile(p.c_str(), data, size) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL JNI_FN(loadSram)(JNIEnv* env, jclass, jstring path) {
    if (!g_gameLoaded) return JNI_FALSE;
    size_t size = g_core.get_memory_size(RETRO_MEMORY_SAVE_RAM);
    void* data = g_core.get_memory_data(RETRO_MEMORY_SAVE_RAM);
    if (!data || size == 0) return JNI_FALSE;
    std::string p = jstr(env, path);
    std::vector<uint8_t> buf;
    if (!readWholeFile(p.c_str(), buf)) return JNI_FALSE;
    memcpy(data, buf.data(), buf.size() < size ? buf.size() : size);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL JNI_FN(reset)(JNIEnv*, jclass) {
    if (!g_gameLoaded) return;
    g_core.reset();
    ra_on_reset();
}

// Captura a área do jogo já desenhada (RGBA, de cima para baixo). Retorna [w, h] + pixels.
JNIEXPORT jintArray JNICALL JNI_FN(captureFrame)(JNIEnv* env, jclass, jint maxWidth) {
    if (g_destW <= 0 || g_destH <= 0) return nullptr;
    std::vector<uint8_t> px((size_t)g_destW * g_destH * 4);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(g_destX, g_destY, g_destW, g_destH, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    int step = 1;
    while (g_destW / step > maxWidth) step++;
    int ow = g_destW / step, oh = g_destH / step;
    std::vector<jint> out((size_t)ow * oh + 2);
    out[0] = ow;
    out[1] = oh;
    for (int y = 0; y < oh; y++) {
        int sy = g_destH - 1 - y * step;  // inverte verticalmente
        for (int x = 0; x < ow; x++) {
            const uint8_t* p = &px[((size_t)sy * g_destW + (size_t)x * step) * 4];
            out[2 + (size_t)y * ow + x] = (jint)(0xFF000000u | ((uint32_t)p[0] << 16) | ((uint32_t)p[1] << 8) | p[2]);
        }
    }
    jintArray arr = env->NewIntArray((jsize)out.size());
    env->SetIntArrayRegion(arr, 0, (jsize)out.size(), out.data());
    return arr;
}

JNIEXPORT void JNICALL JNI_FN(unloadGame)(JNIEnv*, jclass) {
    ra_unload_game();
    if (g_gameLoaded) {
        if (g_hwRender && g_hw.context_destroy) g_hw.context_destroy();
        g_core.unload_game();
        g_gameLoaded = false;
    }
    if (g_coreInitialized) {
        g_core.deinit();
        g_coreInitialized = false;
    }
    destroyFbo();
    // O processo do jogo é encerrado logo depois; não chamamos dlclose de propósito.
}

}  // extern "C"
