// Cartucho — ponte Vulkan (veja vk_bridge.h). Carrega o Vulkan do sistema em tempo de execução,
// então o app continua abrindo em aparelhos sem Vulkan: só os cores que exigem Vulkan deixam de rodar.
#define VK_NO_PROTOTYPES
#include "vk_bridge.h"

#include <vulkan/vulkan.h>

#include "libretro.h"
#include "libretro_vulkan.h"

#include <cstring>
#include <mutex>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace vkb {
namespace {

const retro_hw_render_context_negotiation_interface_vulkan* negotiation = nullptr;
retro_hw_render_interface_vulkan iface{};
bool isReady = false;
bool coreMadeDevice = false;
void* library = nullptr;

PFN_vkGetInstanceProcAddr gipa = nullptr;
PFN_vkGetDeviceProcAddr gdpa = nullptr;
VkInstance instance = VK_NULL_HANDLE;
VkPhysicalDevice gpu = VK_NULL_HANDLE;
VkDevice device = VK_NULL_HANDLE;
VkQueue queue = VK_NULL_HANDLE;
uint32_t queueFamily = 0;

VkCommandPool pool = VK_NULL_HANDLE;
VkCommandBuffer cmd = VK_NULL_HANDLE;
VkFence fence = VK_NULL_HANDLE;
VkBuffer buffer = VK_NULL_HANDLE;
VkDeviceMemory memory = VK_NULL_HANDLE;
VkDeviceSize bufferSize = 0;
void* mapped = nullptr;

// Estado entregue pelo core no quadro atual.
retro_vulkan_image currentImage{};
bool hasImage = false;
std::vector<VkSemaphore> waitSemaphores;
std::vector<VkCommandBuffer> coreCommands;
VkSemaphore signalSemaphore = VK_NULL_HANDLE;
std::mutex queueLock;

#define VKB_FN(name) PFN_##name name = nullptr
VKB_FN(vkCreateInstance);
VKB_FN(vkDestroyInstance);
VKB_FN(vkEnumeratePhysicalDevices);
VKB_FN(vkGetPhysicalDeviceProperties);
VKB_FN(vkGetPhysicalDeviceFeatures);
VKB_FN(vkGetPhysicalDeviceQueueFamilyProperties);
VKB_FN(vkGetPhysicalDeviceMemoryProperties);
VKB_FN(vkEnumerateDeviceExtensionProperties);
VKB_FN(vkCreateDevice);
VKB_FN(vkDestroyDevice);
VKB_FN(vkGetDeviceQueue);
VKB_FN(vkCreateCommandPool);
VKB_FN(vkDestroyCommandPool);
VKB_FN(vkAllocateCommandBuffers);
VKB_FN(vkResetCommandBuffer);
VKB_FN(vkBeginCommandBuffer);
VKB_FN(vkEndCommandBuffer);
VKB_FN(vkCmdPipelineBarrier);
VKB_FN(vkCmdCopyImageToBuffer);
VKB_FN(vkQueueSubmit);
VKB_FN(vkCreateFence);
VKB_FN(vkDestroyFence);
VKB_FN(vkWaitForFences);
VKB_FN(vkResetFences);
VKB_FN(vkCreateBuffer);
VKB_FN(vkDestroyBuffer);
VKB_FN(vkGetBufferMemoryRequirements);
VKB_FN(vkAllocateMemory);
VKB_FN(vkFreeMemory);
VKB_FN(vkBindBufferMemory);
VKB_FN(vkMapMemory);
VKB_FN(vkUnmapMemory);
VKB_FN(vkInvalidateMappedMemoryRanges);
VKB_FN(vkDeviceWaitIdle);
#undef VKB_FN

bool loadLibrary() {
    if (gipa) return true;
#ifdef _WIN32
    HMODULE lib = LoadLibraryA("vulkan-1.dll");
    if (!lib) return false;
    library = lib;
    gipa = (PFN_vkGetInstanceProcAddr)(void*)GetProcAddress(lib, "vkGetInstanceProcAddr");
#else
    void* lib = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
    if (!lib) lib = dlopen("libvulkan.so.1", RTLD_NOW | RTLD_LOCAL);
    if (!lib) return false;
    library = lib;
    gipa = (PFN_vkGetInstanceProcAddr)dlsym(lib, "vkGetInstanceProcAddr");
#endif
    if (!gipa) return false;
    vkCreateInstance = (PFN_vkCreateInstance)gipa(VK_NULL_HANDLE, "vkCreateInstance");
    return vkCreateInstance != nullptr;
}

void loadInstanceFunctions() {
#define I(name) name = (PFN_##name)gipa(instance, #name)
    I(vkDestroyInstance);
    I(vkEnumeratePhysicalDevices);
    I(vkGetPhysicalDeviceProperties);
    I(vkGetPhysicalDeviceFeatures);
    I(vkGetPhysicalDeviceQueueFamilyProperties);
    I(vkGetPhysicalDeviceMemoryProperties);
    I(vkEnumerateDeviceExtensionProperties);
    I(vkCreateDevice);
#undef I
    gdpa = (PFN_vkGetDeviceProcAddr)gipa(instance, "vkGetDeviceProcAddr");
}

void loadDeviceFunctions() {
#define D(name) name = (PFN_##name)gdpa(device, #name)
    D(vkDestroyDevice);
    D(vkGetDeviceQueue);
    D(vkCreateCommandPool);
    D(vkDestroyCommandPool);
    D(vkAllocateCommandBuffers);
    D(vkResetCommandBuffer);
    D(vkBeginCommandBuffer);
    D(vkEndCommandBuffer);
    D(vkCmdPipelineBarrier);
    D(vkCmdCopyImageToBuffer);
    D(vkQueueSubmit);
    D(vkCreateFence);
    D(vkDestroyFence);
    D(vkWaitForFences);
    D(vkResetFences);
    D(vkCreateBuffer);
    D(vkDestroyBuffer);
    D(vkGetBufferMemoryRequirements);
    D(vkAllocateMemory);
    D(vkFreeMemory);
    D(vkBindBufferMemory);
    D(vkMapMemory);
    D(vkUnmapMemory);
    D(vkInvalidateMappedMemoryRanges);
    D(vkDeviceWaitIdle);
#undef D
}

// ---------------------------------------------------------------- callbacks da interface libretro

void RETRO_CALLCONV setImage(void*, const retro_vulkan_image* image, uint32_t numSemaphores, const VkSemaphore* semaphores, uint32_t) {
    if (image) {
        currentImage = *image;
        currentImage.create_info.pNext = nullptr;
        hasImage = true;
    }
    waitSemaphores.assign(semaphores, semaphores + numSemaphores);
}
uint32_t RETRO_CALLCONV getSyncIndex(void*) { return 0; }
uint32_t RETRO_CALLCONV getSyncIndexMask(void*) { return 1; }
void RETRO_CALLCONV setCommandBuffers(void*, uint32_t n, const VkCommandBuffer* buffers) {
    coreCommands.insert(coreCommands.end(), buffers, buffers + n);
}
void RETRO_CALLCONV waitSyncIndex(void*) {
    // Cada quadro já espera a cópia terminar (readFrame), então não há trabalho pendente aqui.
}
void RETRO_CALLCONV lockQueue(void*) { queueLock.lock(); }
void RETRO_CALLCONV unlockQueue(void*) { queueLock.unlock(); }
void RETRO_CALLCONV setSignalSemaphore(void*, VkSemaphore s) { signalSemaphore = s; }

// Criação de instância/dispositivo pedida pelo próprio core (negociação v2).
VkInstance RETRO_CALLCONV createInstanceWrapper(void*, const VkInstanceCreateInfo* info) {
    VkInstance out = VK_NULL_HANDLE;
    if (vkCreateInstance(info, nullptr, &out) != VK_SUCCESS) return VK_NULL_HANDLE;
    return out;
}
VkDevice RETRO_CALLCONV createDeviceWrapper(VkPhysicalDevice physical, void*, const VkDeviceCreateInfo* info) {
    VkDevice out = VK_NULL_HANDLE;
    if (vkCreateDevice(physical, info, nullptr, &out) != VK_SUCCESS) return VK_NULL_HANDLE;
    return out;
}

VkPhysicalDevice pickGpu() {
    uint32_t n = 0;
    vkEnumeratePhysicalDevices(instance, &n, nullptr);
    if (!n) return VK_NULL_HANDLE;
    std::vector<VkPhysicalDevice> list(n);
    vkEnumeratePhysicalDevices(instance, &n, list.data());
    // Prefere a placa dedicada (notebooks gamer têm a integrada e a dedicada).
    for (auto d : list) {
        VkPhysicalDeviceProperties p;
        vkGetPhysicalDeviceProperties(d, &p);
        if (p.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) return d;
    }
    return list[0];
}

bool graphicsQueueFamily(VkPhysicalDevice d, uint32_t& family) {
    uint32_t n = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(d, &n, nullptr);
    std::vector<VkQueueFamilyProperties> props(n);
    vkGetPhysicalDeviceQueueFamilyProperties(d, &n, props.data());
    for (uint32_t i = 0; i < n; i++) {
        if ((props[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && (props[i].queueFlags & VK_QUEUE_COMPUTE_BIT)) {
            family = i;
            return true;
        }
    }
    return false;
}

bool createOwnDevice() {
    if (!graphicsQueueFamily(gpu, queueFamily)) return false;
    float priority = 1.0f;
    VkDeviceQueueCreateInfo q{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    q.queueFamilyIndex = queueFamily;
    q.queueCount = 1;
    q.pQueuePriorities = &priority;
    VkPhysicalDeviceFeatures features;
    vkGetPhysicalDeviceFeatures(gpu, &features);
    VkDeviceCreateInfo info{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    info.queueCreateInfoCount = 1;
    info.pQueueCreateInfos = &q;
    info.pEnabledFeatures = &features;
    return vkCreateDevice(gpu, &info, nullptr, &device) == VK_SUCCESS;
}

uint32_t hostVisibleMemoryType(uint32_t bits) {
    VkPhysicalDeviceMemoryProperties mp;
    vkGetPhysicalDeviceMemoryProperties(gpu, &mp);
    // Preferência: visível + coerente + em cache (leitura rápida pela CPU).
    const VkMemoryPropertyFlags wanted[] = {
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT | VK_MEMORY_PROPERTY_HOST_CACHED_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_CACHED_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
    };
    for (auto flags : wanted)
        for (uint32_t i = 0; i < mp.memoryTypeCount; i++)
            if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & flags) == flags) return i;
    return UINT32_MAX;
}

bool ensureBuffer(VkDeviceSize size) {
    if (buffer && bufferSize >= size) return true;
    if (mapped) { vkUnmapMemory(device, memory); mapped = nullptr; }
    if (buffer) { vkDestroyBuffer(device, buffer, nullptr); buffer = VK_NULL_HANDLE; }
    if (memory) { vkFreeMemory(device, memory, nullptr); memory = VK_NULL_HANDLE; }
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = size;
    bi.usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    if (vkCreateBuffer(device, &bi, nullptr, &buffer) != VK_SUCCESS) return false;
    VkMemoryRequirements req;
    vkGetBufferMemoryRequirements(device, buffer, &req);
    uint32_t type = hostVisibleMemoryType(req.memoryTypeBits);
    if (type == UINT32_MAX) return false;
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = req.size;
    ai.memoryTypeIndex = type;
    if (vkAllocateMemory(device, &ai, nullptr, &memory) != VK_SUCCESS) return false;
    vkBindBufferMemory(device, buffer, memory, 0);
    if (vkMapMemory(device, memory, 0, VK_WHOLE_SIZE, 0, &mapped) != VK_SUCCESS) return false;
    bufferSize = size;
    return true;
}

}  // namespace

void setNegotiation(const void* p) {
    negotiation = (const retro_hw_render_context_negotiation_interface_vulkan*)p;
}

bool ready() { return isReady; }

const void* renderInterface() { return isReady ? &iface : nullptr; }

bool init(std::string& error) {
    if (isReady) return true;
    if (!loadLibrary()) { error = "Este aparelho não tem Vulkan, que este sistema exige."; return false; }

    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "Cartucho";
    app.pEngineName = "Cartucho";
    app.apiVersion = VK_API_VERSION_1_1;
    const VkApplicationInfo* appInfo = &app;
    if (negotiation && negotiation->get_application_info) {
        if (const VkApplicationInfo* coreApp = negotiation->get_application_info()) appInfo = coreApp;
    }

    bool v2 = negotiation && negotiation->interface_version >= 2;
    if (v2 && negotiation->create_instance) {
        instance = negotiation->create_instance(gipa, appInfo, createInstanceWrapper, nullptr);
    } else {
        VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        ci.pApplicationInfo = appInfo;
        if (vkCreateInstance(&ci, nullptr, &instance) != VK_SUCCESS) instance = VK_NULL_HANDLE;
    }
    if (!instance) { error = "Não foi possível iniciar o Vulkan."; return false; }
    loadInstanceFunctions();

    gpu = pickGpu();
    if (!gpu) { error = "Nenhuma placa de vídeo com Vulkan foi encontrada."; return false; }

    retro_vulkan_context ctx{};
    bool made = false;
    if (v2 && negotiation->create_device2) {
        made = negotiation->create_device2(&ctx, instance, gpu, VK_NULL_HANDLE, gipa, createDeviceWrapper, nullptr);
    } else if (negotiation && negotiation->create_device) {
        made = negotiation->create_device(&ctx, instance, gpu, VK_NULL_HANDLE, gipa, nullptr, 0, nullptr, 0, nullptr);
    }
    if (made) {
        coreMadeDevice = true;
        gpu = ctx.gpu ? ctx.gpu : gpu;
        device = ctx.device;
        queue = ctx.queue;
        queueFamily = ctx.queue_family_index;
        loadDeviceFunctions();
    } else {
        if (!createOwnDevice()) { error = "Não foi possível preparar a placa de vídeo (Vulkan)."; return false; }
        loadDeviceFunctions();
        vkGetDeviceQueue(device, queueFamily, 0, &queue);
    }

    VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pi.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    pi.queueFamilyIndex = queueFamily;
    if (vkCreateCommandPool(device, &pi, nullptr, &pool) != VK_SUCCESS) { error = "Vulkan: falha ao criar comandos."; return false; }
    VkCommandBufferAllocateInfo ca{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    ca.commandPool = pool;
    ca.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ca.commandBufferCount = 1;
    vkAllocateCommandBuffers(device, &ca, &cmd);
    VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    vkCreateFence(device, &fi, nullptr, &fence);

    iface = {};
    iface.interface_type = RETRO_HW_RENDER_INTERFACE_VULKAN;
    iface.interface_version = RETRO_HW_RENDER_INTERFACE_VULKAN_VERSION;
    iface.handle = nullptr;
    iface.instance = instance;
    iface.gpu = gpu;
    iface.device = device;
    iface.get_device_proc_addr = gdpa;
    iface.get_instance_proc_addr = gipa;
    iface.queue = queue;
    iface.queue_index = queueFamily;
    iface.set_image = setImage;
    iface.get_sync_index = getSyncIndex;
    iface.get_sync_index_mask = getSyncIndexMask;
    iface.set_command_buffers = setCommandBuffers;
    iface.wait_sync_index = waitSyncIndex;
    iface.lock_queue = lockQueue;
    iface.unlock_queue = unlockQueue;
    iface.set_signal_semaphore = setSignalSemaphore;
    isReady = true;
    return true;
}

bool readFrame(unsigned w, unsigned h, std::vector<uint8_t>& out) {
    if (!isReady || !hasImage || !w || !h) return false;
    VkFormat format = currentImage.create_info.format;
    VkImage image = currentImage.create_info.image;
    if (!image) return false;
    VkDeviceSize size = (VkDeviceSize)w * h * 4;
    if (!ensureBuffer(size)) return false;

    vkResetCommandBuffer(cmd, 0);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &bi);

    const auto& range = currentImage.create_info.subresourceRange;
    VkImageMemoryBarrier toCopy{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    toCopy.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_TRANSFER_WRITE_BIT;
    toCopy.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    toCopy.oldLayout = currentImage.image_layout;
    toCopy.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    toCopy.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toCopy.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toCopy.image = image;
    toCopy.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, range.baseMipLevel, 1, range.baseArrayLayer, 1};
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1, &toCopy);

    VkBufferImageCopy region{};
    region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, range.baseMipLevel, range.baseArrayLayer, 1};
    region.imageExtent = {w, h, 1};
    vkCmdCopyImageToBuffer(cmd, image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, buffer, 1, &region);

    VkImageMemoryBarrier back = toCopy;
    back.srcAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    back.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    back.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    back.newLayout = currentImage.image_layout;
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, 0, 0, nullptr, 0, nullptr, 1, &back);

    VkBufferMemoryBarrier host{VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER};
    host.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    host.dstAccessMask = VK_ACCESS_HOST_READ_BIT;
    host.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    host.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    host.buffer = buffer;
    host.size = VK_WHOLE_SIZE;
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_HOST_BIT, 0, 0, nullptr, 1, &host, 0, nullptr);
    vkEndCommandBuffer(cmd);

    // Comandos do core primeiro (como o libretro pede), depois a cópia.
    std::vector<VkCommandBuffer> all = coreCommands;
    all.push_back(cmd);
    std::vector<VkPipelineStageFlags> stages(waitSemaphores.size(), VK_PIPELINE_STAGE_ALL_COMMANDS_BIT);
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    // Com set_command_buffers, o libretro manda ignorar os semáforos de set_image.
    bool useWaits = coreCommands.empty() && !waitSemaphores.empty();
    si.waitSemaphoreCount = useWaits ? (uint32_t)waitSemaphores.size() : 0;
    si.pWaitSemaphores = useWaits ? waitSemaphores.data() : nullptr;
    si.pWaitDstStageMask = useWaits ? stages.data() : nullptr;
    si.commandBufferCount = (uint32_t)all.size();
    si.pCommandBuffers = all.data();
    si.signalSemaphoreCount = signalSemaphore ? 1 : 0;
    si.pSignalSemaphores = signalSemaphore ? &signalSemaphore : nullptr;
    VkResult r;
    {
        std::lock_guard<std::mutex> lock(queueLock);
        r = vkQueueSubmit(queue, 1, &si, fence);
    }
    coreCommands.clear();
    waitSemaphores.clear();
    signalSemaphore = VK_NULL_HANDLE;
    if (r != VK_SUCCESS) return false;
    vkWaitForFences(device, 1, &fence, VK_TRUE, 2000000000ull);
    vkResetFences(device, 1, &fence);

    VkMappedMemoryRange mr{VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE};
    mr.memory = memory;
    mr.size = VK_WHOLE_SIZE;
    vkInvalidateMappedMemoryRanges(device, 1, &mr);

    // Saída em XRGB8888 (na memória: B, G, R, A).
    out.resize((size_t)size);
    const uint8_t* src = (const uint8_t*)mapped;
    uint8_t* dst = out.data();
    size_t pixels = (size_t)w * h;
    switch (format) {
        case VK_FORMAT_B8G8R8A8_UNORM:
        case VK_FORMAT_B8G8R8A8_SRGB:
            memcpy(dst, src, (size_t)size);
            break;
        case VK_FORMAT_A2B10G10R10_UNORM_PACK32: {
            const uint32_t* s = (const uint32_t*)src;
            for (size_t i = 0; i < pixels; i++) {
                uint32_t v = s[i];
                dst[i * 4 + 2] = (uint8_t)((v & 0x3ff) >> 2);
                dst[i * 4 + 1] = (uint8_t)(((v >> 10) & 0x3ff) >> 2);
                dst[i * 4 + 0] = (uint8_t)(((v >> 20) & 0x3ff) >> 2);
                dst[i * 4 + 3] = 255;
            }
            break;
        }
        case VK_FORMAT_A2R10G10B10_UNORM_PACK32: {
            const uint32_t* s = (const uint32_t*)src;
            for (size_t i = 0; i < pixels; i++) {
                uint32_t v = s[i];
                dst[i * 4 + 0] = (uint8_t)((v & 0x3ff) >> 2);
                dst[i * 4 + 1] = (uint8_t)(((v >> 10) & 0x3ff) >> 2);
                dst[i * 4 + 2] = (uint8_t)(((v >> 20) & 0x3ff) >> 2);
                dst[i * 4 + 3] = 255;
            }
            break;
        }
        default:  // R8G8B8A8 e parecidos: troca R e B.
            for (size_t i = 0; i < pixels; i++) {
                dst[i * 4 + 0] = src[i * 4 + 2];
                dst[i * 4 + 1] = src[i * 4 + 1];
                dst[i * 4 + 2] = src[i * 4 + 0];
                dst[i * 4 + 3] = 255;
            }
            break;
    }
    return true;
}

void shutdown() {
    if (device && vkDeviceWaitIdle) vkDeviceWaitIdle(device);
    if (mapped) { vkUnmapMemory(device, memory); mapped = nullptr; }
    if (buffer) { vkDestroyBuffer(device, buffer, nullptr); buffer = VK_NULL_HANDLE; }
    if (memory) { vkFreeMemory(device, memory, nullptr); memory = VK_NULL_HANDLE; }
    if (fence) { vkDestroyFence(device, fence, nullptr); fence = VK_NULL_HANDLE; }
    if (pool) { vkDestroyCommandPool(device, pool, nullptr); pool = VK_NULL_HANDLE; }
    if (coreMadeDevice && negotiation && negotiation->destroy_device) negotiation->destroy_device();
    else if (device && vkDestroyDevice) vkDestroyDevice(device, nullptr);
    device = VK_NULL_HANDLE;
    if (instance && vkDestroyInstance) vkDestroyInstance(instance, nullptr);
    instance = VK_NULL_HANDLE;
    isReady = false;
    hasImage = false;
    bufferSize = 0;
}

}  // namespace vkb
