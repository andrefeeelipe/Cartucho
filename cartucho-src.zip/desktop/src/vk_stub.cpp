// Cartucho para iPhone — sem Vulkan: os cores que só desenham em Vulkan não entram na versão de iPhone.
#include "vk_bridge.h"

namespace vkb {
void setNegotiation(const void*) {}
bool init(std::string& error) {
    error = "Este jogo precisa de Vulkan, que não existe no iPhone.";
    return false;
}
const void* renderInterface() { return nullptr; }
bool readFrame(unsigned, unsigned, std::vector<uint8_t>&) { return false; }
bool ready() { return false; }
void shutdown() {}
}  // namespace vkb
