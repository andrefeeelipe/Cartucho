// Cartucho para iPhone — toque na interface (tocar, arrastar para rolar, segurar para o menu do jogo),
// escala da tela e o controle desenhado na tela durante o jogo.
#pragma once

#include <SDL.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <map>
#include <string>

#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "platform.h"
#include "systems.h"

namespace touch {

struct State {
    SDL_Window* window = nullptr;
    float scale = 1.0f;          // pontos da tela por unidade do ImGui
    float density = 1.0f;        // pixels por unidade do ImGui (para as fontes saírem nítidas)
    float insetL = 0, insetT = 0, insetR = 0, insetB = 0;  // margens seguras, em unidades do ImGui
    // Dedo que está mexendo na interface.
    SDL_FingerID uiFinger = 0;
    bool uiDown = false, uiScrolling = false, uiLongFired = false;
    float startX = 0, startY = 0, lastX = 0, lastY = 0;
    Uint64 downAt = 0;
    bool textInput = false;
};

inline State& state() {
    static State s;
    return s;
}

/** Tamanho da tela em pontos. */
inline void windowPoints(float& w, float& h) {
    int iw = 1, ih = 1;
    if (state().window) SDL_GetWindowSize(state().window, &iw, &ih);
    w = (float)std::max(iw, 1);
    h = (float)std::max(ih, 1);
}

/**
 * A interface foi desenhada para uma tela de computador (uns 1100 × 560 no mínimo). No celular deitado,
 * ela é reduzida por igual até caber, e as fontes são geradas na resolução real da tela para não borrar.
 */
inline void setup(SDL_Window* window) {
    State& s = state();
    s.window = window;
    float w, h;
    windowPoints(w, h);
    float shortSide = std::min(w, h), longSide = std::max(w, h);
    s.scale = std::min(1.0f, std::min(longSide / 1100.0f, shortSide / 540.0f));
    s.scale = std::max(s.scale, 0.55f);
    int dw = 1, dh = 1;
    SDL_GL_GetDrawableSize(window, &dw, &dh);
    s.density = std::min(3.0f, std::max(1.0f, (float)dw / w / s.scale));
    float l = 0, t = 0, r = 0, b = 0;
#if defined(CARTUCHO_IOS)
    plat::safeInsets(l, t, r, b);
#endif
    s.insetL = l / s.scale;
    s.insetT = t / s.scale;
    s.insetR = r / s.scale;
    s.insetB = b / s.scale;
}

/** Ponto do dedo (0..1 da tela) em unidades do ImGui. */
inline ImVec2 fingerPos(float nx, float ny) {
    float w, h;
    windowPoints(w, h);
    return ImVec2(nx * w / state().scale, ny * h / state().scale);
}

/** Entrega um evento ao ImGui: dedos viram toque/rolagem; mouse e teclado passam com a escala certa. */
inline void processUiEvent(const SDL_Event& in) {
    State& s = state();
    ImGuiIO& io = ImGui::GetIO();
    SDL_Event e = in;
    switch (e.type) {
        case SDL_FINGERDOWN: {
            if (s.uiDown) return;  // só o primeiro dedo mexe na interface
            ImVec2 p = fingerPos(e.tfinger.x, e.tfinger.y);
            s.uiDown = true;
            s.uiScrolling = false;
            s.uiLongFired = false;
            s.uiFinger = e.tfinger.fingerId;
            s.startX = s.lastX = p.x;
            s.startY = s.lastY = p.y;
            s.downAt = SDL_GetTicks64();
            io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen);
            io.AddMousePosEvent(p.x, p.y);
            return;
        }
        case SDL_FINGERMOTION: {
            if (!s.uiDown || e.tfinger.fingerId != s.uiFinger) return;
            ImVec2 p = fingerPos(e.tfinger.x, e.tfinger.y);
            if (!s.uiScrolling && std::hypot(p.x - s.startX, p.y - s.startY) > 12.0f) s.uiScrolling = true;
            if (s.uiScrolling && !s.uiLongFired) {
                // Arrastar rola a lista, como em qualquer app de celular.
                float unit = 5.0f * std::max(ImGui::GetFontSize(), 12.0f);
                io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen);
                io.AddMouseWheelEvent((p.x - s.lastX) / unit, (p.y - s.lastY) / unit);
            }
            s.lastX = p.x;
            s.lastY = p.y;
            return;
        }
        case SDL_FINGERUP: {
            if (!s.uiDown || e.tfinger.fingerId != s.uiFinger) return;
            s.uiDown = false;
            if (s.uiScrolling || s.uiLongFired) return;
            // Toque curto: aperta e solta no mesmo lugar (o ImGui espalha os dois pelos quadros seguintes).
            io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen);
            io.AddMousePosEvent(s.startX, s.startY);
            io.AddMouseButtonEvent(0, true);
            io.AddMouseButtonEvent(0, false);
            return;
        }
        case SDL_MOUSEMOTION:
            if (e.motion.which == SDL_TOUCH_MOUSEID) return;
            e.motion.x = (Sint32)(e.motion.x / s.scale);
            e.motion.y = (Sint32)(e.motion.y / s.scale);
            break;
        case SDL_MOUSEBUTTONDOWN:
        case SDL_MOUSEBUTTONUP:
            if (e.button.which == SDL_TOUCH_MOUSEID) return;
            e.button.x = (Sint32)(e.button.x / s.scale);
            e.button.y = (Sint32)(e.button.y / s.scale);
            break;
        case SDL_MOUSEWHEEL:
            if (e.wheel.which == SDL_TOUCH_MOUSEID) return;
            break;
        default: break;
    }
    ImGui_ImplSDL2_ProcessEvent(&e);
}

/** Depois do ImGui_ImplSDL2_NewFrame: aplica a escala e trata o "segurar" (abre o menu do jogo, como o botão direito). */
inline void afterPlatformNewFrame() {
    State& s = state();
    ImGuiIO& io = ImGui::GetIO();
    float w, h;
    windowPoints(w, h);
    int dw = 1, dh = 1;
    if (s.window) SDL_GL_GetDrawableSize(s.window, &dw, &dh);
    io.DisplaySize = ImVec2(w / s.scale, h / s.scale);
    io.DisplayFramebufferScale = ImVec2((float)dw / io.DisplaySize.x, (float)dh / io.DisplaySize.y);
    if (s.uiDown && !s.uiScrolling && !s.uiLongFired && SDL_GetTicks64() - s.downAt > 480) {
        s.uiLongFired = true;
        io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen);
        io.AddMousePosEvent(s.startX, s.startY);
        io.AddMouseButtonEvent(1, true);
        io.AddMouseButtonEvent(1, false);
    }
    // Teclado do iPhone só aparece quando um campo de texto está ativo.
    if (io.WantTextInput != s.textInput) {
        s.textInput = io.WantTextInput;
        if (s.textInput) SDL_StartTextInput();
        else SDL_StopTextInput();
    }
}

// ------------------------------------------------------------------ controle na tela

struct PadResult {
    uint32_t mask = 0;
    bool menu = false;         // tocou no botão de menu
    bool pointer = false;      // um dedo na tela do jogo (tela de toque do Nintendo DS)
    float px = 0, py = 0;      // posição desse dedo, em unidades do ImGui
    int16_t ax = 0, ay = 0;    // analógico esquerdo (Nintendo 64)
};

struct Pad {
    std::map<SDL_FingerID, ImVec2> fingers;  // dedos na tela, em unidades do ImGui
    SDL_FingerID pointerFinger = 0;
    bool pointerActive = false;
    bool menuWasDown = false;

    void event(const SDL_Event& e) {
        if (e.type == SDL_FINGERDOWN || e.type == SDL_FINGERMOTION) fingers[e.tfinger.fingerId] = fingerPos(e.tfinger.x, e.tfinger.y);
        else if (e.type == SDL_FINGERUP) fingers.erase(e.tfinger.fingerId);
    }
    void clear() {
        fingers.clear();
        pointerActive = false;
        menuWasDown = false;
    }

    /** Lê os dedos e desenha o controle. Botões conforme o console. */
    PadResult update(ImDrawList* dl, const std::string& system, bool visible) {
        PadResult out;
        State& s = state();
        ImGuiIO& io = ImGui::GetIO();
        const float W = io.DisplaySize.x, H = io.DisplaySize.y;
        const float r = std::max(24.0f, std::min(W, H) * 0.075f);  // raio de um botão
        const float margin = 18.0f;
        const float left = s.insetL + margin, right = W - s.insetR - margin, bottom = H - std::max(s.insetB, 6.0f) - margin;

        auto is = [&](std::initializer_list<const char*> ids) {
            for (const char* id : ids) if (system == id) return true;
            return false;
        };
        const bool twoButtons = is({"nes", "gb", "gbc", "gba", "mastersystem", "gamegear", "pce", "pcecd", "lynx", "ngp", "wswan",
                                    "virtualboy", "pokemini", "atari7800", "colecovision", "sega32x", "supervision", "megaduck", "arduboy"});
        const bool shoulders = is({"snes", "gba", "nds", "psx", "psp", "n64", "virtualboy", "pcfx", "3do", "jaguar"});
        const bool triggers = is({"psx", "n64"});
        const bool stick = system == "n64";

        struct Btn { int id; ImVec2 c; float rad; const char* label; };
        Btn btns[12];
        int nb = 0;
        ImVec2 dpad(left + 2.6f * r, bottom - 2.6f * r);
        ImVec2 face(right - 2.6f * r, bottom - 2.6f * r);
        if (twoButtons) {
            btns[nb++] = {RP_A, ImVec2(face.x + 1.05f * r, face.y - 0.45f * r), r, "A"};
            btns[nb++] = {RP_B, ImVec2(face.x - 1.15f * r, face.y + 0.55f * r), r, "B"};
        } else {
            btns[nb++] = {RP_A, ImVec2(face.x + 1.55f * r, face.y), r, "A"};
            btns[nb++] = {RP_B, ImVec2(face.x, face.y + 1.55f * r), r, "B"};
            btns[nb++] = {RP_X, ImVec2(face.x, face.y - 1.55f * r), r, "X"};
            btns[nb++] = {RP_Y, ImVec2(face.x - 1.55f * r, face.y), r, "Y"};
        }
        float topY = s.insetT + margin + 0.6f * r;
        if (shoulders) {
            btns[nb++] = {RP_L, ImVec2(left + 1.2f * r, topY), 0.75f * r, "L"};
            btns[nb++] = {RP_R, ImVec2(right - 1.2f * r, topY), 0.75f * r, "R"};
        }
        if (triggers) {
            btns[nb++] = {RP_L2, ImVec2(left + 1.2f * r, topY + 1.8f * r), 0.75f * r, system == "n64" ? "Z" : "L2"};
            btns[nb++] = {RP_R2, ImVec2(right - 1.2f * r, topY + 1.8f * r), 0.75f * r, "R2"};
        }
        ImVec2 selectC(W * 0.5f - 1.3f * r, bottom - 0.3f * r), startC(W * 0.5f + 1.3f * r, bottom - 0.3f * r);
        btns[nb++] = {RP_SELECT, selectC, 0.55f * r, "Select"};
        btns[nb++] = {RP_START, startC, 0.55f * r, "Start"};
        ImVec2 menuC(W * 0.5f, s.insetT + margin + 0.35f * r);
        float menuR = 0.55f * r;

        bool menuDown = false;
        uint32_t pressed = 0;
        bool sawPointer = false;
        for (const auto& kv : fingers) {
            ImVec2 p = kv.second;
            bool used = false;
            // Direcional: o ângulo do dedo em relação ao centro (oito direções, pode deslizar).
            float dx = p.x - dpad.x, dy = p.y - dpad.y, dist = std::hypot(dx, dy);
            if (dist < 2.6f * r) {
                used = true;
                if (dist > 0.3f * r) {
                    float a = std::atan2(dy, dx);  // 0 = direita, para baixo positivo
                    const float PI = 3.14159265f;
                    auto aim = [&](float target) {
                        float d = std::fabs(std::remainder(a - target, 2 * PI));
                        return d < PI * 3.0f / 8.0f;
                    };
                    if (stick) {
                        float k = std::min(1.0f, dist / (1.6f * r));
                        out.ax = (int16_t)std::clamp(dx / dist * k * 32767.0f, -32767.0f, 32767.0f);
                        out.ay = (int16_t)std::clamp(dy / dist * k * 32767.0f, -32767.0f, 32767.0f);
                    } else {
                        if (aim(0)) pressed |= 1u << RP_RIGHT;
                        if (aim(PI)) pressed |= 1u << RP_LEFT;
                        if (aim(PI / 2)) pressed |= 1u << RP_DOWN;
                        if (aim(-PI / 2)) pressed |= 1u << RP_UP;
                    }
                }
            }
            for (int i = 0; i < nb && !used; i++) {
                if (std::hypot(p.x - btns[i].c.x, p.y - btns[i].c.y) < btns[i].rad * 1.25f) {
                    pressed |= 1u << btns[i].id;
                    // Entre dois botões vizinhos aperta os dois (como apertar A e B juntos com o dedão).
                    for (int j = i + 1; j < nb; j++)
                        if (std::hypot(p.x - btns[j].c.x, p.y - btns[j].c.y) < btns[j].rad * 1.25f) pressed |= 1u << btns[j].id;
                    used = true;
                }
            }
            if (!used && std::hypot(p.x - menuC.x, p.y - menuC.y) < menuR * 1.6f) { menuDown = true; used = true; }
            if (!used && !sawPointer) {
                // Fora dos botões: toque na tela do jogo (o Nintendo DS usa a tela de baixo).
                if (!pointerActive || pointerFinger == kv.first) {
                    pointerActive = true;
                    pointerFinger = kv.first;
                    sawPointer = true;
                    out.pointer = true;
                    out.px = p.x;
                    out.py = p.y;
                }
            }
        }
        if (!sawPointer) pointerActive = false;
        // O menu abre ao soltar o dedo (não no meio de uma jogada).
        if (menuWasDown && !menuDown) out.menu = true;
        menuWasDown = menuDown;
        out.mask = pressed;

        if (visible && dl) {
            const ImU32 fill = IM_COL32(30, 30, 38, 92), fillOn = IM_COL32(79, 67, 174, 200), edge = IM_COL32(255, 255, 255, 70),
                        text = IM_COL32(255, 255, 255, 190);
            ImFont* f = ImGui::GetFont();
            auto label = [&](ImVec2 c, const char* t, float size) {
                ImVec2 ts = f->CalcTextSizeA(size, FLT_MAX, 0, t);
                dl->AddText(f, size, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), text, t);
            };
            // Direcional em cruz.
            float arm = 0.62f * r, len = 1.9f * r;
            dl->AddCircleFilled(dpad, 2.2f * r, IM_COL32(30, 30, 38, 40), 48);
            struct Arm { int id; ImVec2 a, b; };
            Arm arms[4] = {
                {RP_UP, ImVec2(dpad.x - arm, dpad.y - len), ImVec2(dpad.x + arm, dpad.y - arm)},
                {RP_DOWN, ImVec2(dpad.x - arm, dpad.y + arm), ImVec2(dpad.x + arm, dpad.y + len)},
                {RP_LEFT, ImVec2(dpad.x - len, dpad.y - arm), ImVec2(dpad.x - arm, dpad.y + arm)},
                {RP_RIGHT, ImVec2(dpad.x + arm, dpad.y - arm), ImVec2(dpad.x + len, dpad.y + arm)},
            };
            dl->AddRectFilled(ImVec2(dpad.x - arm, dpad.y - arm), ImVec2(dpad.x + arm, dpad.y + arm), fill);
            for (const auto& a : arms) {
                bool on = stick ? false : (pressed >> a.id) & 1u;
                dl->AddRectFilled(a.a, a.b, on ? fillOn : fill, 8.0f);
                dl->AddRect(a.a, a.b, edge, 8.0f);
            }
            if (stick && (out.ax || out.ay)) {
                ImVec2 knob(dpad.x + out.ax / 32767.0f * 1.2f * r, dpad.y + out.ay / 32767.0f * 1.2f * r);
                dl->AddCircleFilled(knob, 0.7f * r, fillOn, 32);
            }
            for (int i = 0; i < nb; i++) {
                bool on = (pressed >> btns[i].id) & 1u;
                bool pill = btns[i].id == RP_START || btns[i].id == RP_SELECT;
                if (pill) {
                    ImVec2 a(btns[i].c.x - 1.6f * btns[i].rad, btns[i].c.y - 0.55f * btns[i].rad), b(btns[i].c.x + 1.6f * btns[i].rad, btns[i].c.y + 0.55f * btns[i].rad);
                    dl->AddRectFilled(a, b, on ? fillOn : fill, 99.0f);
                    dl->AddRect(a, b, edge, 99.0f);
                    label(btns[i].c, btns[i].label, 0.5f * r);
                } else {
                    dl->AddCircleFilled(btns[i].c, btns[i].rad, on ? fillOn : fill, 40);
                    dl->AddCircle(btns[i].c, btns[i].rad, edge, 40, 1.5f);
                    label(btns[i].c, btns[i].label, 0.7f * btns[i].rad);
                }
            }
            dl->AddCircleFilled(menuC, menuR, menuDown ? fillOn : fill, 32);
            for (int k = -1; k <= 1; k++)
                dl->AddLine(ImVec2(menuC.x - 0.45f * menuR, menuC.y + k * 0.3f * menuR), ImVec2(menuC.x + 0.45f * menuR, menuC.y + k * 0.3f * menuR), text, 2.0f);
        }
        return out;
    }
};

}  // namespace touch
