// Cartucho para iPhone — pedaços que só existem no iOS (internet, pastas, margens da tela, compartilhar).
#include "platform.h"

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include <cstdio>

namespace plat {

bool download(const std::string& url, const std::string& target) {
    @autoreleasepool {
        NSString* u = [NSString stringWithUTF8String:url.c_str()];
        NSURL* nsurl = u ? [NSURL URLWithString:u] : nil;
        if (!nsurl) return false;
        NSMutableURLRequest* req = [NSMutableURLRequest requestWithURL:nsurl cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:60];
        [req setValue:@"Cartucho-iOS/1.0" forHTTPHeaderField:@"User-Agent"];
        std::string part = target + ".part";
        NSString* partPath = [NSString stringWithUTF8String:part.c_str()];
        NSString* finalPath = [NSString stringWithUTF8String:target.c_str()];
        __block bool ok = false;
        dispatch_semaphore_t done = dispatch_semaphore_create(0);
        NSURLSessionDownloadTask* task = [[NSURLSession sharedSession]
            downloadTaskWithRequest:req
                  completionHandler:^(NSURL* location, NSURLResponse* response, NSError* error) {
                      NSInteger status = [response isKindOfClass:[NSHTTPURLResponse class]] ? ((NSHTTPURLResponse*)response).statusCode : 0;
                      if (!error && location && status >= 200 && status < 300) {
                          NSFileManager* fm = [NSFileManager defaultManager];
                          [fm removeItemAtPath:partPath error:nil];
                          if ([fm moveItemAtURL:location toURL:[NSURL fileURLWithPath:partPath] error:nil]) {
                              [fm removeItemAtPath:finalPath error:nil];
                              ok = [fm moveItemAtPath:partPath toPath:finalPath error:nil];
                          }
                      }
                      dispatch_semaphore_signal(done);
                  }];
        [task resume];
        dispatch_semaphore_wait(done, dispatch_time(DISPATCH_TIME_NOW, (int64_t)600 * NSEC_PER_SEC));
        return ok;
    }
}

std::string homeDir() {
    @autoreleasepool {
        return std::string([NSHomeDirectory() fileSystemRepresentation]);
    }
}

static UIWindow* keyWindow() {
    for (UIScene* scene in [UIApplication sharedApplication].connectedScenes) {
        if (![scene isKindOfClass:[UIWindowScene class]]) continue;
        for (UIWindow* w in ((UIWindowScene*)scene).windows)
            if (w.isKeyWindow) return w;
    }
    for (UIScene* scene in [UIApplication sharedApplication].connectedScenes)
        if ([scene isKindOfClass:[UIWindowScene class]] && ((UIWindowScene*)scene).windows.count > 0)
            return ((UIWindowScene*)scene).windows.firstObject;
    return nil;
}

void safeInsets(float& left, float& top, float& right, float& bottom) {
    left = top = right = bottom = 0;
    UIWindow* w = keyWindow();
    if (!w) return;
    UIEdgeInsets in = w.safeAreaInsets;
    left = (float)in.left;
    top = (float)in.top;
    right = (float)in.right;
    bottom = (float)in.bottom;
}

void shareFile(const std::string& path) {
    @autoreleasepool {
        UIWindow* w = keyWindow();
        UIViewController* root = w.rootViewController;
        if (!root) return;
        while (root.presentedViewController) root = root.presentedViewController;
        NSURL* url = [NSURL fileURLWithPath:[NSString stringWithUTF8String:path.c_str()]];
        UIActivityViewController* vc = [[UIActivityViewController alloc] initWithActivityItems:@[ url ] applicationActivities:nil];
        if (vc.popoverPresentationController) {  // iPad: a folha sai de um ponto da tela
            vc.popoverPresentationController.sourceView = root.view;
            vc.popoverPresentationController.sourceRect = CGRectMake(root.view.bounds.size.width / 2, root.view.bounds.size.height / 2, 1, 1);
        }
        [root presentViewController:vc animated:YES completion:nil];
    }
}

}  // namespace plat
