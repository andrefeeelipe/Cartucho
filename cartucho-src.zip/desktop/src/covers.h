#pragma once
// Capas dos jogos no Windows: mesmo acervo do celular (libretro-thumbnails, no GitHub) e capas da Loja.
// Tudo roda numa linha por trás: procura o nome mais parecido no índice do acervo, baixa a imagem,
// guarda em %APPDATA%/Cartucho/Cartucho/capas e entrega os pixels (já reduzidos) para a tela.
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cctype>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <deque>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "stb/stb_image.h"

#ifdef _WIN32
#include <urlmon.h>
#include <windows.h>
#endif

namespace covers {

struct Pixels {
    std::string key;
    int w = 0, h = 0;
    std::vector<unsigned char> rgba;
};

namespace detail {

inline const std::map<std::string, std::vector<std::string>>& repos() {
    static const std::map<std::string, std::vector<std::string>> m = {
        {"atari2600", {"Atari_-_2600"}},
        {"atari7800", {"Atari_-_7800"}},
        {"lynx", {"Atari_-_Lynx"}},
        {"nes", {"Nintendo_-_Nintendo_Entertainment_System", "Nintendo_-_Family_Computer_Disk_System"}},
        {"snes", {"Nintendo_-_Super_Nintendo_Entertainment_System", "Nintendo_-_Satellaview"}},
        {"gb", {"Nintendo_-_Game_Boy", "Nintendo_-_Game_Boy_Color"}},
        {"gbc", {"Nintendo_-_Game_Boy_Color", "Nintendo_-_Game_Boy"}},
        {"gba", {"Nintendo_-_Game_Boy_Advance"}},
        {"mastersystem", {"Sega_-_Master_System_-_Mark_III", "Sega_-_SG-1000"}},
        {"gamegear", {"Sega_-_Game_Gear"}},
        {"megadrive", {"Sega_-_Mega_Drive_-_Genesis"}},
        {"segacd", {"Sega_-_Mega-CD_-_Sega_CD"}},
        {"sega32x", {"Sega_-_32X"}},
        {"pce", {"NEC_-_PC_Engine_-_TurboGrafx_16", "NEC_-_PC_Engine_SuperGrafx"}},
        {"pcecd", {"NEC_-_PC_Engine_CD_-_TurboGrafx-CD"}},
        {"ngp", {"SNK_-_Neo_Geo_Pocket_Color", "SNK_-_Neo_Geo_Pocket"}},
        {"wswan", {"Bandai_-_WonderSwan_Color", "Bandai_-_WonderSwan"}},
        {"arcade", {"FBNeo_-_Arcade_Games", "MAME"}},
        {"n64", {"Nintendo_-_Nintendo_64"}},
        {"nds", {"Nintendo_-_Nintendo_DS"}},
        {"3ds", {"Nintendo_-_Nintendo_3DS"}},
        {"psx", {"Sony_-_PlayStation"}},
        {"psp", {"Sony_-_PlayStation_Portable"}},
        {"saturn", {"Sega_-_Saturn"}},
        {"dreamcast", {"Sega_-_Dreamcast"}},
        {"ps2", {"Sony_-_PlayStation_2"}},
        {"gamecube", {"Nintendo_-_GameCube"}},
        {"wii", {"Nintendo_-_Wii"}},
        {"3do", {"The_3DO_Company_-_3DO"}},
        {"jaguar", {"Atari_-_Jaguar"}},
        {"atari5200", {"Atari_-_5200"}},
        {"atari800", {"Atari_-_8-bit"}},
        {"vectrex", {"GCE_-_Vectrex"}},
        {"virtualboy", {"Nintendo_-_Virtual_Boy"}},
        {"neogeocd", {"SNK_-_Neo_Geo_CD"}},
        {"pcfx", {"NEC_-_PC-FX"}},
        {"colecovision", {"Coleco_-_ColecoVision"}},
        {"intellivision", {"Mattel_-_Intellivision"}},
        {"odyssey2", {"Magnavox_-_Odyssey2"}},
        {"channelf", {"Fairchild_-_Channel_F"}},
        {"msx", {"Microsoft_-_MSX", "Microsoft_-_MSX2"}},
        {"zxspectrum", {"Sinclair_-_ZX_Spectrum"}},
        {"amstradcpc", {"Amstrad_-_CPC"}},
        {"c64", {"Commodore_-_64"}},
        {"amiga", {"Commodore_-_Amiga"}},
        {"dos", {"DOS"}},
        {"cdi", {"Philips_-_CD-i"}},
        {"neogeo", {"SNK_-_Neo_Geo"}},
        {"naomi", {"Sega_-_Naomi", "Sega_-_Naomi_2", "Sammy_-_Atomiswave"}},
        {"megaduck", {"Welback_-_Mega_Duck"}},
        {"arcadia", {"Emerson_-_Arcadia_2001"}},
        {"scv", {"Epoch_-_Super_Cassette_Vision"}},
        {"hyperscan", {"Mattel_-_HyperScan"}},
        {"uzebox", {"Uzebox"}},
        {"j2me", {"Mobile_-_J2ME"}},
        {"appleii", {"Apple_-_II"}},
        {"atarist", {"Atari_-_ST"}},
        {"zx81", {"Sinclair_-_ZX_81"}},
        {"bbcmicro", {"Acorn_-_BBC_Micro"}},
        {"vic20", {"Commodore_-_VIC-20"}},
        {"plus4", {"Commodore_-_Plus-4"}},
        {"pc88", {"NEC_-_PC-8001_-_PC-8801"}},
        {"pc98", {"NEC_-_PC-98"}},
        {"x68000", {"Sharp_-_X68000"}},
        {"x1", {"Sharp_-_X1"}},
        {"fmtowns", {"FM_Towns"}},
        {"thomson", {"Thomson_-_MOTO"}},
        {"pico8", {"PICO-8"}},
        {"wasm4", {"WASM-4"}},
        {"lowresnx", {"LowRes_NX"}},
        {"scummvm", {"ScummVM"}},
        {"doom", {"DOOM"}},
        {"quake", {"Quake"}},
        {"cavestory", {"Cave_Story"}},
        {"pokemini", {"Nintendo_-_Pokemon_Mini"}},
        {"supervision", {"Watara_-_Supervision"}},
        {"arduboy", {"Arduboy_Inc_-_Arduboy"}},
        {"gameandwatch", {"Handheld_Electronic_Game"}},
        {"wiiu", {"Nintendo_-_Wii_U"}},
        {"xbox360", {"Microsoft_-_Xbox_360"}},
    };
    return m;
}

struct State {
    std::string dir;
    std::mutex mu;
    std::condition_variable cv;
    std::deque<std::vector<std::string>> queue;  // chave, sistema, título, nome do arquivo, url direta
    std::set<std::string> asked;
    std::deque<Pixels> ready;
    std::map<std::string, std::vector<std::string>> indexCache;
    std::map<std::string, std::vector<std::vector<std::string>>> tokenCache;  // palavras de cada nome do índice
    std::atomic<bool> started{false};
};
inline State& st() {
    static State s;
    return s;
}

#ifdef _WIN32
inline std::wstring wide(const std::string& s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}
#endif

inline std::string readFile(const std::string& path) {
#ifdef _WIN32
    std::ifstream in(wide(path), std::ios::binary);
#else
    std::ifstream in(path, std::ios::binary);
#endif
    std::stringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

inline bool download(const std::string& url, const std::string& target) {
#ifdef _WIN32
    std::string part = target + ".part";
    if (URLDownloadToFileW(nullptr, wide(url).c_str(), wide(part).c_str(), 0, nullptr) != S_OK) return false;
    _wremove(wide(target).c_str());
    return MoveFileW(wide(part).c_str(), wide(target).c_str()) != 0;
#else
    (void)url; (void)target;
    return false;
#endif
}

inline std::string urlEncode(const std::string& s) {
    std::string out;
    char buf[4];
    for (unsigned char ch : s) {
        if (isalnum(ch) || ch == '-' || ch == '_' || ch == '.' || ch == '~') out += (char)ch;
        else { snprintf(buf, sizeof(buf), "%%%02X", ch); out += buf; }
    }
    return out;
}

inline std::string hashKey(const std::string& s) {
    unsigned long long h = 1469598103934665603ULL;
    for (unsigned char c : s) { h ^= c; h *= 1099511628211ULL; }
    char buf[24];
    snprintf(buf, sizeof(buf), "%016llx", h);
    return buf;
}

// --- comparação de nomes (igual ao celular, em versão enxuta)

inline std::string stripTags(const std::string& s) {
    std::string out;
    int depth = 0;
    for (char c : s) {
        if (c == '(' || c == '[') depth++;
        else if ((c == ')' || c == ']') && depth > 0) depth--;
        else if (depth == 0) out += c;
    }
    return out;
}

inline std::vector<std::string> tokens(const std::string& name) {
    static const std::map<std::string, std::string> conv = {
        {"ii", "2"}, {"iii", "3"}, {"iv", "4"}, {"vi", "6"}, {"vii", "7"}, {"viii", "8"}, {"ix", "9"},
        {"branco", "white"}, {"branca", "white"}, {"preto", "black"}, {"preta", "black"}, {"diamante", "diamond"},
        {"perola", "pearl"}, {"platina", "platinum"}, {"ouro", "gold"}, {"prata", "silver"}, {"rubi", "ruby"},
        {"safira", "sapphire"}, {"esmeralda", "emerald"}, {"vermelho", "red"}, {"azul", "blue"}, {"amarelo", "yellow"},
        {"verde", "green"}, {"cristal", "crystal"}, {"fogo", "fire"}, {"folha", "leaf"}};
    static const std::set<std::string> skip = {"the", "a", "an", "of", "and", "de", "do", "da", "o", "e", "www", "com", "net",
        "org", "br", "bra", "brasil", "pt", "ptbr", "por", "portugues", "copia", "traducao", "traduzido", "dublado", "rom",
        "roms", "iso", "pal", "ntsc", "usa", "us", "eur", "jap", "version", "hack", "beta", "proto", "translated", "translation"};
    std::string s = stripTags(name);
    // "SuperMarioWorld" -> "Super Mario World"
    std::string split;
    for (size_t i = 0; i < s.size(); i++) {
        if (i > 0 && isupper((unsigned char)s[i]) && islower((unsigned char)s[i - 1])) split += ' ';
        split += s[i];
    }
    std::vector<std::string> out;
    std::string cur;
    auto flush = [&] {
        if (cur.empty()) return;
        auto it = conv.find(cur);
        std::string t = it != conv.end() ? it->second : cur;
        if (!skip.count(t)) out.push_back(t);
        cur.clear();
    };
    for (size_t i = 0; i < split.size(); i++) {
        unsigned char c = (unsigned char)split[i];
        if (c == '&') { flush(); out.push_back("and"); continue; }
        if (c >= 0x80) {
            // Acentos comuns em UTF-8 (é, ã, ç…) viram a letra sem acento.
            if (c == 0xC3 && i + 1 < split.size()) {
                unsigned char d = (unsigned char)split[++i];
                const char* map = "aaaaaaaceeeeiiiidnooooo/ouuuuyby";
                if (d >= 0xA0 && d <= 0xBF) cur += map[d - 0xA0];
                else if (d >= 0x80 && d <= 0x9F) cur += (char)tolower(map[d - 0x80]);
            }
            continue;
        }
        if (isalnum(c)) cur += (char)tolower(c);
        else flush();
    }
    flush();
    return out;
}

inline double similarity(const std::vector<std::string>& ta, const std::vector<std::string>& tb) {
    if (ta.empty() || tb.empty()) return 0;
    std::set<std::string> na, nb, sa(ta.begin(), ta.end()), sb(tb.begin(), tb.end());
    for (auto& t : ta) if (std::all_of(t.begin(), t.end(), ::isdigit)) na.insert(t);
    for (auto& t : tb) if (std::all_of(t.begin(), t.end(), ::isdigit)) nb.insert(t);
    if (na != nb) return 0;  // números diferentes = jogos diferentes (Mega Man 2 x 3)
    int common = 0;
    for (auto& t : sa) common += (int)sb.count(t);
    return 2.0 * common / (double)(sa.size() + sb.size());
}

inline int regionRank(const std::string& n) {
    static const char* order[] = {"(USA", "(World", "(Brazil", "(Europe", "(Japan, USA", "(Japan"};
    for (int i = 0; i < 6; i++) if (n.find(order[i]) != std::string::npos) return i;
    return 6;
}

inline std::string bestMatch(const std::string& wanted, const std::vector<std::string>& names,
                             const std::vector<std::vector<std::string>>& nameTokens) {
    auto tw = tokens(wanted);
    if (tw.empty()) return "";
    std::string best;
    double bestScore = 0;
    for (size_t i = 0; i < names.size(); i++) {
        const auto& n = names[i];
        double sc = similarity(tw, nameTokens[i]);
        if (sc < 0.6) continue;
        if (sc > bestScore + 1e-9 || (std::abs(sc - bestScore) < 1e-9 && regionRank(n) < regionRank(best))) {
            bestScore = sc;
            best = n;
        }
    }
    return best;
}

// --- índice do acervo (lista de capas de um sistema), guardado por 30 dias

inline std::string jsonUnescape(const std::string& s) {
    std::string out;
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] != '\\' || i + 1 >= s.size()) { out += s[i]; continue; }
        char e = s[++i];
        if (e == 'u' && i + 4 < s.size()) {
            unsigned cp = (unsigned)strtoul(s.substr(i + 1, 4).c_str(), nullptr, 16);
            i += 4;
            if (cp < 0x80) out += (char)cp;
            else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F)); }
            else { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
        } else out += e == 'n' ? '\n' : e == 't' ? '\t' : e;
    }
    return out;
}

inline std::vector<std::string> index(const std::string& repo) {
    State& s = st();
    auto it = s.indexCache.find(repo);
    if (it != s.indexCache.end()) return it->second;
    std::string file = s.dir + "indice/" + repo + ".txt";
    std::vector<std::string> names;
    std::error_code ec;
    namespace fs = std::filesystem;
    fs::path fp = fs::u8path(file);
    bool fresh = fs::exists(fp, ec) &&
                 std::chrono::duration_cast<std::chrono::hours>(fs::file_time_type::clock::now() - fs::last_write_time(fp, ec)).count() < 24 * 30;
    if (!fresh) {
        std::string json = s.dir + "indice/" + repo + ".json";
        bool got = false;
        for (const char* branch : {"master", "main"}) {
            if (download(std::string("https://api.github.com/repos/libretro-thumbnails/") + repo + "/git/trees/" + branch + "?recursive=1", json)) { got = true; break; }
        }
        if (got) {
            std::string text = readFile(json);
            std::string out;
            const std::string key = "\"path\":";
            for (size_t p = text.find(key); p != std::string::npos; p = text.find(key, p + 1)) {
                size_t q = text.find('"', p + key.size());
                if (q == std::string::npos) break;
                size_t e = q + 1;
                while (e < text.size() && !(text[e] == '"' && text[e - 1] != '\\')) e++;
                std::string path = jsonUnescape(text.substr(q + 1, e - q - 1));
                const std::string pre = "Named_Boxarts/";
                if (path.compare(0, pre.size(), pre) == 0 && path.size() > 4 && path.substr(path.size() - 4) == ".png")
                    out += path.substr(pre.size(), path.size() - pre.size() - 4) + "\n";
            }
#ifdef _WIN32
            _wremove(wide(json).c_str());
            if (!out.empty()) {
                FILE* f = _wfopen(wide(file).c_str(), L"wb");
                if (f) { fwrite(out.data(), 1, out.size(), f); fclose(f); }
            }
#endif
        }
    }
    std::stringstream in(readFile(file));
    std::string line;
    while (std::getline(in, line)) if (!line.empty()) names.push_back(line);
    auto& toks = s.tokenCache[repo];
    toks.clear();
    for (const auto& n : names) toks.push_back(tokens(n));
    s.indexCache[repo] = names;
    return names;
}

/** Decodifica e reduz (no máximo 320 px de altura) para não pesar na placa de vídeo. */
inline bool decode(const std::string& path, Pixels& px) {
    std::string bytes = readFile(path);
    if (bytes.size() < 16) return false;
    int w = 0, h = 0, n = 0;
    unsigned char* data = stbi_load_from_memory((const unsigned char*)bytes.data(), (int)bytes.size(), &w, &h, &n, 4);
    if (!data) return false;
    int maxH = 320;
    int tw = w, th = h;
    if (h > maxH) { th = maxH; tw = std::max(1, w * maxH / h); }
    px.w = tw;
    px.h = th;
    px.rgba.resize((size_t)tw * th * 4);
    for (int y = 0; y < th; y++) {
        int y0 = y * h / th, y1 = std::max(y0 + 1, (y + 1) * h / th);
        for (int x = 0; x < tw; x++) {
            int x0 = x * w / tw, x1 = std::max(x0 + 1, (x + 1) * w / tw);
            unsigned sum[4] = {0, 0, 0, 0}, cnt = 0;
            for (int yy = y0; yy < y1; yy++)
                for (int xx = x0; xx < x1; xx++) {
                    const unsigned char* p = data + ((size_t)yy * w + xx) * 4;
                    for (int k = 0; k < 4; k++) sum[k] += p[k];
                    cnt++;
                }
            unsigned char* o = &px.rgba[((size_t)y * tw + x) * 4];
            for (int k = 0; k < 4; k++) o[k] = (unsigned char)(sum[k] / cnt);
        }
    }
    stbi_image_free(data);
    return true;
}

inline void work(const std::vector<std::string>& job) {
    State& s = st();
    const std::string &key = job[0], &system = job[1], &title = job[2], &fileStem = job[3], &direct = job[4];
    std::string file = s.dir + hashKey(key) + ".png";
    std::string miss = s.dir + hashKey(key) + ".sem";
    namespace fs = std::filesystem;
    std::error_code ec;
    if (!fs::exists(fs::u8path(file), ec)) {
        // Já procurou e não achou: tenta de novo só depois de 3 dias.
        if (fs::exists(fs::u8path(miss), ec) &&
            std::chrono::duration_cast<std::chrono::hours>(fs::file_time_type::clock::now() - fs::last_write_time(fs::u8path(miss), ec)).count() < 72)
            return;
        bool ok = false;
        if (!direct.empty()) ok = download(direct, file);
        if (!ok) {
            auto r = repos().find(system);
            if (r != repos().end()) {
                for (const auto& repo : r->second) {
                    auto names = index(repo);
                    const auto& toks = s.tokenCache[repo];
                    std::string m = bestMatch(title, names, toks);
                    if (m.empty()) m = bestMatch(fileStem, names, toks);
                    if (m.empty()) continue;
                    ok = download("https://raw.githubusercontent.com/libretro-thumbnails/" + repo + "/master/Named_Boxarts/" + urlEncode(m) + ".png", file);
                    if (ok) break;
                }
            }
        }
        if (!ok) {
#ifdef _WIN32
            FILE* f = _wfopen(wide(miss).c_str(), L"wb");
            if (f) fclose(f);
#endif
            return;
        }
    }
    Pixels px;
    px.key = key;
    if (!decode(file, px)) { fs::remove(fs::u8path(file), ec); return; }
    std::lock_guard<std::mutex> lock(s.mu);
    s.ready.push_back(std::move(px));
}

}  // namespace detail

/** Começa a linha das capas (uma vez). */
inline void start(const std::string& prefPath) {
    detail::State& s = detail::st();
    if (s.started.exchange(true)) return;
    s.dir = prefPath + "capas/";
    std::error_code ec;
    std::filesystem::create_directories(std::filesystem::u8path(s.dir + "indice"), ec);
    std::thread([] {
        detail::State& s = detail::st();
        while (true) {
            std::vector<std::string> job;
            {
                std::unique_lock<std::mutex> lock(s.mu);
                s.cv.wait(lock, [&] { return !s.queue.empty(); });
                job = std::move(s.queue.front());
                s.queue.pop_front();
            }
            try { detail::work(job); } catch (...) {}
        }
    }).detach();
}

/** Pede a capa de um jogo (só a primeira vez conta). Os mais recentes pedidos vêm primeiro (o que está na tela). */
inline void request(const std::string& key, const std::string& system, const std::string& title, const std::string& fileStem,
                    const std::string& directUrl = "") {
    detail::State& s = detail::st();
    std::lock_guard<std::mutex> lock(s.mu);
    if (!s.asked.insert(key).second) return;
    s.queue.push_front({key, system, title, fileStem, directUrl});
    s.cv.notify_one();
}

/** Na tela (linha principal): pega uma capa pronta para virar textura. */
inline bool take(Pixels& out) {
    detail::State& s = detail::st();
    std::lock_guard<std::mutex> lock(s.mu);
    if (s.ready.empty()) return false;
    out = std::move(s.ready.front());
    s.ready.pop_front();
    return true;
}

}  // namespace covers
