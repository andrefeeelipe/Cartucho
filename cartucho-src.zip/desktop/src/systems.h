// Cartucho para Windows — tabela de sistemas, extensões e cores (mesma lógica do app Android).
#pragma once

#include <algorithm>
#include <cctype>
#include <string>
#include <vector>

struct SystemInfo {
    const char* id;
    const char* name;
    const char* shortName;
    const char* core;  // nome do .dll sem "_libretro.dll"
    std::vector<std::string> extensions;
};

inline const std::vector<SystemInfo>& allSystems() {
    static const std::vector<SystemInfo> systems = {
        {"atari2600", "Atari 2600", "2600", "stella", {"a26", "bin"}},
        {"atari7800", "Atari 7800", "7800", "prosystem", {"a78"}},
        {"lynx", "Atari Lynx", "LYNX", "handy", {"lnx"}},
        {"nes", "NES / Famicom", "NES", "fceumm", {"nes", "fds", "unf", "unif", "nez"}},
        {"snes", "Super Nintendo", "SNES", "snes9x", {"sfc", "smc", "fig", "swc", "bs", "st"}},
        {"gb", "Game Boy", "GB", "gambatte", {"gb", "sgb", "dmg"}},
        {"gbc", "Game Boy Color", "GBC", "gambatte", {"gbc", "cgb"}},
        {"gba", "Game Boy Advance", "GBA", "mgba", {"gba", "agb"}},
        {"mastersystem", "Master System", "SMS", "genesis_plus_gx", {"sms", "sg"}},
        {"gamegear", "Game Gear", "GG", "genesis_plus_gx", {"gg"}},
        {"megadrive", "Mega Drive", "MD", "genesis_plus_gx", {"md", "gen", "smd", "bin"}},
        {"segacd", "Sega CD", "SCD", "genesis_plus_gx", {"cue", "chd", "iso"}},
        {"sega32x", "Sega 32X", "32X", "picodrive", {"32x"}},
        {"pce", "PC Engine", "PCE", "mednafen_pce_fast", {"pce", "sgx"}},
        {"pcecd", "PC Engine CD", "PCECD", "mednafen_pce_fast", {"cue", "chd"}},
        {"ngp", "Neo Geo Pocket", "NGP", "mednafen_ngp", {"ngp", "ngc"}},
        {"wswan", "WonderSwan", "WS", "mednafen_wswan", {"ws", "wsc"}},
        {"arcade", "Arcade", "ARC", "fbneo", {"zip"}},
        {"n64", "Nintendo 64", "N64", "mupen64plus_next", {"n64", "z64", "v64"}},
        {"nds", "Nintendo DS", "NDS", "melonds", {"nds"}},
        {"psx", "PlayStation", "PS1", "pcsx_rearmed", {"cue", "chd", "pbp", "iso", "m3u", "bin", "img"}},
        {"psp", "PSP", "PSP", "ppsspp", {"iso", "cso", "pbp"}},
        {"saturn", "Sega Saturn", "SAT", "yabause", {"cue", "chd", "iso"}},
        {"dreamcast", "Dreamcast", "DC", "flycast", {"gdi", "chd", "cdi"}},
        {"ps2", "PlayStation 2", "PS2", "play", {"iso", "chd", "cso"}},
    };
    return systems;
}

inline std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    return s;
}

inline const SystemInfo* systemById(const std::string& id) {
    for (const auto& s : allSystems())
        if (id == s.id) return &s;
    return nullptr;
}

inline std::vector<const SystemInfo*> candidatesFor(const std::string& extIn) {
    std::string ext = lower(extIn);
    std::vector<const SystemInfo*> out;
    for (const auto& s : allSystems())
        for (const auto& e : s.extensions)
            if (e == ext) out.push_back(&s);
    return out;
}

inline bool containsWord(const std::string& hay, const std::string& word) {
    size_t pos = 0;
    while ((pos = hay.find(word, pos)) != std::string::npos) {
        bool startOk = pos == 0 || !std::isalnum((unsigned char)hay[pos - 1]);
        size_t end = pos + word.size();
        bool endOk = end >= hay.size() || !std::isalnum((unsigned char)hay[end]);
        if (startOk && endOk) return true;
        pos = end;
    }
    return false;
}

/** Dica de sistema pelo nome da pasta ("SNES", "Playstation 2", "Mega Drive"...). */
inline const SystemInfo* hintFromFolder(const std::string& folderIn) {
    std::string f = lower(folderIn);
    for (char& ch : f)
        if (ch == '_' || ch == '-') ch = ' ';
    struct H { std::vector<std::string> words; const char* id; };
    static const std::vector<H> hints = {
        {{"super nintendo", "super famicom", "snes", "sfc"}, "snes"},
        {{"game boy advance", "gba"}, "gba"},
        {{"game boy color", "gbc"}, "gbc"},
        {{"game boy", "gb"}, "gb"},
        {{"nintendo 64", "n64"}, "n64"},
        {{"nintendo ds", "nds"}, "nds"},
        {{"famicom", "nes"}, "nes"},
        {{"playstation 2", "ps2"}, "ps2"},
        {{"psp"}, "psp"},
        {{"playstation", "psx", "ps1"}, "psx"},
        {{"sega cd", "mega cd", "segacd"}, "segacd"},
        {{"32x"}, "sega32x"},
        {{"mega drive", "megadrive", "genesis"}, "megadrive"},
        {{"master system", "sms"}, "mastersystem"},
        {{"game gear"}, "gamegear"},
        {{"saturn"}, "saturn"},
        {{"dreamcast"}, "dreamcast"},
        {{"pc engine cd", "turbografx cd"}, "pcecd"},
        {{"pc engine", "turbografx", "pce"}, "pce"},
        {{"neo geo pocket", "ngp"}, "ngp"},
        {{"wonderswan"}, "wswan"},
        {{"arcade", "mame", "fbneo", "fba", "neogeo"}, "arcade"},
        {{"atari 2600", "2600"}, "atari2600"},
        {{"atari 7800", "7800"}, "atari7800"},
        {{"lynx"}, "lynx"},
    };
    for (const auto& h : hints)
        for (const auto& w : h.words)
            if (containsWord(f, w)) return systemById(h.id);
    return nullptr;
}

enum RetroPadId {
    RP_B = 0, RP_Y, RP_SELECT, RP_START, RP_UP, RP_DOWN, RP_LEFT, RP_RIGHT,
    RP_A, RP_X, RP_L, RP_R, RP_L2, RP_R2, RP_L3, RP_R3, RP_COUNT
};

inline const char* retroPadName(int id) {
    static const char* names[RP_COUNT] = {"B", "Y", "Select", "Start", "Cima", "Baixo", "Esquerda", "Direita",
                                          "A", "X", "L", "R", "L2", "R2", "L3", "R3"};
    return (id >= 0 && id < RP_COUNT) ? names[id] : "?";
}
