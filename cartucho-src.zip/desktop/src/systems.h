// Cartucho para Windows — tabela de sistemas, extensões e cores (mesma lógica do app Android).
#pragma once

#include <algorithm>
#include <cstdio>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif
#include <cctype>
#if defined(CARTUCHO_MOBILE)
#include <SDL.h>
#endif
#include <string>
#include <vector>

struct SystemInfo {
    const char* id;
    const char* name;
    const char* shortName;
    const char* core;  // nome do .dll sem "_libretro.dll"
    std::vector<std::string> extensions;
};

inline const std::vector<SystemInfo>& allSystemsFull();

#if defined(CARTUCHO_MOBILE)
/** iPhone: só os consoles cujo emulador veio no app (até PS1 e PSP; sem JIT os mais pesados não rodam). */
inline bool mobileCoreAvailable(const char* core);
inline const std::vector<SystemInfo>& allSystems() {
    static const std::vector<SystemInfo> systems = [] {
        static const char* heavy[] = {"ps2", "gamecube", "wii", "wiiu", "xbox360", "3ds", "dreamcast", "naomi", "saturn"};
        std::vector<SystemInfo> out;
        for (const auto& s : allSystemsFull()) {
            bool skip = false;
            for (const char* h : heavy) if (std::string(s.id) == h) skip = true;
            if (!skip && mobileCoreAvailable(s.core)) out.push_back(s);
        }
        return out;
    }();
    return systems;
}
#else
inline const std::vector<SystemInfo>& allSystems() { return allSystemsFull(); }
#endif

inline const std::vector<SystemInfo>& allSystemsFull() {
    static const std::vector<SystemInfo> systems = {
        {"atari2600", "Atari 2600", "2600", "stella", {"a26", "bin"}},
        {"atari7800", "Atari 7800", "7800", "prosystem", {"a78"}},
        {"lynx", "Atari Lynx", "LYNX", "handy", {"lnx"}},
        {"nes", "NES / Famicom", "NES", "fceumm", {"nes", "fds", "unf", "unif", "nez"}},
        {"snes", "Super Nintendo", "SNES", "snes9x", {"sfc", "smc", "fig", "swc", "bs", "st"}},
        {"gb", "Game Boy", "GB", "gambatte", {"gb", "sgb", "dmg"}},
        {"gbc", "Game Boy Color", "GBC", "gambatte", {"gbc", "cgb"}},
        {"gba", "Game Boy Advance", "GBA", "mgba", {"gba", "agb"}},
        {"mastersystem", "Master System", "SMS", "genesis_plus_gx", {"sms", "sg"}},
        {"gamegear", "Game Gear", "GG", "genesis_plus_gx", {"gg"}},
        {"megadrive", "Mega Drive", "MD", "genesis_plus_gx", {"md", "gen", "smd", "bin"}},
        {"segacd", "Sega CD", "SCD", "genesis_plus_gx", {"cue", "chd", "iso"}},
        {"sega32x", "Sega 32X", "32X", "picodrive", {"32x"}},
        {"pce", "PC Engine", "PCE", "mednafen_pce_fast", {"pce", "sgx"}},
        {"pcecd", "PC Engine CD", "PCECD", "mednafen_pce_fast", {"cue", "chd"}},
        {"ngp", "Neo Geo Pocket", "NGP", "mednafen_ngp", {"ngp", "ngc"}},
        {"wswan", "WonderSwan", "WS", "mednafen_wswan", {"ws", "wsc"}},
        {"arcade", "Arcade", "ARC", "fbneo", {"zip"}},
        {"n64", "Nintendo 64", "N64", "mupen64plus_next", {"n64", "z64", "v64"}},
        {"nds", "Nintendo DS", "NDS", "melonds", {"nds", "dsi", "srl"}},
        {"3ds", "Nintendo 3DS", "3DS", "citra", {"3ds", "3dsx", "cci", "cxi"}},
        {"psx", "PlayStation", "PS1", "pcsx_rearmed", {"cue", "chd", "pbp", "iso", "m3u", "bin", "img"}},
        {"psp", "PSP", "PSP", "ppsspp", {"iso", "cso", "pbp"}},
        {"saturn", "Sega Saturn", "SAT", "yabause", {"cue", "chd", "iso"}},
        {"dreamcast", "Dreamcast", "DC", "flycast", {"gdi", "chd", "cdi"}},
        {"ps2", "PlayStation 2", "PS2", "play", {"iso", "chd", "cso"}},
        {"gamecube", "GameCube", "GC", "dolphin", {"gcm", "iso", "rvz", "gcz", "ciso", "wia", "dol", "tgc"}},
        {"wii", "Wii", "WII", "dolphin", {"wbfs", "rvz", "iso", "wia", "gcz", "wad"}},
        {"3do", "3DO", "3DO", "opera", {"iso", "chd", "cue"}},
        {"jaguar", "Atari Jaguar", "JAG", "virtualjaguar", {"j64", "jag"}},
        {"atari5200", "Atari 5200", "5200", "atari800", {"a52"}},
        {"atari800", "Atari 800 / XL", "A800", "atari800", {"atr", "xex", "xfd", "atx", "cas", "car"}},
        {"vectrex", "Vectrex", "VEC", "vecx", {"vec", "gam"}},
        {"virtualboy", "Virtual Boy", "VB", "mednafen_vb", {"vb", "vboy"}},
        {"neogeocd", "Neo Geo CD", "NGCD", "neocd", {"cue", "chd"}},
        {"pcfx", "PC-FX", "PCFX", "mednafen_pcfx", {"cue", "chd", "ccd"}},
        {"colecovision", "ColecoVision", "CV", "gearcoleco", {"col", "cv"}},
        {"intellivision", "Intellivision", "INTV", "freeintv", {"int", "intv"}},
        {"odyssey2", "Odyssey 2", "O2", "o2em", {"o2"}},
        {"channelf", "Channel F", "CHF", "freechaf", {"chf"}},
        {"msx", "MSX", "MSX", "bluemsx", {"mx1", "mx2", "rom", "dsk", "cas"}},
        {"zxspectrum", "ZX Spectrum", "ZX", "fuse", {"tzx", "tap", "z80", "sna", "szx", "scl", "trd"}},
        {"amstradcpc", "Amstrad CPC", "CPC", "cap32", {"cdt", "cpr", "dsk", "sna"}},
        {"c64", "Commodore 64", "C64", "vice_x64sc", {"d64", "t64", "prg", "crt", "g64", "d71", "d81", "x64", "tap"}},
        {"amiga", "Amiga", "AMI", "puae", {"adf", "adz", "dms", "ipf", "hdf", "lha", "uae"}},
        {"dos", "DOS (PC antigo)", "DOS", "dosbox_pure", {"exe", "dosz"}},
        {"pokemini", "Pokemon Mini", "PM", "pokemini", {"min"}},
        {"supervision", "Watara Supervision", "SV", "potator", {"sv"}},
        {"arduboy", "Arduboy", "ARB", "arduous", {"hex", "arduboy"}},
        {"tic80", "TIC-80", "TIC", "tic80", {"tic"}},
        {"cdi", "Philips CD-i", "CDI", "same_cdi", {"chd"}},
        {"neogeo", "Neo Geo (AES/MVS)", "NEO", "geolith", {"neo"}},
        {"naomi", "Sega Naomi / Atomiswave", "NAOMI", "flycast", {"lst", "dat"}},
        {"megaduck", "Mega Duck", "DUCK", "sameduck", {"md1", "md2", "bin"}},
        {"arcadia", "Emerson Arcadia 2001", "A2001", "amiarcadia", {"tvc", "bin"}},
        {"scv", "Epoch Super Cassette Vision", "SCV", "emuscv", {"cart", "bin", "rom", "0"}},
        {"hyperscan", "Mattel HyperScan", "HYPER", "hyperscanemu", {"iso", "chd"}},
        {"uzebox", "Uzebox", "UZE", "uzem", {"uze"}},
        {"gametank", "GameTank", "GTK", "gametank", {"gtr"}},
        {"vmu", "VMU do Dreamcast", "VMU", "vemulator", {"vms", "dci"}},
        {"j2me", "Celular Java (J2ME)", "JAVA", "squirreljme", {"jar", "jad"}},
        {"palm", "Palm OS", "PALM", "mu", {"prc", "pqa"}},
        {"ti83", "Calculadora TI-83", "TI83", "numero", {"8xp", "8xk", "8xg", "83p"}},
        {"appleii", "Apple II", "APL2", "applewin", {"do", "po", "nib", "woz", "2mg", "dsk"}},
        {"mac", "Macintosh clássico", "MAC", "minivmac", {"hvf", "dsk", "img"}},
        {"atarist", "Atari ST", "ST", "hatari", {"st", "msa", "stx", "dim", "ipf"}},
        {"zx81", "ZX81", "ZX81", "81", {"p", "81"}},
        {"bbcmicro", "BBC Micro", "BBC", "b2", {"ssd", "dsd", "uef"}},
        {"vic20", "Commodore VIC-20", "VIC", "vice_xvic", {"20", "40", "60", "a0", "b0", "prg", "d64", "crt", "tap"}},
        {"plus4", "Commodore Plus/4", "+4", "vice_xplus4", {"prg", "d64", "tap", "crt"}},
        {"pet", "Commodore PET", "PET", "vice_xpet", {"prg", "d64", "tap"}},
        {"c128", "Commodore 128", "C128", "vice_x128", {"d64", "d71", "d81", "prg", "crt"}},
        {"pc88", "NEC PC-88", "PC88", "quasi88", {"d88", "t88", "cmt"}},
        {"pc98", "NEC PC-98", "PC98", "np2kai", {"d98", "fdi", "hdi", "fdd", "nhd", "thd", "hdd", "98d"}},
        {"x68000", "Sharp X68000", "X68K", "px68k", {"xdf", "2hd", "hdm", "dim", "d88", "hdf"}},
        {"x1", "Sharp X1", "X1", "x1", {"2d", "tfd", "88d", "dx1", "d88", "2hd"}},
        {"fmtowns", "FM Towns", "TOWNS", "geartowns", {"cue", "chd", "iso"}},
        {"enterprise", "Enterprise 128", "EP", "ep128emu_core", {"dtf", "128", "trn", "img"}},
        {"thomson", "Thomson MO/TO", "TO", "theodore", {"fd", "sap", "k7", "m5", "m7"}},
        {"p2000", "Philips P2000", "P2K", "m2000", {"cas"}},
        {"bk", "Elektronika BK", "BK", "bk", {"bin"}},
        {"galaksija", "Galaksija", "GAL", "galaksija", {"gtp", "tap"}},
        {"pico8", "PICO-8", "P8", "retro8", {"p8"}},
        {"wasm4", "WASM-4", "W4", "wasm4", {"wasm"}},
        {"lowresnx", "LowRes NX", "LRNX", "lowresnx", {"nx"}},
        {"rpgmaker", "RPG Maker 2000/2003", "RPGM", "easyrpg", {"ldb", "easyrpg"}},
        {"scummvm", "ScummVM (aventuras)", "SCUMM", "scummvm", {"scummvm"}},
        {"doom", "Doom", "DOOM", "prboom", {"wad", "iwad", "pwad"}},
        {"quake", "Quake", "QUAKE", "tyrquake", {"pak"}},
        {"wolf3d", "Wolfenstein 3D", "WOLF", "ecwolf", {"wl6", "wl1", "n3d", "sod", "sdm", "sd2", "sd3", "pk3"}},
        {"duke3d", "Duke Nukem 3D", "DUKE", "eduke32", {"grp"}},
        {"cavestory", "Cave Story", "CAVE", "nxengine", {"cavestory"}},
        {"outrun", "OutRun (Cannonball)", "ORUN", "cannonball", {"88", "132"}},
        {"wiiu", "Wii U (beta)", "WIIU", "cemu", {"wua", "wud", "wux", "rpx", "wuhb"}},
        {"xbox360", "Xbox 360 (beta)", "X360", "xenia_edge", {"xex", "zar", "xcp", "iso"}},
        {"gameandwatch", "Game & Watch", "G&W", "gw", {"mgw"}},
    };
    return systems;
}

#if defined(CARTUCHO_MOBILE)
inline bool mobileCoreAvailable(const char* core) {
#if defined(CARTUCHO_IOS)
    static std::string base = [] {
        char* b = SDL_GetBasePath();
        std::string r = b ? b : "./";
        SDL_free(b);
        return r;
    }();
    std::string path = base + "Frameworks/" + core + ".framework/" + core;
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return false;
    fclose(f);
    return true;
#else
    (void)core;
    return true;
#endif
}
#endif

inline std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    return s;
}

inline const SystemInfo* systemById(const std::string& id) {
    for (const auto& s : allSystems())
        if (id == s.id) return &s;
    return nullptr;
}

inline std::vector<const SystemInfo*> candidatesFor(const std::string& extIn) {
    std::string ext = lower(extIn);
    std::vector<const SystemInfo*> out;
    for (const auto& s : allSystems())
        for (const auto& e : s.extensions)
            if (e == ext) out.push_back(&s);
    return out;
}

inline bool containsWord(const std::string& hay, const std::string& word) {
    size_t pos = 0;
    while ((pos = hay.find(word, pos)) != std::string::npos) {
        bool startOk = pos == 0 || !std::isalnum((unsigned char)hay[pos - 1]);
        size_t end = pos + word.size();
        bool endOk = end >= hay.size() || !std::isalnum((unsigned char)hay[end]);
        if (startOk && endOk) return true;
        pos = end;
    }
    return false;
}

/** Lê o cabeçalho de discos e descobre o sistema quando a extensão é ambígua (.iso, .rvz, .wia, .bin). */
inline const char* sniffDisc(const std::string& path, const std::string& extIn) {
    std::string ext = lower(extIn);
    FILE* f = nullptr;
#ifdef _WIN32
    int n = MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, nullptr, 0);
    std::wstring w(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, &w[0], n);
    f = _wfopen(w.c_str(), L"rb");
#else
    f = fopen(path.c_str(), "rb");
#endif
    if (!f) return nullptr;
    std::vector<unsigned char> h(0x9400, 0);
    size_t got = fread(h.data(), 1, h.size(), f);
#ifdef _WIN32
    _fseeki64(f, 0, SEEK_END);
    long long size = _ftelli64(f);
#else
    fseeko(f, 0, SEEK_END);
    long long size = (long long)ftello(f);
#endif
    fclose(f);
    if (got < 0x60) return nullptr;
    auto be = [&](size_t o) { return ((unsigned)h[o] << 24) | ((unsigned)h[o + 1] << 16) | ((unsigned)h[o + 2] << 8) | h[o + 3]; };
    auto is3do = [&](size_t at) { if (got < at + 8 || h[at] != 1 || h[at + 6] != 1) return false; for (int i = 1; i <= 5; i++) if (h[at + i] != 0x5A) return false; return true; };
    if (ext == "rvz" || ext == "wia") {
        unsigned t = be(0x48);
        return t == 1 ? "gamecube" : t == 2 ? "wii" : nullptr;
    }
    if (be(0x18) == 0x5D1C9EA3u) return "wii";
    if (be(0x1C) == 0xC2339F3Du) return "gamecube";
    if (is3do(0) || is3do(0x10)) return "3do";
    std::string s0(reinterpret_cast<const char*>(h.data()), 16), s1(reinterpret_cast<const char*>(h.data()) + 0x10, 16);
    if (s0.rfind("SEGADISCSYSTEM", 0) == 0 || s1.rfind("SEGADISCSYSTEM", 0) == 0) return "segacd";
    if (s0.rfind("SEGA SEGASATURN", 0) == 0 || s1.rfind("SEGA SEGASATURN", 0) == 0) return "saturn";
    if (ext == "iso" && size > 0x10014) {
        // Xbox 360 (XDVDFS): "MICROSOFT*XBOX*MEDIA" 64 KB depois do início da partição do jogo.
        FILE* g = nullptr;
#ifdef _WIN32
        g = _wfopen(w.c_str(), L"rb");
#else
        g = fopen(path.c_str(), "rb");
#endif
        if (g) {
            const long long starts[] = {0LL, 0x2080000LL, 0xFD90000LL};
            char tag[21] = {};
            bool xbox = false;
            for (long long st : starts) {
                if (st + 0x10014 > size) break;
#ifdef _WIN32
                _fseeki64(g, st + 0x10000, SEEK_SET);
#else
                fseeko(g, (off_t)(st + 0x10000), SEEK_SET);
#endif
                if (fread(tag, 1, 20, g) == 20 && std::string(tag, 20) == "MICROSOFT*XBOX*MEDIA") { xbox = true; break; }
            }
            fclose(g);
            if (xbox) return "xbox360";
        }
    }
    if (got >= 0x8030 && std::string(reinterpret_cast<const char*>(h.data()) + 0x8001, 5) == "CD001") {
        std::string sysId(reinterpret_cast<const char*>(h.data()) + 0x8008, 32);
        if (sysId.find("PSP GAME") != std::string::npos) return "psp";
        if (sysId.find("PLAYSTATION") != std::string::npos) return size > 800000000LL ? "ps2" : "psx";
    }
    return nullptr;
}

/** Dica de sistema pelo nome da pasta ("SNES", "Playstation 2", "Mega Drive"...). */
inline const SystemInfo* hintFromFolder(const std::string& folderIn) {
    std::string f = lower(folderIn);
    for (char& ch : f)
        if (ch == '_' || ch == '-') ch = ' ';
    struct H { std::vector<std::string> words; const char* id; };
    static const std::vector<H> hints = {
        {{"gamecube", "game cube", "ngc", "gc"}, "gamecube"},
        {{"wii u", "wiiu"}, "wiiu"},
        {{"xbox 360", "x360", "xbox360"}, "xbox360"},
        {{"wii"}, "wii"},
        {{"3do"}, "3do"},
        {{"jaguar"}, "jaguar"},
        {{"atari 5200", "5200"}, "atari5200"},
        {{"atari 800", "atari xl", "atari xe", "atari 8 bit"}, "atari800"},
        {{"vectrex"}, "vectrex"},
        {{"virtual boy", "virtualboy"}, "virtualboy"},
        {{"neo geo cd", "neogeo cd", "neogeocd"}, "neogeocd"},
        {{"pc fx", "pcfx"}, "pcfx"},
        {{"colecovision", "coleco"}, "colecovision"},
        {{"intellivision"}, "intellivision"},
        {{"odyssey", "videopac"}, "odyssey2"},
        {{"channel f"}, "channelf"},
        {{"msx", "msx2"}, "msx"},
        {{"zx spectrum", "spectrum", "zx"}, "zxspectrum"},
        {{"amstrad", "cpc"}, "amstradcpc"},
        {{"commodore 64", "c64", "commodore"}, "c64"},
        {{"amiga"}, "amiga"},
        {{"dos", "ms dos", "msdos"}, "dos"},
        {{"pokemon mini"}, "pokemini"},
        {{"supervision"}, "supervision"},
        {{"arduboy"}, "arduboy"},
        {{"tic 80", "tic80"}, "tic80"},
        {{"philips cd i", "philips cdi", "cd i"}, "cdi"},
        {{"naomi", "atomiswave"}, "naomi"},
        {{"mega duck", "megaduck"}, "megaduck"},
        {{"arcadia", "interton"}, "arcadia"},
        {{"super cassette", "scv"}, "scv"},
        {{"hyperscan"}, "hyperscan"},
        {{"uzebox"}, "uzebox"},
        {{"gametank", "game tank"}, "gametank"},
        {{"vmu", "visual memory"}, "vmu"},
        {{"j2me", "java", "celular"}, "j2me"},
        {{"palm"}, "palm"},
        {{"ti 83", "ti83", "ti 83"}, "ti83"},
        {{"apple ii", "apple 2", "appleii"}, "appleii"},
        {{"macintosh", "mac"}, "mac"},
        {{"atari st"}, "atarist"},
        {{"zx81", "zx 81", "tk85"}, "zx81"},
        {{"bbc micro", "bbc", "acorn"}, "bbcmicro"},
        {{"vic 20", "vic20", "vic 20"}, "vic20"},
        {{"plus4", "plus 4", "c16"}, "plus4"},
        {{"commodore pet", "pet"}, "pet"},
        {{"c128", "commodore 128"}, "c128"},
        {{"pc 88", "pc88", "pc 8801"}, "pc88"},
        {{"pc 98", "pc98", "pc 9801"}, "pc98"},
        {{"x68000", "x68k"}, "x68000"},
        {{"sharp x1"}, "x1"},
        {{"fm towns", "fmtowns"}, "fmtowns"},
        {{"enterprise"}, "enterprise"},
        {{"thomson"}, "thomson"},
        {{"p2000"}, "p2000"},
        {{"elektronika"}, "bk"},
        {{"galaksija"}, "galaksija"},
        {{"pico 8", "pico8"}, "pico8"},
        {{"wasm 4", "wasm4"}, "wasm4"},
        {{"lowres"}, "lowresnx"},
        {{"rpg maker", "rpgmaker"}, "rpgmaker"},
        {{"scummvm", "scumm"}, "scummvm"},
        {{"doom", "freedoom"}, "doom"},
        {{"quake"}, "quake"},
        {{"wolfenstein", "wolf3d"}, "wolf3d"},
        {{"duke nukem", "duke3d"}, "duke3d"},
        {{"cave story", "doukutsu"}, "cavestory"},
        {{"outrun", "out run", "cannonball"}, "outrun"},
        {{"game and watch", "game & watch", "game e watch"}, "gameandwatch"},
        {{"super nintendo", "super famicom", "snes", "sfc"}, "snes"},
        {{"game boy advance", "gba"}, "gba"},
        {{"game boy color", "gbc"}, "gbc"},
        {{"game boy", "gb"}, "gb"},
        {{"nintendo 64", "n64"}, "n64"},
        {{"nintendo 3ds", "3ds"}, "3ds"},
        {{"nintendo ds", "nds"}, "nds"},
        {{"famicom", "nes"}, "nes"},
        {{"playstation 2", "ps2"}, "ps2"},
        {{"psp"}, "psp"},
        {{"playstation", "psx", "ps1"}, "psx"},
        {{"sega cd", "mega cd", "segacd"}, "segacd"},
        {{"32x"}, "sega32x"},
        {{"mega drive", "megadrive", "genesis"}, "megadrive"},
        {{"master system", "sms"}, "mastersystem"},
        {{"game gear"}, "gamegear"},
        {{"saturn"}, "saturn"},
        {{"dreamcast"}, "dreamcast"},
        {{"pc engine cd", "turbografx cd"}, "pcecd"},
        {{"pc engine", "turbografx", "pce"}, "pce"},
        {{"neo geo pocket", "ngp"}, "ngp"},
        {{"wonderswan"}, "wswan"},
        {{"arcade", "mame", "fbneo", "fba", "neogeo"}, "arcade"},
        {{"atari 2600", "2600"}, "atari2600"},
        {{"atari 7800", "7800"}, "atari7800"},
        {{"lynx"}, "lynx"},
    };
    for (const auto& h : hints)
        for (const auto& w : h.words)
            if (containsWord(f, w)) return systemById(h.id);
    return nullptr;
}

enum RetroPadId {
    RP_B = 0, RP_Y, RP_SELECT, RP_START, RP_UP, RP_DOWN, RP_LEFT, RP_RIGHT,
    RP_A, RP_X, RP_L, RP_R, RP_L2, RP_R2, RP_L3, RP_R3, RP_COUNT
};

inline const char* retroPadName(int id) {
    static const char* names[RP_COUNT] = {"B", "Y", "Select", "Start", "Cima", "Baixo", "Esquerda", "Direita",
                                          "A", "X", "L", "R", "L2", "R2", "L3", "R3"};
    return (id >= 0 && id < RP_COUNT) ? names[id] : "?";
}
