// Cartucho para Windows — saves na nuvem (Google Drive), na mesma pasta usada pelo app do celular.
//
// Entrar: o navegador abre a página do Google; a resposta volta para um endereço local
// (http://127.0.0.1:<porta>), como o Google recomenda para programas de computador (OAuth com PKCE).
// O token fica cifrado pelo Windows (DPAPI) na pasta do usuário. Permissão "drive.file": o
// Cartucho só enxerga os arquivos que ele mesmo criou (a pasta "Cartucho" com os saves).
//
// Sincronizar: espelha a pasta local saves/<sistema>/ com Cartucho/saves/<sistema>/ no Drive.
// O arquivo mais novo vence; o que seria substituído vai antes para backup-saves/ (5 cópias).
#pragma once

#ifdef _WIN32

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <bcrypt.h>
#include <shellapi.h>
#include <wincrypt.h>
#include <winhttp.h>

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <map>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#ifndef CARTUCHO_GOOGLE_ID
#define CARTUCHO_GOOGLE_ID ""
#endif
#ifndef CARTUCHO_GOOGLE_SECRET
#define CARTUCHO_GOOGLE_SECRET ""
#endif

namespace gdrive {

namespace fs = std::filesystem;

// ------------------------------------------------------------------ texto

inline std::wstring wide(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), w.data(), n);
    return w;
}

inline std::string narrow(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), s.data(), n, nullptr, nullptr);
    return s;
}

inline std::string urlEncode(const std::string& s) {
    static const char* hex = "0123456789ABCDEF";
    std::string o;
    for (unsigned char c : s) {
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c;
        else { o += '%'; o += hex[c >> 4]; o += hex[c & 15]; }
    }
    return o;
}

inline std::string base64url(const unsigned char* data, size_t len) {
    static const char* t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    std::string o;
    for (size_t i = 0; i < len; i += 3) {
        unsigned v = data[i] << 16 | (i + 1 < len ? data[i + 1] << 8 : 0) | (i + 2 < len ? data[i + 2] : 0);
        o += t[(v >> 18) & 63];
        o += t[(v >> 12) & 63];
        if (i + 1 < len) o += t[(v >> 6) & 63];
        if (i + 2 < len) o += t[v & 63];
    }
    return o;
}

inline std::string randomToken(size_t bytes = 32) {
    std::vector<unsigned char> b(bytes);
    BCryptGenRandom(nullptr, b.data(), (ULONG)b.size(), BCRYPT_USE_SYSTEM_PREFERRED_RNG);
    return base64url(b.data(), b.size());
}

inline std::string sha256b64url(const std::string& s) {
    unsigned char hash[32] = {};
    BCRYPT_ALG_HANDLE alg = nullptr;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) == 0) {
        BCryptHash(alg, nullptr, 0, (PUCHAR)s.data(), (ULONG)s.size(), hash, sizeof(hash));
        BCryptCloseAlgorithmProvider(alg, 0);
    }
    return base64url(hash, sizeof(hash));
}

// ------------------------------------------------------------------ JSON mínimo

struct Json {
    enum Type { Null, Bool, Num, Str, Arr, Obj } type = Null;
    double num = 0;
    bool b = false;
    std::string str;
    std::vector<Json> arr;
    std::map<std::string, Json> obj;

    const Json& operator[](const std::string& k) const {
        static Json none;
        auto it = obj.find(k);
        return it == obj.end() ? none : it->second;
    }
    std::string s() const { return type == Str ? str : std::string(); }
};

struct JsonParser {
    const std::string& t;
    size_t p = 0;
    explicit JsonParser(const std::string& text) : t(text) {}
    void ws() { while (p < t.size() && isspace((unsigned char)t[p])) p++; }
    Json value() {
        ws();
        Json j;
        if (p >= t.size()) return j;
        char c = t[p];
        if (c == '{') {
            j.type = Json::Obj;
            p++;
            ws();
            if (p < t.size() && t[p] == '}') { p++; return j; }
            while (p < t.size()) {
                ws();
                std::string k = string();
                ws();
                if (p < t.size() && t[p] == ':') p++;
                j.obj[k] = value();
                ws();
                if (p < t.size() && t[p] == ',') { p++; continue; }
                if (p < t.size() && t[p] == '}') { p++; break; }
                break;
            }
        } else if (c == '[') {
            j.type = Json::Arr;
            p++;
            ws();
            if (p < t.size() && t[p] == ']') { p++; return j; }
            while (p < t.size()) {
                j.arr.push_back(value());
                ws();
                if (p < t.size() && t[p] == ',') { p++; continue; }
                if (p < t.size() && t[p] == ']') { p++; break; }
                break;
            }
        } else if (c == '"') {
            j.type = Json::Str;
            j.str = string();
        } else if (t.compare(p, 4, "true") == 0) { j.type = Json::Bool; j.b = true; p += 4; }
        else if (t.compare(p, 5, "false") == 0) { j.type = Json::Bool; p += 5; }
        else if (t.compare(p, 4, "null") == 0) { p += 4; }
        else {
            size_t start = p;
            while (p < t.size() && (isdigit((unsigned char)t[p]) || strchr("+-.eE", t[p]))) p++;
            j.type = Json::Num;
            j.num = atof(t.substr(start, p - start).c_str());
        }
        return j;
    }
    std::string string() {
        std::string o;
        if (p >= t.size() || t[p] != '"') return o;
        p++;
        while (p < t.size() && t[p] != '"') {
            char c = t[p++];
            if (c == '\\' && p < t.size()) {
                char e = t[p++];
                switch (e) {
                    case 'n': o += '\n'; break;
                    case 't': o += '\t'; break;
                    case 'r': o += '\r'; break;
                    case 'b': o += '\b'; break;
                    case 'f': o += '\f'; break;
                    case 'u': {
                        unsigned cp = (unsigned)strtoul(t.substr(p, 4).c_str(), nullptr, 16);
                        p += 4;
                        if (cp >= 0xD800 && cp <= 0xDBFF && t.compare(p, 2, "\\u") == 0) {
                            unsigned lo = (unsigned)strtoul(t.substr(p + 2, 4).c_str(), nullptr, 16);
                            p += 6;
                            cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                        }
                        if (cp < 0x80) o += (char)cp;
                        else if (cp < 0x800) { o += (char)(0xC0 | cp >> 6); o += (char)(0x80 | (cp & 63)); }
                        else if (cp < 0x10000) { o += (char)(0xE0 | cp >> 12); o += (char)(0x80 | ((cp >> 6) & 63)); o += (char)(0x80 | (cp & 63)); }
                        else { o += (char)(0xF0 | cp >> 18); o += (char)(0x80 | ((cp >> 12) & 63)); o += (char)(0x80 | ((cp >> 6) & 63)); o += (char)(0x80 | (cp & 63)); }
                        break;
                    }
                    default: o += e;
                }
            } else o += c;
        }
        p++;
        return o;
    }
};

inline Json parseJson(const std::string& s) { JsonParser jp(s); return jp.value(); }

inline std::string jsonEscape(const std::string& s) {
    std::string o;
    for (char c : s) {
        if (c == '"' || c == '\\') { o += '\\'; o += c; }
        else if ((unsigned char)c < 0x20) { char b[8]; snprintf(b, sizeof(b), "\\u%04x", c); o += b; }
        else o += c;
    }
    return o;
}

// ------------------------------------------------------------------ HTTP (WinHTTP)

struct Response {
    int status = 0;
    std::string body;
};

inline Response http(const std::string& method, const std::string& url, const std::vector<std::string>& headers = {},
                     const std::string& body = std::string()) {
    Response r;
    URL_COMPONENTS uc{};
    uc.dwStructSize = sizeof(uc);
    wchar_t host[256] = {}, path[4096] = {};
    uc.lpszHostName = host;
    uc.dwHostNameLength = 256;
    uc.lpszUrlPath = path;
    uc.dwUrlPathLength = 4096;
    wchar_t extra[4096] = {};
    uc.lpszExtraInfo = extra;
    uc.dwExtraInfoLength = 4096;
    std::wstring wurl = wide(url);
    if (!WinHttpCrackUrl(wurl.c_str(), 0, 0, &uc)) return r;
    HINTERNET s = WinHttpOpen(L"Cartucho/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!s) return r;
    WinHttpSetTimeouts(s, 15000, 15000, 30000, 60000);
    HINTERNET c = WinHttpConnect(s, host, uc.nPort, 0);
    std::wstring full = std::wstring(path) + extra;
    HINTERNET q = c ? WinHttpOpenRequest(c, wide(method).c_str(), full.c_str(), nullptr, WINHTTP_NO_REFERER,
                                         WINHTTP_DEFAULT_ACCEPT_TYPES, uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0)
                    : nullptr;
    if (q) {
        std::wstring hs;
        for (const auto& h : headers) hs += wide(h) + L"\r\n";
        BOOL ok = WinHttpSendRequest(q, hs.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : hs.c_str(), (DWORD)-1L,
                                     body.empty() ? WINHTTP_NO_REQUEST_DATA : (LPVOID)body.data(), (DWORD)body.size(), (DWORD)body.size(), 0);
        if (ok && WinHttpReceiveResponse(q, nullptr)) {
            DWORD code = 0, len = sizeof(code);
            WinHttpQueryHeaders(q, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &code, &len, WINHTTP_NO_HEADER_INDEX);
            r.status = (int)code;
            DWORD avail = 0;
            while (WinHttpQueryDataAvailable(q, &avail) && avail > 0) {
                std::string chunk(avail, 0);
                DWORD read = 0;
                if (!WinHttpReadData(q, chunk.data(), avail, &read) || read == 0) break;
                r.body.append(chunk.data(), read);
            }
        }
        WinHttpCloseHandle(q);
    }
    if (c) WinHttpCloseHandle(c);
    WinHttpCloseHandle(s);
    return r;
}

// ------------------------------------------------------------------ arquivos e horários

inline long long fileMtimeMs(const std::string& path) {
    WIN32_FILE_ATTRIBUTE_DATA d{};
    if (!GetFileAttributesExW(wide(path).c_str(), GetFileExInfoStandard, &d)) return 0;
    ULARGE_INTEGER u;
    u.LowPart = d.ftLastWriteTime.dwLowDateTime;
    u.HighPart = d.ftLastWriteTime.dwHighDateTime;
    return (long long)(u.QuadPart / 10000ULL) - 11644473600000LL;
}

inline void setFileMtimeMs(const std::string& path, long long ms) {
    HANDLE h = CreateFileW(wide(path).c_str(), FILE_WRITE_ATTRIBUTES, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE) return;
    ULARGE_INTEGER u;
    u.QuadPart = (unsigned long long)(ms + 11644473600000LL) * 10000ULL;
    FILETIME ft{u.LowPart, u.HighPart};
    SetFileTime(h, nullptr, nullptr, &ft);
    CloseHandle(h);
}

inline long long parseRfc3339(const std::string& s) {
    int Y, M, D, h, m;
    double sec;
    if (sscanf(s.c_str(), "%d-%d-%dT%d:%d:%lfZ", &Y, &M, &D, &h, &m, &sec) < 6) return 0;
    std::tm tm{};
    tm.tm_year = Y - 1900;
    tm.tm_mon = M - 1;
    tm.tm_mday = D;
    tm.tm_hour = h;
    tm.tm_min = m;
    tm.tm_sec = (int)sec;
    return (long long)_mkgmtime(&tm) * 1000LL + (long long)((sec - (int)sec) * 1000);
}

inline std::string readFile(const std::string& path) {
    std::ifstream in(fs::path(wide(path)), std::ios::binary);
    std::stringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

inline bool writeFile(const std::string& path, const std::string& data) {
    std::ofstream out(fs::path(wide(path)), std::ios::binary | std::ios::trunc);
    out.write(data.data(), (std::streamsize)data.size());
    return (bool)out;
}

// ------------------------------------------------------------------ conta

struct State {
    std::mutex mu;
    std::string status = "";     // texto para a tela de ajustes
    std::string email;
    std::atomic<bool> busy{false};
    long long lastSync = 0;
};

inline State& state() { static State s; return s; }

inline bool configured() { return std::string(CARTUCHO_GOOGLE_ID).size() > 10; }

inline void setStatus(const std::string& s) {
    std::lock_guard<std::mutex> l(state().mu);
    state().status = s;
}

inline std::string status() {
    std::lock_guard<std::mutex> l(state().mu);
    return state().status;
}

class Account {
public:
    explicit Account(std::string dir) : dir_(std::move(dir)) { load(); }

    bool signedIn() const { return !refresh_.empty(); }
    std::string email() const { return email_; }

    /** Abre o navegador, espera a resposta do Google e guarda o acesso. Bloqueia (até 3 minutos). */
    bool signIn(std::string& error) {
        if (!configured()) { error = "Esta versão foi compilada sem o acesso ao Google Drive."; return false; }
        WSADATA wsa;
        WSAStartup(MAKEWORD(2, 2), &wsa);
        SOCKET ls = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        sockaddr_in a{};
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        a.sin_port = 0;
        if (ls == INVALID_SOCKET || bind(ls, (sockaddr*)&a, sizeof(a)) != 0 || listen(ls, 1) != 0) {
            error = "Não foi possível abrir a porta local para o login.";
            if (ls != INVALID_SOCKET) closesocket(ls);
            return false;
        }
        int alen = sizeof(a);
        getsockname(ls, (sockaddr*)&a, &alen);
        std::string redirect = "http://127.0.0.1:" + std::to_string(ntohs(a.sin_port));
        std::string verifier = randomToken(48);
        std::string stateTok = randomToken(16);
        std::string url = "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + urlEncode(CARTUCHO_GOOGLE_ID) +
                          "&redirect_uri=" + urlEncode(redirect) + "&response_type=code" +
                          "&scope=" + urlEncode("https://www.googleapis.com/auth/drive.file email") +
                          "&code_challenge=" + sha256b64url(verifier) + "&code_challenge_method=S256" +
                          "&access_type=offline&prompt=consent&state=" + stateTok;
        ShellExecuteW(nullptr, L"open", wide(url).c_str(), nullptr, nullptr, SW_SHOWNORMAL);

        // Espera o navegador voltar com o código.
        fd_set set;
        FD_ZERO(&set);
        FD_SET(ls, &set);
        timeval tv{180, 0};
        if (select(0, &set, nullptr, nullptr, &tv) <= 0) { closesocket(ls); error = "O login não foi concluído a tempo."; return false; }
        SOCKET cs = accept(ls, nullptr, nullptr);
        closesocket(ls);
        if (cs == INVALID_SOCKET) { error = "Falha ao receber a resposta do Google."; return false; }
        char buf[8192] = {};
        int n = recv(cs, buf, sizeof(buf) - 1, 0);
        std::string req(buf, n > 0 ? n : 0);
        std::string code = queryParam(req, "code"), gotState = queryParam(req, "state");
        std::string page = code.empty()
            ? "<h2>O login foi cancelado.</h2><p>Pode fechar esta aba e tentar de novo no Cartucho.</p>"
            : "<h2>Pronto! O Cartucho está ligado ao seu Google Drive.</h2><p>Pode fechar esta aba e voltar ao jogo.</p>";
        std::string resp = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n"
                           "<html><body style=\"font-family:sans-serif;max-width:520px;margin:60px auto\">" + page + "</body></html>";
        send(cs, resp.data(), (int)resp.size(), 0);
        closesocket(cs);
        if (code.empty() || gotState != stateTok) { error = "O login foi cancelado."; return false; }

        Response r = http("POST", "https://oauth2.googleapis.com/token", {"Content-Type: application/x-www-form-urlencoded"},
                          "code=" + urlEncode(code) + "&client_id=" + urlEncode(CARTUCHO_GOOGLE_ID) +
                              "&client_secret=" + urlEncode(CARTUCHO_GOOGLE_SECRET) + "&redirect_uri=" + urlEncode(redirect) +
                              "&grant_type=authorization_code&code_verifier=" + verifier);
        Json j = parseJson(r.body);
        if (r.status != 200 || j["refresh_token"].s().empty()) { error = "O Google recusou o login (" + std::to_string(r.status) + ")."; return false; }
        refresh_ = j["refresh_token"].s();
        access_ = j["access_token"].s();
        accessUntil_ = GetTickCount64() + (unsigned long long)(j["expires_in"].num - 60) * 1000ULL;
        Json who = parseJson(http("GET", "https://www.googleapis.com/oauth2/v3/userinfo", {"Authorization: Bearer " + access_}).body);
        email_ = who["email"].s();
        save();
        return true;
    }

    void signOut() {
        if (!refresh_.empty()) http("POST", "https://oauth2.googleapis.com/revoke", {"Content-Type: application/x-www-form-urlencoded"}, "token=" + urlEncode(refresh_));
        refresh_.clear();
        access_.clear();
        email_.clear();
        std::error_code ec;
        fs::remove(fs::path(wide(dir_ + "drive.bin")), ec);
    }

    /** Token de acesso válido (renova quando precisa). Vazio se a conta saiu. */
    std::string token() {
        if (refresh_.empty()) return {};
        if (!access_.empty() && GetTickCount64() < accessUntil_) return access_;
        Response r = http("POST", "https://oauth2.googleapis.com/token", {"Content-Type: application/x-www-form-urlencoded"},
                          "client_id=" + urlEncode(CARTUCHO_GOOGLE_ID) + "&client_secret=" + urlEncode(CARTUCHO_GOOGLE_SECRET) +
                              "&refresh_token=" + urlEncode(refresh_) + "&grant_type=refresh_token");
        Json j = parseJson(r.body);
        if (r.status == 400 || r.status == 401) { refresh_.clear(); save(); return {}; }
        if (r.status != 200) return {};
        access_ = j["access_token"].s();
        accessUntil_ = GetTickCount64() + (unsigned long long)(j["expires_in"].num - 60) * 1000ULL;
        return access_;
    }

private:
    static std::string queryParam(const std::string& req, const std::string& key) {
        size_t line = req.find("\r\n");
        std::string first = req.substr(0, line);
        size_t q = first.find('?');
        if (q == std::string::npos) return {};
        std::string qs = first.substr(q + 1, first.find(' ', q) - q - 1);
        std::stringstream ss(qs);
        std::string kv;
        while (std::getline(ss, kv, '&')) {
            size_t eq = kv.find('=');
            if (eq != std::string::npos && kv.substr(0, eq) == key) {
                std::string v = kv.substr(eq + 1), o;
                for (size_t i = 0; i < v.size(); i++) {
                    if (v[i] == '%' && i + 2 < v.size()) { o += (char)strtol(v.substr(i + 1, 2).c_str(), nullptr, 16); i += 2; }
                    else if (v[i] == '+') o += ' ';
                    else o += v[i];
                }
                return o;
            }
        }
        return {};
    }

    void load() {
        std::string blob = readFile(dir_ + "drive.bin");
        if (blob.empty()) return;
        DATA_BLOB in{(DWORD)blob.size(), (BYTE*)blob.data()}, out{};
        if (!CryptUnprotectData(&in, nullptr, nullptr, nullptr, nullptr, 0, &out)) return;
        std::string plain((char*)out.pbData, out.cbData);
        LocalFree(out.pbData);
        size_t nl = plain.find('\n');
        refresh_ = plain.substr(0, nl);
        if (nl != std::string::npos) email_ = plain.substr(nl + 1);
    }

    void save() {
        if (refresh_.empty()) {
            std::error_code ec;
            fs::remove(fs::path(wide(dir_ + "drive.bin")), ec);
            return;
        }
        std::string plain = refresh_ + "\n" + email_;
        DATA_BLOB in{(DWORD)plain.size(), (BYTE*)plain.data()}, out{};
        if (!CryptProtectData(&in, L"Cartucho", nullptr, nullptr, nullptr, 0, &out)) return;
        writeFile(dir_ + "drive.bin", std::string((char*)out.pbData, out.cbData));
        LocalFree(out.pbData);
    }

    std::string dir_, refresh_, access_, email_;
    unsigned long long accessUntil_ = 0;
};

// ------------------------------------------------------------------ Drive

struct RemoteFile {
    std::string id, name;
    bool folder = false;
    long long mtime = 0;
};

class Drive {
public:
    explicit Drive(Account& acc) : acc_(acc) {}

    std::vector<RemoteFile> list(const std::string& query, std::string& error) {
        std::vector<RemoteFile> out;
        std::string pageToken;
        do {
            std::string url = "https://www.googleapis.com/drive/v3/files?pageSize=1000&spaces=drive&q=" + urlEncode(query) +
                              "&fields=" + urlEncode("nextPageToken,files(id,name,mimeType,modifiedTime,appProperties)") +
                              (pageToken.empty() ? "" : "&pageToken=" + urlEncode(pageToken));
            Response r = get(url);
            if (r.status != 200) { error = "Drive respondeu " + std::to_string(r.status); return out; }
            Json j = parseJson(r.body);
            for (const auto& f : j["files"].arr) {
                RemoteFile rf;
                rf.id = f["id"].s();
                rf.name = f["name"].s();
                rf.folder = f["mimeType"].s() == "application/vnd.google-apps.folder";
                std::string local = f["appProperties"]["cartuchoMtime"].s();
                rf.mtime = local.empty() ? parseRfc3339(f["modifiedTime"].s()) : _atoi64(local.c_str());
                out.push_back(rf);
            }
            pageToken = j["nextPageToken"].s();
        } while (!pageToken.empty());
        return out;
    }

    std::string createFolder(const std::string& name, const std::string& parent) {
        std::string body = "{\"name\":\"" + jsonEscape(name) + "\",\"mimeType\":\"application/vnd.google-apps.folder\"" +
                           (parent.empty() ? "" : ",\"parents\":[\"" + parent + "\"]") + "}";
        Response r = send("POST", "https://www.googleapis.com/drive/v3/files?fields=id", {"Content-Type: application/json; charset=UTF-8"}, body);
        return parseJson(r.body)["id"].s();
    }

    bool upload(const std::string& localPath, const std::string& name, const std::string& parent, const std::string& existingId) {
        std::string data = readFile(localPath);
        std::string meta = "{\"name\":\"" + jsonEscape(name) + "\",\"appProperties\":{\"cartuchoMtime\":\"" +
                           std::to_string(fileMtimeMs(localPath)) + "\"}" +
                           (existingId.empty() ? ",\"parents\":[\"" + parent + "\"]" : "") + "}";
        std::string boundary = "cartucho" + randomToken(8);
        std::string body = "--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta + "\r\n--" + boundary +
                           "\r\nContent-Type: application/octet-stream\r\n\r\n" + data + "\r\n--" + boundary + "--";
        std::string url = existingId.empty() ? "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id"
                                             : "https://www.googleapis.com/upload/drive/v3/files/" + existingId + "?uploadType=multipart&fields=id";
        Response r = send(existingId.empty() ? "POST" : "PATCH", url, {"Content-Type: multipart/related; boundary=" + boundary}, body);
        return r.status == 200;
    }

    bool download(const std::string& id, const std::string& dest) {
        Response r = get("https://www.googleapis.com/drive/v3/files/" + id + "?alt=media");
        if (r.status != 200) return false;
        std::string tmp = dest + ".download";
        if (!writeFile(tmp, r.body)) return false;
        return MoveFileExW(wide(tmp).c_str(), wide(dest).c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
    }

private:
    Response get(const std::string& url) { return send("GET", url, {}, std::string()); }

    Response send(const std::string& method, const std::string& url, std::vector<std::string> headers, const std::string& body) {
        std::string tok = acc_.token();
        if (tok.empty()) return Response{401, ""};
        headers.push_back("Authorization: Bearer " + tok);
        return http(method, url, headers, body);
    }

    Account& acc_;
};

/** Espelha a pasta local de saves com Cartucho/saves no Drive. Devolve um resumo para a tela. */
inline std::string syncSaves(Account& acc, const std::string& prefPath) {
    if (!acc.signedIn()) return "Entre com o Google para sincronizar.";
    Drive d(acc);
    std::string err;
    auto roots = d.list("name = 'Cartucho' and mimeType = 'application/vnd.google-apps.folder' and trashed = false", err);
    if (!err.empty()) return "Sem conexão com o Drive (" + err + ").";
    std::string root = roots.empty() ? d.createFolder("Cartucho", "") : roots.front().id;
    if (root.empty()) return "Não foi possível criar a pasta Cartucho no Drive.";
    auto folders = d.list("'" + root + "' in parents and trashed = false", err);
    std::string savesId;
    for (const auto& f : folders) if (f.folder && f.name == "saves") savesId = f.id;
    if (savesId.empty()) savesId = d.createFolder("saves", root);

    int up = 0, down = 0;
    std::string local = prefPath + "saves";
    std::error_code ec;
    fs::create_directories(fs::path(wide(local)), ec);
    auto remoteSystems = d.list("'" + savesId + "' in parents and trashed = false", err);
    std::map<std::string, std::string> sysIds;
    for (const auto& f : remoteSystems) if (f.folder) sysIds[f.name] = f.id;
    std::vector<std::string> systems;
    for (const auto& e : fs::directory_iterator(fs::path(wide(local)), ec))
        if (e.is_directory()) systems.push_back(narrow(e.path().filename().wstring()));
    for (const auto& kv : sysIds)
        if (std::find(systems.begin(), systems.end(), kv.first) == systems.end()) systems.push_back(kv.first);

    for (const auto& sys : systems) {
        std::string dir = local + "/" + sys;
        fs::create_directories(fs::path(wide(dir)), ec);
        std::string sid = sysIds.count(sys) ? sysIds[sys] : d.createFolder(sys, savesId);
        if (sid.empty()) continue;
        auto remote = d.list("'" + sid + "' in parents and trashed = false", err);
        std::map<std::string, RemoteFile> byName;
        for (const auto& r : remote) if (!r.folder) byName[r.name] = r;
        std::vector<std::string> localNames;
        for (const auto& e : fs::directory_iterator(fs::path(wide(dir)), ec)) {
            if (!e.is_regular_file()) continue;
            std::string name = narrow(e.path().filename().wstring());
            if (name.size() > 4 && (name.rfind(".tmp") == name.size() - 4 || name.find(".download") != std::string::npos)) continue;
            localNames.push_back(name);
            std::string path = dir + "/" + name;
            long long lt = fileMtimeMs(path);
            auto it = byName.find(name);
            if (it == byName.end()) {
                if (d.upload(path, name, sid, "")) up++;
            } else if (lt > it->second.mtime + 2000) {
                if (d.upload(path, name, sid, it->second.id)) up++;
            } else if (it->second.mtime > lt + 2000) {
                // Guarda o save daqui antes de trocar pelo mais novo da nuvem.
                std::string bdir = prefPath + "backup-saves/" + sys;
                fs::create_directories(fs::path(wide(bdir)), ec);
                fs::copy_file(fs::path(wide(path)), fs::path(wide(bdir + "/" + name + "." + std::to_string(lt))), fs::copy_options::overwrite_existing, ec);
                if (d.download(it->second.id, path)) { setFileMtimeMs(path, it->second.mtime); down++; }
            }
        }
        for (const auto& kv : byName) {
            if (std::find(localNames.begin(), localNames.end(), kv.first) != localNames.end()) continue;
            std::string path = dir + "/" + kv.first;
            if (d.download(kv.second.id, path)) { setFileMtimeMs(path, kv.second.mtime); down++; }
        }
    }
    char buf[160];
    SYSTEMTIME st;
    GetLocalTime(&st);
    snprintf(buf, sizeof(buf), "Sincronizado às %02d:%02d · %d enviado(s), %d baixado(s)", st.wHour, st.wMinute, up, down);
    return buf;
}

}  // namespace gdrive

#endif  // _WIN32
