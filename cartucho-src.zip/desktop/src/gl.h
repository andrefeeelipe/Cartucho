// Cartucho — qual OpenGL usar: o de computador (via glad) ou o OpenGL ES 3 do iPhone.
#pragma once

#if defined(CARTUCHO_GLES)
#  if defined(__APPLE__)
#    include <OpenGLES/ES3/gl.h>
#    include <OpenGLES/ES3/glext.h>
#  else
#    include <GLES3/gl3.h>
#  endif
#else
#  include <glad/gl.h>
#endif
