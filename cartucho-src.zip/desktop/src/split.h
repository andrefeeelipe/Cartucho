// Cartucho para Windows — jogos divididos em partes ("jogo.iso.001", ".002"…, "jogo.wbfs" + ".wbf1",
// "ul.XXXXXXXX.SLUS_123.45.00" do OPL). A biblioteca mostra um jogo só e as partes são juntadas
// num arquivo na hora de jogar (ou ao extrair um .zip que traga as partes dentro).
#pragma once

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <regex>
#include <string>
#include <vector>

namespace split {

namespace fs = std::filesystem;

enum Scheme { NONE, NUMBERED, WBFS, OPL };

struct Info {
    Scheme scheme = NONE;
    std::string joined;  // nome do arquivo inteiro
    int index = 0;       // 1 = primeira parte
    std::string prefix;  // para montar o nome das outras partes
};

inline Info parse(const std::string& name) {
    static const std::regex numbered(R"(^(.+\.[A-Za-z0-9]{1,5})\.(\d{3})$)");
    static const std::regex wbf(R"(^(.+)\.[wW][bB][fF](\d)$)");
    static const std::regex opl(R"(^[uU][lL]\.([0-9A-Fa-f]{8})\.(.+)\.(\d{2})$)");
    std::smatch m;
    Info i;
    if (std::regex_match(name, m, numbered)) {
        i.scheme = NUMBERED; i.joined = m[1]; i.index = std::stoi(m[2]); i.prefix = m[1];
    } else if (std::regex_match(name, m, wbf)) {
        i.scheme = WBFS; i.joined = std::string(m[1]) + ".wbfs"; i.index = std::stoi(m[2]) + 1; i.prefix = m[1];
    } else if (name.size() > 5 && std::equal(name.end() - 5, name.end(), ".wbfs", [](char a, char b) { return tolower(a) == b; })) {
        i.scheme = WBFS; i.joined = name; i.index = 1; i.prefix = name.substr(0, name.size() - 5);
    } else if (std::regex_match(name, m, opl)) {
        i.scheme = OPL; i.joined = std::string(m[2]) + ".iso"; i.index = std::stoi(m[3]) + 1;
        i.prefix = "ul." + std::string(m[1]) + "." + std::string(m[2]);
    }
    return i;
}

/** Nome da parte n (1 = primeira). */
inline std::string partName(const Info& i, int n) {
    char buf[16];
    switch (i.scheme) {
        case NUMBERED: snprintf(buf, sizeof(buf), ".%03d", n); return i.prefix + buf;
        case WBFS: return n == 1 ? i.prefix + ".wbfs" : i.prefix + ".wbf" + std::to_string(n - 1);
        case OPL: snprintf(buf, sizeof(buf), ".%02d", n - 1); return i.prefix + buf;
        default: return {};
    }
}

/** Partes do jogo, a partir da primeira (vazio se o arquivo não estiver dividido). */
inline std::vector<fs::path> partsOf(const fs::path& first) {
    std::vector<fs::path> out;
    Info i = parse(first.filename().u8string());
    if (i.scheme == NONE || i.index != 1) return out;
    std::error_code ec;
    for (int n = 1; n < 1000; n++) {
        fs::path p = first.parent_path() / fs::u8path(partName(i, n));
        if (!fs::exists(p, ec)) break;
        out.push_back(p);
    }
    if (out.size() < 2) out.clear();
    return out;
}

/** Junta as partes em [target]. */
inline bool join(const std::vector<fs::path>& parts, const fs::path& target) {
    fs::path tmp = target;
    tmp += ".juntando";
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out) return false;
        std::vector<char> buf(1 << 20);
        for (const auto& p : parts) {
            std::ifstream in(p, std::ios::binary);
            if (!in) return false;
            while (in) {
                in.read(buf.data(), (std::streamsize)buf.size());
                out.write(buf.data(), in.gcount());
            }
        }
        if (!out) return false;
    }
    std::error_code ec;
    fs::remove(target, ec);
    fs::rename(tmp, target, ec);
    return !ec;
}

/** Numa pasta (por exemplo, um .zip extraído): junta o que estiver em partes e apaga os pedaços. */
inline void joinInDir(const fs::path& dir) {
    std::error_code ec;
    std::vector<fs::path> firsts;
    for (const auto& e : fs::directory_iterator(dir, ec))
        if (e.is_regular_file(ec) && parse(e.path().filename().u8string()).index == 1) firsts.push_back(e.path());
    for (const auto& f : firsts) {
        auto parts = partsOf(f);
        if (parts.empty()) continue;
        fs::path target = dir / fs::u8path(parse(f.filename().u8string()).joined);
        if (join(parts, target))
            for (const auto& p : parts) if (p != target) fs::remove(p, ec);
    }
}

}  // namespace split
