// Cartucho para Windows — biblioteca, ajustes e o modo de jogo (--play).
// Cada jogo roda em um processo próprio: ao sair, o emulador é descarregado por completo.

#ifdef _WIN32
// O winsock2 precisa vir antes do windows.h (usado pelo login do Google Drive).
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#endif
#include <SDL.h>
#include <glad/gl.h>

#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_sdl2.h"
#include "miniz.h"

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "host.h"
#include "systems.h"
#include "perf.h"
#include "gdrive.h"
#include "split.h"
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_ONLY_GIF
#include "covers.h"

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <shobjidl.h>
#include <shlobj.h>
#include <knownfolders.h>
#include <urlmon.h>
#include <psapi.h>
#include <csignal>
#include <cstdarg>
#include <ctime>
#pragma comment(lib, "ole32.lib")
#endif

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Caminhos e texto

static std::string g_prefPath;  // %APPDATA%/Cartucho/Cartucho/
static std::string g_basePath;  // pasta do executável

static fs::path u8path(const std::string& s) { return fs::u8path(s); }
static std::string pathToUtf8(const fs::path& p) {
    auto u = p.u8string();
    return std::string(u.begin(), u.end());
}

/** Extensão em minúsculas, com o ponto (".zip"), sem converter para a página de código do Windows:
 *  path::string() quebra (exceção) com nomes em japonês, ★, ™ e outros símbolos. */
static std::string extOf(const std::string& name) {
    size_t slash = name.find_last_of("/\\");
    size_t dot = name.find_last_of('.');
    if (dot == std::string::npos || (slash != std::string::npos && dot < slash) || dot + 1 == name.size()) return "";
    std::string e = name.substr(dot);
    for (auto& ch : e) ch = (char)tolower((unsigned char)ch);
    return e;
}
static std::string extOf(const fs::path& p) { return extOf(pathToUtf8(p.filename())); }

#ifdef _WIN32
static std::wstring widen(const std::string& s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}
static std::string narrow(const std::wstring& w) {
    if (w.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}

#endif

// ------------------------------------------------------------------ diagnóstico
// O modo de jogo escreve as etapas em ultimo-jogo.log; se fechar por erro, o endereço e o módulo
// vão para ultimo-erro.txt. A biblioteca mostra isso para o usuário copiar e mandar.
static const char* g_logName = "ultimo-jogo.log";   // na tela inicial: inicio.log
static const char* g_errName = "ultimo-erro.txt";   // na tela inicial: inicio-erro.txt
static std::string logPath() { return g_prefPath + g_logName; }
static std::string errorPath() { return g_prefPath + g_errName; }

static void logStep(const char* fmt, ...) {
    char line[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
#ifdef _WIN32
    FILE* f = _wfopen(widen(logPath()).c_str(), L"a");
#else
    FILE* f = fopen(logPath().c_str(), "a");
#endif
    if (!f) return;
    fprintf(f, "%s\n", line);
    fclose(f);
}

static std::string readText(const std::string& path) {
#ifdef _WIN32
    std::ifstream in(widen(path), std::ios::binary);
#else
    std::ifstream in(path, std::ios::binary);
#endif
    std::stringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

#ifdef _WIN32
static std::string moduleOf(void* addr, unsigned long long& offset) {
    HMODULE mod = nullptr;
    offset = (unsigned long long)addr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)addr, &mod) || !mod) return "?";
    wchar_t name[MAX_PATH];
    GetModuleFileNameW(mod, name, MAX_PATH);
    offset = (unsigned long long)((char*)addr - (char*)mod);
    std::string full = narrow(name);
    size_t slash = full.find_last_of("\\/");
    return slash == std::string::npos ? full : full.substr(slash + 1);
}

static void writeCrash(const char* what, void* address) {
    std::string text = "Cartucho fechou por um erro: ";
    text += what;
    char buf[256];
    if (address) {
        unsigned long long off = 0;
        std::string mod = moduleOf(address, off);
        snprintf(buf, sizeof(buf), "\nEndereço: %s+0x%llx\n", mod.c_str(), off);
        text += buf;
    }
    void* frames[40];
    USHORT n = CaptureStackBackTrace(0, 40, frames, nullptr);
    text += "Pilha:\n";
    for (USHORT k = 0; k < n; k++) {
        unsigned long long off = 0;
        std::string mod = moduleOf(frames[k], off);
        snprintf(buf, sizeof(buf), "  %s+0x%llx\n", mod.c_str(), off);
        text += buf;
    }
    text += "\nEtapas:\n" + readText(logPath());
    FILE* f = _wfopen(widen(errorPath()).c_str(), L"w");
    if (f) { fputs(text.c_str(), f); fclose(f); }
}

static LONG WINAPI crashFilter(EXCEPTION_POINTERS* ep) {
    char what[64];
    snprintf(what, sizeof(what), "exceção 0x%08lX", ep && ep->ExceptionRecord ? ep->ExceptionRecord->ExceptionCode : 0ul);
    writeCrash(what, ep && ep->ExceptionRecord ? ep->ExceptionRecord->ExceptionAddress : nullptr);
    return EXCEPTION_CONTINUE_SEARCH;
}

static void abortHandler(int) {
    writeCrash("abort (erro interno de um core)", nullptr);
    _exit(3);
}
#endif

/** Os emuladores abrem arquivos com fopen (página de código ANSI): caminhos com acento viram nome curto 8.3. */
static std::string pathForCore(const std::string& utf8) {
#ifdef _WIN32
    bool ascii = std::all_of(utf8.begin(), utf8.end(), [](unsigned char c) { return c < 0x80; });
    if (ascii) return utf8;
    std::wstring w = widen(utf8);
    DWORD n = GetShortPathNameW(w.c_str(), nullptr, 0);
    if (n == 0) return utf8;
    std::wstring shortPath(n, 0);
    GetShortPathNameW(w.c_str(), &shortPath[0], n);
    shortPath.resize(wcslen(shortPath.c_str()));
    return narrow(shortPath);
#else
    return utf8;
#endif
}

// ---------------------------------------------------------------------------
// Configuração (config.ini simples: chave=valor)

struct Config {
    std::vector<std::string> folders;
    int keys[RP_COUNT];
    bool fullscreen = false;
    bool integerScale = false;
    bool smooth = false;
    float volume = 1.0f;
    int autoSaveMinutes = 5;   // 0 = desligado; opções: 0,1,2,5,10,15,30
};

static Config g_config;

static void defaultKeys(Config& c) {
    c.keys[RP_B] = SDL_SCANCODE_Z;
    c.keys[RP_A] = SDL_SCANCODE_X;
    c.keys[RP_Y] = SDL_SCANCODE_A;
    c.keys[RP_X] = SDL_SCANCODE_S;
    c.keys[RP_L] = SDL_SCANCODE_Q;
    c.keys[RP_R] = SDL_SCANCODE_W;
    c.keys[RP_L2] = SDL_SCANCODE_E;
    c.keys[RP_R2] = SDL_SCANCODE_R;
    c.keys[RP_L3] = SDL_SCANCODE_D;
    c.keys[RP_R3] = SDL_SCANCODE_F;
    c.keys[RP_START] = SDL_SCANCODE_RETURN;
    c.keys[RP_SELECT] = SDL_SCANCODE_BACKSPACE;
    c.keys[RP_UP] = SDL_SCANCODE_UP;
    c.keys[RP_DOWN] = SDL_SCANCODE_DOWN;
    c.keys[RP_LEFT] = SDL_SCANCODE_LEFT;
    c.keys[RP_RIGHT] = SDL_SCANCODE_RIGHT;
}

static std::string configPath() { return g_prefPath + "config.ini"; }
static std::string perfPath() { return g_prefPath + "perf.ini"; }

static void loadConfig() {
    defaultKeys(g_config);
    std::ifstream in(u8path(configPath()));
    std::string line;
    while (std::getline(in, line)) {
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        if (k == "folder") g_config.folders.push_back(v);
        else if (k == "fullscreen") g_config.fullscreen = v == "1";
        else if (k == "integer") g_config.integerScale = v == "1";
        else if (k == "smooth") g_config.smooth = v == "1";
        else if (k == "volume") g_config.volume = (float)atof(v.c_str());
        else if (k == "autosave") g_config.autoSaveMinutes = atoi(v.c_str());
        else if (k.rfind("key", 0) == 0) {
            int id = atoi(k.c_str() + 3);
            if (id >= 0 && id < RP_COUNT) g_config.keys[id] = atoi(v.c_str());
        }
    }
}

static void saveConfig() {
    std::ofstream out(u8path(configPath()), std::ios::trunc);
    for (const auto& f : g_config.folders) out << "folder=" << f << "\n";
    out << "fullscreen=" << (g_config.fullscreen ? 1 : 0) << "\n";
    out << "integer=" << (g_config.integerScale ? 1 : 0) << "\n";
    out << "smooth=" << (g_config.smooth ? 1 : 0) << "\n";
    out << "volume=" << g_config.volume << "\n";
    out << "autosave=" << g_config.autoSaveMinutes << "\n";
    for (int i = 0; i < RP_COUNT; i++) out << "key" << i << "=" << g_config.keys[i] << "\n";
}

// ---------------------------------------------------------------------------
// Biblioteca

struct Game {
    std::string path;
    std::string title;
    std::string system;
};

static std::vector<Game> g_games;
static int g_gamesVersion = 0;  // muda quando a lista de jogos muda (para refazer os grupos de versões)

static std::string titleFromStem(std::string stem) {
    std::string out;
    int depth = 0;
    for (char ch : stem) {
        if (ch == '(' || ch == '[') depth++;
        else if (ch == ')' || ch == ']') { if (depth > 0) depth--; }
        else if (depth == 0) out.push_back(ch == '_' ? ' ' : ch);
    }
    // Sem endereço de site no nome ("www.romsportugues.com", "i16games.com.br").
    {
        std::string clean, word;
        auto keep = [&](const std::string& w) {
            std::string lw = lower(w);
            bool site = lw.rfind("www.", 0) == 0 || lw.find(".com") != std::string::npos || lw.find(".net") != std::string::npos ||
                        lw.find(".org") != std::string::npos || lw.find(".tk") != std::string::npos;
            if (!site && !w.empty()) clean += (clean.empty() ? "" : " ") + w;
        };
        for (char c : out) { if (c == ' ') { keep(word); word.clear(); } else word += c; }
        keep(word);
        while (!clean.empty() && (clean.back() == '-' || clean.back() == ' ')) clean.pop_back();
        out = clean;
    }
    return out.empty() ? stem : out;
}

/** Sistema de um .zip pelo que tem dentro; sem ROM de console, é arcade. */
static std::string detectZip(const std::string& path) {
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_file(&zip, pathForCore(path).c_str(), 0)) return "";
    std::string found;
    mz_uint n = mz_zip_reader_get_num_files(&zip);
    for (mz_uint i = 0; i < n && found.empty(); i++) {
        char name[512];
        mz_zip_reader_get_filename(&zip, i, name, sizeof(name));
        std::string ext = extOf(std::string(name));
        if (!ext.empty()) ext.erase(0, 1);
        auto c = candidatesFor(ext);
        c.erase(std::remove_if(c.begin(), c.end(), [](const SystemInfo* s) { return std::string(s->id) == "arcade"; }), c.end());
        if (c.size() == 1) found = c[0]->id;
    }
    mz_zip_reader_end(&zip);
    return found.empty() ? "arcade" : found;
}

/** Primeira letra do título para o filtro A–Z (acentos viram a letra base; "#" para o resto). */
static char titleLetter(const std::string& title) {
    std::string t = title;
    if (t.rfind("The ", 0) == 0) t.erase(0, 4);
    size_t i = 0;
    while (i < t.size() && (t[i] == ' ' || t[i] == '"' || t[i] == '\'')) i++;
    if (i >= t.size()) return '#';
    unsigned char c = (unsigned char)t[i];
    if (c < 0x80) { c = (unsigned char)toupper(c); return (c >= 'A' && c <= 'Z') ? (char)c : '#'; }
    if (c == 0xC3 && i + 1 < t.size()) {  // Latin-1 em UTF-8: À..ÿ
        unsigned cp = 0xC0 + ((unsigned char)t[i + 1] & 0x3F);
        static const char* map = "AAAAAAACEEEEIIIIDNOOOOOxOUUUUYTsaaaaaaaceeeeiiiidnooooo/ouuuuyty";
        char b = map[cp - 0xC0];
        b = (char)toupper((unsigned char)b);
        return (b >= 'A' && b <= 'Z') ? b : '#';
    }
    return '#';
}

static std::string storePlatformForPath(const std::string& path);

// O que já se sabe de cada arquivo (sistema detectado pelo conteúdo), para não abrir de novo os .zip e
// as ISOs a cada vez que o Cartucho abre (numa pasta do Google Drive, abrir = baixar).
static std::vector<Game> scanFoldersNow(const std::atomic<bool>& stop) {
    std::vector<Game> found;
    std::map<std::string, std::string> cache;
    {
        std::stringstream in(readText(g_prefPath + "pastas-cache.txt"));
        std::string line;
        while (std::getline(in, line)) {
            size_t tab = line.rfind('\t');
            if (tab != std::string::npos) cache[line.substr(0, tab)] = line.substr(tab + 1);
        }
    }
    std::map<std::string, std::string> seen;
    std::vector<std::string> roots = g_config.folders;
    roots.push_back(g_prefPath + "loja");  // jogos baixados pela Loja
    for (const auto& folder : roots) {
        std::error_code ec;
        fs::recursive_directory_iterator it(u8path(folder), fs::directory_options::skip_permission_denied, ec), end;
        for (; it != end && !stop.load(); it.increment(ec)) {
            if (ec) break;
          try {
            if (!it->is_regular_file(ec)) continue;
            fs::path p = it->path();
            std::string key = pathToUtf8(p) + "|" + std::to_string((unsigned long long)it->file_size(ec)) + "|" +
                              std::to_string((long long)it->last_write_time(ec).time_since_epoch().count());
            auto known = cache.find(key);
            // Jogo em partes: só a primeira entra, com o nome e a extensão do arquivo inteiro.
            split::Info part = split::parse(pathToUtf8(p.filename()));
            bool isSplit = false;
            if (part.scheme != split::NONE) {
                if (part.index > 1) continue;
                isSplit = !split::partsOf(p).empty();
            }
            fs::path logical = isSplit ? p.parent_path() / u8path(part.joined) : p;
            std::string ext = extOf(logical);
            if (ext.size() < 2) continue;
            ext.erase(0, 1);
            std::string sys = storePlatformForPath(pathToUtf8(p));
            if (!sys.empty()) {
                if (ext == "part") continue;
            } else if (ext == "zip" && !isSplit) {
                sys = known != cache.end() ? known->second : detectZip(pathToUtf8(p));
                seen[key] = sys;
            } else {
                auto c = candidatesFor(ext);
                if (c.empty()) continue;
                // Trilhas .bin ao lado de um .cue não viram jogos.
                if (ext == "bin" || ext == "img") {
                    fs::path cue = p;
                    cue.replace_extension(".cue");
                    if (fs::exists(cue, ec)) continue;
                }
                if (c.size() == 1) {
                    sys = c[0]->id;
                } else {
                    const SystemInfo* hint = nullptr;
                    for (fs::path d = p.parent_path(); !d.empty() && d != d.parent_path() && !hint; d = d.parent_path())
                        hint = hintFromFolder(pathToUtf8(d.filename()));
                    bool ok = hint && std::find(c.begin(), c.end(), hint) != c.end();
                    if (ok) sys = hint->id;
                    else if (known != cache.end()) sys = known->second;
                    else {
                        const char* sniffed = isSplit ? nullptr : sniffDisc(pathToUtf8(p), ext);
                        sys = sniffed ? sniffed : c[0]->id;
                        seen[key] = sys;
                    }
                }
            }
            if (sys.empty()) continue;
            found.push_back({pathToUtf8(p), titleFromStem(pathToUtf8(logical.stem())), sys});
          } catch (const std::exception& e) {
            // Um arquivo estranho não pode derrubar o programa: pula e segue.
            logStep("pasta: arquivo ignorado (%s)", e.what());
          }
        }
    }
    if (!stop.load()) {
        std::string out;
        for (const auto& kv : seen) out += kv.first + "\t" + kv.second + "\n";
#ifdef _WIN32
        FILE* f = _wfopen(widen(g_prefPath + "pastas-cache.txt").c_str(), L"wb");
#else
        FILE* f = fopen((g_prefPath + "pastas-cache.txt").c_str(), "wb");
#endif
        if (f) { fwrite(out.data(), 1, out.size(), f); fclose(f); }
    }
    // Jogos grátis que vêm junto com o programa (os dados chegam com o emulador).
    {
        std::error_code ec;
        std::string cave = g_prefPath + "system/nxengine/Doukutsu.exe";
        if (fs::exists(u8path(cave), ec)) found.push_back({cave, "Cave Story", "cavestory"});
    }
    std::sort(found.begin(), found.end(), [](const Game& a, const Game& b) { return lower(a.title) < lower(b.title); });
    return found;
}

// A procura nas pastas roda por trás: a janela abre na hora, mesmo com milhares de jogos ou pasta na nuvem.
static std::mutex g_scanMutex;
static std::vector<Game> g_scanResult;
static std::atomic<bool> g_scanReady{false}, g_scanning{false}, g_scanAgain{false}, g_scanStop{false};

static void scanFolders() {
    if (g_scanning.exchange(true)) { g_scanAgain = true; return; }
    std::thread([] {
        do {
            g_scanAgain = false;
            std::vector<Game> r;
            try {
                r = scanFoldersNow(g_scanStop);
            } catch (const std::exception& e) {
                logStep("pasta: procura interrompida (%s)", e.what());
            }
            if (g_scanStop.load()) break;
            std::lock_guard<std::mutex> lock(g_scanMutex);
            g_scanResult = std::move(r);
            g_scanReady = true;
        } while (g_scanAgain.load() && !g_scanStop.load());
        g_scanning = false;
    }).detach();
}

/** Na tela: troca a lista quando a procura termina. */
static void pollScan() {
    if (!g_scanReady.load()) return;
    std::lock_guard<std::mutex> lock(g_scanMutex);
    g_games = std::move(g_scanResult);
    g_gamesVersion++;
    g_scanReady = false;
    logStep("pasta: %d jogos encontrados", (int)g_games.size());
}

#ifdef _WIN32
static std::string pickFolder() {
    std::string result;
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    IFileOpenDialog* dlg = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_ALL, IID_IFileOpenDialog, (void**)&dlg))) {
        DWORD opts = 0;
        dlg->GetOptions(&opts);
        dlg->SetOptions(opts | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
        dlg->SetTitle(L"Escolha a pasta com seus jogos");
        if (SUCCEEDED(dlg->Show(nullptr))) {
            IShellItem* item = nullptr;
            if (SUCCEEDED(dlg->GetResult(&item))) {
                PWSTR p = nullptr;
                if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &p))) {
                    result = narrow(p);
                    CoTaskMemFree(p);
                }
                item->Release();
            }
        }
        dlg->Release();
    }
    CoUninitialize();
    return result;
}
#else
static std::string pickFolder() { return ""; }
#endif

// ---------------------------------------------------------------------------
// Estilo: identidade do Cartucho (claro, roxo de destaque, Inter + Space Grotesk)

static perf::Hardware g_hw;
static std::string perfPath();
static ImFont* g_fontBody = nullptr;
static ImFont* g_fontTitle = nullptr;
static ImFont* g_fontSmall = nullptr;
static ImFont* g_fontSemi = nullptr;      // Inter 600
static ImFont* g_fontLabel = nullptr;     // Inter 700 pequeno (rótulos em caixa alta)
static ImFont* g_fontWordmark = nullptr;  // Space Grotesk 700 (nome Cartucho)
// Fontes grandes do card de compartilhar (desenhadas em vários tamanhos a partir destas).
static ImFont* g_cardDisplay = nullptr;
static ImFont* g_cardSemi = nullptr;
static ImFont* g_cardBold = nullptr;
static ImFont* g_cardRegular = nullptr;

namespace brand {
static inline ImU32 rgb(int r, int g, int b, int a = 255) { return IM_COL32(r, g, b, a); }
static const ImU32 surface = rgb(0xE3, 0xE3, 0xEA), surfaceRaised = rgb(0xF3, 0xF3, 0xF7), card = rgb(255, 255, 255);
static const ImU32 line = rgb(0xCA, 0xCA, 0xD3), lineSoft = rgb(0xE1, 0xE1, 0xE8), placeholder = rgb(0xE9, 0xE9, 0xEE);
static const ImU32 ink = rgb(0x1E, 0x1E, 0x24), muted2 = rgb(0x55, 0x55, 0x6A);
static const ImU32 purple = rgb(0x4F, 0x43, 0xAE), purpleDark = rgb(0x3A, 0x30, 0x88), lavender = rgb(0xC9, 0xC6, 0xEE);
static const ImU32 lavenderMid = rgb(0x8F, 0x86, 0xD6), lavenderSoft = rgb(0xE6, 0xE4, 0xF8), lavenderInk = rgb(0x2A, 0x23, 0x66);
static const ImU32 red = rgb(0xD3, 0x26, 0x2F), yellow = rgb(0xF0, 0xBE, 0x1E), green = rgb(0x23, 0x96, 0x5A), blue = rgb(0x2A, 0x5D, 0xB8);
static const ImU32 plate = rgb(0xD2, 0xD2, 0xDB), plateHi = rgb(0xED, 0xED, 0xF2), plateShade = rgb(0xB9, 0xB9, 0xC4), pad = rgb(0xBD, 0xBD, 0xC8);
static const ImU32 dots[4] = {red, yellow, green, blue};
static inline ImVec4 v(ImU32 c) { return ImGui::ColorConvertU32ToFloat4(c); }
}  // namespace brand

static GLuint g_brandIcon = 0;  // ícone do cartucho (assets/brand_icon.png)

static void setupStyle() {
    ImGuiIO& io = ImGui::GetIO();
    std::error_code ec;
    // Caminho curto quando a pasta tem acento (o ImGui abre a fonte com fopen).
    auto font = [&](const char* name) { return pathForCore(g_basePath + "assets/" + name); };
    auto has = [&](const char* name) { return fs::exists(u8path(g_basePath + "assets/" + name), ec); };
    const ImWchar* ranges = io.Fonts->GetGlyphRangesDefault();
    if (has("Inter-Regular.ttf") && has("SpaceGrotesk-Bold.ttf")) {
        g_fontBody = io.Fonts->AddFontFromFileTTF(font("Inter-Regular.ttf").c_str(), 17.0f, nullptr, ranges);
        g_fontSmall = io.Fonts->AddFontFromFileTTF(font("Inter-Regular.ttf").c_str(), 14.0f, nullptr, ranges);
        g_fontSemi = io.Fonts->AddFontFromFileTTF(font(has("Inter-SemiBold.ttf") ? "Inter-SemiBold.ttf" : "Inter-Regular.ttf").c_str(), 17.0f, nullptr, ranges);
        g_fontLabel = io.Fonts->AddFontFromFileTTF(font(has("Inter-Bold.ttf") ? "Inter-Bold.ttf" : "Inter-Regular.ttf").c_str(), 12.5f, nullptr, ranges);
        g_fontTitle = io.Fonts->AddFontFromFileTTF(font("SpaceGrotesk-Bold.ttf").c_str(), 34.0f, nullptr, ranges);
        g_fontWordmark = io.Fonts->AddFontFromFileTTF(font("SpaceGrotesk-Bold.ttf").c_str(), 21.0f, nullptr, ranges);
        g_cardDisplay = io.Fonts->AddFontFromFileTTF(font("SpaceGrotesk-Bold.ttf").c_str(), 72.0f, nullptr, ranges);
        g_cardSemi = io.Fonts->AddFontFromFileTTF(font(has("Inter-SemiBold.ttf") ? "Inter-SemiBold.ttf" : "Inter-Regular.ttf").c_str(), 44.0f, nullptr, ranges);
        g_cardBold = io.Fonts->AddFontFromFileTTF(font(has("Inter-Bold.ttf") ? "Inter-Bold.ttf" : "Inter-Regular.ttf").c_str(), 26.0f, nullptr, ranges);
        g_cardRegular = io.Fonts->AddFontFromFileTTF(font("Inter-Regular.ttf").c_str(), 28.0f, nullptr, ranges);
    } else if (has("Geist-Regular.ttf")) {
        g_fontBody = io.Fonts->AddFontFromFileTTF(font("Geist-Regular.ttf").c_str(), 18.0f, nullptr, ranges);
        g_fontSmall = io.Fonts->AddFontFromFileTTF(font("Geist-Regular.ttf").c_str(), 14.0f);
        g_fontTitle = io.Fonts->AddFontFromFileTTF(font("Geist-SemiBold.ttf").c_str(), 36.0f);
    }
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 0;
    s.ChildRounding = 16;
    s.FrameRounding = 22;  // botões e campos em pílula (o ImGui limita à metade da altura)
    s.PopupRounding = 16;
    s.GrabRounding = 10;
    s.TabRounding = 12;
    s.ScrollbarRounding = 8;
    s.FramePadding = ImVec2(16, 11);
    s.ItemSpacing = ImVec2(12, 12);
    s.WindowPadding = ImVec2(32, 28);
    s.FrameBorderSize = 1;
    s.ChildBorderSize = 0;
    s.PopupBorderSize = 1;
    s.WindowBorderSize = 0;
    s.GrabMinSize = 14;
    ImVec4* c = s.Colors;
    using namespace brand;
    c[ImGuiCol_WindowBg] = v(card);
    c[ImGuiCol_ChildBg] = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_PopupBg] = v(card);
    c[ImGuiCol_Border] = v(line);
    c[ImGuiCol_BorderShadow] = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_Text] = v(ink);
    c[ImGuiCol_TextDisabled] = v(muted2);
    c[ImGuiCol_TextSelectedBg] = v(lavender);
    c[ImGuiCol_FrameBg] = v(surfaceRaised);
    c[ImGuiCol_FrameBgHovered] = v(placeholder);
    c[ImGuiCol_FrameBgActive] = v(placeholder);
    c[ImGuiCol_Button] = v(card);
    c[ImGuiCol_ButtonHovered] = v(surfaceRaised);
    c[ImGuiCol_ButtonActive] = v(placeholder);
    c[ImGuiCol_Header] = v(lavenderSoft);
    c[ImGuiCol_HeaderHovered] = v(lavenderSoft);
    c[ImGuiCol_HeaderActive] = v(lavender);
    c[ImGuiCol_CheckMark] = v(purple);
    c[ImGuiCol_SliderGrab] = v(purple);
    c[ImGuiCol_SliderGrabActive] = v(purpleDark);
    c[ImGuiCol_NavCursor] = v(purple);
    c[ImGuiCol_Tab] = v(surfaceRaised);
    c[ImGuiCol_TabHovered] = v(lavenderSoft);
    c[ImGuiCol_TabSelected] = v(lavenderSoft);
    c[ImGuiCol_TabSelectedOverline] = v(purple);
    c[ImGuiCol_Separator] = v(placeholder);
    c[ImGuiCol_ScrollbarBg] = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_ScrollbarGrab] = v(line);
    c[ImGuiCol_ScrollbarGrabHovered] = v(muted2);
    c[ImGuiCol_ScrollbarGrabActive] = v(muted2);
    c[ImGuiCol_TableHeaderBg] = v(surfaceRaised);
    c[ImGuiCol_TableRowBg] = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_TableRowBgAlt] = v(surfaceRaised);
    c[ImGuiCol_TableBorderLight] = v(placeholder);
    c[ImGuiCol_TableBorderStrong] = v(lineSoft);
    c[ImGuiCol_ModalWindowDimBg] = ImVec4(0.12f, 0.12f, 0.14f, 0.35f);
    c[ImGuiCol_PlotHistogram] = v(purple);
}

// Seções em grafite (menu do jogo): mesmos papéis, cores escuras do sistema.
static const int kGraphiteColors = 21;
static void pushGraphite() {
    auto P = [](ImGuiCol col, int r, int g, int b, float a = 1.0f) { ImGui::PushStyleColor(col, ImVec4(r / 255.f, g / 255.f, b / 255.f, a)); };
    P(ImGuiCol_WindowBg, 0x2B, 0x2B, 0x33, 0.98f);
    P(ImGuiCol_PopupBg, 0x2B, 0x2B, 0x33);
    P(ImGuiCol_Text, 255, 255, 255);
    P(ImGuiCol_TextDisabled, 0xC4, 0xC4, 0xD0);
    P(ImGuiCol_Border, 0x4A, 0x4A, 0x55);
    P(ImGuiCol_Button, 0x39, 0x39, 0x44);
    P(ImGuiCol_ButtonHovered, 0x4A, 0x4A, 0x55);
    P(ImGuiCol_ButtonActive, 0x55, 0x55, 0x6A);
    P(ImGuiCol_FrameBg, 0x39, 0x39, 0x44);
    P(ImGuiCol_FrameBgHovered, 0x4A, 0x4A, 0x55);
    P(ImGuiCol_FrameBgActive, 0x4A, 0x4A, 0x55);
    P(ImGuiCol_Header, 0x39, 0x39, 0x44);
    P(ImGuiCol_HeaderHovered, 0x4A, 0x4A, 0x55);
    P(ImGuiCol_HeaderActive, 0x4A, 0x4A, 0x55);
    P(ImGuiCol_CheckMark, 0xC9, 0xC6, 0xEE);
    P(ImGuiCol_SliderGrab, 0xC9, 0xC6, 0xEE);
    P(ImGuiCol_Tab, 0x39, 0x39, 0x44);
    P(ImGuiCol_TabHovered, 0x4A, 0x4A, 0x55);
    P(ImGuiCol_TabSelected, 0x4A, 0x4A, 0x55);
    P(ImGuiCol_TableRowBgAlt, 0x39, 0x39, 0x44);
    P(ImGuiCol_Separator, 0x4A, 0x4A, 0x55);
}
static void popGraphite() { ImGui::PopStyleColor(kGraphiteColors); }

static bool primaryButton(const char* label, ImVec2 size = ImVec2(0, 0)) {
    ImGui::PushStyleColor(ImGuiCol_Button, brand::v(brand::purple));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, brand::v(brand::purpleDark));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, brand::v(brand::purpleDark));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
    ImGui::PushStyleColor(ImGuiCol_Border, brand::v(brand::purple));
    if (g_fontSemi) ImGui::PushFont(g_fontSemi);
    bool r = ImGui::Button(label, size);
    if (g_fontSemi) ImGui::PopFont();
    ImGui::PopStyleColor(5);
    return r;
}

// Pílula de filtro: preenchida em ink quando ativa.
static bool chip(const char* label, bool selected) {
    if (selected) {
        ImGui::PushStyleColor(ImGuiCol_Button, brand::v(brand::ink));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, brand::v(brand::ink));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, brand::v(brand::ink));
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
        ImGui::PushStyleColor(ImGuiCol_Border, brand::v(brand::ink));
    }
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(15, 7));
    bool r = ImGui::Button(label);
    ImGui::PopStyleVar();
    if (selected) ImGui::PopStyleColor(5);
    return r;
}

// Os quatro pontos (vermelho, amarelo, verde, azul).
static float drawDots(ImDrawList* dl, ImVec2 p, float size, float gap) {
    for (int i = 0; i < 4; i++) dl->AddCircleFilled(ImVec2(p.x + size * 0.5f + i * (size + gap), p.y), size * 0.5f, brand::dots[i], 20);
    return 4 * size + 3 * gap;
}

// Rótulo em caixa alta (label do design system).
static void sectionLabel(const char* text) {
    if (g_fontLabel) ImGui::PushFont(g_fontLabel);
    ImGui::PushStyleColor(ImGuiCol_Text, brand::v(brand::muted2));
    ImGui::TextUnformatted(text);
    ImGui::PopStyleColor();
    if (g_fontLabel) ImGui::PopFont();
}

// Carrega uma imagem PNG como textura (ícone da marca).
static GLuint loadTexturePng(const std::string& path, int* outW = nullptr, int* outH = nullptr) {
    std::string data = readText(path);
    if (data.empty()) return 0;
    int w = 0, h = 0, n = 0;
    unsigned char* px = stbi_load_from_memory((const unsigned char*)data.data(), (int)data.size(), &w, &h, &n, 4);
    if (!px) return 0;
    GLuint tex = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    stbi_image_free(px);
    if (outW) *outW = w;
    if (outH) *outH = h;
    return tex;
}

static GLuint brandIcon() {
    static bool tried = false;
    if (!tried) {
        tried = true;
        g_brandIcon = loadTexturePng(g_basePath + "assets/brand_icon.png");
    }
    return g_brandIcon;
}

// Ícones de traço (2px, cantos arredondados) desenhados à mão, numa grade de 24×24.
static void navIcon(ImDrawList* dl, int kind, ImVec2 o, float sz, ImU32 col) {
    float k = sz / 24.0f;
    auto P = [&](float x, float y) { return ImVec2(o.x + x * k, o.y + y * k); };
    float t = 1.8f;
    if (kind == 0) {  // grade
        for (int i = 0; i < 4; i++) {
            float x = (i % 2) ? 13.5f : 3.5f, y = (i / 2) ? 13.5f : 3.5f;
            dl->AddRect(P(x, y), P(x + 7, y + 7), col, 1.5f * k, 0, t);
        }
    } else if (kind == 1) {  // sacola
        dl->AddRect(P(5, 8), P(19, 21), col, 2 * k, 0, t);
        dl->PathArcTo(P(12, 8), 3.5f * k, 3.14159f, 6.28318f, 12);
        dl->PathStroke(col, 0, t);
    } else if (kind == 2) {  // engrenagem
        dl->AddCircle(P(12, 12), 3.2f * k, col, 16, t);
        for (int i = 0; i < 8; i++) {
            float a = i * 0.785398f;
            dl->AddLine(P(12 + cosf(a) * 7, 12 + sinf(a) * 7), P(12 + cosf(a) * 9.5f, 12 + sinf(a) * 9.5f), col, t);
        }
        dl->AddCircle(P(12, 12), 6.6f * k, col, 24, t);
    } else {  // controle
        dl->AddRect(P(3, 8), P(21, 18), col, 5 * k, 0, t);
        dl->AddLine(P(8, 11), P(8, 15), col, t);
        dl->AddLine(P(6, 13), P(10, 13), col, t);
        dl->AddCircleFilled(P(16, 12), 1.1f * k, col);
        dl->AddCircleFilled(P(18, 14), 1.1f * k, col);
    }
}

// Menu lateral: selo, Biblioteca / Loja / Ajustes e o controle conectado. Devolve o item clicado (ou -1).
static int sidebar(int current) {
    using namespace brand;
    int picked = -1;
    ImGui::PushStyleColor(ImGuiCol_ChildBg, v(card));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(16, 20));
    ImGui::BeginChild("##side", ImVec2(232, 0), ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoScrollbar);
    ImGui::PopStyleVar();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 wp = ImGui::GetWindowPos(), ws = ImGui::GetWindowSize();
    dl->AddLine(ImVec2(wp.x + ws.x - 1, wp.y), ImVec2(wp.x + ws.x - 1, wp.y + ws.y), placeholder, 1.0f);

    // Selo: ícone + Cartucho + quatro pontos.
    ImVec2 p = ImGui::GetCursorScreenPos();
    float icon = 34;
    if (GLuint tex = brandIcon()) dl->AddImageRounded((ImTextureID)(intptr_t)tex, ImVec2(p.x + 6, p.y), ImVec2(p.x + 6 + icon, p.y + icon), ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 8);
    else dl->AddRectFilled(ImVec2(p.x + 6, p.y), ImVec2(p.x + 6 + icon, p.y + icon), placeholder, 8);
    ImFont* wf = g_fontWordmark ? g_fontWordmark : ImGui::GetFont();
    ImVec2 ts = wf->CalcTextSizeA(wf->FontSize, FLT_MAX, 0, "Cartucho");
    dl->AddText(wf, wf->FontSize, ImVec2(p.x + 6 + icon + 10, p.y + (icon - ts.y) * 0.5f), ink, "Cartucho");
    drawDots(dl, ImVec2(p.x + 6 + icon + 10 + ts.x + 9, p.y + icon * 0.5f), 6, 3);
    ImGui::Dummy(ImVec2(0, icon + 22));

    const char* names[3] = {"Biblioteca", "Loja", "Ajustes"};
    const int icons[3] = {0, 1, 2};
    for (int i = 0; i < 3; i++) {
        ImGui::PushID(i);
        ImVec2 q = ImGui::GetCursorScreenPos();
        float w = ImGui::GetContentRegionAvail().x, h = 44;
        if (ImGui::InvisibleButton("##nav", ImVec2(w, h))) picked = i;
        bool hov = ImGui::IsItemHovered() || ImGui::IsItemFocused();
        bool on = current == i;
        if (on) dl->AddRectFilled(q, ImVec2(q.x + w, q.y + h), lavenderSoft, 12);
        else if (hov) dl->AddRectFilled(q, ImVec2(q.x + w, q.y + h), surfaceRaised, 12);
        ImU32 col = on ? purpleDark : ink;
        navIcon(dl, icons[i], ImVec2(q.x + 14, q.y + 11), 22, col);
        ImFont* f = on && g_fontSemi ? g_fontSemi : ImGui::GetFont();
        ImVec2 ns = f->CalcTextSizeA(f->FontSize, FLT_MAX, 0, names[i]);
        dl->AddText(f, f->FontSize, ImVec2(q.x + 48, q.y + (h - ns.y) * 0.5f), col, names[i]);
        ImGui::PopID();
        ImGui::Dummy(ImVec2(0, 2));
    }

    // Embaixo: o controle conectado.
    float boxH = 64;
    float y = ImGui::GetWindowPos().y + ImGui::GetWindowSize().y - 20 - boxH;
    ImVec2 b0(ImGui::GetWindowPos().x + 16, y), b1(ImGui::GetWindowPos().x + 232 - 16, y + boxH);
    dl->AddRectFilled(b0, b1, surfaceRaised, 16);
    ImFont* lf = g_fontLabel ? g_fontLabel : ImGui::GetFont();
    dl->AddText(lf, lf->FontSize, ImVec2(b0.x + 14, b0.y + 13), muted2, "CONTROLE");
    int pads = SDL_NumJoysticks();
    std::string st = pads > 0 ? "Conectado · " + std::to_string(pads) + (pads == 1 ? " controle" : " controles") : "Teclado";
    ImFont* sf = g_fontSemi ? g_fontSemi : ImGui::GetFont();
    dl->AddText(sf, sf->FontSize * 0.92f, ImVec2(b0.x + 14, b0.y + 32), ink, st.c_str());
    ImGui::EndChild();
    ImGui::PopStyleColor();
    return picked;
}

// ---------------------------------------------------------------------------
// Tempo de jogo (o jogo roda em outro processo: conta do início ao fim dele)

static void recordPlaytime(const std::string& path, long long start, long long secs) {
    if (secs < 10) return;
    std::ofstream out(u8path(g_prefPath + "tempo-de-jogo.tsv"), std::ios::app | std::ios::binary);
    out << path << '\t' << start << '\t' << secs << '\n';
}

struct PlayStats { long long seconds = 0; long long first = 0; };

static PlayStats playStats(const std::string& path) {
    PlayStats st;
    std::istringstream in(readText(g_prefPath + "tempo-de-jogo.tsv"));
    std::string line;
    while (std::getline(in, line)) {
        size_t a = line.find('\t'), b = line.find('\t', a + 1);
        if (a == std::string::npos || b == std::string::npos || line.compare(0, a, path) != 0 || a != path.size()) continue;
        long long start = atoll(line.substr(a + 1, b - a - 1).c_str()), secs = atoll(line.substr(b + 1).c_str());
        st.seconds += secs;
        if (start > 0 && (st.first == 0 || start < st.first)) st.first = start;
    }
    return st;
}

static std::string hoursText(long long seconds) {
    if (seconds < 60) return "—";
    long long h = seconds / 3600, m = (seconds % 3600) / 60;
    if (h == 0) return std::to_string(m) + "min";
    if (m == 0) return std::to_string(h) + "h";
    return std::to_string(h) + "h " + std::to_string(m) + "min";
}

// ---------------------------------------------------------------------------
// Card de compartilhar no formato Link (1200 × 630), o do computador

struct CardInfo {
    std::string title, console, hours, since;
    GLuint cover = 0;
    ImVec2 coverSize;
};

// Corta o texto (UTF-8) com reticências para caber na largura.
static std::string fitText(ImFont* f, float size, const std::string& text, float width) {
    if (f->CalcTextSizeA(size, FLT_MAX, 0, text.c_str()).x <= width) return text;
    std::string t = text;
    while (!t.empty()) {
        do { t.pop_back(); } while (!t.empty() && ((unsigned char)t.back() & 0xC0) == 0x80);
        if (!t.empty() && ((unsigned char)t.back() & 0xC0) == 0xC0) t.pop_back();
        std::string e = t + "…";
        if (f->CalcTextSizeA(size, FLT_MAX, 0, e.c_str()).x <= width) return e;
    }
    return "…";
}

static void drawLinkCard(ImDrawList* dl, const CardInfo& ci) {
    using namespace brand;
    const float W = 1200, H = 630;
    ImFont* disp = g_cardDisplay ? g_cardDisplay : ImGui::GetFont();
    ImFont* semi = g_cardSemi ? g_cardSemi : ImGui::GetFont();
    ImFont* bold = g_cardBold ? g_cardBold : ImGui::GetFont();
    dl->AddRectFilled(ImVec2(0, 0), ImVec2(W, H), surface);

    // Placa do cartucho com a capa no centro e o controle no canto.
    float s = 320, k = s / 300.0f, x = 64, y = (H - 12 - s) * 0.5f, r = s * 0.133f;
    for (int i = 0; i < 12; i++) {
        float t = i / 11.0f;
        dl->AddRectFilled(ImVec2(x + 30 * k - t * 10, y + 50 * k + t * 18), ImVec2(x + s - 30 * k + t * 10, y + s + 6 * k + t * 18), IM_COL32(40, 40, 60, (int)(14 * (1 - t))), r);
    }
    dl->AddRectFilled(ImVec2(x, y), ImVec2(x + s, y + s), plateHi, r);
    dl->AddRectFilled(ImVec2(x, y + 3 * k), ImVec2(x + s, y + s), plateShade, r);
    dl->AddRectFilled(ImVec2(x, y + 3 * k), ImVec2(x + s, y + s - 6 * k), plate, r);
    // O cartucho (198 × 178 na placa de 300): ranhuras, etiqueta escura com o nome do jogo e travas.
    {
        float cx0 = x + 51 * k, cy0 = y + 61 * k, cw = 198 * k, chh = 178 * k;
        for (int i = 0; i < 8; i++) dl->AddRectFilled(ImVec2(cx0 + 12 * k - i, cy0 + 26 * k + i * 1.5f), ImVec2(cx0 + cw - 12 * k + i, cy0 + chh + i * 1.5f), IM_COL32(30, 30, 40, 14), 16 * k);
        dl->AddRectFilled(ImVec2(cx0, cy0), ImVec2(cx0 + cw, cy0 + chh), IM_COL32(0x8C, 0x8C, 0x8C, 255), 16 * k);
        float rib = 32 * k;
        for (int side = 0; side < 2; side++) {
            float rx = side == 0 ? cx0 : cx0 + cw - rib;
            dl->AddRectFilled(ImVec2(rx, cy0), ImVec2(rx + rib, cy0 + chh), IM_COL32(0x9F, 0x9F, 0x9F, 255), 16 * k, side == 0 ? ImDrawFlags_RoundCornersLeft : ImDrawFlags_RoundCornersRight);
            for (float ly = cy0 + 22.4f * k; ly < cy0 + chh - 2; ly += 25.4f * k)
                dl->AddRectFilled(ImVec2(rx, ly), ImVec2(rx + rib, ly + 3 * k), IM_COL32(0x77, 0x77, 0x77, 255));
        }
        float mx0 = cx0 + rib + 6 * k, mx1 = cx0 + cw - rib - 6 * k, labelH = 78 * k;
        dl->AddRectFilled(ImVec2(mx0, cy0), ImVec2(mx1, cy0 + labelH), IM_COL32(0x59, 0x59, 0x59, 255), 6 * k, ImDrawFlags_RoundCornersBottom);
        dl->AddRectFilled(ImVec2(mx0, cy0 + labelH + 10 * k), ImVec2(mx1, cy0 + chh), IM_COL32(0xA3, 0xA3, 0xA3, 255), 6 * k, ImDrawFlags_RoundCornersTop);
        dl->AddCircleFilled(ImVec2(cx0 + 16 * k, cy0 + 130 * k), 5 * k, IM_COL32(0xDB, 0xDB, 0xDB, 255), 16);
        dl->AddCircleFilled(ImVec2(cx0 + cw - 16 * k, cy0 + 130 * k), 5 * k, IM_COL32(0xDB, 0xDB, 0xDB, 255), 16);
        // Nome em caixa alta, centralizado em até 2 linhas.
        std::string up;
        for (char ch : ci.title) up += (ch >= 'a' && ch <= 'z') ? (char)(ch - 32) : ch;
        float tw = mx1 - mx0 - 16 * k, fs = 18 * k;
        std::vector<std::string> lines;
        std::vector<std::string> words;
        {
            std::istringstream ws(up);
            std::string w;
            while (ws >> w) words.push_back(w);
        }
        auto join = [&](size_t from, size_t to) {
            std::string r;
            for (size_t i = from; i < to; i++) r += (i > from ? " " : "") + words[i];
            return r;
        };
        auto width = [&](const std::string& t) { return disp->CalcTextSizeA(fs, FLT_MAX, 0, t.c_str()).x; };
        for (;; fs -= 1) {
            lines.clear();
            std::string all = join(0, words.size());
            if (words.size() < 2 || width(all) <= tw) lines.push_back(all);
            else {
                // Duas linhas equilibradas (como o text-wrap: balance do modelo).
                size_t best = 1;
                float bestW = FLT_MAX;
                for (size_t i = 1; i < words.size(); i++) {
                    float m = std::max(width(join(0, i)), width(join(i, words.size())));
                    if (m < bestW) { bestW = m; best = i; }
                }
                lines.push_back(join(0, best));
                lines.push_back(join(best, words.size()));
            }
            bool fits = true;
            for (auto& l : lines) if (width(l) > tw) fits = false;
            if (fits || fs <= 10 * k) break;
        }
        float lh = fs * 1.0f, ty = cy0 + (labelH - lh * lines.size()) * 0.5f;
        for (auto& l : lines) {
            float lw = disp->CalcTextSizeA(fs, FLT_MAX, 0, l.c_str()).x;
            dl->AddText(disp, fs, ImVec2((mx0 + mx1 - lw) * 0.5f, ty), IM_COL32(0xED, 0xED, 0xED, 255), l.c_str());
            ty += lh;
        }
    }
    float d = s / 3.0f, px = x + s - d + 18 * k, py = y + s - d + 18 * k;
    dl->AddCircleFilled(ImVec2(px + d * 0.5f, py + d * 0.5f), d * 0.5f, IM_COL32(0xD9, 0xD9, 0xE1, 255), 48);
    dl->AddCircleFilled(ImVec2(px + d * 0.5f, py + d * 0.5f + 2 * k), d * 0.5f - 0.5f, pad, 48);
    float b = d * 0.27f;
    const float bp[4][2] = {{0.37f, 0.08f}, {0.65f, 0.37f}, {0.37f, 0.65f}, {0.08f, 0.37f}};
    const ImU32 bc[4] = {blue, red, yellow, green};
    for (int i = 0; i < 4; i++) dl->AddCircleFilled(ImVec2(px + d * bp[i][0] + b * 0.5f, py + d * bp[i][1] + b * 0.5f), b * 0.5f, bc[i], 24);

    // Coluna da direita.
    float cx = 440, right = 1136, cwid = right - cx, cy = 50;
    if (GLuint tex = brandIcon()) dl->AddImageRounded((ImTextureID)(intptr_t)tex, ImVec2(cx, cy), ImVec2(cx + 32, cy + 32), ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 8);
    float nameSize = 21;
    ImVec2 ns = disp->CalcTextSizeA(nameSize, FLT_MAX, 0, "Cartucho");
    dl->AddText(disp, nameSize, ImVec2(cx + 42, cy + (32 - ns.y) * 0.5f), ink, "Cartucho");
    drawDots(dl, ImVec2(cx + 42 + ns.x + 10, cy + 16), 8, 4);
    if (!ci.console.empty()) {
        float fs = 16;
        ImVec2 ps = semi->CalcTextSizeA(fs, FLT_MAX, 0, ci.console.c_str());
        ImVec2 p0(right - ps.x - 26, cy + 1), p1(right, cy + 31);
        dl->AddRectFilled(p0, p1, lavenderSoft, 99);
        dl->AddText(semi, fs, ImVec2(p0.x + 13, p0.y + (30 - ps.y) * 0.5f), purpleDark, ci.console.c_str());
    }
    cy = 104;
    float lw = drawDots(dl, ImVec2(cx, cy + 9), 8, 4);
    dl->AddText(bold, 15, ImVec2(cx + lw + 10, cy), muted2, "NO MEU CARTUCHO");
    // Título no tamanho do modelo, com o meio das letras na altura 171.
    float ts = 55;
    dl->AddText(disp, ts, ImVec2(cx - 2, 171 - ts * 0.62f), purple, "JOGANDO AGORA");
    cy = 254;

    struct Stat { const char* label; ImU32 dot; std::string value; };
    Stat stats[4] = {{"HORAS JOGADAS", red, ci.hours}, {"JOGANDO DESDE", yellow, ci.since}, {"JOGO", green, ci.title}, {"CONSOLE", blue, ci.console.empty() ? "—" : ci.console}};
    float colW = (cwid - 24) / 2;
    for (int i = 0; i < 4; i++) {
        float sx = cx + (i % 2) * 360, sy = cy + (i / 2) * 67;
        dl->AddCircleFilled(ImVec2(sx + 4.5f, sy + 8), 4.5f, stats[i].dot, 16);
        dl->AddText(bold, 13.5f, ImVec2(sx + 16, sy), muted2, stats[i].label);
        std::string val = fitText(semi, 22, stats[i].value, colW);
        dl->AddText(semi, 22, ImVec2(sx, sy + 23), ink, val.c_str());
    }
    dl->AddText(semi, 13.5f, ImVec2(cx, 568), muted2, "CARTUCHO · EMULADOR");
    drawDots(dl, ImVec2(right - (4 * 7 + 3 * 3.5f), 574), 7, 3.5f);
    // As três listras.
    dl->AddRectFilled(ImVec2(0, H - 12), ImVec2(W / 3, H), purple);
    dl->AddRectFilled(ImVec2(W / 3, H - 12), ImVec2(2 * W / 3, H), lavenderMid);
    dl->AddRectFilled(ImVec2(2 * W / 3, H - 12), ImVec2(W, H), lavender);
}

// Desenha o card numa textura fora da tela e devolve os pixels (de baixo para cima, como o OpenGL lê).
static bool renderLinkCard(const CardInfo& ci, std::vector<unsigned char>& rgba, int& outW, int& outH) {
    const int W = 1200, H = 630;
    ImDrawList dl(ImGui::GetDrawListSharedData());
    dl._ResetForNewFrame();
    dl.PushTextureID(ImGui::GetIO().Fonts->TexID);
    dl.PushClipRect(ImVec2(0, 0), ImVec2((float)W, (float)H));
    drawLinkCard(&dl, ci);

    GLint prevFbo = 0, vp[4];
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prevFbo);
    glGetIntegerv(GL_VIEWPORT, vp);
    GLuint tex = 0, fbo = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glGenFramebuffers(1, &fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    if (ok) {
        glViewport(0, 0, W, H);
        glDisable(GL_SCISSOR_TEST);
        glClearColor(0xE3 / 255.f, 0xE3 / 255.f, 0xEA / 255.f, 1);
        glClear(GL_COLOR_BUFFER_BIT);
        ImDrawData dd;
        dd.Valid = true;
        dd.DisplayPos = ImVec2(0, 0);
        dd.DisplaySize = ImVec2((float)W, (float)H);
        dd.FramebufferScale = ImVec2(1, 1);
        dd.AddDrawList(&dl);
        ImGui_ImplOpenGL3_RenderDrawData(&dd);
        rgba.resize((size_t)W * H * 4);
        glPixelStorei(GL_PACK_ALIGNMENT, 1);
        glReadPixels(0, 0, W, H, GL_RGBA, GL_UNSIGNED_BYTE, rgba.data());
        for (size_t i = 3; i < rgba.size(); i += 4) rgba[i] = 255;
    }
    glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)prevFbo);
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glDeleteFramebuffers(1, &fbo);
    glDeleteTextures(1, &tex);
    outW = W;
    outH = H;
    return ok;
}

// Salva o PNG em Imagens\Cartucho (ou na pasta do app) e copia a imagem para a área de transferência.
static std::string saveAndCopyCard(const std::vector<unsigned char>& rgba, int w, int h, const std::string& title) {
    size_t len = 0;
    void* png = tdefl_write_image_to_png_file_in_memory_ex(rgba.data(), w, h, 4, &len, MZ_DEFAULT_LEVEL, MZ_TRUE);
    if (!png) return "";
    std::string dir = g_prefPath + "cards";
#ifdef _WIN32
    PWSTR pics = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Pictures, 0, nullptr, &pics)) && pics) {
        dir = pathToUtf8(fs::path(pics) / L"Cartucho");
        CoTaskMemFree(pics);
    }
#endif
    std::error_code ec;
    fs::create_directories(u8path(dir), ec);
    std::string clean;
    for (char ch : title) clean += strchr("\\/:*?\"<>|", ch) ? '_' : ch;
    std::string path = dir + "/Cartucho - " + clean.substr(0, 60) + " - " + std::to_string((long long)time(nullptr)) + ".png";
    {
        std::ofstream out(u8path(path), std::ios::binary);
        out.write((const char*)png, (std::streamsize)len);
    }
    mz_free(png);
#ifdef _WIN32
    // Área de transferência: bitmap de baixo para cima (o OpenGL já entrega assim), em BGRA.
    if (OpenClipboard(nullptr)) {
        EmptyClipboard();
        size_t bytes = sizeof(BITMAPINFOHEADER) + (size_t)w * h * 4;
        HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE, bytes);
        if (mem) {
            auto* bi = (BITMAPINFOHEADER*)GlobalLock(mem);
            memset(bi, 0, sizeof(*bi));
            bi->biSize = sizeof(BITMAPINFOHEADER);
            bi->biWidth = w;
            bi->biHeight = h;
            bi->biPlanes = 1;
            bi->biBitCount = 32;
            bi->biCompression = BI_RGB;
            unsigned char* dst = (unsigned char*)(bi + 1);
            for (size_t i = 0; i < (size_t)w * h; i++) {
                dst[i * 4 + 0] = rgba[i * 4 + 2];
                dst[i * 4 + 1] = rgba[i * 4 + 1];
                dst[i * 4 + 2] = rgba[i * 4 + 0];
                dst[i * 4 + 3] = 255;
            }
            GlobalUnlock(mem);
            if (!SetClipboardData(CF_DIB, mem)) GlobalFree(mem);
        }
        CloseClipboard();
    }
#endif
    return path;
}

// ---------------------------------------------------------------------------
// Janela e laço comum

struct App {
    SDL_Window* window = nullptr;
    SDL_GLContext gl = nullptr;
};

// Abre a janela com OpenGL 3.3 no driver que estiver carregado. Não mostra nada: só diz o motivo se falhar.
static bool tryOpenGLWindow(App& app, const char* title, bool fullscreen, std::string& why) {
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
    Uint32 flags = SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI;
    if (fullscreen) flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;
    app.window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 760, flags);
    if (!app.window) { why = std::string("janela: ") + SDL_GetError(); return false; }
    app.gl = SDL_GL_CreateContext(app.window);
    if (!app.gl) {
        // Alguns drivers só dão OpenGL 3.3 no perfil "core"; o Cartucho funciona nele também.
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
        app.gl = SDL_GL_CreateContext(app.window);
    }
    if (!app.gl) { why = std::string("OpenGL 3.3: ") + SDL_GetError(); return false; }
    SDL_GL_MakeCurrent(app.window, app.gl);
    SDL_GL_SetSwapInterval(1);
    int glVersion = gladLoadGL((GLADloadfunc)SDL_GL_GetProcAddress);
    if (!glVersion || GLAD_VERSION_MAJOR(glVersion) * 10 + GLAD_VERSION_MINOR(glVersion) < 33) {
        const char* renderer = glVersion && glGetString ? (const char*)glGetString(GL_RENDERER) : nullptr;
        why = std::string("o driver de vídeo só oferece OpenGL ") + (glVersion ? std::to_string(GLAD_VERSION_MAJOR(glVersion)) + "." + std::to_string(GLAD_VERSION_MINOR(glVersion)) : "nenhum") +
              " (" + (renderer ? renderer : "desconhecido") + ")";
        return false;
    }
    return true;
}

static void closeOpenGLWindow(App& app) {
    if (app.gl) SDL_GL_DeleteContext(app.gl);
    if (app.window) SDL_DestroyWindow(app.window);
    app.gl = nullptr;
    app.window = nullptr;
}

// Plano B para qualquer Windows: computador sem driver de vídeo, máquina virtual, placa antiga, área de
// trabalho remota… O Cartucho traz um OpenGL que roda no processador (Mesa, pasta "mesa").
static bool g_softwareGL = false;
static bool g_quiet = false;  // autoteste: sem janelas de aviso (ninguém para clicar em OK)
static bool loadSoftwareOpenGL() {
#ifdef _WIN32
    std::string dir = g_basePath + "mesa";
    std::string dll = dir + "/opengl32.dll";
    if (GetFileAttributesW(widen(dll).c_str()) == INVALID_FILE_ATTRIBUTES) return false;
    SetDllDirectoryW(widen(dir).c_str());  // as DLLs que o Mesa usa ficam na mesma pasta
    _putenv_s("GALLIUM_DRIVER", "llvmpipe");
    SDL_GL_UnloadLibrary();
    if (SDL_GL_LoadLibrary(dll.c_str()) != 0) return false;
    g_softwareGL = true;
    return true;
#else
    return false;
#endif
}

static bool createWindow(App& app, const char* title, bool fullscreen) {
    std::string why, firstWhy;
    bool ok = !g_softwareGL && tryOpenGLWindow(app, title, fullscreen, why);
    if (!ok) {
        firstWhy = why;
        closeOpenGLWindow(app);
        if (g_softwareGL || loadSoftwareOpenGL()) {
            ok = tryOpenGLWindow(app, title, fullscreen, why);
            if (ok) logStep("OpenGL da placa indisponível (%s); usando OpenGL por software", firstWhy.c_str());
            else closeOpenGLWindow(app);
        }
    }
    if (!ok) {
        std::string msg = "O Cartucho não conseguiu abrir a janela de vídeo.\n\nMotivo: " + (firstWhy.empty() ? why : firstWhy);
        if (!firstWhy.empty() && why != firstWhy) msg += "\nPlano B (OpenGL por software): " + why;
        msg += "\n\nInstale o driver de vídeo mais novo do fabricante (NVIDIA, AMD ou Intel) pelo Windows Update ou pelo site dele e tente de novo.";
        logStep("%s", msg.c_str());
        if (!g_quiet) SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Cartucho", msg.c_str(), nullptr);
        return false;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard | ImGuiConfigFlags_NavEnableGamepad;
    io.IniFilename = nullptr;
    setupStyle();
    ImGui_ImplSDL2_InitForOpenGL(app.window, app.gl);
    ImGui_ImplOpenGL3_Init("#version 330");
    return true;
}

static void destroyWindow(App& app) {
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    if (app.gl) SDL_GL_DeleteContext(app.gl);
    if (app.window) SDL_DestroyWindow(app.window);
}

static void beginFrame() {
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplSDL2_NewFrame();
    ImGui::NewFrame();
}

static void endFrame(App& app, bool clear) {
    ImGui::Render();
    int w, h;
    SDL_GL_GetDrawableSize(app.window, &w, &h);
    glViewport(0, 0, w, h);
    if (clear) {
        glClearColor(0.067f, 0.067f, 0.067f, 1);
        glClear(GL_COLOR_BUFFER_BIT);
    }
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    SDL_GL_SwapWindow(app.window);
}

// ---------------------------------------------------------------------------
// Modo de jogo

static std::string fileStem(const std::string& path) { return pathToUtf8(u8path(path).stem()); }

/** Extrai um .zip de console para uma pasta temporária e devolve o arquivo principal. */
static std::string extractZip(const std::string& zipPath, const SystemInfo& sys) {
    fs::path dir = u8path(g_prefPath + "run");
    std::error_code ec;
    fs::remove_all(dir, ec);
    fs::create_directories(dir, ec);
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_file(&zip, pathForCore(zipPath).c_str(), 0)) return "";
    std::string main;
    mz_uint n = mz_zip_reader_get_num_files(&zip);
    for (mz_uint i = 0; i < n; i++) {
        if (mz_zip_reader_is_file_a_directory(&zip, i)) continue;
        char name[512];
        mz_zip_reader_get_filename(&zip, i, name, sizeof(name));
        std::string base = pathToUtf8(u8path(name).filename());
        fs::path out = dir / u8path(base);
        mz_zip_reader_extract_to_file(&zip, i, pathForCore(pathToUtf8(dir)).append("/").append(base).c_str(), 0);
        std::string ext = extOf(base);
        if (!ext.empty()) ext.erase(0, 1);
        bool isSheet = ext == "cue" || ext == "gdi" || ext == "m3u";
        bool matches = std::find(sys.extensions.begin(), sys.extensions.end(), ext) != sys.extensions.end();
        if (isSheet || (main.empty() && matches)) main = pathToUtf8(out);
    }
    mz_zip_reader_end(&zip);
    if (main.empty()) {
        // O .zip trouxe o jogo em partes (jogo.iso.001, .002…): junta e procura de novo.
        split::joinInDir(dir);
        for (const auto& e : fs::directory_iterator(dir, ec)) {
            std::string x = extOf(e.path());
            if (!x.empty()) x.erase(0, 1);
            if (std::find(sys.extensions.begin(), sys.extensions.end(), x) != sys.extensions.end()) { main = pathToUtf8(e.path()); break; }
        }
    }
    return main;
}

/** Copia os arquivos de sistema que vêm com o programa (Dolphin Sys, blueMSX, PPSSPP) para a pasta do usuário. */
static void installBundledSystemFiles() {
    std::error_code ec;
    fs::path src = u8path(g_basePath + "system");
    fs::path dst = u8path(g_prefPath + "system");
    if (!fs::exists(src, ec)) return;
    fs::path marker = dst / ".bundled-v3";
    if (fs::exists(marker, ec)) return;
    fs::create_directories(dst, ec);
    fs::copy(src, dst, fs::copy_options::recursive | fs::copy_options::skip_existing, ec);
    FILE* m = fopen(pathToUtf8(marker).c_str(), "w");
    if (m) fclose(m);
}

static int playGame(const std::string& gamePath, const std::string& systemId, int autoFrames = 0) {
#ifdef _WIN32
    SetUnhandledExceptionFilter(crashFilter);
    signal(SIGABRT, abortHandler);
    _wremove(widen(logPath()).c_str());
    _wremove(widen(errorPath()).c_str());
#endif
    logStep("Cartucho para Windows · jogo: %s · sistema: %s", fileStem(gamePath).c_str(), systemId.c_str());
    const SystemInfo* sys = systemById(systemId);
    if (!sys) { logStep("sistema desconhecido"); return 1; }
    App app;
    std::string title = "Cartucho — " + titleFromStem(fileStem(gamePath));
    logStep("abrindo a janela do jogo");
    if (!createWindow(app, title.c_str(), autoFrames > 0 ? false : g_config.fullscreen)) { logStep("falha ao criar a janela/OpenGL: %s", SDL_GetError()); return 1; }
    // Fora da tela cheia, o jogo abre maximizado (ocupa a tela, com a barra de título para mover e fechar).
    if (autoFrames == 0 && !g_config.fullscreen) SDL_MaximizeWindow(app.window);
    logStep("OpenGL: %s / %s", (const char*)glGetString(GL_VENDOR), (const char*)glGetString(GL_RENDERER));

    // PS2: com a BIOS do console em system/pcsx2/bios, usa o PCSX2 (bem mais rápido); sem ela, o Play!.
    std::string coreName = sys->core;
    if (std::string(sys->id) == "ps2") {
        std::error_code ecb;
        bool bios = false;
        for (const auto& e : fs::directory_iterator(u8path(g_prefPath + "system/pcsx2/bios"), ecb))
            if (e.is_regular_file(ecb) && e.file_size(ecb) > 1000000) bios = true;
        if (bios && fs::exists(u8path(g_basePath + "cores/pcsx2_libretro.dll"), ecb)) coreName = "pcsx2";
    }
    std::string corePath = g_basePath + "cores/" + coreName + "_libretro.dll";
    {
        std::error_code ec0;
        logStep("core: %s (%s)", corePath.c_str(), fs::exists(u8path(corePath), ec0) ? "encontrado" : "NÃO encontrado");
    }
    std::string systemDir = g_prefPath + "system";
    std::string saveDir = g_prefPath + "saves/" + sys->id;
    std::string stateDir = g_prefPath + "states/" + sys->id;
    std::error_code ec;
    fs::create_directories(u8path(systemDir), ec);
    fs::create_directories(u8path(saveDir), ec);
    fs::create_directories(u8path(stateDir), ec);

    std::string actual = gamePath;
    std::string logicalPath = gamePath;
    {
        // Jogo em partes: junta tudo num arquivo só antes de abrir.
        auto parts = split::partsOf(u8path(gamePath));
        if (!parts.empty()) {
            logStep("juntando %d partes", (int)parts.size());
            fs::path runDir = u8path(g_prefPath + "run-partes");
            std::error_code ecj;
            fs::remove_all(runDir, ecj);
            fs::create_directories(runDir, ecj);
            fs::path joined = runDir / u8path(split::parse(pathToUtf8(u8path(gamePath).filename())).joined);
            if (split::join(parts, joined)) { actual = pathToUtf8(joined); logicalPath = actual; }
        }
    }
    std::string ext = extOf(actual);
    if (ext == ".zip" && std::string(sys->id) != "arcade" && std::string(sys->id) != "naomi") actual = extractZip(actual, *sys);

    std::string core = coreName;
    if (core == "melonds") {  // telas empilhadas e clique do mouse como toque na tela de baixo
        host::setOption("melonds_screen_layout", "Top/Bottom");
        host::setOption("melonds_screen_gap", "0");
        host::setOption("melonds_touch_mode", "Touch");
    } else if (core == "citra") {
        host::setOption("citra_layout_option", "Default Top-Bottom Screen");
        host::setOption("citra_touch_touchscreen", "enabled");
        host::setOption("citra_mouse_touchscreen", "disabled");
    }

    std::string error;
    logStep("carregando o core e o jogo");
    bool ok = !actual.empty() &&
              host::start(pathForCore(corePath), pathForCore(actual), pathForCore(systemDir), pathForCore(saveDir), error);
    if (actual.empty()) error = "Não encontrei o jogo dentro do arquivo compactado.";
    logStep(ok ? "jogo carregado" : "falha ao carregar: %s", error.c_str());
    if (autoFrames > 0 && !ok) return 2;
    long long framesDone = 0;
    bool logged60 = false;

    std::string stem = fileStem(logicalPath);
    std::string sram = saveDir + "/" + stem + ".srm";
    if (ok) host::loadSram(pathForCore(sram));
    host::setVolume(g_config.volume);

    SDL_GameController* pads[4] = {nullptr, nullptr, nullptr, nullptr};
    SDL_JoystickID padIds[4] = {-1, -1, -1, -1};
    auto openPads = [&]() {
        for (int i = 0; i < SDL_NumJoysticks(); i++) {
            if (!SDL_IsGameController(i)) continue;
            SDL_JoystickID id = SDL_JoystickGetDeviceInstanceID(i);
            bool already = false;
            for (int p = 0; p < 4; p++) if (padIds[p] == id) already = true;
            if (already) continue;
            for (int p = 0; p < 4; p++) {
                if (!pads[p]) { pads[p] = SDL_GameControllerOpen(i); padIds[p] = id; break; }
            }
        }
    };
    openPads();

    bool menu = !ok;
    bool running = true;
    bool fastForward = false;
    std::string toast;
    Uint64 toastUntil = 0;
    Uint64 last = SDL_GetPerformanceCounter();
    Uint64 lastSram = SDL_GetTicks64();
    // Save automático rotativo (3 slots): auto1/auto2/auto3
    int autoSlot = 1;
    Uint64 lastAutoSave = SDL_GetTicks64();
    auto autoStatePath = [&](int s) { return stateDir + "/" + stem + ".auto" + std::to_string(s) + ".state"; };
    // Watchdog de tela congelada: detecta fps zero por 5+ segundos
    long long watchdogSnapshot = 0;
    Uint64 watchdogFrozenSince = 0;
    bool watchdogSaved = false;
    Uint64 lastWatchdogCheck = SDL_GetTicks64();
    // Velocidade real: quadros emulados ÷ quadros esperados, só em jogo normal (sem menu nem acelerar).
    double measuredTime = 0, measuredFrames = 0;
    double acc = 0;
    int slot = 1;
    int capturingKey = -1;                              // menu > Controles: esperando a nova tecla
    Uint64 menuHintUntil = SDL_GetTicks64() + 5000;    // botão "Menu" visível no começo e ao mexer o mouse

    auto showToast = [&](const std::string& t) { toast = t; toastUntil = SDL_GetTicks64() + 2000; };
    auto statePath = [&](int s) { return stateDir + "/" + stem + ".slot" + std::to_string(s); };

    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (capturingKey >= 0 && e.type == SDL_KEYDOWN) {
                if (e.key.keysym.scancode != SDL_SCANCODE_ESCAPE) g_config.keys[capturingKey] = e.key.keysym.scancode;
                capturingKey = -1;
                saveConfig();
                continue;
            }
            ImGui_ImplSDL2_ProcessEvent(&e);
            if (e.type == SDL_QUIT) running = false;
            if (e.type == SDL_MOUSEMOTION) menuHintUntil = SDL_GetTicks64() + 2500;
            if (e.type == SDL_CONTROLLERDEVICEADDED) openPads();
            if (!menu && (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP || e.type == SDL_MOUSEMOTION)) {
                int ww, wh, dw, dh;
                SDL_GetWindowSize(app.window, &ww, &wh);
                SDL_GL_GetDrawableSize(app.window, &dw, &dh);
                int mx, my;
                Uint32 state = SDL_GetMouseState(&mx, &my);
                host::setPointer(mx * (float)dw / (ww > 0 ? ww : 1), my * (float)dh / (wh > 0 ? wh : 1), (state & SDL_BUTTON_LMASK) != 0);
            }
            if (e.type == SDL_CONTROLLERDEVICEREMOVED) {
                for (int p = 0; p < 4; p++) {
                    if (padIds[p] == e.cdevice.which) {
                        SDL_GameControllerClose(pads[p]);
                        pads[p] = nullptr;
                        padIds[p] = -1;
                        if (p == 0 && ok) menu = true;
                    }
                }
            }
            if (e.type == SDL_KEYDOWN && !e.key.repeat) {
                SDL_Scancode sc = e.key.keysym.scancode;
                if (sc == SDL_SCANCODE_ESCAPE && ok) { menu = !menu; capturingKey = -1; }
                if (sc == SDL_SCANCODE_F11) {
                    g_config.fullscreen = !g_config.fullscreen;
                    SDL_SetWindowFullscreen(app.window, g_config.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
                }
                if (sc == SDL_SCANCODE_F2 && ok) showToast(host::saveState(pathForCore(statePath(slot))) ? "Estado salvo" : "Não foi possível salvar");
                if (sc == SDL_SCANCODE_F4 && ok) showToast(host::loadState(pathForCore(statePath(slot))) ? "Estado carregado" : "Nenhum estado neste espaço");
                if (sc == SDL_SCANCODE_TAB) fastForward = true;
            }
            if (e.type == SDL_KEYUP && e.key.keysym.scancode == SDL_SCANCODE_TAB) fastForward = false;
            if (e.type == SDL_CONTROLLERBUTTONDOWN && e.cbutton.button == SDL_CONTROLLER_BUTTON_GUIDE && ok) menu = !menu;
        }
        host::setPaused(menu);

        // Entrada: teclado no jogador 1; controles nos jogadores 1-4.
        uint32_t masks[4] = {0, 0, 0, 0};
        if (!menu) {
            const Uint8* ks = SDL_GetKeyboardState(nullptr);
            for (int i = 0; i < RP_COUNT; i++)
                if (g_config.keys[i] > 0 && ks[g_config.keys[i]]) masks[0] |= 1u << i;
            for (int p = 0; p < 4; p++) {
                SDL_GameController* c = pads[p];
                if (!c) continue;
                struct M { SDL_GameControllerButton b; int id; };
                static const M map[] = {
                    {SDL_CONTROLLER_BUTTON_A, RP_B}, {SDL_CONTROLLER_BUTTON_B, RP_A}, {SDL_CONTROLLER_BUTTON_X, RP_Y},
                    {SDL_CONTROLLER_BUTTON_Y, RP_X}, {SDL_CONTROLLER_BUTTON_LEFTSHOULDER, RP_L},
                    {SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, RP_R}, {SDL_CONTROLLER_BUTTON_LEFTSTICK, RP_L3},
                    {SDL_CONTROLLER_BUTTON_RIGHTSTICK, RP_R3}, {SDL_CONTROLLER_BUTTON_START, RP_START},
                    {SDL_CONTROLLER_BUTTON_BACK, RP_SELECT}, {SDL_CONTROLLER_BUTTON_DPAD_UP, RP_UP},
                    {SDL_CONTROLLER_BUTTON_DPAD_DOWN, RP_DOWN}, {SDL_CONTROLLER_BUTTON_DPAD_LEFT, RP_LEFT},
                    {SDL_CONTROLLER_BUTTON_DPAD_RIGHT, RP_RIGHT},
                };
                for (const auto& m : map)
                    if (SDL_GameControllerGetButton(c, m.b)) masks[p] |= 1u << m.id;
                if (SDL_GameControllerGetAxis(c, SDL_CONTROLLER_AXIS_TRIGGERLEFT) > 12000) masks[p] |= 1u << RP_L2;
                if (SDL_GameControllerGetAxis(c, SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > 12000) masks[p] |= 1u << RP_R2;
                auto axis = [&](SDL_GameControllerAxis a) {
                    int v = SDL_GameControllerGetAxis(c, a);
                    return std::abs(v) < 5000 ? 0 : v;
                };
                host::setAnalog(p, 0, axis(SDL_CONTROLLER_AXIS_LEFTX), axis(SDL_CONTROLLER_AXIS_LEFTY));
                host::setAnalog(p, 1, axis(SDL_CONTROLLER_AXIS_RIGHTX), axis(SDL_CONTROLLER_AXIS_RIGHTY));
            }
        }
        for (int p = 0; p < 4; p++) host::setButtons(p, masks[p]);

        // Ritmo pelo relógio (fps do core), independente da taxa do monitor.
        Uint64 now = SDL_GetPerformanceCounter();
        double dt = (double)(now - last) / SDL_GetPerformanceFrequency();
        last = now;
        if (dt > 0.25) dt = 0.25;
        if (ok && !menu) {
            acc += dt;
            double frame = 1.0 / host::fps();
            int runs = 0;
            while (acc >= frame && runs < 3) {
                if (framesDone == 0) logStep("primeiro quadro");
                host::runFrame(fastForward);
                acc -= frame;
                runs++;
                framesDone++;
            }
            if (framesDone >= 60 && !logged60) { logStep("60 quadros ok"); logged60 = true; }
            if (autoFrames > 0 && framesDone >= autoFrames) running = false;
            if (!fastForward && dt < 0.2) {
                measuredTime += dt;
                measuredFrames += runs;
            }
            if (runs == 3) acc = 0;
            if (SDL_GetTicks64() - lastSram > 30000) {
                lastSram = SDL_GetTicks64();
                host::saveSram(pathForCore(sram));
            }
            // Save automático rotativo
            Uint64 nowMs = SDL_GetTicks64();
            if (g_config.autoSaveMinutes > 0) {
                Uint64 periodMs = (Uint64)g_config.autoSaveMinutes * 60000ULL;
                if (nowMs - lastAutoSave >= periodMs) {
                    lastAutoSave = nowMs;
                    std::string tmpPath = stateDir + "/" + stem + ".autotmp.state";
                    if (host::saveState(pathForCore(tmpPath))) {
                        std::error_code ecrn;
                        fs::rename(u8path(tmpPath), u8path(autoStatePath(autoSlot)), ecrn);
                        autoSlot = (autoSlot % 3) + 1;
                    }
                }
            }
            // Watchdog de tela congelada (fps zero por 5+ s → save emergencial)
            if (nowMs - lastWatchdogCheck >= 1000) {
                lastWatchdogCheck = nowMs;
                long long curFrames = framesDone;
                if (curFrames != watchdogSnapshot) {
                    watchdogSnapshot = curFrames;
                    watchdogFrozenSince = 0;
                    watchdogSaved = false;
                } else {
                    if (watchdogFrozenSince == 0) watchdogFrozenSince = nowMs;
                    else if (!watchdogSaved && nowMs - watchdogFrozenSince >= 5000) {
                        watchdogSaved = true;
                        std::string tmpPath = stateDir + "/" + stem + ".autotmp.state";
                        if (host::saveState(pathForCore(tmpPath))) {
                            std::error_code ecrn;
                            fs::rename(u8path(tmpPath), u8path(autoStatePath(autoSlot)), ecrn);
                            autoSlot = (autoSlot % 3) + 1;
                        }
                        showToast("⚠ O jogo pode ter travado — checkpoint salvo");
                    }
                }
            }
        }

        int w, h;
        SDL_GL_GetDrawableSize(app.window, &w, &h);
        host::draw(w, h, g_config.integerScale, g_config.smooth);

        beginFrame();
        ImGuiIO& io = ImGui::GetIO();
        pushGraphite();  // dentro do jogo, tudo em grafite
        if (!toast.empty() && SDL_GetTicks64() < toastUntil) {
            ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, 24), ImGuiCond_Always, ImVec2(0.5f, 0));
            ImGui::Begin("##toast", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoNav);
            ImGui::TextUnformatted(toast.c_str());
            ImGui::End();
        }
        // Fora do menu: um botão "Menu" discreto aparece ao mexer o mouse (e nos primeiros segundos de jogo).
        if (!menu && ok && SDL_GetTicks64() < menuHintUntil) {
            ImGui::SetNextWindowPos(ImVec2(16, 16));
            ImGui::SetNextWindowBgAlpha(0.0f);
            ImGui::Begin("##menuhint", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoNav |
                                                     ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoBackground);
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.07f, 0.07f, 0.07f, 0.78f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.16f, 0.16f, 0.16f, 0.92f));
            if (ImGui::Button("Menu  ·  Esc")) menu = true;
            ImGui::PopStyleColor(2);
            ImGui::End();
        }
        if (menu) {
            ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), io.DisplaySize, IM_COL32(0, 0, 0, 170));
            ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
            ImGui::SetNextWindowSize(ImVec2(std::min(520.0f, io.DisplaySize.x - 32), 0));
            ImGui::PushStyleColor(ImGuiCol_WindowBg, brand::v(IM_COL32(0x2B, 0x2B, 0x33, 250)));
            ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 22.0f);
            ImGui::Begin("##menu", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize);
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextWrapped("%s", ok ? titleFromStem(stem).c_str() : "Não deu para abrir o jogo");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::TextDisabled("%s", sys->name);
            ImGui::Spacing();
            ImVec2 full(-1, 0);
            float half = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x) * 0.5f;
            if (!ok) {
                ImGui::TextWrapped("%s", error.c_str());
                ImGui::Spacing();
                if (primaryButton("Voltar à biblioteca", full)) running = false;
            } else if (ImGui::BeginTabBar("##menutabs")) {
                if (ImGui::BeginTabItem("Jogo")) {
                    ImGui::Spacing();
                    if (primaryButton("Continuar jogando", full)) menu = false;
                    ImGui::Spacing();
                    ImGui::TextDisabled("Estado salvo (escolha um dos 3 espaços)");
                    float third = (ImGui::GetContentRegionAvail().x - 2 * ImGui::GetStyle().ItemSpacing.x) / 3.0f;
                    for (int k = 1; k <= 3; k++) {
                        if (k > 1) ImGui::SameLine();
                        char lbl[16];
                        snprintf(lbl, sizeof(lbl), "Espaço %d", k);
                        bool sel = slot == k;
                        if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(157 / 255.f, 184 / 255.f, 1, 0.28f));
                        if (ImGui::Button(lbl, ImVec2(third, 0))) slot = k;
                        if (sel) ImGui::PopStyleColor();
                    }
                    if (ImGui::Button("Salvar  (F2)", ImVec2(half, 0))) { showToast(host::saveState(pathForCore(statePath(slot))) ? "Estado salvo no espaço " + std::to_string(slot) : "Não foi possível salvar"); menu = false; }
                    ImGui::SameLine();
                    if (ImGui::Button("Carregar  (F4)", ImVec2(half, 0))) { showToast(host::loadState(pathForCore(statePath(slot))) ? "Estado carregado" : "Nenhum estado neste espaço"); menu = false; }
                    ImGui::Spacing();
                    if (ImGui::Button("Reiniciar o jogo", full)) { host::reset(); menu = false; }
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();
                    ImGui::TextDisabled("Save automático (checkpoints rotativos)");
                    static const int autoOpts[] = {0,1,2,5,10,15,30};
                    static const char* autoLabels[] = {"Desligado","1 minuto","2 minutos","5 minutos","10 minutos","15 minutos","30 minutos"};
                    int curIdx = 0;
                    for (int i = 0; i < 7; i++) if (autoOpts[i] == g_config.autoSaveMinutes) { curIdx = i; break; }
                    ImGui::SetNextItemWidth(-1);
                    if (ImGui::BeginCombo("##autosave", autoLabels[curIdx])) {
                        for (int i = 0; i < 7; i++) {
                            bool sel = (i == curIdx);
                            if (ImGui::Selectable(autoLabels[i], sel)) {
                                g_config.autoSaveMinutes = autoOpts[i];
                                lastAutoSave = SDL_GetTicks64();
                                saveConfig();
                            }
                            if (sel) ImGui::SetItemDefaultFocus();
                        }
                        ImGui::EndCombo();
                    }
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Vídeo e som")) {
                    ImGui::Spacing();
                    bool fs = g_config.fullscreen;
                    if (ImGui::Checkbox("Tela cheia  (F11)", &fs)) {
                        g_config.fullscreen = fs;
                        SDL_SetWindowFullscreen(app.window, fs ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
                    }
                    ImGui::Checkbox("Escala inteira (pixels nítidos, pode deixar bordas)", &g_config.integerScale);
                    ImGui::Checkbox("Filtro suave (imagem menos serrilhada)", &g_config.smooth);
                    ImGui::Spacing();
                    ImGui::TextUnformatted("Volume");
                    ImGui::SetNextItemWidth(-1);
                    int vol = (int)(g_config.volume * 100 + 0.5f);
                    if (ImGui::SliderInt("##volume", &vol, 0, 100, "%d%%")) { g_config.volume = vol / 100.0f; host::setVolume(g_config.volume); }
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Controles")) {
                    ImGui::Spacing();
                    ImGui::TextDisabled("Teclado do jogador 1: clique numa tecla e aperte a nova.");
                    ImGui::TextDisabled("Controles USB e Bluetooth já funcionam sozinhos (até 4).");
                    ImGui::BeginChild("##keys", ImVec2(0, std::min(320.0f, io.DisplaySize.y * 0.4f)), ImGuiChildFlags_None);
                    if (ImGui::BeginTable("##keytable", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
                        static const int order[] = {RP_UP, RP_DOWN, RP_LEFT, RP_RIGHT, RP_A, RP_B, RP_X, RP_Y, RP_L, RP_R, RP_L2, RP_R2, RP_L3, RP_R3, RP_START, RP_SELECT};
                        for (int id : order) {
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn();
                            ImGui::AlignTextToFramePadding();
                            ImGui::TextUnformatted(retroPadName(id));
                            ImGui::TableNextColumn();
                            ImGui::PushID(id);
                            const char* label = capturingKey == id ? "Aperte uma tecla…" : SDL_GetScancodeName((SDL_Scancode)g_config.keys[id]);
                            if (ImGui::Button(label && *label ? label : "—", ImVec2(-1, 0))) capturingKey = id;
                            ImGui::PopID();
                        }
                        ImGui::EndTable();
                    }
                    ImGui::EndChild();
                    if (ImGui::Button("Restaurar teclas padrão", full)) { defaultKeys(g_config); saveConfig(); }
                    ImGui::EndTabItem();
                }
                ImGui::EndTabBar();
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();
                if (ImGui::Button("Sair do jogo e voltar à biblioteca", full)) running = false;
                ImGui::TextDisabled("Esc abre e fecha este menu  ·  segure Tab para acelerar");
            }
            ImGui::End();
            ImGui::PopStyleVar();
            ImGui::PopStyleColor();
        }
        popGraphite();
        endFrame(app, false);
    }

    if (ok) host::saveSram(pathForCore(sram));
    if (ok && measuredTime > 20.0) {
        float speed = (float)std::min(1.0, measuredFrames / (measuredTime * host::fps()));
        perf::saveMeasured(pathForCore(perfPath()), gamePath, speed);
    }
    saveConfig();
    logStep("encerrando (%lld quadros)", framesDone);
    host::shutdown();
    logStep("fim");
    for (auto* p : pads) if (p) SDL_GameControllerClose(p);
    destroyWindow(app);
    return 0;
}

// ---------------------------------------------------------------------------
// Biblioteca (janela principal)

static std::string g_crashReport;  // detalhes do último jogo que fechou por erro

#ifdef _WIN32
// ---------------------------------------------------------------- saves na nuvem (Google Drive)

static std::unique_ptr<gdrive::Account> g_drive;
static std::atomic<long long> g_lastDriveSync{0};

/** Sincroniza os saves em segundo plano (ao abrir o programa e ao fechar um jogo). */
static void startDriveSync() {
    if (!g_drive || !g_drive->signedIn() || gdrive::state().busy.exchange(true)) return;
    gdrive::setStatus("Sincronizando os saves…");
    std::thread([] {
        std::string r = gdrive::syncSaves(*g_drive, g_prefPath);
        gdrive::setStatus(r);
        g_lastDriveSync = (long long)GetTickCount64();
        gdrive::state().busy = false;
    }).detach();
}

/** Antes de abrir um jogo: traz o save mais novo da nuvem (de outro aparelho), sem demorar muito. */
static void driveSyncBeforePlay() {
    if (!g_drive || !g_drive->signedIn()) return;
    for (int i = 0; i < 150 && gdrive::state().busy.load(); i++) SDL_Delay(100);
    if ((long long)GetTickCount64() - g_lastDriveSync.load() < 60000) return;
    if (gdrive::state().busy.exchange(true)) return;
    gdrive::setStatus(gdrive::syncSaves(*g_drive, g_prefPath));
    g_lastDriveSync = (long long)GetTickCount64();
    gdrive::state().busy = false;
}
#endif

static void launchGame(const Game& g, SDL_Window* window) {
    saveConfig();
#ifdef _WIN32
    driveSyncBeforePlay();
    wchar_t exe[MAX_PATH];
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring cmd = L"\"" + std::wstring(exe) + L"\" --play \"" + widen(g.path) + L"\" " + widen(g.system);
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    long long started = (long long)time(nullptr);
    if (CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
        SDL_HideWindow(window);
        WaitForSingleObject(pi.hProcess, INFINITE);
        recordPlaytime(g.path, started, (long long)time(nullptr) - started);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        if (code != 0 && code != 1 && code != 2) {
            std::string err = readText(g_prefPath + "ultimo-erro.txt");
            g_crashReport = err.empty() ? "O jogo fechou sozinho (código " + std::to_string((unsigned long)code) + ").\n\nEtapas:\n" + readText(g_prefPath + "ultimo-jogo.log") : err;
        }
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        SDL_ShowWindow(window);
        SDL_RaiseWindow(window);
        startDriveSync();
    }
    loadConfig();
#else
    (void)window;
    playGame(g.path, g.system);
#endif
}


// ------------------------------------------------------------------ Loja (homebrew gratuito do Homebrew Hub)
struct StoreGame {
    std::string slug, title, platform, type, developer, license, file, shot, basePath, year, desc;
    std::string url, cover, lang, source, site;
    std::vector<std::string> genres;
    int players = 0;
    char letter = '#';
};
static std::vector<StoreGame> g_store;
static std::map<std::string, size_t> g_storeBySlug;
static std::atomic<int> g_storeState{0};  // 0 parado · 1 baixando · 2 pronto · 3 erro
static std::string g_storeDone;            // caminho do jogo baixado
static std::string g_storeError;

static void parseStore(const std::string& text);

static void loadStore() {
    g_store.clear();
    g_storeBySlug.clear();
    parseStore(readText(g_basePath + "loja.tsv"));
    // Sem catálogo junto do programa (instalação antiga ou arquivo apagado): usa o salvo ou baixa o da versão mais nova.
    std::string saved = g_prefPath + "loja.tsv";
    if (g_store.empty()) parseStore(readText(saved));
#ifdef _WIN32
    if (g_store.empty()) {
        std::string part = saved + ".part";
        if (URLDownloadToFileW(nullptr, L"https://github.com/andrefeeelipe/Cartucho/releases/latest/download/loja.tsv",
                               widen(part).c_str(), 0, nullptr) == S_OK) {
            std::error_code ec;
            fs::remove(u8path(saved), ec);
            fs::rename(u8path(part), u8path(saved), ec);
            parseStore(readText(saved));
        }
    }
#endif
}

static void parseStore(const std::string& text) {
    std::stringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        std::vector<std::string> f;
        size_t start = 0;
        while (true) {
            size_t tab = line.find('\t', start);
            f.push_back(line.substr(start, tab == std::string::npos ? std::string::npos : tab - start));
            if (tab == std::string::npos) break;
            start = tab + 1;
        }
        if (f.size() < 11 || f[0].empty() || f[6].empty() || !systemById(f[2])) continue;
        StoreGame g{f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9], f[10]};
        if (f.size() >= 18) {
            g.url = f[11]; g.cover = f[12]; g.lang = f[14]; g.players = atoi(f[15].c_str()); g.source = f[16]; g.site = f[17];
            std::stringstream gs(f[13]);
            std::string one;
            while (std::getline(gs, one, ',')) if (!one.empty()) g.genres.push_back(one);
        }
        g.letter = titleLetter(g.title);
        g_storeBySlug[g.slug] = g_store.size();
        g_store.push_back(std::move(g));
    }
}

/** Jogo da Loja pelo caminho do arquivo baixado (a pasta tem o código do jogo). */
static const StoreGame* storeGameForPath(const std::string& path) {
    fs::path p = u8path(path);
    std::string slug = pathToUtf8(p.parent_path().filename());
    auto it = g_storeBySlug.find(slug);
    if (it == g_storeBySlug.end()) return nullptr;
    bool inStore = lower(pathToUtf8(p.parent_path().parent_path().filename())) == "loja";
    return inStore ? &g_store[it->second] : nullptr;
}

static std::string storePlatformForPath(const std::string& path) {
    const StoreGame* g = storeGameForPath(path);
    return g ? g->platform : std::string();
}

static std::string storeLocalPath(const StoreGame& g) { return g_prefPath + "loja/" + g.slug + "/" + g.file; }

static std::string urlEncode(const std::string& s) {
    std::string out;
    char buf[4];
    for (unsigned char ch : s) {
        if (isalnum(ch) || ch == '-' || ch == '_' || ch == '.' || ch == '~' || ch == '/') out += (char)ch;
        else { snprintf(buf, sizeof(buf), "%%%02X", ch); out += buf; }
    }
    return out;
}

static void downloadStoreGame(StoreGame g) {
    g_storeState = 1;
    std::thread([g]() {
        std::string target = storeLocalPath(g);
        std::error_code ec;
        fs::create_directories(u8path(target).parent_path(), ec);
        std::string urls[2] = {
            g.url.empty() ? "https://hh3.gbdev.io/static/" + g.basePath + "/entries/" + urlEncode(g.slug) + "/" + urlEncode(g.file) : g.url,
            g.url.empty() ? "https://hh3.gbdev.io/api/entry/" + urlEncode(g.slug) + "/" + urlEncode(g.file) : g.url,
        };
        bool ok = false;
#ifdef _WIN32
        std::string part = target + ".part";
        for (const auto& u : urls) {
            if (g.url.empty() && g.basePath.empty() && &u == &urls[0]) continue;
            if (URLDownloadToFileW(nullptr, widen(u).c_str(), widen(part).c_str(), 0, nullptr) == S_OK) { ok = true; break; }
        }
        if (ok) {
            fs::rename(u8path(part), u8path(target), ec);
            ok = !ec;
        }
#endif
        if (ok) { g_storeDone = target; g_storeState = 2; }
        else { g_storeError = "Não foi possível baixar \"" + g.title + "\". Confira a internet e tente de novo."; g_storeState = 3; }
    }).detach();
}

static const char* storePlatformName(const std::string& p) {
    const SystemInfo* s = systemById(p);
    return s ? s->name : p.c_str();
}

static const char* kGenres[] = {"Ação", "Aventura", "Plataforma", "Tiro", "Corrida", "Esporte", "Luta", "Quebra-cabeça", "RPG",
                                "Estratégia", "Simulação", "Labirinto", "Tabuleiro e cartas", "Educativo", "Casual", "Música"};

static bool hasGenre(const StoreGame& g, const char* genre) {
    return std::find(g.genres.begin(), g.genres.end(), std::string(genre)) != g.genres.end();
}

/** Nome de arquivo de versão em português (traduções da comunidade e lançamentos brasileiros). */
static bool looksPortuguese(const std::string& name) {
    std::string n = lower(name);
    for (const char* k : {"pt-br", "ptbr", "pt_br", "(br)", "[br]", "(brazil", "portugu", "traduc", "[t+por", "[t-por", "[t+bra", "(pt)"})
        if (n.find(k) != std::string::npos) return true;
    return false;
}

/** Faixa A–Z: devolve true quando a letra escolhida muda. */
static bool letterBar(char& selected, const bool available[27]) {
    bool changed = false;
    const char* labels = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (ImGui::SmallButton(selected == 0 ? "[A-Z]" : "A-Z")) { selected = 0; changed = true; }
    for (int i = 0; i < 27; i++) {
        ImGui::SameLine(0, 2);
        char buf[8];
        char l = labels[i];
        snprintf(buf, sizeof(buf), selected == l ? "[%c]" : "%c", l);
        ImGui::BeginDisabled(!available[i] && selected != l);
        if (ImGui::SmallButton(buf)) { selected = selected == l ? 0 : l; changed = true; }
        ImGui::EndDisabled();
    }
    return changed;
}

static int letterIndex(char l) { return l == '#' ? 0 : (l >= 'A' && l <= 'Z') ? l - 'A' + 1 : 0; }

static std::string lowerStr(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), ::tolower);
    return s;
}

// ---- Versões do mesmo jogo (traduzida, original, outra região, .zip e solto…) viram um cartão só.

/** Chave do jogo: sistema + palavras do nome sem região, tradução, lixo de site ("Pokemon Fire Red (PT-BR)" e
 *  "Pokemon - FireRed Version (USA)" dão a mesma chave). Sem palavras, o jogo fica sozinho. */
static std::string versionKey(const Game& g) {
    std::string k;
    for (const auto& t : covers::detail::tokens(g.title)) k += t;
    if (k.size() < 2) return "p:" + g.path;
    const SystemInfo* sys = systemById(g.system);
    // Game Boy e Game Boy Color dividem jogos: contam como o mesmo sistema aqui.
    std::string sid = g.system == "gbc" ? "gb" : g.system;
    (void)sys;
    return sid + "|" + k;
}

struct VersionGroups {
    int version = -1;
    std::vector<int> groupOf;                 // jogo -> grupo
    std::vector<std::vector<size_t>> members; // grupo -> jogos
};

static void buildGroups(VersionGroups& vg) {
    if (vg.version == g_gamesVersion && vg.groupOf.size() == g_games.size()) return;
    vg.version = g_gamesVersion;
    vg.groupOf.assign(g_games.size(), -1);
    vg.members.clear();
    std::map<std::string, int> byKey;
    for (size_t i = 0; i < g_games.size(); i++) {
        std::string key = versionKey(g_games[i]);
        auto it = byKey.find(key);
        int gid;
        if (it == byKey.end()) { gid = (int)vg.members.size(); byKey[key] = gid; vg.members.emplace_back(); }
        else gid = it->second;
        vg.groupOf[i] = gid;
        vg.members[gid].push_back(i);
    }
    if (!g_games.empty()) logStep("biblioteca: %d arquivos em %d cartões (versões juntas)", (int)g_games.size(), (int)vg.members.size());
}

/** Versão escolhida por último para cada jogo (versoes.txt): o clique já abre ela. */
static std::map<std::string, std::string> g_versionChoice;
static void loadVersionChoices() {
    std::stringstream in(readText(g_prefPath + "versoes.txt"));
    std::string line;
    while (std::getline(in, line)) {
        size_t tab = line.find('\t');
        if (tab != std::string::npos) g_versionChoice[line.substr(0, tab)] = line.substr(tab + 1);
    }
}
static void saveVersionChoices() {
    std::string out;
    for (const auto& kv : g_versionChoice) out += kv.first + "\t" + kv.second + "\n";
#ifdef _WIN32
    FILE* f = _wfopen(widen(g_prefPath + "versoes.txt").c_str(), L"wb");
#else
    FILE* f = fopen((g_prefPath + "versoes.txt").c_str(), "wb");
#endif
    if (f) { fwrite(out.data(), 1, out.size(), f); fclose(f); }
}

/** Nome curto de uma versão para a lista: o que está entre parênteses/colchetes no arquivo, ou o próprio nome. */
static std::string versionLabel(const Game& g) {
    std::string name = pathToUtf8(u8path(g.path).filename());
    std::string tags;
    int depth = 0;
    std::string cur;
    for (char c : name) {
        if (c == '(' || c == '[') { if (depth++ == 0) cur.clear(); continue; }
        if ((c == ')' || c == ']') && depth > 0) { if (--depth == 0 && !cur.empty()) tags += (tags.empty() ? "" : " · ") + cur; continue; }
        if (depth > 0) cur += c;
    }
    std::string ext = extOf(name);
    if (!ext.empty()) ext = ext.substr(1);
    for (auto& ch : ext) ch = (char)toupper((unsigned char)ch);
    return (tags.empty() ? g.title : tags) + "  ·  " + ext;
}

static int runLibrary(int autoFrames = 0) {
#ifdef _WIN32
    // Se a tela inicial fechar por erro, o motivo fica em inicio-erro.txt e aparece na próxima vez que abrir.
    g_logName = "inicio.log";
    g_errName = "inicio-erro.txt";
    std::string previous = readText(errorPath());
    _wremove(widen(errorPath()).c_str());
    _wremove(widen(logPath()).c_str());
    SetUnhandledExceptionFilter(crashFilter);
    signal(SIGABRT, abortHandler);
#endif
    logStep("Cartucho iniciando");
    App app;
    if (!createWindow(app, "Cartucho", false)) return 1;
    logStep("janela aberta");
    g_hw = perf::detect();
    perf::loadMeasured(pathForCore(perfPath()));
    loadStore();
    logStep("loja: %d jogos", (int)g_store.size());
    covers::start(g_prefPath);
    loadVersionChoices();
    VersionGroups groups;
    int versionsOf = -1;          // grupo cuja lista de versões está aberta
    bool openVersions = false;
    int menuFor = -1;             // jogo do menu do botão direito
    bool openGameMenu = false;
    GLuint cardTex = 0;           // prévia do card de compartilhar
    std::string cardPath;
    bool openCard = false;
    std::map<std::string, std::pair<GLuint, ImVec2>> coverTex;  // capa já na placa de vídeo, por jogo
    scanFolders();
#ifdef _WIN32
    if (!previous.empty()) g_crashReport = "Da última vez, o Cartucho fechou sozinho ao abrir. Se continuar, copie e mande isto:\n\n" + previous;
#endif
#ifdef _WIN32
    g_drive = std::make_unique<gdrive::Account>(g_prefPath);
    startDriveSync();
#endif
    char storeSearch[128] = "";
    std::string storePlatform;
    int storeKind = 0;      // 0 jogos · 1 demos · 2 tudo
    int storeGenre = -1;
    int storeLang = 0;      // 0 todos · 1 pt · 2 en · 3 es · 4 outros
    int storeEra = 0;       // 0 todas · 1980..2020
    int storePlayers = 0;   // 0 tanto faz · 1 · 2+
    int storeSort = 0;      // 0 A–Z · 1 Z–A · 2 novos · 3 antigos
    bool storeOnlyHave = false;
    char storeLetter = 0;
    std::vector<size_t> storeView;
    std::string storeViewKey = "?";
    char libLetter = 0;
    int libGenre = -1;
    bool libPt = false;
    int libSort = 0;
    std::vector<std::string> storePlatforms;
    for (const auto& sg : g_store)
        if (std::find(storePlatforms.begin(), storePlatforms.end(), sg.platform) == storePlatforms.end()) storePlatforms.push_back(sg.platform);
    std::string storeWanted;  // título do jogo baixando
    const Game* confirmGame = nullptr;
    perf::Verdict confirmVerdict;
    bool openConfirm = false;

    enum class Screen { Library, Settings, Store };
    Screen screen = Screen::Library;
    char search[128] = "";
    int filter = -1;
    int capturing = -1;
    bool running = true;

    int frame = 0;
    while (running) {
        pollScan();
        // Capas que acabaram de chegar viram textura (poucas por quadro, para não engasgar).
        for (int k = 0; k < 6; k++) {
            covers::Pixels px;
            if (!covers::take(px)) break;
            GLuint tex = 0;
            glGenTextures(1, &tex);
            glBindTexture(GL_TEXTURE_2D, tex);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, px.w, px.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.rgba.data());
            coverTex[px.key] = {tex, ImVec2((float)px.w, (float)px.h)};
            if (coverTex.size() <= 3) logStep("capa: %s (%dx%d)", fileStem(px.key).c_str(), px.w, px.h);
        }
        // Autoteste da tela inicial: passa pela Biblioteca, Loja e Ajustes e sai.
        if (autoFrames > 0) {
            frame++;
            if (frame == autoFrames / 3) screen = Screen::Store;
            if (frame == 2 * autoFrames / 3) screen = Screen::Settings;
            if (frame == autoFrames) screen = Screen::Library;
            // Espera a procura e (até ~20 s) a primeira capa chegar da internet.
            if (frame >= autoFrames && !g_scanning.load() && (!coverTex.empty() || frame > autoFrames * 6)) running = false;
            if (frame > autoFrames * 40) { logStep("autoteste: a procura nas pastas não terminou"); running = false; }
        }
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (capturing >= 0 && e.type == SDL_KEYDOWN) {
                if (e.key.keysym.scancode != SDL_SCANCODE_ESCAPE) g_config.keys[capturing] = e.key.keysym.scancode;
                capturing = -1;
                saveConfig();
                continue;
            }
            ImGui_ImplSDL2_ProcessEvent(&e);
            if (e.type == SDL_QUIT) running = false;
        }

        beginFrame();
        ImGuiIO& io = ImGui::GetIO();
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(io.DisplaySize);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGui::Begin("##main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBringToFrontOnFocus);
        ImGui::PopStyleVar();
        // Menu lateral de 232px (Windows), como no wireframe.
        {
            int pick = sidebar(screen == Screen::Library ? 0 : screen == Screen::Store ? 1 : 2);
            if (pick == 0) screen = Screen::Library;
            if (pick == 1) screen = Screen::Store;
            if (pick == 2) screen = Screen::Settings;
            if (pick >= 0) capturing = -1;
        }
        ImGui::SameLine(0, 0);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(36, 30));
        ImGui::BeginChild("##content", ImVec2(0, 0), ImGuiChildFlags_AlwaysUseWindowPadding);
        ImGui::PopStyleVar();

        if (!g_crashReport.empty() && !ImGui::IsPopupOpen("##erro-jogo")) ImGui::OpenPopup("##erro-jogo");
        if (ImGui::BeginPopupModal("##erro-jogo", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("O jogo fechou por um erro");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::TextDisabled("Copie os detalhes e mande para quem mantém o app, para corrigir.");
            ImGui::InputTextMultiline("##crash", &g_crashReport[0], g_crashReport.size() + 1, ImVec2(560, 260), ImGuiInputTextFlags_ReadOnly);
            if (ImGui::Button("Copiar detalhes")) SDL_SetClipboardText(g_crashReport.c_str());
            ImGui::SameLine();
            if (ImGui::Button("Fechar")) { g_crashReport.clear(); ImGui::CloseCurrentPopup(); }
            ImGui::EndPopup();
        }

        if (screen == Screen::Library) {
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("Biblioteca");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::SameLine(ImGui::GetWindowWidth() - 36 - ImGui::CalcTextSize("Adicionar pasta").x - 40);
            if (primaryButton("Adicionar pasta")) {
                std::string folder = pickFolder();
                if (!folder.empty()) {
                    g_config.folders.push_back(folder);
                    saveConfig();
                    scanFolders();
                }
            }

            ImGui::SetNextItemWidth(320);
            ImGui::InputTextWithHint("##search", "Buscar na biblioteca", search, sizeof(search));
            ImGui::SameLine();
            ImGui::SetNextItemWidth(220);
            // Só os sistemas que têm jogo na biblioteca, em ordem alfabética, com quantos jogos cada um tem.
            std::vector<std::pair<int, int>> haveSystems;  // índice do sistema, quantidade
            {
                std::map<std::string, int> count;
                for (const auto& g : g_games) count[g.system]++;
                for (int i = 0; i < (int)allSystems().size(); i++) {
                    auto it = count.find(allSystems()[i].id);
                    if (it != count.end()) haveSystems.push_back({i, it->second});
                }
                std::sort(haveSystems.begin(), haveSystems.end(), [](const auto& a, const auto& b) {
                    return lower(allSystems()[a.first].name) < lower(allSystems()[b.first].name);
                });
            }
            if (filter >= 0 && std::none_of(haveSystems.begin(), haveSystems.end(), [&](const auto& h) { return h.first == filter; })) filter = -1;
            // Pílulas: Todos e os consoles que têm jogo (quebram linha quando não cabem).
            ImGui::SameLine();
            if (chip("Em português", libPt)) libPt = !libPt;
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Traduções PT-BR, versões brasileiras e jogos da Loja feitos em português.");
            {
                float right = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x;
                if (chip("Todos", filter < 0)) filter = -1;
                for (const auto& h : haveSystems) {
                    const char* name = allSystems()[h.first].shortName;
                    float w = ImGui::CalcTextSize(name).x + 30;
                    float lastX = ImGui::GetItemRectMax().x;
                    if (lastX + 8 + w < right) ImGui::SameLine(0, 8);
                    ImGui::PushID(h.first);
                    if (chip(name, filter == h.first)) filter = filter == h.first ? -1 : h.first;
                    ImGui::PopID();
                }
            }
            ImGui::SameLine();
            ImGui::SetNextItemWidth(150);
            if (ImGui::BeginCombo("##libgenre", libGenre < 0 ? "Todos os gêneros" : kGenres[libGenre])) {
                if (ImGui::Selectable("Todos os gêneros", libGenre < 0)) libGenre = -1;
                for (int i = 0; i < (int)IM_ARRAYSIZE(kGenres); i++)
                    if (ImGui::Selectable(kGenres[i], libGenre == i)) libGenre = i;
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            const char* libSorts[] = {"A-Z", "Z-A"};
            ImGui::SetNextItemWidth(70);
            ImGui::Combo("##libsort", &libSort, libSorts, 2);
            // Lista filtrada (sem a letra, para saber quais letras têm jogos).
            std::string q = lower(search);
            buildGroups(groups);
            std::vector<size_t> libView;
            std::vector<char> groupShown(groups.members.size(), 0);
            bool libLetters[27] = {};
            for (size_t i = 0; i < g_games.size(); i++) {
                const Game& g = g_games[i];
                if (filter >= 0 && g.system != allSystems()[filter].id) continue;
                if (!q.empty() && lower(g.title).find(q) == std::string::npos) continue;
                const StoreGame* sg = storeGameForPath(g.path);
                if (libGenre >= 0 && !(sg && hasGenre(*sg, kGenres[libGenre]))) continue;
                if (libPt && !((sg && sg->lang == "pt") || looksPortuguese(pathToUtf8(u8path(g.path).filename())))) continue;
                char l = titleLetter(g.title);
                libLetters[letterIndex(l)] = true;
                if (libLetter && l != libLetter) continue;
                // Um cartão por jogo: mostra a versão escolhida antes, senão a traduzida, senão a primeira.
                int gid = groups.groupOf[i];
                if (groupShown[gid]) continue;
                groupShown[gid] = 1;
                const auto& mem = groups.members[gid];
                size_t rep = i;
                if (mem.size() > 1) {
                    auto ch = g_versionChoice.find(versionKey(g));
                    bool picked = false;
                    if (ch != g_versionChoice.end())
                        for (size_t m : mem) if (g_games[m].path == ch->second) { rep = m; picked = true; }
                    if (!picked)
                        for (size_t m : mem) if (looksPortuguese(pathToUtf8(u8path(g_games[m].path).filename()))) { rep = m; break; }
                }
                libView.push_back(rep);
            }
            std::sort(libView.begin(), libView.end(), [](size_t a, size_t b) { return lower(g_games[a].title) < lower(g_games[b].title); });
            if (libSort == 1) std::reverse(libView.begin(), libView.end());
            ImGui::SameLine();
            ImGui::TextDisabled("%d jogos", (int)libView.size());
            if (g_games.size() > 12) letterBar(libLetter, libLetters);

            if (g_games.empty() && g_scanning.load()) {
                ImGui::Dummy(ImVec2(0, 60));
                ImGui::TextUnformatted("Procurando jogos nas suas pastas…");
                ImGui::TextDisabled("Na primeira vez, com pasta grande ou na nuvem (Google Drive), pode levar alguns minutos.");
            } else if (g_games.empty()) {
                ImGui::Dummy(ImVec2(0, 60));
                ImGui::TextUnformatted("Nenhum jogo ainda");
                ImGui::TextDisabled("Clique em \"Adicionar pasta\" e escolha a pasta onde estão os seus jogos.");
                ImGui::TextDisabled("Teclado: setas, Z/X/A/S, Q/W, Enter (Start), Backspace (Select). Joysticks são reconhecidos sozinhos.");
            } else {
                ImGui::BeginChild("##grid", ImVec2(0, 0), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground);
                float tileW = 168, coverH = 224, tileH = coverH + 58, gap = 20;
                int cols = std::max(1, (int)((ImGui::GetContentRegionAvail().x + gap) / (tileW + gap)));
                // Espalha as colunas para ocupar a largura toda.
                tileW = std::floor((ImGui::GetContentRegionAvail().x - gap * (cols - 1)) / cols);
                coverH = std::floor(tileW * 4.0f / 3.0f);
                tileH = coverH + 58;
                ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(gap, 18));
                int col = 0;
                if (libView.empty()) ImGui::TextDisabled("Nenhum jogo com esses filtros.");
                for (size_t i : libView) {
                    const Game& g = g_games[i];
                    if (col > 0) ImGui::SameLine();
                    ImGui::PushID((int)i);
                    ImVec2 pos = ImGui::GetCursorScreenPos();
                    bool clicked = ImGui::InvisibleButton("##tile", ImVec2(tileW, tileH));
                    bool hovered = ImGui::IsItemHovered() || ImGui::IsItemFocused();
                    ImDrawList* dl = ImGui::GetWindowDrawList();
                    const SystemInfo* sys = systemById(g.system);
                    // Capa: pede quando o cartão aparece na tela; enquanto não chega, mostra o nome do jogo.
                    if (ImGui::IsItemVisible()) {
                        const StoreGame* sg = storeGameForPath(g.path);
                        covers::request(g.path, g.system, g.title, fileStem(g.path), sg ? sg->cover : std::string());
                    }
                    ImVec2 c0(pos.x, pos.y), c1(pos.x + tileW, pos.y + coverH);
                    dl->AddRectFilled(c0, c1, brand::placeholder, 12);
                    auto ct = coverTex.find(g.path);
                    if (ct != coverTex.end()) {
                        // Corta para preencher (3:4), cantos de 12px.
                        float bw = c1.x - c0.x, bh = c1.y - c0.y;
                        float ar = ct->second.second.x / ct->second.second.y, box = bw / bh;
                        ImVec2 uv0(0, 0), uv1(1, 1);
                        if (ar > box) { float f = box / ar; uv0.x = (1 - f) * 0.5f; uv1.x = 1 - uv0.x; }
                        else { float f = ar / box; uv0.y = (1 - f) * 0.5f; uv1.y = 1 - uv0.y; }
                        dl->AddImageRounded((ImTextureID)(intptr_t)ct->second.first, c0, c1, uv0, uv1, IM_COL32_WHITE, 12);
                    } else {
                        ImFont* tf = g_fontWordmark ? g_fontWordmark : ImGui::GetFont();
                        float fs = tf->FontSize;
                        ImVec2 ts = tf->CalcTextSizeA(fs, FLT_MAX, tileW - 28, g.title.c_str());
                        ImGui::PushClipRect(c0, c1, true);
                        dl->AddText(tf, fs, ImVec2(c0.x + 14, (c0.y + c1.y - ts.y) * 0.5f), brand::purpleDark, g.title.c_str(), nullptr, tileW - 28);
                        ImGui::PopClipRect();
                    }
                    if (hovered) dl->AddRect(ImVec2(c0.x - 1.5f, c0.y - 1.5f), ImVec2(c1.x + 1.5f, c1.y + 1.5f), brand::purple, 13, 0, 3.0f);
                    // Nome e console embaixo da capa.
                    ImGui::PushClipRect(ImVec2(pos.x, c1.y), ImVec2(pos.x + tileW, pos.y + tileH), true);
                    ImFont* nf = g_fontSemi ? g_fontSemi : ImGui::GetFont();
                    dl->AddText(nf, nf->FontSize * 0.94f, ImVec2(pos.x, c1.y + 10), brand::ink, g.title.c_str());
                    ImGui::PopClipRect();
                    if (g_fontSmall) ImGui::PushFont(g_fontSmall);
                    dl->AddText(ImVec2(pos.x, c1.y + 33), brand::muted2, sys ? sys->name : "?");
                    if (g_fontSmall) ImGui::PopFont();
                    // Desempenho: só aparece quando não roda liso, sempre com ícone e texto.
                    perf::Verdict verdict = perf::rate(g_hw, g.system, g.path);
                    if (verdict.level != perf::Level::Smooth) {
                        bool may = verdict.level == perf::Level::MayStutter;
                        const char* tag = may ? "Engasga" : verdict.level == perf::Level::Heavy ? "Trava" : "Não roda";
                        if (g_fontSmall) ImGui::PushFont(g_fontSmall);
                        ImVec2 ts = ImGui::CalcTextSize(tag);
                        ImVec2 t0(c0.x + 10, c0.y + 10), t1(t0.x + 26 + ts.x + 10, t0.y + ts.y + 10);
                        dl->AddRectFilled(t0, t1, brand::card, 99);
                        ImVec2 dc(t0.x + 13, (t0.y + t1.y) * 0.5f);
                        dl->AddCircleFilled(dc, 7, may ? brand::yellow : brand::red, 16);
                        const char* mk = may ? "!" : "x";
                        ImVec2 ms = ImGui::CalcTextSize(mk);
                        dl->AddText(ImVec2(dc.x - ms.x * 0.5f, dc.y - ms.y * 0.5f), may ? IM_COL32(0x2A, 0x24, 0x10, 255) : IM_COL32_WHITE, mk);
                        dl->AddText(ImVec2(t0.x + 26, t0.y + 5), brand::ink, tag);
                        if (g_fontSmall) ImGui::PopFont();
                    }
                    if (hovered && verdict.level != perf::Level::Smooth) ImGui::SetTooltip("%s\n%s", verdict.label.c_str(), verdict.reason.c_str());
                    const auto& versions = groups.members[groups.groupOf[i]];
                    if (versions.size() > 1) {
                        if (g_fontSmall) ImGui::PushFont(g_fontSmall);
                        std::string vt = std::to_string(versions.size()) + " versões";
                        ImVec2 vs = ImGui::CalcTextSize(vt.c_str());
                        ImVec2 v0(c0.x + 10, c1.y - vs.y - 18);
                        dl->AddRectFilled(v0, ImVec2(v0.x + vs.x + 20, v0.y + vs.y + 8), brand::lavenderSoft, 99);
                        dl->AddText(ImVec2(v0.x + 10, v0.y + 4), brand::purpleDark, vt.c_str());
                        if (g_fontSmall) ImGui::PopFont();
                        if (hovered) ImGui::SetTooltip("Clique com o botão direito para mais opções");
                    }
                    // Várias versões e nenhuma escolhida ainda (ou botão direito): pergunta qual jogar.
                    bool rightClick = ImGui::IsItemClicked(ImGuiMouseButton_Right);
                    if (rightClick) {
                        menuFor = (int)i;
                        openGameMenu = true;
                        clicked = false;
                    }
                    if (versions.size() > 1 && clicked && !g_versionChoice.count(versionKey(g))) {
                        versionsOf = groups.groupOf[i];
                        openVersions = true;
                        clicked = false;
                    }
                    if (clicked) {
                        if (verdict.level == perf::Level::Heavy || verdict.level == perf::Level::CantRun) {
                            confirmGame = &g;
                            confirmVerdict = verdict;
                            openConfirm = true;
                        } else {
                            launchGame(g, app.window);
                            perf::loadMeasured(pathForCore(perfPath()));
                        }
                    }
                    ImGui::PopID();
                    col = (col + 1) % cols;
                }
                ImGui::PopStyleVar();
                ImGui::EndChild();
            }
            // Botão direito numa capa: jogar, outra versão ou compartilhar o card.
            if (openGameMenu) { ImGui::OpenPopup("##jogo"); openGameMenu = false; }
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14, 12));
            if (ImGui::BeginPopup("##jogo")) {
                if (menuFor >= 0 && menuFor < (int)g_games.size()) {
                    const Game& mg = g_games[menuFor];
                    if (g_fontSemi) ImGui::PushFont(g_fontSemi);
                    ImGui::TextUnformatted(mg.title.c_str());
                    if (g_fontSemi) ImGui::PopFont();
                    ImGui::Separator();
                    if (ImGui::Selectable("Jogar")) {
                        perf::Verdict v2 = perf::rate(g_hw, mg.system, mg.path);
                        ImGui::CloseCurrentPopup();
                        if (v2.level == perf::Level::Heavy || v2.level == perf::Level::CantRun) {
                            confirmGame = &mg;
                            confirmVerdict = v2;
                            openConfirm = true;
                        } else {
                            launchGame(mg, app.window);
                            perf::loadMeasured(pathForCore(perfPath()));
                        }
                    }
                    if (groups.members[groups.groupOf[menuFor]].size() > 1 && ImGui::Selectable("Escolher outra versão")) {
                        versionsOf = groups.groupOf[menuFor];
                        openVersions = true;
                    }
                    if (ImGui::Selectable("Compartilhar card")) {
                        const SystemInfo* ms = systemById(mg.system);
                        PlayStats st = playStats(mg.path);
                        CardInfo ci;
                        ci.title = mg.title;
                        ci.console = ms ? ms->shortName : "";
                        ci.hours = hoursText(st.seconds);
                        time_t when = st.first > 0 ? (time_t)st.first : time(nullptr);
                        char buf[16];
                        strftime(buf, sizeof(buf), "%d/%m/%Y", localtime(&when));
                        ci.since = buf;
                        auto ct = coverTex.find(mg.path);
                        if (ct != coverTex.end()) { ci.cover = ct->second.first; ci.coverSize = ct->second.second; }
                        std::vector<unsigned char> px;
                        int cw = 0, chh = 0;
                        if (renderLinkCard(ci, px, cw, chh)) {
                            cardPath = saveAndCopyCard(px, cw, chh, mg.title);
                            if (cardTex) glDeleteTextures(1, &cardTex);
                            glGenTextures(1, &cardTex);
                            glBindTexture(GL_TEXTURE_2D, cardTex);
                            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
                            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
                            glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
                            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, cw, chh, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
                            openCard = true;
                        }
                    }
                }
                ImGui::EndPopup();
            }
            ImGui::PopStyleVar();
            if (openCard) { ImGui::OpenPopup("##card"); openCard = false; }
            ImGui::SetNextWindowSize(ImVec2(660, 0));
            if (ImGui::BeginPopupModal("##card", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
                if (g_fontTitle) ImGui::PushFont(g_fontTitle);
                ImGui::TextUnformatted("Card pronto.");
                if (g_fontTitle) ImGui::PopFont();
                if (cardTex) ImGui::Image((ImTextureID)(intptr_t)cardTex, ImVec2(596, 313), ImVec2(0, 1), ImVec2(1, 0));
                ImGui::TextWrapped("%s", cardPath.empty() ? "Não foi possível salvar a imagem." : "Já está copiado: é só colar no WhatsApp, Discord ou onde quiser. Também ficou salvo em Imagens › Cartucho.");
                ImGui::Spacing();
#ifdef _WIN32
                if (!cardPath.empty() && primaryButton("Abrir a pasta")) {
                    ShellExecuteW(nullptr, L"open", widen(pathToUtf8(u8path(cardPath).parent_path())).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
                }
                ImGui::SameLine();
#endif
                if (ImGui::Button("Fechar")) ImGui::CloseCurrentPopup();
                ImGui::EndPopup();
            }
            if (openVersions) { ImGui::OpenPopup("##versoes"); openVersions = false; }
            ImGui::SetNextWindowSize(ImVec2(520, 0));
            if (ImGui::BeginPopupModal("##versoes", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
                if (versionsOf >= 0 && versionsOf < (int)groups.members.size()) {
                    const auto& mem = groups.members[versionsOf];
                    if (g_fontTitle) ImGui::PushFont(g_fontTitle);
                    ImGui::TextWrapped("%s", g_games[mem[0]].title.c_str());
                    if (g_fontTitle) ImGui::PopFont();
                    ImGui::TextDisabled("Você tem %d versões deste jogo. Qual quer jogar?", (int)mem.size());
                    ImGui::Spacing();
                    std::string key = versionKey(g_games[mem[0]]);
                    auto chosen = g_versionChoice.find(key);
                    for (size_t m : mem) {
                        const Game& v = g_games[m];
                        ImGui::PushID((int)m);
                        bool current = chosen != g_versionChoice.end() && chosen->second == v.path;
                        std::string label = versionLabel(v) + (current ? "   (última escolhida)" : "");
                        if (ImGui::Button(label.c_str(), ImVec2(-1, 0))) {
                            g_versionChoice[key] = v.path;
                            saveVersionChoices();
                            ImGui::CloseCurrentPopup();
                            launchGame(v, app.window);
                            perf::loadMeasured(pathForCore(perfPath()));
                        }
                        if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", v.path.c_str());
                        ImGui::PopID();
                    }
                    ImGui::Spacing();
                    ImGui::TextDisabled("Da próxima vez, o clique abre a versão escolhida. Botão direito troca.");
                }
                if (ImGui::Button("Cancelar", ImVec2(-1, 0))) ImGui::CloseCurrentPopup();
                ImGui::EndPopup();
            }
            if (openConfirm) { ImGui::OpenPopup("##aviso-desempenho"); openConfirm = false; }
            if (ImGui::BeginPopupModal("##aviso-desempenho", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
                if (g_fontTitle) ImGui::PushFont(g_fontTitle);
                ImGui::TextUnformatted(confirmVerdict.label.c_str());
                if (g_fontTitle) ImGui::PopFont();
                ImGui::PushTextWrapPos(420);
                ImGui::TextUnformatted(confirmVerdict.reason.c_str());
                ImGui::TextDisabled("Você pode jogar mesmo assim. Depois da partida, o Cartucho mede a velocidade real e atualiza este aviso.");
                ImGui::PopTextWrapPos();
                ImGui::Spacing();
                if (ImGui::Button("Jogar mesmo assim") && confirmGame) {
                    Game g = *confirmGame;
                    ImGui::CloseCurrentPopup();
                    confirmGame = nullptr;
                    launchGame(g, app.window);
                    perf::loadMeasured(pathForCore(perfPath()));
                }
                ImGui::SameLine();
                if (ImGui::Button("Agora não")) { ImGui::CloseCurrentPopup(); confirmGame = nullptr; }
                ImGui::EndPopup();
            }
        } else if (screen == Screen::Store) {
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("Loja");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::TextDisabled("Jogos gratuitos liberados pelos autores: Homebrew Hub (GB, GBC, GBA, NES), ZXDB/Spectrum Computing (ZX Spectrum) e TIC-80.");
            ImGui::SetNextItemWidth(260);
            ImGui::InputTextWithHint("##storesearch", "Buscar por nome, autor ou gênero", storeSearch, sizeof(storeSearch));
            ImGui::SameLine();
            ImGui::SetNextItemWidth(170);
            if (ImGui::BeginCombo("##storeplat", storePlatform.empty() ? "Todos os consoles" : storePlatformName(storePlatform))) {
                if (ImGui::Selectable("Todos os consoles", storePlatform.empty())) storePlatform.clear();
                for (const auto& p : storePlatforms)
                    if (ImGui::Selectable(storePlatformName(p), storePlatform == p)) storePlatform = p;
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            ImGui::SetNextItemWidth(150);
            if (ImGui::BeginCombo("##storegenre", storeGenre < 0 ? "Todos os gêneros" : kGenres[storeGenre])) {
                if (ImGui::Selectable("Todos os gêneros", storeGenre < 0)) storeGenre = -1;
                for (int i = 0; i < (int)IM_ARRAYSIZE(kGenres); i++)
                    if (ImGui::Selectable(kGenres[i], storeGenre == i)) storeGenre = i;
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            const char* langs[] = {"Todos os idiomas", "Português", "Inglês", "Espanhol", "Outros"};
            ImGui::SetNextItemWidth(140);
            ImGui::Combo("##storelang", &storeLang, langs, 5);
            const char* eras[] = {"Todas as épocas", "Anos 80", "Anos 90", "Anos 2000", "Anos 2010", "2020 em diante"};
            int eraIdx = storeEra == 0 ? 0 : (storeEra - 1970) / 10;
            ImGui::SetNextItemWidth(150);
            if (ImGui::Combo("##storeera", &eraIdx, eras, 6)) storeEra = eraIdx == 0 ? 0 : 1970 + eraIdx * 10;
            ImGui::SameLine();
            const char* plays[] = {"Jogadores: tanto faz", "1 jogador", "2 ou mais"};
            ImGui::SetNextItemWidth(160);
            ImGui::Combo("##storeplayers", &storePlayers, plays, 3);
            ImGui::SameLine();
            const char* kinds[] = {"Jogos", "Demos", "Tudo"};
            ImGui::SetNextItemWidth(90);
            ImGui::Combo("##storekind", &storeKind, kinds, 3);
            ImGui::SameLine();
            const char* sorts[] = {"A-Z", "Z-A", "Mais novos", "Mais antigos"};
            ImGui::SetNextItemWidth(120);
            ImGui::Combo("##storesort", &storeSort, sorts, 4);
            ImGui::SameLine();
            ImGui::Checkbox("Só baixados", &storeOnlyHave);
            ImGui::SameLine();
            if (ImGui::SmallButton("Limpar filtros")) {
                storeSearch[0] = 0; storePlatform.clear(); storeGenre = -1; storeLang = 0; storeEra = 0; storePlayers = 0;
                storeKind = 0; storeSort = 0; storeOnlyHave = false; storeLetter = 0;
            }

            int state = g_storeState.load();
            if (state == 1) ImGui::TextDisabled("Baixando %s…", storeWanted.c_str());
            if (state == 3) { ImGui::TextColored(ImVec4(0.92f, 0.4f, 0.35f, 1), "%s", g_storeError.c_str()); }
            if (state == 2) {
                g_storeState = 0;
                scanFolders();
                storeViewKey = "?";
                std::string sysId = storePlatformForPath(g_storeDone);
                Game g{g_storeDone, titleFromStem(fileStem(g_storeDone)), sysId};
                if (const StoreGame* sg = storeGameForPath(g_storeDone)) g.title = sg->title;
                launchGame(g, app.window);
            }

            // Recalcula a lista só quando algum filtro muda (o catálogo tem milhares de jogos).
            std::string q = lowerStr(storeSearch);
            char keyBuf[512];
            snprintf(keyBuf, sizeof(keyBuf), "%s|%s|%d|%d|%d|%d|%d|%d|%d|%d|%c", q.c_str(), storePlatform.c_str(), storeGenre, storeLang, storeEra,
                     storePlayers, storeKind, storeSort, (int)storeOnlyHave, (int)g_games.size(), storeLetter ? storeLetter : '-');
            static bool lettersAvail[27];
            if (storeViewKey != keyBuf) {
                storeViewKey = keyBuf;
                storeView.clear();
                std::set<std::string> have;
                if (storeOnlyHave)
                    for (const auto& g : g_games) if (const StoreGame* sg = storeGameForPath(g.path)) have.insert(sg->slug);
                memset(lettersAvail, 0, sizeof(lettersAvail));
                for (size_t k = 0; k < g_store.size(); k++) {
                    const StoreGame& sg = g_store[k];
                    if (!storePlatform.empty() && sg.platform != storePlatform) continue;
                    if (storeKind != 2 && (sg.type == "demo") != (storeKind == 1)) continue;
                    if (storeGenre >= 0 && !hasGenre(sg, kGenres[storeGenre])) continue;
                    if (storeLang == 1 && sg.lang != "pt") continue;
                    if (storeLang == 2 && sg.lang != "en") continue;
                    if (storeLang == 3 && sg.lang != "es") continue;
                    if (storeLang == 4 && (sg.lang.empty() || sg.lang == "pt" || sg.lang == "en" || sg.lang == "es")) continue;
                    int y = atoi(sg.year.c_str());
                    if (storeEra && !(y >= storeEra && (storeEra == 2020 || y < storeEra + 10))) continue;
                    if (storePlayers == 1 && sg.players > 1) continue;
                    if (storePlayers == 2 && sg.players < 2) continue;
                    if (storeOnlyHave && !have.count(sg.slug)) continue;
                    if (!q.empty()) {
                        bool hit = lowerStr(sg.title).find(q) != std::string::npos || lowerStr(sg.developer).find(q) != std::string::npos;
                        for (const auto& gn : sg.genres) hit = hit || lowerStr(gn).find(q) != std::string::npos;
                        if (!hit) continue;
                    }
                    lettersAvail[letterIndex(sg.letter)] = true;
                    if (storeLetter && sg.letter != storeLetter) continue;
                    storeView.push_back(k);
                }
                auto title = [](const StoreGame& g) { return lowerStr(g.title); };
                std::stable_sort(storeView.begin(), storeView.end(), [&](size_t a, size_t b) {
                    const StoreGame &x = g_store[a], &y2 = g_store[b];
                    switch (storeSort) {
                        case 1: return title(x) > title(y2);
                        case 2: return atoi(x.year.c_str()) > atoi(y2.year.c_str());
                        case 3: { int ya = atoi(x.year.c_str()), yb = atoi(y2.year.c_str()); return (ya ? ya : 9999) < (yb ? yb : 9999); }
                        default: return title(x) < title(y2);
                    }
                });
            }
            if (letterBar(storeLetter, lettersAvail)) storeViewKey = "?";
            ImGui::SameLine();
            ImGui::TextDisabled("  %d de %d títulos", (int)storeView.size(), (int)g_store.size());

            if (g_store.empty()) {
                ImGui::Dummy(ImVec2(0, 40));
                ImGui::TextDisabled("O catálogo não está disponível agora. Confira a internet e abra a Loja de novo.");
            } else if (ImGui::BeginTable("##store", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp, ImVec2(0, ImGui::GetContentRegionAvail().y))) {
                ImGui::TableSetupScrollFreeze(0, 1);
                ImGui::TableSetupColumn("Jogo", ImGuiTableColumnFlags_WidthStretch, 3.0f);
                ImGui::TableSetupColumn("Console", ImGuiTableColumnFlags_WidthStretch, 1.2f);
                ImGui::TableSetupColumn("Gênero", ImGuiTableColumnFlags_WidthStretch, 1.4f);
                ImGui::TableSetupColumn("Autor", ImGuiTableColumnFlags_WidthStretch, 2.0f);
                ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, 130);
                ImGui::TableHeadersRow();
                ImGuiListClipper clipper;
                clipper.Begin((int)storeView.size());
                while (clipper.Step()) {
                    for (int row = clipper.DisplayStart; row < clipper.DisplayEnd; row++) {
                        size_t k = storeView[row];
                        const StoreGame& sg = g_store[k];
                        ImGui::PushID((int)k);
                        ImGui::TableNextRow();
                        ImGui::TableNextColumn();
                        ImGui::TextUnformatted(sg.title.c_str());
                        if (ImGui::IsItemHovered()) {
                            ImGui::BeginTooltip();
                            ImGui::PushTextWrapPos(460);
                            if (!sg.desc.empty()) ImGui::TextUnformatted(sg.desc.c_str());
                            if (!sg.year.empty()) ImGui::TextDisabled("Ano: %s", sg.year.c_str());
                            ImGui::TextDisabled("Licença: %s", sg.license.empty() ? "definida pelo autor" : sg.license.c_str());
                            ImGui::TextDisabled("Fonte: %s", sg.source.empty() ? "Homebrew Hub" : sg.source.c_str());
                            ImGui::PopTextWrapPos();
                            ImGui::EndTooltip();
                        }
                        ImGui::TableNextColumn();
                        ImGui::TextUnformatted(storePlatformName(sg.platform));
                        ImGui::TableNextColumn();
                        ImGui::TextDisabled("%s", sg.genres.empty() ? "" : sg.genres[0].c_str());
                        ImGui::TableNextColumn();
                        ImGui::TextDisabled("%s", sg.developer.c_str());
                        ImGui::TableNextColumn();
                        std::error_code ec2;
                        bool have = fs::exists(u8path(storeLocalPath(sg)), ec2);
                        if (ImGui::Button(have ? "Jogar" : "Baixar e jogar", ImVec2(-1, 0)) && g_storeState.load() != 1) {
                            if (have) {
                                Game g{storeLocalPath(sg), sg.title, sg.platform};
                                launchGame(g, app.window);
                            } else {
                                storeWanted = sg.title;
                                downloadStoreGame(sg);
                            }
                        }
                        ImGui::PopID();
                    }
                }
                ImGui::EndTable();
            }
        } else {
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("Ajustes");
            if (g_fontTitle) ImGui::PopFont();
            if (ImGui::BeginTabBar("##tabs")) {
                if (ImGui::BeginTabItem("Controles")) {
                    ImGui::TextDisabled("Teclado (jogador 1). Clique em uma tecla e aperte a nova. Esc cancela.");
                    ImGui::TextDisabled("Joysticks USB/Bluetooth são configurados automaticamente (até 4 jogadores).");
                    if (ImGui::BeginTable("##keys", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
                        static const int order[] = {RP_UP, RP_DOWN, RP_LEFT, RP_RIGHT, RP_A, RP_B, RP_X, RP_Y, RP_L, RP_R, RP_L2, RP_R2, RP_L3, RP_R3, RP_START, RP_SELECT};
                        for (int id : order) {
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn();
                            ImGui::TextUnformatted(retroPadName(id));
                            ImGui::TableNextColumn();
                            ImGui::PushID(id);
                            const char* label = capturing == id ? "Aperte uma tecla…" : SDL_GetScancodeName((SDL_Scancode)g_config.keys[id]);
                            if (ImGui::Button(label && *label ? label : "—", ImVec2(220, 0))) capturing = id;
                            ImGui::PopID();
                        }
                        ImGui::EndTable();
                    }
                    if (ImGui::Button("Restaurar teclas padrão")) { defaultKeys(g_config); saveConfig(); }
                    ImGui::TextDisabled("Durante o jogo: Esc menu · F2 salvar estado · F4 carregar · F11 tela cheia · Tab acelerar");
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Vídeo e áudio")) {
                    bool changed = false;
                    changed |= ImGui::Checkbox("Abrir os jogos em tela cheia", &g_config.fullscreen);
                    changed |= ImGui::Checkbox("Escala inteira (pixels nítidos)", &g_config.integerScale);
                    changed |= ImGui::Checkbox("Filtro suave", &g_config.smooth);
                    ImGui::TextUnformatted("Volume");
                    ImGui::SetNextItemWidth(320);
                    int vol = (int)(g_config.volume * 100 + 0.5f);
                    if (ImGui::SliderInt("##volume", &vol, 0, 100, "%d%%")) { g_config.volume = vol / 100.0f; changed = true; }
                    if (changed) saveConfig();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Pastas")) {
                    for (size_t i = 0; i < g_config.folders.size(); i++) {
                        ImGui::PushID((int)i);
                        ImGui::TextUnformatted(g_config.folders[i].c_str());
                        ImGui::SameLine();
                        if (ImGui::SmallButton("Remover")) {
                            g_config.folders.erase(g_config.folders.begin() + i);
                            saveConfig();
                            scanFolders();
                            ImGui::PopID();
                            break;
                        }
                        ImGui::PopID();
                    }
                    if (ImGui::Button("Procurar jogos de novo")) scanFolders();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Este computador")) {
                    ImGui::TextWrapped("Processador: %s (%d núcleos lógicos%s)", g_hw.cpu.c_str(), g_hw.threads, g_hw.avx2 ? ", AVX2" : "");
                    if (g_hw.vramMB > 0) ImGui::TextWrapped("Placa de vídeo: %s (%d MB)", g_hw.gpu.c_str(), g_hw.vramMB);
                    else ImGui::TextWrapped("Placa de vídeo: %s", g_hw.gpu.c_str());
                    if (g_hw.ramMB > 0) ImGui::Text("Memória: %.1f GB", g_hw.ramMB / 1024.0);
                    ImGui::Spacing();
                    ImGui::TextDisabled("O que esperar de cada sistema. Depois que você joga, o aviso de cada jogo usa a velocidade medida.");
                    if (ImGui::BeginTable("##perf", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
                        for (const auto& sysInfo : allSystems()) {
                            perf::Verdict v = perf::rate(g_hw, sysInfo.id, "");
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn();
                            ImGui::TextUnformatted(sysInfo.name);
                            ImGui::TableNextColumn();
                            ImVec4 col = v.level == perf::Level::Smooth ? ImVec4(0.55f, 0.85f, 0.6f, 1) : v.level == perf::Level::MayStutter ? ImVec4(0.9f, 0.7f, 0.3f, 1) : ImVec4(0.92f, 0.4f, 0.35f, 1);
                            ImGui::TextColored(col, "%s", v.label.c_str());
                            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", v.reason.c_str());
                        }
                        ImGui::EndTable();
                    }
                    ImGui::EndTabItem();
                }
#ifdef _WIN32
                if (ImGui::BeginTabItem("Nuvem")) {
                    ImGui::TextWrapped("Saves na nuvem: jogue no celular e continue no computador (e o contrário). "
                                       "O Cartucho usa a mesma pasta do Google Drive do app do celular e só enxerga os arquivos que ele mesmo criou.");
                    ImGui::Dummy(ImVec2(0, 8));
                    if (!gdrive::configured()) {
                        ImGui::TextDisabled("Esta versão foi compilada sem o acesso ao Google Drive.");
                    } else if (g_drive && g_drive->signedIn()) {
                        ImGui::Text("Conta: %s", g_drive->email().empty() ? "Google" : g_drive->email().c_str());
                        std::string st = gdrive::status();
                        if (!st.empty()) ImGui::TextDisabled("%s", st.c_str());
                        ImGui::BeginDisabled(gdrive::state().busy.load());
                        if (ImGui::Button("Sincronizar agora")) startDriveSync();
                        ImGui::EndDisabled();
                        ImGui::SameLine();
                        if (ImGui::Button("Desconectar")) { g_drive->signOut(); gdrive::setStatus(""); }
                        ImGui::Dummy(ImVec2(0, 6));
                        ImGui::TextDisabled("Sincroniza ao abrir o Cartucho, antes de cada jogo e ao fechar o jogo. Se os dois aparelhos");
                        ImGui::TextDisabled("tiverem um save diferente, vale o mais novo; o outro fica guardado em backup-saves.");
                    } else {
                        std::string st = gdrive::status();
                        ImGui::BeginDisabled(gdrive::state().busy.load());
                        if (ImGui::Button("Entrar com Google")) {
                            gdrive::state().busy = true;
                            gdrive::setStatus("Termine o login na página que abriu no navegador…");
                            std::thread([] {
                                std::string err;
                                bool ok = g_drive->signIn(err);
                                gdrive::state().busy = false;
                                if (ok) startDriveSync();
                                else gdrive::setStatus(err);
                            }).detach();
                        }
                        ImGui::EndDisabled();
                        if (!st.empty()) ImGui::TextDisabled("%s", st.c_str());
                        ImGui::TextDisabled("Use a mesma conta Google do celular (Ajustes > Nuvem no app).");
                    }
                    ImGui::EndTabItem();
                }
#endif
                if (ImGui::BeginTabItem("BIOS e sobre")) {
                    ImGui::TextWrapped("Arquivos de BIOS (quando um sistema precisar) vão em:");
                    ImGui::TextUnformatted((g_prefPath + "system").c_str());
                    if (ImGui::Button("Abrir essa pasta")) {
                        std::error_code ec;
                        fs::create_directories(u8path(g_prefPath + "system"), ec);
#ifdef _WIN32
                        ShellExecuteW(nullptr, L"open", widen(g_prefPath + "system").c_str(), nullptr, nullptr, SW_SHOWNORMAL);
#endif
                    }
                    ImGui::Spacing();
                    ImGui::TextWrapped("O Cartucho não inclui jogos nem BIOS. Use apenas arquivos que você possui. Funciona offline.");
                    ImGui::TextDisabled("Emuladores libretro (licenças em LICENSES.md) · github.com/andrefeeelipe/cartucho");
                    ImGui::EndTabItem();
                }
                ImGui::EndTabBar();
            }
        }
        ImGui::EndChild();
        ImGui::End();
        endFrame(app, true);
    }
    saveConfig();
    destroyWindow(app);
    return 0;
}

int main(int argc, char** argv) {
    SDL_SetHint(SDL_HINT_WINDOWS_INTRESOURCE_ICON, "1");  // ícone do Cartucho na janela e na barra de tarefas
    SDL_SetHint(SDL_HINT_WINDOWS_INTRESOURCE_ICON_SMALL, "1");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER | SDL_INIT_TIMER) != 0) {
        // Sem som ou sem controle ainda dá para jogar: tenta só o vídeo antes de desistir.
        std::string err = SDL_GetError();
        if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) != 0) {
            std::string msg = "O Cartucho não conseguiu iniciar neste Windows.\n\nDetalhe: " + err;
            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Cartucho", msg.c_str(), nullptr);
            return 1;
        }
        SDL_InitSubSystem(SDL_INIT_AUDIO);
        SDL_InitSubSystem(SDL_INIT_GAMECONTROLLER);
    }
    char* pref = SDL_GetPrefPath("Cartucho", "Cartucho");
    g_prefPath = pref ? pref : "./";
    SDL_free(pref);
    char* base = SDL_GetBasePath();
    g_basePath = base ? base : "./";
    SDL_free(base);
    for (auto& ch : g_prefPath) if (ch == '\\') ch = '/';
    for (auto& ch : g_basePath) if (ch == '\\') ch = '/';
    loadConfig();
    installBundledSystemFiles();

    std::string gamePath, systemId;
    int autoFrames = 0;  // --autoteste <jogo> <sistema>: roda 300 quadros e sai (usado pelo GitHub Actions)
#ifdef _WIN32
    // Argumentos em UTF-16 para aceitar nomes com acento.
    int wargc = 0;
    LPWSTR* wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);
    for (int i = 1; i + 2 < wargc + 0 + 1 && i < wargc; i++) {
        if ((std::wstring(wargv[i]) == L"--play" || std::wstring(wargv[i]) == L"--autoteste") && i + 2 < wargc) {
            if (std::wstring(wargv[i]) == L"--autoteste") { autoFrames = 300; g_quiet = true; }
            gamePath = narrow(wargv[i + 1]);
            systemId = narrow(wargv[i + 2]);
        }
    }
    for (int i = 1; i < wargc; i++)
        if (std::wstring(wargv[i]) == L"--autoteste-inicio") { autoFrames = 240; g_quiet = true; }
    LocalFree(wargv);
    (void)argc;
    (void)argv;
#else
    for (int i = 1; i + 2 < argc; i++)
        if (std::string(argv[i]) == "--play") { gamePath = argv[i + 1]; systemId = argv[i + 2]; }
#endif

    int rc = gamePath.empty() ? runLibrary(autoFrames) : playGame(gamePath, systemId, autoFrames);
    g_scanStop = true;
    SDL_Quit();
    return rc;
}
