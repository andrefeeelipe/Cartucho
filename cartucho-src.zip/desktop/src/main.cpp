// Cartucho para Windows — biblioteca, ajustes e o modo de jogo (--play).
// Cada jogo roda em um processo próprio: ao sair, o emulador é descarregado por completo.

#ifdef _WIN32
// O winsock2 precisa vir antes do windows.h (usado pelo login do Google Drive).
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#endif
#include <SDL.h>
#include <glad/gl.h>

#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_sdl2.h"
#include "miniz.h"

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "host.h"
#include "systems.h"
#include "perf.h"
#include "gdrive.h"
#include "split.h"

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <shobjidl.h>
#include <urlmon.h>
#include <psapi.h>
#include <csignal>
#include <cstdarg>
#include <ctime>
#pragma comment(lib, "ole32.lib")
#endif

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Caminhos e texto

static std::string g_prefPath;  // %APPDATA%/Cartucho/Cartucho/
static std::string g_basePath;  // pasta do executável

static fs::path u8path(const std::string& s) { return fs::u8path(s); }
static std::string pathToUtf8(const fs::path& p) {
    auto u = p.u8string();
    return std::string(u.begin(), u.end());
}

#ifdef _WIN32
static std::wstring widen(const std::string& s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}
static std::string narrow(const std::wstring& w) {
    if (w.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}

#endif

// ------------------------------------------------------------------ diagnóstico
// O modo de jogo escreve as etapas em ultimo-jogo.log; se fechar por erro, o endereço e o módulo
// vão para ultimo-erro.txt. A biblioteca mostra isso para o usuário copiar e mandar.
static std::string logPath() { return g_prefPath + "ultimo-jogo.log"; }
static std::string errorPath() { return g_prefPath + "ultimo-erro.txt"; }

static void logStep(const char* fmt, ...) {
    char line[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
#ifdef _WIN32
    FILE* f = _wfopen(widen(logPath()).c_str(), L"a");
#else
    FILE* f = fopen(logPath().c_str(), "a");
#endif
    if (!f) return;
    fprintf(f, "%s\n", line);
    fclose(f);
}

static std::string readText(const std::string& path) {
#ifdef _WIN32
    std::ifstream in(widen(path), std::ios::binary);
#else
    std::ifstream in(path, std::ios::binary);
#endif
    std::stringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

#ifdef _WIN32
static std::string moduleOf(void* addr, unsigned long long& offset) {
    HMODULE mod = nullptr;
    offset = (unsigned long long)addr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)addr, &mod) || !mod) return "?";
    wchar_t name[MAX_PATH];
    GetModuleFileNameW(mod, name, MAX_PATH);
    offset = (unsigned long long)((char*)addr - (char*)mod);
    std::string full = narrow(name);
    size_t slash = full.find_last_of("\\/");
    return slash == std::string::npos ? full : full.substr(slash + 1);
}

static void writeCrash(const char* what, void* address) {
    std::string text = "Cartucho fechou por um erro: ";
    text += what;
    char buf[256];
    if (address) {
        unsigned long long off = 0;
        std::string mod = moduleOf(address, off);
        snprintf(buf, sizeof(buf), "\nEndereço: %s+0x%llx\n", mod.c_str(), off);
        text += buf;
    }
    void* frames[40];
    USHORT n = CaptureStackBackTrace(0, 40, frames, nullptr);
    text += "Pilha:\n";
    for (USHORT k = 0; k < n; k++) {
        unsigned long long off = 0;
        std::string mod = moduleOf(frames[k], off);
        snprintf(buf, sizeof(buf), "  %s+0x%llx\n", mod.c_str(), off);
        text += buf;
    }
    text += "\nEtapas:\n" + readText(logPath());
    FILE* f = _wfopen(widen(errorPath()).c_str(), L"w");
    if (f) { fputs(text.c_str(), f); fclose(f); }
}

static LONG WINAPI crashFilter(EXCEPTION_POINTERS* ep) {
    char what[64];
    snprintf(what, sizeof(what), "exceção 0x%08lX", ep && ep->ExceptionRecord ? ep->ExceptionRecord->ExceptionCode : 0ul);
    writeCrash(what, ep && ep->ExceptionRecord ? ep->ExceptionRecord->ExceptionAddress : nullptr);
    return EXCEPTION_CONTINUE_SEARCH;
}

static void abortHandler(int) {
    writeCrash("abort (erro interno de um core)", nullptr);
    _exit(3);
}
#endif

/** Os emuladores abrem arquivos com fopen (página de código ANSI): caminhos com acento viram nome curto 8.3. */
static std::string pathForCore(const std::string& utf8) {
#ifdef _WIN32
    bool ascii = std::all_of(utf8.begin(), utf8.end(), [](unsigned char c) { return c < 0x80; });
    if (ascii) return utf8;
    std::wstring w = widen(utf8);
    DWORD n = GetShortPathNameW(w.c_str(), nullptr, 0);
    if (n == 0) return utf8;
    std::wstring shortPath(n, 0);
    GetShortPathNameW(w.c_str(), &shortPath[0], n);
    shortPath.resize(wcslen(shortPath.c_str()));
    return narrow(shortPath);
#else
    return utf8;
#endif
}

// ---------------------------------------------------------------------------
// Configuração (config.ini simples: chave=valor)

struct Config {
    std::vector<std::string> folders;
    int keys[RP_COUNT];
    bool fullscreen = false;
    bool integerScale = false;
    bool smooth = false;
    float volume = 1.0f;
};

static Config g_config;

static void defaultKeys(Config& c) {
    c.keys[RP_B] = SDL_SCANCODE_Z;
    c.keys[RP_A] = SDL_SCANCODE_X;
    c.keys[RP_Y] = SDL_SCANCODE_A;
    c.keys[RP_X] = SDL_SCANCODE_S;
    c.keys[RP_L] = SDL_SCANCODE_Q;
    c.keys[RP_R] = SDL_SCANCODE_W;
    c.keys[RP_L2] = SDL_SCANCODE_E;
    c.keys[RP_R2] = SDL_SCANCODE_R;
    c.keys[RP_L3] = SDL_SCANCODE_D;
    c.keys[RP_R3] = SDL_SCANCODE_F;
    c.keys[RP_START] = SDL_SCANCODE_RETURN;
    c.keys[RP_SELECT] = SDL_SCANCODE_BACKSPACE;
    c.keys[RP_UP] = SDL_SCANCODE_UP;
    c.keys[RP_DOWN] = SDL_SCANCODE_DOWN;
    c.keys[RP_LEFT] = SDL_SCANCODE_LEFT;
    c.keys[RP_RIGHT] = SDL_SCANCODE_RIGHT;
}

static std::string configPath() { return g_prefPath + "config.ini"; }
static std::string perfPath() { return g_prefPath + "perf.ini"; }

static void loadConfig() {
    defaultKeys(g_config);
    std::ifstream in(u8path(configPath()));
    std::string line;
    while (std::getline(in, line)) {
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        if (k == "folder") g_config.folders.push_back(v);
        else if (k == "fullscreen") g_config.fullscreen = v == "1";
        else if (k == "integer") g_config.integerScale = v == "1";
        else if (k == "smooth") g_config.smooth = v == "1";
        else if (k == "volume") g_config.volume = (float)atof(v.c_str());
        else if (k.rfind("key", 0) == 0) {
            int id = atoi(k.c_str() + 3);
            if (id >= 0 && id < RP_COUNT) g_config.keys[id] = atoi(v.c_str());
        }
    }
}

static void saveConfig() {
    std::ofstream out(u8path(configPath()), std::ios::trunc);
    for (const auto& f : g_config.folders) out << "folder=" << f << "\n";
    out << "fullscreen=" << (g_config.fullscreen ? 1 : 0) << "\n";
    out << "integer=" << (g_config.integerScale ? 1 : 0) << "\n";
    out << "smooth=" << (g_config.smooth ? 1 : 0) << "\n";
    out << "volume=" << g_config.volume << "\n";
    for (int i = 0; i < RP_COUNT; i++) out << "key" << i << "=" << g_config.keys[i] << "\n";
}

// ---------------------------------------------------------------------------
// Biblioteca

struct Game {
    std::string path;
    std::string title;
    std::string system;
};

static std::vector<Game> g_games;
static std::atomic<bool> g_scanning{false};

static std::string titleFromStem(std::string stem) {
    std::string out;
    int depth = 0;
    for (char ch : stem) {
        if (ch == '(' || ch == '[') depth++;
        else if (ch == ')' || ch == ']') { if (depth > 0) depth--; }
        else if (depth == 0) out.push_back(ch == '_' ? ' ' : ch);
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    while (!out.empty() && out.front() == ' ') out.erase(0, 1);
    return out.empty() ? stem : out;
}

/** Sistema de um .zip pelo que tem dentro; sem ROM de console, é arcade. */
static std::string detectZip(const std::string& path) {
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_file(&zip, pathForCore(path).c_str(), 0)) return "";
    std::string found;
    mz_uint n = mz_zip_reader_get_num_files(&zip);
    for (mz_uint i = 0; i < n && found.empty(); i++) {
        char name[512];
        mz_zip_reader_get_filename(&zip, i, name, sizeof(name));
        std::string ext = lower(fs::path(name).extension().string());
        if (!ext.empty()) ext.erase(0, 1);
        auto c = candidatesFor(ext);
        c.erase(std::remove_if(c.begin(), c.end(), [](const SystemInfo* s) { return std::string(s->id) == "arcade"; }), c.end());
        if (c.size() == 1) found = c[0]->id;
    }
    mz_zip_reader_end(&zip);
    return found.empty() ? "arcade" : found;
}

/** Primeira letra do título para o filtro A–Z (acentos viram a letra base; "#" para o resto). */
static char titleLetter(const std::string& title) {
    std::string t = title;
    if (t.rfind("The ", 0) == 0) t.erase(0, 4);
    size_t i = 0;
    while (i < t.size() && (t[i] == ' ' || t[i] == '"' || t[i] == '\'')) i++;
    if (i >= t.size()) return '#';
    unsigned char c = (unsigned char)t[i];
    if (c < 0x80) { c = (unsigned char)toupper(c); return (c >= 'A' && c <= 'Z') ? (char)c : '#'; }
    if (c == 0xC3 && i + 1 < t.size()) {  // Latin-1 em UTF-8: À..ÿ
        unsigned cp = 0xC0 + ((unsigned char)t[i + 1] & 0x3F);
        static const char* map = "AAAAAAACEEEEIIIIDNOOOOOxOUUUUYTsaaaaaaaceeeeiiiidnooooo/ouuuuyty";
        char b = map[cp - 0xC0];
        b = (char)toupper((unsigned char)b);
        return (b >= 'A' && b <= 'Z') ? b : '#';
    }
    return '#';
}

static std::string storePlatformForPath(const std::string& path);

static void scanFolders() {
    std::vector<Game> found;
    std::vector<std::string> roots = g_config.folders;
    roots.push_back(g_prefPath + "loja");  // jogos baixados pela Loja
    for (const auto& folder : roots) {
        std::error_code ec;
        fs::recursive_directory_iterator it(u8path(folder), fs::directory_options::skip_permission_denied, ec), end;
        for (; it != end; it.increment(ec)) {
            if (ec) break;
            if (!it->is_regular_file(ec)) continue;
            fs::path p = it->path();
            // Jogo em partes: só a primeira entra, com o nome e a extensão do arquivo inteiro.
            split::Info part = split::parse(pathToUtf8(p.filename()));
            bool isSplit = false;
            if (part.scheme != split::NONE) {
                if (part.index > 1) continue;
                isSplit = !split::partsOf(p).empty();
            }
            fs::path logical = isSplit ? p.parent_path() / u8path(part.joined) : p;
            std::string ext = lower(logical.extension().string());
            if (ext.size() < 2) continue;
            ext.erase(0, 1);
            std::string sys = storePlatformForPath(pathToUtf8(p));
            if (!sys.empty()) {
                if (ext == "part") continue;
            } else if (ext == "zip" && !isSplit) {
                sys = detectZip(pathToUtf8(p));
            } else {
                auto c = candidatesFor(ext);
                if (c.empty()) continue;
                // Trilhas .bin ao lado de um .cue não viram jogos.
                if (ext == "bin" || ext == "img") {
                    fs::path cue = p;
                    cue.replace_extension(".cue");
                    if (fs::exists(cue, ec)) continue;
                }
                if (c.size() == 1) {
                    sys = c[0]->id;
                } else {
                    const SystemInfo* hint = nullptr;
                    for (fs::path d = p.parent_path(); !d.empty() && d != d.parent_path() && !hint; d = d.parent_path())
                        hint = hintFromFolder(pathToUtf8(d.filename()));
                    bool ok = hint && std::find(c.begin(), c.end(), hint) != c.end();
                    const char* sniffed = ok || isSplit ? nullptr : sniffDisc(pathToUtf8(p), ext);
                    sys = ok ? hint->id : sniffed ? sniffed : c[0]->id;
                }
            }
            if (sys.empty()) continue;
            found.push_back({pathToUtf8(p), titleFromStem(pathToUtf8(logical.stem())), sys});
        }
    }
    // Jogos grátis que vêm junto com o programa (os dados chegam com o emulador).
    {
        std::error_code ec;
        std::string cave = g_prefPath + "system/nxengine/Doukutsu.exe";
        if (fs::exists(u8path(cave), ec)) found.push_back({cave, "Cave Story", "cavestory"});
    }
    std::sort(found.begin(), found.end(), [](const Game& a, const Game& b) { return lower(a.title) < lower(b.title); });
    g_games = std::move(found);
}

#ifdef _WIN32
static std::string pickFolder() {
    std::string result;
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    IFileOpenDialog* dlg = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_ALL, IID_IFileOpenDialog, (void**)&dlg))) {
        DWORD opts = 0;
        dlg->GetOptions(&opts);
        dlg->SetOptions(opts | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
        dlg->SetTitle(L"Escolha a pasta com seus jogos");
        if (SUCCEEDED(dlg->Show(nullptr))) {
            IShellItem* item = nullptr;
            if (SUCCEEDED(dlg->GetResult(&item))) {
                PWSTR p = nullptr;
                if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &p))) {
                    result = narrow(p);
                    CoTaskMemFree(p);
                }
                item->Release();
            }
        }
        dlg->Release();
    }
    CoUninitialize();
    return result;
}
#else
static std::string pickFolder() { return ""; }
#endif

// ---------------------------------------------------------------------------
// Estilo (minimalista, escuro)

static perf::Hardware g_hw;
static std::string perfPath();
static ImFont* g_fontBody = nullptr;
static ImFont* g_fontTitle = nullptr;
static ImFont* g_fontSmall = nullptr;

static void setupStyle() {
    ImGuiIO& io = ImGui::GetIO();
    std::string regular = g_basePath + "assets/Geist-Regular.ttf";
    std::string semibold = g_basePath + "assets/Geist-SemiBold.ttf";
    if (fs::exists(u8path(regular))) {
        g_fontBody = io.Fonts->AddFontFromFileTTF(regular.c_str(), 18.0f, nullptr, io.Fonts->GetGlyphRangesDefault());
        g_fontSmall = io.Fonts->AddFontFromFileTTF(regular.c_str(), 14.0f);
        g_fontTitle = io.Fonts->AddFontFromFileTTF(semibold.c_str(), 36.0f);
    }
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 0;
    s.ChildRounding = 12;
    s.FrameRounding = 8;
    s.PopupRounding = 12;
    s.GrabRounding = 8;
    s.TabRounding = 8;
    s.FramePadding = ImVec2(14, 10);
    s.ItemSpacing = ImVec2(12, 12);
    s.WindowPadding = ImVec2(32, 28);
    s.FrameBorderSize = 1;
    s.ChildBorderSize = 1;
    ImVec4* c = s.Colors;
    auto rgb = [](int r, int g, int b, float a = 1.0f) { return ImVec4(r / 255.f, g / 255.f, b / 255.f, a); };
    c[ImGuiCol_WindowBg] = rgb(17, 17, 17);
    c[ImGuiCol_ChildBg] = rgb(26, 26, 26);
    c[ImGuiCol_PopupBg] = rgb(26, 26, 26, 0.98f);
    c[ImGuiCol_Border] = rgb(255, 255, 255, 0.08f);
    c[ImGuiCol_Text] = rgb(242, 242, 240);
    c[ImGuiCol_TextDisabled] = rgb(138, 138, 134);
    c[ImGuiCol_FrameBg] = rgb(34, 34, 34);
    c[ImGuiCol_FrameBgHovered] = rgb(44, 44, 44);
    c[ImGuiCol_FrameBgActive] = rgb(52, 52, 52);
    c[ImGuiCol_Button] = rgb(34, 34, 34);
    c[ImGuiCol_ButtonHovered] = rgb(48, 48, 48);
    c[ImGuiCol_ButtonActive] = rgb(60, 60, 60);
    c[ImGuiCol_Header] = rgb(40, 40, 40);
    c[ImGuiCol_HeaderHovered] = rgb(48, 48, 48);
    c[ImGuiCol_HeaderActive] = rgb(60, 60, 60);
    c[ImGuiCol_CheckMark] = rgb(157, 184, 255);
    c[ImGuiCol_SliderGrab] = rgb(242, 242, 240);
    c[ImGuiCol_SliderGrabActive] = rgb(255, 255, 255);
    c[ImGuiCol_NavCursor] = rgb(157, 184, 255);
    c[ImGuiCol_Tab] = rgb(26, 26, 26);
    c[ImGuiCol_TabHovered] = rgb(48, 48, 48);
    c[ImGuiCol_TabSelected] = rgb(242, 242, 240, 0.12f);
    c[ImGuiCol_ScrollbarBg] = rgb(17, 17, 17);
}

static bool primaryButton(const char* label, ImVec2 size = ImVec2(0, 0)) {
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.95f, 0.95f, 0.94f, 1));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1, 1, 1, 1));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.85f, 0.85f, 0.84f, 1));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.07f, 0.07f, 0.07f, 1));
    bool r = ImGui::Button(label, size);
    ImGui::PopStyleColor(4);
    return r;
}

// ---------------------------------------------------------------------------
// Janela e laço comum

struct App {
    SDL_Window* window = nullptr;
    SDL_GLContext gl = nullptr;
};

static bool createWindow(App& app, const char* title, bool fullscreen) {
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
    Uint32 flags = SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI;
    if (fullscreen) flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;
    app.window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 760, flags);
    if (!app.window) return false;
    app.gl = SDL_GL_CreateContext(app.window);
    if (!app.gl) return false;
    SDL_GL_MakeCurrent(app.window, app.gl);
    SDL_GL_SetSwapInterval(1);
    int glVersion = gladLoadGL((GLADloadfunc)SDL_GL_GetProcAddress);
    if (!glVersion || GLAD_VERSION_MAJOR(glVersion) * 10 + GLAD_VERSION_MINOR(glVersion) < 33) {
        // Sem OpenGL 3.3 (driver de vídeo ausente ou genérico): avisa em vez de fechar sozinho.
        const char* renderer = glVersion ? (const char*)glGetString(GL_RENDERER) : nullptr;
        std::string msg = "Esta placa de vídeo (ou o driver instalado) não oferece OpenGL 3.3, que o Cartucho precisa.\n\n";
        msg += "Driver encontrado: ";
        msg += renderer ? renderer : "nenhum";
        msg += "\n\nInstale o driver de vídeo mais novo do fabricante (NVIDIA, AMD ou Intel) e tente de novo.";
        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Cartucho", msg.c_str(), app.window);
        return false;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard | ImGuiConfigFlags_NavEnableGamepad;
    io.IniFilename = nullptr;
    setupStyle();
    ImGui_ImplSDL2_InitForOpenGL(app.window, app.gl);
    ImGui_ImplOpenGL3_Init("#version 330");
    return true;
}

static void destroyWindow(App& app) {
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    if (app.gl) SDL_GL_DeleteContext(app.gl);
    if (app.window) SDL_DestroyWindow(app.window);
}

static void beginFrame() {
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplSDL2_NewFrame();
    ImGui::NewFrame();
}

static void endFrame(App& app, bool clear) {
    ImGui::Render();
    int w, h;
    SDL_GL_GetDrawableSize(app.window, &w, &h);
    glViewport(0, 0, w, h);
    if (clear) {
        glClearColor(0.067f, 0.067f, 0.067f, 1);
        glClear(GL_COLOR_BUFFER_BIT);
    }
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    SDL_GL_SwapWindow(app.window);
}

// ---------------------------------------------------------------------------
// Modo de jogo

static std::string fileStem(const std::string& path) { return pathToUtf8(u8path(path).stem()); }

/** Extrai um .zip de console para uma pasta temporária e devolve o arquivo principal. */
static std::string extractZip(const std::string& zipPath, const SystemInfo& sys) {
    fs::path dir = u8path(g_prefPath + "run");
    std::error_code ec;
    fs::remove_all(dir, ec);
    fs::create_directories(dir, ec);
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_file(&zip, pathForCore(zipPath).c_str(), 0)) return "";
    std::string main;
    mz_uint n = mz_zip_reader_get_num_files(&zip);
    for (mz_uint i = 0; i < n; i++) {
        if (mz_zip_reader_is_file_a_directory(&zip, i)) continue;
        char name[512];
        mz_zip_reader_get_filename(&zip, i, name, sizeof(name));
        std::string base = pathToUtf8(u8path(name).filename());
        fs::path out = dir / u8path(base);
        mz_zip_reader_extract_to_file(&zip, i, pathForCore(pathToUtf8(dir)).append("/").append(base).c_str(), 0);
        std::string ext = lower(u8path(base).extension().string());
        if (!ext.empty()) ext.erase(0, 1);
        bool isSheet = ext == "cue" || ext == "gdi" || ext == "m3u";
        bool matches = std::find(sys.extensions.begin(), sys.extensions.end(), ext) != sys.extensions.end();
        if (isSheet || (main.empty() && matches)) main = pathToUtf8(out);
    }
    mz_zip_reader_end(&zip);
    if (main.empty()) {
        // O .zip trouxe o jogo em partes (jogo.iso.001, .002…): junta e procura de novo.
        split::joinInDir(dir);
        for (const auto& e : fs::directory_iterator(dir, ec)) {
            std::string x = lower(e.path().extension().string());
            if (!x.empty()) x.erase(0, 1);
            if (std::find(sys.extensions.begin(), sys.extensions.end(), x) != sys.extensions.end()) { main = pathToUtf8(e.path()); break; }
        }
    }
    return main;
}

/** Copia os arquivos de sistema que vêm com o programa (Dolphin Sys, blueMSX, PPSSPP) para a pasta do usuário. */
static void installBundledSystemFiles() {
    std::error_code ec;
    fs::path src = u8path(g_basePath + "system");
    fs::path dst = u8path(g_prefPath + "system");
    if (!fs::exists(src, ec)) return;
    fs::path marker = dst / ".bundled-v3";
    if (fs::exists(marker, ec)) return;
    fs::create_directories(dst, ec);
    fs::copy(src, dst, fs::copy_options::recursive | fs::copy_options::skip_existing, ec);
    FILE* m = fopen(pathToUtf8(marker).c_str(), "w");
    if (m) fclose(m);
}

static int playGame(const std::string& gamePath, const std::string& systemId, int autoFrames = 0) {
#ifdef _WIN32
    SetUnhandledExceptionFilter(crashFilter);
    signal(SIGABRT, abortHandler);
    _wremove(widen(logPath()).c_str());
    _wremove(widen(errorPath()).c_str());
#endif
    logStep("Cartucho para Windows · jogo: %s · sistema: %s", fileStem(gamePath).c_str(), systemId.c_str());
    const SystemInfo* sys = systemById(systemId);
    if (!sys) { logStep("sistema desconhecido"); return 1; }
    App app;
    std::string title = "Cartucho — " + titleFromStem(fileStem(gamePath));
    logStep("abrindo a janela do jogo");
    if (!createWindow(app, title.c_str(), autoFrames > 0 ? false : g_config.fullscreen)) { logStep("falha ao criar a janela/OpenGL: %s", SDL_GetError()); return 1; }
    logStep("OpenGL: %s / %s", (const char*)glGetString(GL_VENDOR), (const char*)glGetString(GL_RENDERER));

    // PS2: com a BIOS do console em system/pcsx2/bios, usa o PCSX2 (bem mais rápido); sem ela, o Play!.
    std::string coreName = sys->core;
    if (std::string(sys->id) == "ps2") {
        std::error_code ecb;
        bool bios = false;
        for (const auto& e : fs::directory_iterator(u8path(g_prefPath + "system/pcsx2/bios"), ecb))
            if (e.is_regular_file() && e.file_size() > 1000000) bios = true;
        if (bios && fs::exists(u8path(g_basePath + "cores/pcsx2_libretro.dll"), ecb)) coreName = "pcsx2";
    }
    std::string corePath = g_basePath + "cores/" + coreName + "_libretro.dll";
    {
        std::error_code ec0;
        logStep("core: %s (%s)", corePath.c_str(), fs::exists(u8path(corePath), ec0) ? "encontrado" : "NÃO encontrado");
    }
    std::string systemDir = g_prefPath + "system";
    std::string saveDir = g_prefPath + "saves/" + sys->id;
    std::string stateDir = g_prefPath + "states/" + sys->id;
    std::error_code ec;
    fs::create_directories(u8path(systemDir), ec);
    fs::create_directories(u8path(saveDir), ec);
    fs::create_directories(u8path(stateDir), ec);

    std::string actual = gamePath;
    std::string logicalPath = gamePath;
    {
        // Jogo em partes: junta tudo num arquivo só antes de abrir.
        auto parts = split::partsOf(u8path(gamePath));
        if (!parts.empty()) {
            logStep("juntando %d partes", (int)parts.size());
            fs::path runDir = u8path(g_prefPath + "run-partes");
            std::error_code ecj;
            fs::remove_all(runDir, ecj);
            fs::create_directories(runDir, ecj);
            fs::path joined = runDir / u8path(split::parse(pathToUtf8(u8path(gamePath).filename())).joined);
            if (split::join(parts, joined)) { actual = pathToUtf8(joined); logicalPath = actual; }
        }
    }
    std::string ext = lower(u8path(actual).extension().string());
    if (ext == ".zip" && std::string(sys->id) != "arcade" && std::string(sys->id) != "naomi") actual = extractZip(actual, *sys);

    std::string core = coreName;
    if (core == "melonds") {  // telas empilhadas e clique do mouse como toque na tela de baixo
        host::setOption("melonds_screen_layout", "Top/Bottom");
        host::setOption("melonds_screen_gap", "0");
        host::setOption("melonds_touch_mode", "Touch");
    } else if (core == "citra") {
        host::setOption("citra_layout_option", "Default Top-Bottom Screen");
        host::setOption("citra_touch_touchscreen", "enabled");
        host::setOption("citra_mouse_touchscreen", "disabled");
    }

    std::string error;
    logStep("carregando o core e o jogo");
    bool ok = !actual.empty() &&
              host::start(pathForCore(corePath), pathForCore(actual), pathForCore(systemDir), pathForCore(saveDir), error);
    if (actual.empty()) error = "Não encontrei o jogo dentro do arquivo compactado.";
    logStep(ok ? "jogo carregado" : "falha ao carregar: %s", error.c_str());
    if (autoFrames > 0 && !ok) return 2;
    long long framesDone = 0;
    bool logged60 = false;

    std::string stem = fileStem(logicalPath);
    std::string sram = saveDir + "/" + stem + ".srm";
    if (ok) host::loadSram(pathForCore(sram));
    host::setVolume(g_config.volume);

    SDL_GameController* pads[4] = {nullptr, nullptr, nullptr, nullptr};
    SDL_JoystickID padIds[4] = {-1, -1, -1, -1};
    auto openPads = [&]() {
        for (int i = 0; i < SDL_NumJoysticks(); i++) {
            if (!SDL_IsGameController(i)) continue;
            SDL_JoystickID id = SDL_JoystickGetDeviceInstanceID(i);
            bool already = false;
            for (int p = 0; p < 4; p++) if (padIds[p] == id) already = true;
            if (already) continue;
            for (int p = 0; p < 4; p++) {
                if (!pads[p]) { pads[p] = SDL_GameControllerOpen(i); padIds[p] = id; break; }
            }
        }
    };
    openPads();

    bool menu = !ok;
    bool running = true;
    bool fastForward = false;
    std::string toast;
    Uint64 toastUntil = 0;
    Uint64 last = SDL_GetPerformanceCounter();
    Uint64 lastSram = SDL_GetTicks64();
    // Velocidade real: quadros emulados ÷ quadros esperados, só em jogo normal (sem menu nem acelerar).
    double measuredTime = 0, measuredFrames = 0;
    double acc = 0;
    int slot = 1;

    auto showToast = [&](const std::string& t) { toast = t; toastUntil = SDL_GetTicks64() + 2000; };
    auto statePath = [&](int s) { return stateDir + "/" + stem + ".slot" + std::to_string(s); };

    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            ImGui_ImplSDL2_ProcessEvent(&e);
            if (e.type == SDL_QUIT) running = false;
            if (e.type == SDL_CONTROLLERDEVICEADDED) openPads();
            if (!menu && (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP || e.type == SDL_MOUSEMOTION)) {
                int ww, wh, dw, dh;
                SDL_GetWindowSize(app.window, &ww, &wh);
                SDL_GL_GetDrawableSize(app.window, &dw, &dh);
                int mx, my;
                Uint32 state = SDL_GetMouseState(&mx, &my);
                host::setPointer(mx * (float)dw / (ww > 0 ? ww : 1), my * (float)dh / (wh > 0 ? wh : 1), (state & SDL_BUTTON_LMASK) != 0);
            }
            if (e.type == SDL_CONTROLLERDEVICEREMOVED) {
                for (int p = 0; p < 4; p++) {
                    if (padIds[p] == e.cdevice.which) {
                        SDL_GameControllerClose(pads[p]);
                        pads[p] = nullptr;
                        padIds[p] = -1;
                        if (p == 0 && ok) menu = true;
                    }
                }
            }
            if (e.type == SDL_KEYDOWN && !e.key.repeat) {
                SDL_Scancode sc = e.key.keysym.scancode;
                if (sc == SDL_SCANCODE_ESCAPE && ok) menu = !menu;
                if (sc == SDL_SCANCODE_F11) {
                    g_config.fullscreen = !g_config.fullscreen;
                    SDL_SetWindowFullscreen(app.window, g_config.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
                }
                if (sc == SDL_SCANCODE_F2 && ok) showToast(host::saveState(pathForCore(statePath(slot))) ? "Estado salvo" : "Não foi possível salvar");
                if (sc == SDL_SCANCODE_F4 && ok) showToast(host::loadState(pathForCore(statePath(slot))) ? "Estado carregado" : "Nenhum estado neste espaço");
                if (sc == SDL_SCANCODE_TAB) fastForward = true;
            }
            if (e.type == SDL_KEYUP && e.key.keysym.scancode == SDL_SCANCODE_TAB) fastForward = false;
            if (e.type == SDL_CONTROLLERBUTTONDOWN && e.cbutton.button == SDL_CONTROLLER_BUTTON_GUIDE && ok) menu = !menu;
        }
        host::setPaused(menu);

        // Entrada: teclado no jogador 1; controles nos jogadores 1-4.
        uint32_t masks[4] = {0, 0, 0, 0};
        if (!menu) {
            const Uint8* ks = SDL_GetKeyboardState(nullptr);
            for (int i = 0; i < RP_COUNT; i++)
                if (g_config.keys[i] > 0 && ks[g_config.keys[i]]) masks[0] |= 1u << i;
            for (int p = 0; p < 4; p++) {
                SDL_GameController* c = pads[p];
                if (!c) continue;
                struct M { SDL_GameControllerButton b; int id; };
                static const M map[] = {
                    {SDL_CONTROLLER_BUTTON_A, RP_B}, {SDL_CONTROLLER_BUTTON_B, RP_A}, {SDL_CONTROLLER_BUTTON_X, RP_Y},
                    {SDL_CONTROLLER_BUTTON_Y, RP_X}, {SDL_CONTROLLER_BUTTON_LEFTSHOULDER, RP_L},
                    {SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, RP_R}, {SDL_CONTROLLER_BUTTON_LEFTSTICK, RP_L3},
                    {SDL_CONTROLLER_BUTTON_RIGHTSTICK, RP_R3}, {SDL_CONTROLLER_BUTTON_START, RP_START},
                    {SDL_CONTROLLER_BUTTON_BACK, RP_SELECT}, {SDL_CONTROLLER_BUTTON_DPAD_UP, RP_UP},
                    {SDL_CONTROLLER_BUTTON_DPAD_DOWN, RP_DOWN}, {SDL_CONTROLLER_BUTTON_DPAD_LEFT, RP_LEFT},
                    {SDL_CONTROLLER_BUTTON_DPAD_RIGHT, RP_RIGHT},
                };
                for (const auto& m : map)
                    if (SDL_GameControllerGetButton(c, m.b)) masks[p] |= 1u << m.id;
                if (SDL_GameControllerGetAxis(c, SDL_CONTROLLER_AXIS_TRIGGERLEFT) > 12000) masks[p] |= 1u << RP_L2;
                if (SDL_GameControllerGetAxis(c, SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > 12000) masks[p] |= 1u << RP_R2;
                auto axis = [&](SDL_GameControllerAxis a) {
                    int v = SDL_GameControllerGetAxis(c, a);
                    return std::abs(v) < 5000 ? 0 : v;
                };
                host::setAnalog(p, 0, axis(SDL_CONTROLLER_AXIS_LEFTX), axis(SDL_CONTROLLER_AXIS_LEFTY));
                host::setAnalog(p, 1, axis(SDL_CONTROLLER_AXIS_RIGHTX), axis(SDL_CONTROLLER_AXIS_RIGHTY));
            }
        }
        for (int p = 0; p < 4; p++) host::setButtons(p, masks[p]);

        // Ritmo pelo relógio (fps do core), independente da taxa do monitor.
        Uint64 now = SDL_GetPerformanceCounter();
        double dt = (double)(now - last) / SDL_GetPerformanceFrequency();
        last = now;
        if (dt > 0.25) dt = 0.25;
        if (ok && !menu) {
            acc += dt;
            double frame = 1.0 / host::fps();
            int runs = 0;
            while (acc >= frame && runs < 3) {
                if (framesDone == 0) logStep("primeiro quadro");
                host::runFrame(fastForward);
                acc -= frame;
                runs++;
                framesDone++;
            }
            if (framesDone >= 60 && !logged60) { logStep("60 quadros ok"); logged60 = true; }
            if (autoFrames > 0 && framesDone >= autoFrames) running = false;
            if (!fastForward && dt < 0.2) {
                measuredTime += dt;
                measuredFrames += runs;
            }
            if (runs == 3) acc = 0;
            if (SDL_GetTicks64() - lastSram > 30000) {
                lastSram = SDL_GetTicks64();
                host::saveSram(pathForCore(sram));
            }
        }

        int w, h;
        SDL_GL_GetDrawableSize(app.window, &w, &h);
        host::draw(w, h, g_config.integerScale, g_config.smooth);

        beginFrame();
        ImGuiIO& io = ImGui::GetIO();
        if (!toast.empty() && SDL_GetTicks64() < toastUntil) {
            ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, 24), ImGuiCond_Always, ImVec2(0.5f, 0));
            ImGui::Begin("##toast", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoNav);
            ImGui::TextUnformatted(toast.c_str());
            ImGui::End();
        }
        if (menu) {
            ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), io.DisplaySize, IM_COL32(0, 0, 0, 150));
            ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
            ImGui::SetNextWindowSize(ImVec2(420, 0));
            ImGui::Begin("##menu", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize);
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted(ok ? titleFromStem(stem).c_str() : "Não deu para abrir o jogo");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::TextDisabled("%s", sys->name);
            ImGui::Spacing();
            ImVec2 full(-1, 0);
            if (!ok) {
                ImGui::TextWrapped("%s", error.c_str());
                ImGui::Spacing();
                if (primaryButton("Voltar à biblioteca", full)) running = false;
            } else {
                if (primaryButton("Continuar", full)) menu = false;
                ImGui::SetNextItemWidth(-1);
                ImGui::SliderInt("##slot", &slot, 1, 3, "Espaço %d");
                if (ImGui::Button("Salvar estado  (F2)", full)) { showToast(host::saveState(pathForCore(statePath(slot))) ? "Estado salvo" : "Não foi possível salvar"); menu = false; }
                if (ImGui::Button("Carregar estado  (F4)", full)) { showToast(host::loadState(pathForCore(statePath(slot))) ? "Estado carregado" : "Nenhum estado neste espaço"); menu = false; }
                if (ImGui::Button("Reiniciar jogo", full)) { host::reset(); menu = false; }
                if (ImGui::Button(g_config.fullscreen ? "Sair da tela cheia  (F11)" : "Tela cheia  (F11)", full)) {
                    g_config.fullscreen = !g_config.fullscreen;
                    SDL_SetWindowFullscreen(app.window, g_config.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
                }
                if (ImGui::SliderFloat("Volume", &g_config.volume, 0.0f, 1.0f, "%.0f%%")) host::setVolume(g_config.volume);
                ImGui::Checkbox("Escala inteira", &g_config.integerScale);
                ImGui::Checkbox("Filtro suave", &g_config.smooth);
                ImGui::Spacing();
                if (ImGui::Button("Sair do jogo", full)) running = false;
                ImGui::TextDisabled("Esc abre e fecha este menu · Tab acelera");
            }
            ImGui::End();
        }
        endFrame(app, false);
    }

    if (ok) host::saveSram(pathForCore(sram));
    if (ok && measuredTime > 20.0) {
        float speed = (float)std::min(1.0, measuredFrames / (measuredTime * host::fps()));
        perf::saveMeasured(pathForCore(perfPath()), gamePath, speed);
    }
    saveConfig();
    logStep("encerrando (%lld quadros)", framesDone);
    host::shutdown();
    logStep("fim");
    for (auto* p : pads) if (p) SDL_GameControllerClose(p);
    destroyWindow(app);
    return 0;
}

// ---------------------------------------------------------------------------
// Biblioteca (janela principal)

static std::string g_crashReport;  // detalhes do último jogo que fechou por erro

#ifdef _WIN32
// ---------------------------------------------------------------- saves na nuvem (Google Drive)

static std::unique_ptr<gdrive::Account> g_drive;
static std::atomic<long long> g_lastDriveSync{0};

/** Sincroniza os saves em segundo plano (ao abrir o programa e ao fechar um jogo). */
static void startDriveSync() {
    if (!g_drive || !g_drive->signedIn() || gdrive::state().busy.exchange(true)) return;
    gdrive::setStatus("Sincronizando os saves…");
    std::thread([] {
        std::string r = gdrive::syncSaves(*g_drive, g_prefPath);
        gdrive::setStatus(r);
        g_lastDriveSync = (long long)GetTickCount64();
        gdrive::state().busy = false;
    }).detach();
}

/** Antes de abrir um jogo: traz o save mais novo da nuvem (de outro aparelho), sem demorar muito. */
static void driveSyncBeforePlay() {
    if (!g_drive || !g_drive->signedIn()) return;
    for (int i = 0; i < 150 && gdrive::state().busy.load(); i++) SDL_Delay(100);
    if ((long long)GetTickCount64() - g_lastDriveSync.load() < 60000) return;
    if (gdrive::state().busy.exchange(true)) return;
    gdrive::setStatus(gdrive::syncSaves(*g_drive, g_prefPath));
    g_lastDriveSync = (long long)GetTickCount64();
    gdrive::state().busy = false;
}
#endif

static void launchGame(const Game& g, SDL_Window* window) {
    saveConfig();
#ifdef _WIN32
    driveSyncBeforePlay();
    wchar_t exe[MAX_PATH];
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring cmd = L"\"" + std::wstring(exe) + L"\" --play \"" + widen(g.path) + L"\" " + widen(g.system);
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
        SDL_HideWindow(window);
        WaitForSingleObject(pi.hProcess, INFINITE);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        if (code != 0 && code != 1 && code != 2) {
            std::string err = readText(errorPath());
            g_crashReport = err.empty() ? "O jogo fechou sozinho (código " + std::to_string((unsigned long)code) + ").\n\nEtapas:\n" + readText(logPath()) : err;
        }
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        SDL_ShowWindow(window);
        SDL_RaiseWindow(window);
        startDriveSync();
    }
    loadConfig();
#else
    (void)window;
    playGame(g.path, g.system);
#endif
}


// ------------------------------------------------------------------ Loja (homebrew gratuito do Homebrew Hub)
struct StoreGame {
    std::string slug, title, platform, type, developer, license, file, shot, basePath, year, desc;
    std::string url, cover, lang, source, site;
    std::vector<std::string> genres;
    int players = 0;
    char letter = '#';
};
static std::vector<StoreGame> g_store;
static std::map<std::string, size_t> g_storeBySlug;
static std::atomic<int> g_storeState{0};  // 0 parado · 1 baixando · 2 pronto · 3 erro
static std::string g_storeDone;            // caminho do jogo baixado
static std::string g_storeError;

static void parseStore(const std::string& text);

static void loadStore() {
    g_store.clear();
    g_storeBySlug.clear();
    parseStore(readText(g_basePath + "loja.tsv"));
    // Sem catálogo junto do programa (instalação antiga ou arquivo apagado): usa o salvo ou baixa o da versão mais nova.
    std::string saved = g_prefPath + "loja.tsv";
    if (g_store.empty()) parseStore(readText(saved));
#ifdef _WIN32
    if (g_store.empty()) {
        std::string part = saved + ".part";
        if (URLDownloadToFileW(nullptr, L"https://github.com/andrefeeelipe/Cartucho/releases/latest/download/loja.tsv",
                               widen(part).c_str(), 0, nullptr) == S_OK) {
            std::error_code ec;
            fs::remove(u8path(saved), ec);
            fs::rename(u8path(part), u8path(saved), ec);
            parseStore(readText(saved));
        }
    }
#endif
}

static void parseStore(const std::string& text) {
    std::stringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        std::vector<std::string> f;
        size_t start = 0;
        while (true) {
            size_t tab = line.find('\t', start);
            f.push_back(line.substr(start, tab == std::string::npos ? std::string::npos : tab - start));
            if (tab == std::string::npos) break;
            start = tab + 1;
        }
        if (f.size() < 11 || f[0].empty() || f[6].empty() || !systemById(f[2])) continue;
        StoreGame g{f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9], f[10]};
        if (f.size() >= 18) {
            g.url = f[11]; g.cover = f[12]; g.lang = f[14]; g.players = atoi(f[15].c_str()); g.source = f[16]; g.site = f[17];
            std::stringstream gs(f[13]);
            std::string one;
            while (std::getline(gs, one, ',')) if (!one.empty()) g.genres.push_back(one);
        }
        g.letter = titleLetter(g.title);
        g_storeBySlug[g.slug] = g_store.size();
        g_store.push_back(std::move(g));
    }
}

/** Jogo da Loja pelo caminho do arquivo baixado (a pasta tem o código do jogo). */
static const StoreGame* storeGameForPath(const std::string& path) {
    fs::path p = u8path(path);
    std::string slug = pathToUtf8(p.parent_path().filename());
    auto it = g_storeBySlug.find(slug);
    if (it == g_storeBySlug.end()) return nullptr;
    bool inStore = lower(pathToUtf8(p.parent_path().parent_path().filename())) == "loja";
    return inStore ? &g_store[it->second] : nullptr;
}

static std::string storePlatformForPath(const std::string& path) {
    const StoreGame* g = storeGameForPath(path);
    return g ? g->platform : std::string();
}

static std::string storeLocalPath(const StoreGame& g) { return g_prefPath + "loja/" + g.slug + "/" + g.file; }

static std::string urlEncode(const std::string& s) {
    std::string out;
    char buf[4];
    for (unsigned char ch : s) {
        if (isalnum(ch) || ch == '-' || ch == '_' || ch == '.' || ch == '~' || ch == '/') out += (char)ch;
        else { snprintf(buf, sizeof(buf), "%%%02X", ch); out += buf; }
    }
    return out;
}

static void downloadStoreGame(StoreGame g) {
    g_storeState = 1;
    std::thread([g]() {
        std::string target = storeLocalPath(g);
        std::error_code ec;
        fs::create_directories(u8path(target).parent_path(), ec);
        std::string urls[2] = {
            g.url.empty() ? "https://hh3.gbdev.io/static/" + g.basePath + "/entries/" + urlEncode(g.slug) + "/" + urlEncode(g.file) : g.url,
            g.url.empty() ? "https://hh3.gbdev.io/api/entry/" + urlEncode(g.slug) + "/" + urlEncode(g.file) : g.url,
        };
        bool ok = false;
#ifdef _WIN32
        std::string part = target + ".part";
        for (const auto& u : urls) {
            if (g.url.empty() && g.basePath.empty() && &u == &urls[0]) continue;
            if (URLDownloadToFileW(nullptr, widen(u).c_str(), widen(part).c_str(), 0, nullptr) == S_OK) { ok = true; break; }
        }
        if (ok) {
            fs::rename(u8path(part), u8path(target), ec);
            ok = !ec;
        }
#endif
        if (ok) { g_storeDone = target; g_storeState = 2; }
        else { g_storeError = "Não foi possível baixar \"" + g.title + "\". Confira a internet e tente de novo."; g_storeState = 3; }
    }).detach();
}

static const char* storePlatformName(const std::string& p) {
    const SystemInfo* s = systemById(p);
    return s ? s->name : p.c_str();
}

static const char* kGenres[] = {"Ação", "Aventura", "Plataforma", "Tiro", "Corrida", "Esporte", "Luta", "Quebra-cabeça", "RPG",
                                "Estratégia", "Simulação", "Labirinto", "Tabuleiro e cartas", "Educativo", "Casual", "Música"};

static bool hasGenre(const StoreGame& g, const char* genre) {
    return std::find(g.genres.begin(), g.genres.end(), std::string(genre)) != g.genres.end();
}

/** Nome de arquivo de versão em português (traduções da comunidade e lançamentos brasileiros). */
static bool looksPortuguese(const std::string& name) {
    std::string n = lower(name);
    for (const char* k : {"pt-br", "ptbr", "pt_br", "(br)", "[br]", "(brazil", "portugu", "traduc", "[t+por", "[t-por", "[t+bra", "(pt)"})
        if (n.find(k) != std::string::npos) return true;
    return false;
}

/** Faixa A–Z: devolve true quando a letra escolhida muda. */
static bool letterBar(char& selected, const bool available[27]) {
    bool changed = false;
    const char* labels = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (ImGui::SmallButton(selected == 0 ? "[A-Z]" : "A-Z")) { selected = 0; changed = true; }
    for (int i = 0; i < 27; i++) {
        ImGui::SameLine(0, 2);
        char buf[8];
        char l = labels[i];
        snprintf(buf, sizeof(buf), selected == l ? "[%c]" : "%c", l);
        ImGui::BeginDisabled(!available[i] && selected != l);
        if (ImGui::SmallButton(buf)) { selected = selected == l ? 0 : l; changed = true; }
        ImGui::EndDisabled();
    }
    return changed;
}

static int letterIndex(char l) { return l == '#' ? 0 : (l >= 'A' && l <= 'Z') ? l - 'A' + 1 : 0; }

static std::string lowerStr(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), ::tolower);
    return s;
}

static int runLibrary() {
    App app;
    if (!createWindow(app, "Cartucho", false)) return 1;
    g_hw = perf::detect();
    perf::loadMeasured(pathForCore(perfPath()));
    loadStore();
    scanFolders();
#ifdef _WIN32
    g_drive = std::make_unique<gdrive::Account>(g_prefPath);
    startDriveSync();
#endif
    char storeSearch[128] = "";
    std::string storePlatform;
    int storeKind = 0;      // 0 jogos · 1 demos · 2 tudo
    int storeGenre = -1;
    int storeLang = 0;      // 0 todos · 1 pt · 2 en · 3 es · 4 outros
    int storeEra = 0;       // 0 todas · 1980..2020
    int storePlayers = 0;   // 0 tanto faz · 1 · 2+
    int storeSort = 0;      // 0 A–Z · 1 Z–A · 2 novos · 3 antigos
    bool storeOnlyHave = false;
    char storeLetter = 0;
    std::vector<size_t> storeView;
    std::string storeViewKey = "?";
    char libLetter = 0;
    int libGenre = -1;
    bool libPt = false;
    int libSort = 0;
    std::vector<std::string> storePlatforms;
    for (const auto& sg : g_store)
        if (std::find(storePlatforms.begin(), storePlatforms.end(), sg.platform) == storePlatforms.end()) storePlatforms.push_back(sg.platform);
    std::string storeWanted;  // título do jogo baixando
    const Game* confirmGame = nullptr;
    perf::Verdict confirmVerdict;
    bool openConfirm = false;

    enum class Screen { Library, Settings, Store };
    Screen screen = Screen::Library;
    char search[128] = "";
    int filter = -1;
    int capturing = -1;
    bool running = true;

    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (capturing >= 0 && e.type == SDL_KEYDOWN) {
                if (e.key.keysym.scancode != SDL_SCANCODE_ESCAPE) g_config.keys[capturing] = e.key.keysym.scancode;
                capturing = -1;
                saveConfig();
                continue;
            }
            ImGui_ImplSDL2_ProcessEvent(&e);
            if (e.type == SDL_QUIT) running = false;
        }

        beginFrame();
        ImGuiIO& io = ImGui::GetIO();
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(io.DisplaySize);
        ImGui::Begin("##main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBringToFrontOnFocus);

        if (!g_crashReport.empty() && !ImGui::IsPopupOpen("##erro-jogo")) ImGui::OpenPopup("##erro-jogo");
        if (ImGui::BeginPopupModal("##erro-jogo", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("O jogo fechou por um erro");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::TextDisabled("Copie os detalhes e mande para quem mantém o app, para corrigir.");
            ImGui::InputTextMultiline("##crash", &g_crashReport[0], g_crashReport.size() + 1, ImVec2(560, 260), ImGuiInputTextFlags_ReadOnly);
            if (ImGui::Button("Copiar detalhes")) SDL_SetClipboardText(g_crashReport.c_str());
            ImGui::SameLine();
            if (ImGui::Button("Fechar")) { g_crashReport.clear(); ImGui::CloseCurrentPopup(); }
            ImGui::EndPopup();
        }

        if (screen == Screen::Library) {
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("Biblioteca");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::SameLine(ImGui::GetWindowWidth() - 450);
            if (ImGui::Button("Loja")) screen = Screen::Store;
            ImGui::SameLine();
            if (primaryButton("Adicionar pasta")) {
                std::string folder = pickFolder();
                if (!folder.empty()) {
                    g_config.folders.push_back(folder);
                    saveConfig();
                    scanFolders();
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("Ajustes")) screen = Screen::Settings;

            ImGui::SetNextItemWidth(320);
            ImGui::InputTextWithHint("##search", "Buscar na biblioteca", search, sizeof(search));
            ImGui::SameLine();
            ImGui::SetNextItemWidth(220);
            const char* current = filter < 0 ? "Todos os sistemas" : allSystems()[filter].name;
            if (ImGui::BeginCombo("##filter", current)) {
                if (ImGui::Selectable("Todos os sistemas", filter < 0)) filter = -1;
                for (int i = 0; i < (int)allSystems().size(); i++)
                    if (ImGui::Selectable(allSystems()[i].name, filter == i)) filter = i;
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            ImGui::SetNextItemWidth(150);
            if (ImGui::BeginCombo("##libgenre", libGenre < 0 ? "Todos os gêneros" : kGenres[libGenre])) {
                if (ImGui::Selectable("Todos os gêneros", libGenre < 0)) libGenre = -1;
                for (int i = 0; i < (int)IM_ARRAYSIZE(kGenres); i++)
                    if (ImGui::Selectable(kGenres[i], libGenre == i)) libGenre = i;
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            ImGui::Checkbox("Em português", &libPt);
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Traduções PT-BR, versões brasileiras e jogos da Loja feitos em português.");
            ImGui::SameLine();
            const char* libSorts[] = {"A-Z", "Z-A"};
            ImGui::SetNextItemWidth(70);
            ImGui::Combo("##libsort", &libSort, libSorts, 2);
            // Lista filtrada (sem a letra, para saber quais letras têm jogos).
            std::string q = lower(search);
            std::vector<size_t> libView;
            bool libLetters[27] = {};
            for (size_t i = 0; i < g_games.size(); i++) {
                const Game& g = g_games[i];
                if (filter >= 0 && g.system != allSystems()[filter].id) continue;
                if (!q.empty() && lower(g.title).find(q) == std::string::npos) continue;
                const StoreGame* sg = storeGameForPath(g.path);
                if (libGenre >= 0 && !(sg && hasGenre(*sg, kGenres[libGenre]))) continue;
                if (libPt && !((sg && sg->lang == "pt") || looksPortuguese(pathToUtf8(u8path(g.path).filename())))) continue;
                char l = titleLetter(g.title);
                libLetters[letterIndex(l)] = true;
                if (libLetter && l != libLetter) continue;
                libView.push_back(i);
            }
            if (libSort == 1) std::reverse(libView.begin(), libView.end());
            ImGui::SameLine();
            ImGui::TextDisabled("%d de %d jogos", (int)libView.size(), (int)g_games.size());
            if (g_games.size() > 12) letterBar(libLetter, libLetters);

            if (g_games.empty()) {
                ImGui::Dummy(ImVec2(0, 60));
                ImGui::TextUnformatted("Nenhum jogo ainda");
                ImGui::TextDisabled("Clique em \"Adicionar pasta\" e escolha a pasta onde estão os seus jogos.");
                ImGui::TextDisabled("Teclado: setas, Z/X/A/S, Q/W, Enter (Start), Backspace (Select). Joysticks são reconhecidos sozinhos.");
            } else {
                ImGui::BeginChild("##grid", ImVec2(0, 0), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground);
                float tileW = 190, tileH = 120;
                int cols = std::max(1, (int)((ImGui::GetContentRegionAvail().x + 12) / (tileW + 12)));
                int col = 0;
                if (libView.empty()) ImGui::TextDisabled("Nenhum jogo com esses filtros.");
                for (size_t i : libView) {
                    const Game& g = g_games[i];
                    if (col > 0) ImGui::SameLine();
                    ImGui::PushID((int)i);
                    ImVec2 pos = ImGui::GetCursorScreenPos();
                    bool clicked = ImGui::InvisibleButton("##tile", ImVec2(tileW, tileH));
                    bool hovered = ImGui::IsItemHovered() || ImGui::IsItemFocused();
                    ImDrawList* dl = ImGui::GetWindowDrawList();
                    dl->AddRectFilled(pos, ImVec2(pos.x + tileW, pos.y + tileH), hovered ? IM_COL32(40, 40, 40, 255) : IM_COL32(26, 26, 26, 255), 12);
                    dl->AddRect(pos, ImVec2(pos.x + tileW, pos.y + tileH), hovered ? IM_COL32(157, 184, 255, 255) : IM_COL32(255, 255, 255, 20), 12, 0, hovered ? 2.0f : 1.0f);
                    const SystemInfo* sys = systemById(g.system);
                    if (g_fontSmall) ImGui::PushFont(g_fontSmall);
                    dl->AddText(ImVec2(pos.x + 14, pos.y + 12), IM_COL32(138, 138, 134, 255), sys ? sys->shortName : "?");
                    if (g_fontSmall) ImGui::PopFont();
                    ImGui::PushClipRect(pos, ImVec2(pos.x + tileW - 12, pos.y + tileH), true);
                    dl->AddText(nullptr, 0, ImVec2(pos.x + 14, pos.y + tileH - 52), IM_COL32(242, 242, 240, 255), g.title.c_str(), nullptr, tileW - 28);
                    ImGui::PopClipRect();
                    perf::Verdict verdict = perf::rate(g_hw, g.system, g.path);
                    if (verdict.level != perf::Level::Smooth) {
                        ImU32 col = verdict.level == perf::Level::MayStutter ? IM_COL32(230, 180, 80, 255) : IM_COL32(235, 100, 90, 255);
                        if (g_fontSmall) ImGui::PushFont(g_fontSmall);
                        const char* tag = verdict.level == perf::Level::MayStutter ? "pode engasgar" : verdict.level == perf::Level::Heavy ? "vai travar" : "não roda";
                        ImVec2 ts = ImGui::CalcTextSize(tag);
                        dl->AddText(ImVec2(pos.x + tileW - 14 - ts.x, pos.y + 12), col, tag);
                        if (g_fontSmall) ImGui::PopFont();
                    }
                    if (hovered && verdict.level != perf::Level::Smooth) ImGui::SetTooltip("%s\n%s", verdict.label.c_str(), verdict.reason.c_str());
                    if (clicked) {
                        if (verdict.level == perf::Level::Heavy || verdict.level == perf::Level::CantRun) {
                            confirmGame = &g;
                            confirmVerdict = verdict;
                            openConfirm = true;
                        } else {
                            launchGame(g, app.window);
                            perf::loadMeasured(pathForCore(perfPath()));
                        }
                    }
                    ImGui::PopID();
                    col = (col + 1) % cols;
                }
                ImGui::EndChild();
            }
            if (openConfirm) { ImGui::OpenPopup("##aviso-desempenho"); openConfirm = false; }
            if (ImGui::BeginPopupModal("##aviso-desempenho", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
                if (g_fontTitle) ImGui::PushFont(g_fontTitle);
                ImGui::TextUnformatted(confirmVerdict.label.c_str());
                if (g_fontTitle) ImGui::PopFont();
                ImGui::PushTextWrapPos(420);
                ImGui::TextUnformatted(confirmVerdict.reason.c_str());
                ImGui::TextDisabled("Você pode jogar mesmo assim. Depois da partida, o Cartucho mede a velocidade real e atualiza este aviso.");
                ImGui::PopTextWrapPos();
                ImGui::Spacing();
                if (ImGui::Button("Jogar mesmo assim") && confirmGame) {
                    Game g = *confirmGame;
                    ImGui::CloseCurrentPopup();
                    confirmGame = nullptr;
                    launchGame(g, app.window);
                    perf::loadMeasured(pathForCore(perfPath()));
                }
                ImGui::SameLine();
                if (ImGui::Button("Agora não")) { ImGui::CloseCurrentPopup(); confirmGame = nullptr; }
                ImGui::EndPopup();
            }
        } else if (screen == Screen::Store) {
            if (ImGui::Button("< Voltar")) screen = Screen::Library;
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("Loja");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::TextDisabled("Jogos gratuitos liberados pelos autores: Homebrew Hub (GB, GBC, GBA, NES), ZXDB/Spectrum Computing (ZX Spectrum) e TIC-80.");
            ImGui::SetNextItemWidth(260);
            ImGui::InputTextWithHint("##storesearch", "Buscar por nome, autor ou gênero", storeSearch, sizeof(storeSearch));
            ImGui::SameLine();
            ImGui::SetNextItemWidth(170);
            if (ImGui::BeginCombo("##storeplat", storePlatform.empty() ? "Todos os consoles" : storePlatformName(storePlatform))) {
                if (ImGui::Selectable("Todos os consoles", storePlatform.empty())) storePlatform.clear();
                for (const auto& p : storePlatforms)
                    if (ImGui::Selectable(storePlatformName(p), storePlatform == p)) storePlatform = p;
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            ImGui::SetNextItemWidth(150);
            if (ImGui::BeginCombo("##storegenre", storeGenre < 0 ? "Todos os gêneros" : kGenres[storeGenre])) {
                if (ImGui::Selectable("Todos os gêneros", storeGenre < 0)) storeGenre = -1;
                for (int i = 0; i < (int)IM_ARRAYSIZE(kGenres); i++)
                    if (ImGui::Selectable(kGenres[i], storeGenre == i)) storeGenre = i;
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            const char* langs[] = {"Todos os idiomas", "Português", "Inglês", "Espanhol", "Outros"};
            ImGui::SetNextItemWidth(140);
            ImGui::Combo("##storelang", &storeLang, langs, 5);
            const char* eras[] = {"Todas as épocas", "Anos 80", "Anos 90", "Anos 2000", "Anos 2010", "2020 em diante"};
            int eraIdx = storeEra == 0 ? 0 : (storeEra - 1970) / 10;
            ImGui::SetNextItemWidth(150);
            if (ImGui::Combo("##storeera", &eraIdx, eras, 6)) storeEra = eraIdx == 0 ? 0 : 1970 + eraIdx * 10;
            ImGui::SameLine();
            const char* plays[] = {"Jogadores: tanto faz", "1 jogador", "2 ou mais"};
            ImGui::SetNextItemWidth(160);
            ImGui::Combo("##storeplayers", &storePlayers, plays, 3);
            ImGui::SameLine();
            const char* kinds[] = {"Jogos", "Demos", "Tudo"};
            ImGui::SetNextItemWidth(90);
            ImGui::Combo("##storekind", &storeKind, kinds, 3);
            ImGui::SameLine();
            const char* sorts[] = {"A-Z", "Z-A", "Mais novos", "Mais antigos"};
            ImGui::SetNextItemWidth(120);
            ImGui::Combo("##storesort", &storeSort, sorts, 4);
            ImGui::SameLine();
            ImGui::Checkbox("Só baixados", &storeOnlyHave);
            ImGui::SameLine();
            if (ImGui::SmallButton("Limpar filtros")) {
                storeSearch[0] = 0; storePlatform.clear(); storeGenre = -1; storeLang = 0; storeEra = 0; storePlayers = 0;
                storeKind = 0; storeSort = 0; storeOnlyHave = false; storeLetter = 0;
            }

            int state = g_storeState.load();
            if (state == 1) ImGui::TextDisabled("Baixando %s…", storeWanted.c_str());
            if (state == 3) { ImGui::TextColored(ImVec4(0.92f, 0.4f, 0.35f, 1), "%s", g_storeError.c_str()); }
            if (state == 2) {
                g_storeState = 0;
                scanFolders();
                storeViewKey = "?";
                std::string sysId = storePlatformForPath(g_storeDone);
                Game g{g_storeDone, titleFromStem(fileStem(g_storeDone)), sysId};
                if (const StoreGame* sg = storeGameForPath(g_storeDone)) g.title = sg->title;
                launchGame(g, app.window);
            }

            // Recalcula a lista só quando algum filtro muda (o catálogo tem milhares de jogos).
            std::string q = lowerStr(storeSearch);
            char keyBuf[512];
            snprintf(keyBuf, sizeof(keyBuf), "%s|%s|%d|%d|%d|%d|%d|%d|%d|%d|%c", q.c_str(), storePlatform.c_str(), storeGenre, storeLang, storeEra,
                     storePlayers, storeKind, storeSort, (int)storeOnlyHave, (int)g_games.size(), storeLetter ? storeLetter : '-');
            static bool lettersAvail[27];
            if (storeViewKey != keyBuf) {
                storeViewKey = keyBuf;
                storeView.clear();
                std::set<std::string> have;
                if (storeOnlyHave)
                    for (const auto& g : g_games) if (const StoreGame* sg = storeGameForPath(g.path)) have.insert(sg->slug);
                memset(lettersAvail, 0, sizeof(lettersAvail));
                for (size_t k = 0; k < g_store.size(); k++) {
                    const StoreGame& sg = g_store[k];
                    if (!storePlatform.empty() && sg.platform != storePlatform) continue;
                    if (storeKind != 2 && (sg.type == "demo") != (storeKind == 1)) continue;
                    if (storeGenre >= 0 && !hasGenre(sg, kGenres[storeGenre])) continue;
                    if (storeLang == 1 && sg.lang != "pt") continue;
                    if (storeLang == 2 && sg.lang != "en") continue;
                    if (storeLang == 3 && sg.lang != "es") continue;
                    if (storeLang == 4 && (sg.lang.empty() || sg.lang == "pt" || sg.lang == "en" || sg.lang == "es")) continue;
                    int y = atoi(sg.year.c_str());
                    if (storeEra && !(y >= storeEra && (storeEra == 2020 || y < storeEra + 10))) continue;
                    if (storePlayers == 1 && sg.players > 1) continue;
                    if (storePlayers == 2 && sg.players < 2) continue;
                    if (storeOnlyHave && !have.count(sg.slug)) continue;
                    if (!q.empty()) {
                        bool hit = lowerStr(sg.title).find(q) != std::string::npos || lowerStr(sg.developer).find(q) != std::string::npos;
                        for (const auto& gn : sg.genres) hit = hit || lowerStr(gn).find(q) != std::string::npos;
                        if (!hit) continue;
                    }
                    lettersAvail[letterIndex(sg.letter)] = true;
                    if (storeLetter && sg.letter != storeLetter) continue;
                    storeView.push_back(k);
                }
                auto title = [](const StoreGame& g) { return lowerStr(g.title); };
                std::stable_sort(storeView.begin(), storeView.end(), [&](size_t a, size_t b) {
                    const StoreGame &x = g_store[a], &y2 = g_store[b];
                    switch (storeSort) {
                        case 1: return title(x) > title(y2);
                        case 2: return atoi(x.year.c_str()) > atoi(y2.year.c_str());
                        case 3: { int ya = atoi(x.year.c_str()), yb = atoi(y2.year.c_str()); return (ya ? ya : 9999) < (yb ? yb : 9999); }
                        default: return title(x) < title(y2);
                    }
                });
            }
            if (letterBar(storeLetter, lettersAvail)) storeViewKey = "?";
            ImGui::SameLine();
            ImGui::TextDisabled("  %d de %d títulos", (int)storeView.size(), (int)g_store.size());

            if (g_store.empty()) {
                ImGui::Dummy(ImVec2(0, 40));
                ImGui::TextDisabled("O catálogo não está disponível agora. Confira a internet e abra a Loja de novo.");
            } else if (ImGui::BeginTable("##store", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp, ImVec2(0, ImGui::GetContentRegionAvail().y))) {
                ImGui::TableSetupScrollFreeze(0, 1);
                ImGui::TableSetupColumn("Jogo", ImGuiTableColumnFlags_WidthStretch, 3.0f);
                ImGui::TableSetupColumn("Console", ImGuiTableColumnFlags_WidthStretch, 1.2f);
                ImGui::TableSetupColumn("Gênero", ImGuiTableColumnFlags_WidthStretch, 1.4f);
                ImGui::TableSetupColumn("Autor", ImGuiTableColumnFlags_WidthStretch, 2.0f);
                ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, 130);
                ImGui::TableHeadersRow();
                ImGuiListClipper clipper;
                clipper.Begin((int)storeView.size());
                while (clipper.Step()) {
                    for (int row = clipper.DisplayStart; row < clipper.DisplayEnd; row++) {
                        size_t k = storeView[row];
                        const StoreGame& sg = g_store[k];
                        ImGui::PushID((int)k);
                        ImGui::TableNextRow();
                        ImGui::TableNextColumn();
                        ImGui::TextUnformatted(sg.title.c_str());
                        if (ImGui::IsItemHovered()) {
                            ImGui::BeginTooltip();
                            ImGui::PushTextWrapPos(460);
                            if (!sg.desc.empty()) ImGui::TextUnformatted(sg.desc.c_str());
                            if (!sg.year.empty()) ImGui::TextDisabled("Ano: %s", sg.year.c_str());
                            ImGui::TextDisabled("Licença: %s", sg.license.empty() ? "definida pelo autor" : sg.license.c_str());
                            ImGui::TextDisabled("Fonte: %s", sg.source.empty() ? "Homebrew Hub" : sg.source.c_str());
                            ImGui::PopTextWrapPos();
                            ImGui::EndTooltip();
                        }
                        ImGui::TableNextColumn();
                        ImGui::TextUnformatted(storePlatformName(sg.platform));
                        ImGui::TableNextColumn();
                        ImGui::TextDisabled("%s", sg.genres.empty() ? "" : sg.genres[0].c_str());
                        ImGui::TableNextColumn();
                        ImGui::TextDisabled("%s", sg.developer.c_str());
                        ImGui::TableNextColumn();
                        std::error_code ec2;
                        bool have = fs::exists(u8path(storeLocalPath(sg)), ec2);
                        if (ImGui::Button(have ? "Jogar" : "Baixar e jogar", ImVec2(-1, 0)) && g_storeState.load() != 1) {
                            if (have) {
                                Game g{storeLocalPath(sg), sg.title, sg.platform};
                                launchGame(g, app.window);
                            } else {
                                storeWanted = sg.title;
                                downloadStoreGame(sg);
                            }
                        }
                        ImGui::PopID();
                    }
                }
                ImGui::EndTable();
            }
        } else {
            if (ImGui::Button("< Voltar")) { screen = Screen::Library; capturing = -1; }
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("Ajustes");
            if (g_fontTitle) ImGui::PopFont();
            if (ImGui::BeginTabBar("##tabs")) {
                if (ImGui::BeginTabItem("Controles")) {
                    ImGui::TextDisabled("Teclado (jogador 1). Clique em uma tecla e aperte a nova. Esc cancela.");
                    ImGui::TextDisabled("Joysticks USB/Bluetooth são configurados automaticamente (até 4 jogadores).");
                    if (ImGui::BeginTable("##keys", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
                        static const int order[] = {RP_UP, RP_DOWN, RP_LEFT, RP_RIGHT, RP_A, RP_B, RP_X, RP_Y, RP_L, RP_R, RP_L2, RP_R2, RP_L3, RP_R3, RP_START, RP_SELECT};
                        for (int id : order) {
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn();
                            ImGui::TextUnformatted(retroPadName(id));
                            ImGui::TableNextColumn();
                            ImGui::PushID(id);
                            const char* label = capturing == id ? "Aperte uma tecla…" : SDL_GetScancodeName((SDL_Scancode)g_config.keys[id]);
                            if (ImGui::Button(label && *label ? label : "—", ImVec2(220, 0))) capturing = id;
                            ImGui::PopID();
                        }
                        ImGui::EndTable();
                    }
                    if (ImGui::Button("Restaurar teclas padrão")) { defaultKeys(g_config); saveConfig(); }
                    ImGui::TextDisabled("Durante o jogo: Esc menu · F2 salvar estado · F4 carregar · F11 tela cheia · Tab acelerar");
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Vídeo e áudio")) {
                    bool changed = false;
                    changed |= ImGui::Checkbox("Abrir os jogos em tela cheia", &g_config.fullscreen);
                    changed |= ImGui::Checkbox("Escala inteira (pixels nítidos)", &g_config.integerScale);
                    changed |= ImGui::Checkbox("Filtro suave", &g_config.smooth);
                    ImGui::SetNextItemWidth(320);
                    changed |= ImGui::SliderFloat("Volume", &g_config.volume, 0.0f, 1.0f, "%.2f");
                    if (changed) saveConfig();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Pastas")) {
                    for (size_t i = 0; i < g_config.folders.size(); i++) {
                        ImGui::PushID((int)i);
                        ImGui::TextUnformatted(g_config.folders[i].c_str());
                        ImGui::SameLine();
                        if (ImGui::SmallButton("Remover")) {
                            g_config.folders.erase(g_config.folders.begin() + i);
                            saveConfig();
                            scanFolders();
                            ImGui::PopID();
                            break;
                        }
                        ImGui::PopID();
                    }
                    if (ImGui::Button("Procurar jogos de novo")) scanFolders();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Este computador")) {
                    ImGui::TextWrapped("Processador: %s (%d núcleos lógicos%s)", g_hw.cpu.c_str(), g_hw.threads, g_hw.avx2 ? ", AVX2" : "");
                    if (g_hw.vramMB > 0) ImGui::TextWrapped("Placa de vídeo: %s (%d MB)", g_hw.gpu.c_str(), g_hw.vramMB);
                    else ImGui::TextWrapped("Placa de vídeo: %s", g_hw.gpu.c_str());
                    if (g_hw.ramMB > 0) ImGui::Text("Memória: %.1f GB", g_hw.ramMB / 1024.0);
                    ImGui::Spacing();
                    ImGui::TextDisabled("O que esperar de cada sistema. Depois que você joga, o aviso de cada jogo usa a velocidade medida.");
                    if (ImGui::BeginTable("##perf", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
                        for (const auto& sysInfo : allSystems()) {
                            perf::Verdict v = perf::rate(g_hw, sysInfo.id, "");
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn();
                            ImGui::TextUnformatted(sysInfo.name);
                            ImGui::TableNextColumn();
                            ImVec4 col = v.level == perf::Level::Smooth ? ImVec4(0.55f, 0.85f, 0.6f, 1) : v.level == perf::Level::MayStutter ? ImVec4(0.9f, 0.7f, 0.3f, 1) : ImVec4(0.92f, 0.4f, 0.35f, 1);
                            ImGui::TextColored(col, "%s", v.label.c_str());
                            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", v.reason.c_str());
                        }
                        ImGui::EndTable();
                    }
                    ImGui::EndTabItem();
                }
#ifdef _WIN32
                if (ImGui::BeginTabItem("Nuvem")) {
                    ImGui::TextWrapped("Saves na nuvem: jogue no celular e continue no computador (e o contrário). "
                                       "O Cartucho usa a mesma pasta do Google Drive do app do celular e só enxerga os arquivos que ele mesmo criou.");
                    ImGui::Dummy(ImVec2(0, 8));
                    if (!gdrive::configured()) {
                        ImGui::TextDisabled("Esta versão foi compilada sem o acesso ao Google Drive.");
                    } else if (g_drive && g_drive->signedIn()) {
                        ImGui::Text("Conta: %s", g_drive->email().empty() ? "Google" : g_drive->email().c_str());
                        std::string st = gdrive::status();
                        if (!st.empty()) ImGui::TextDisabled("%s", st.c_str());
                        ImGui::BeginDisabled(gdrive::state().busy.load());
                        if (ImGui::Button("Sincronizar agora")) startDriveSync();
                        ImGui::EndDisabled();
                        ImGui::SameLine();
                        if (ImGui::Button("Desconectar")) { g_drive->signOut(); gdrive::setStatus(""); }
                        ImGui::Dummy(ImVec2(0, 6));
                        ImGui::TextDisabled("Sincroniza ao abrir o Cartucho, antes de cada jogo e ao fechar o jogo. Se os dois aparelhos");
                        ImGui::TextDisabled("tiverem um save diferente, vale o mais novo; o outro fica guardado em backup-saves.");
                    } else {
                        std::string st = gdrive::status();
                        ImGui::BeginDisabled(gdrive::state().busy.load());
                        if (ImGui::Button("Entrar com Google")) {
                            gdrive::state().busy = true;
                            gdrive::setStatus("Termine o login na página que abriu no navegador…");
                            std::thread([] {
                                std::string err;
                                bool ok = g_drive->signIn(err);
                                gdrive::state().busy = false;
                                if (ok) startDriveSync();
                                else gdrive::setStatus(err);
                            }).detach();
                        }
                        ImGui::EndDisabled();
                        if (!st.empty()) ImGui::TextDisabled("%s", st.c_str());
                        ImGui::TextDisabled("Use a mesma conta Google do celular (Ajustes > Nuvem no app).");
                    }
                    ImGui::EndTabItem();
                }
#endif
                if (ImGui::BeginTabItem("BIOS e sobre")) {
                    ImGui::TextWrapped("Arquivos de BIOS (quando um sistema precisar) vão em:");
                    ImGui::TextUnformatted((g_prefPath + "system").c_str());
                    if (ImGui::Button("Abrir essa pasta")) {
                        std::error_code ec;
                        fs::create_directories(u8path(g_prefPath + "system"), ec);
#ifdef _WIN32
                        ShellExecuteW(nullptr, L"open", widen(g_prefPath + "system").c_str(), nullptr, nullptr, SW_SHOWNORMAL);
#endif
                    }
                    ImGui::Spacing();
                    ImGui::TextWrapped("O Cartucho não inclui jogos nem BIOS. Use apenas arquivos que você possui. Funciona offline.");
                    ImGui::TextDisabled("Emuladores libretro (licenças em LICENSES.md) · github.com/andrefeeelipe/cartucho");
                    ImGui::EndTabItem();
                }
                ImGui::EndTabBar();
            }
        }
        ImGui::End();
        endFrame(app, true);
    }
    saveConfig();
    destroyWindow(app);
    return 0;
}

int main(int argc, char** argv) {
    SDL_SetHint(SDL_HINT_WINDOWS_INTRESOURCE_ICON, "1");  // ícone do Cartucho na janela e na barra de tarefas
    SDL_SetHint(SDL_HINT_WINDOWS_INTRESOURCE_ICON_SMALL, "1");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER | SDL_INIT_TIMER) != 0) return 1;
    char* pref = SDL_GetPrefPath("Cartucho", "Cartucho");
    g_prefPath = pref ? pref : "./";
    SDL_free(pref);
    char* base = SDL_GetBasePath();
    g_basePath = base ? base : "./";
    SDL_free(base);
    for (auto& ch : g_prefPath) if (ch == '\\') ch = '/';
    for (auto& ch : g_basePath) if (ch == '\\') ch = '/';
    loadConfig();
    installBundledSystemFiles();

    std::string gamePath, systemId;
    int autoFrames = 0;  // --autoteste <jogo> <sistema>: roda 300 quadros e sai (usado pelo GitHub Actions)
#ifdef _WIN32
    // Argumentos em UTF-16 para aceitar nomes com acento.
    int wargc = 0;
    LPWSTR* wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);
    for (int i = 1; i + 2 < wargc + 0 + 1 && i < wargc; i++) {
        if ((std::wstring(wargv[i]) == L"--play" || std::wstring(wargv[i]) == L"--autoteste") && i + 2 < wargc) {
            if (std::wstring(wargv[i]) == L"--autoteste") autoFrames = 300;
            gamePath = narrow(wargv[i + 1]);
            systemId = narrow(wargv[i + 2]);
        }
    }
    LocalFree(wargv);
    (void)argc;
    (void)argv;
#else
    for (int i = 1; i + 2 < argc; i++)
        if (std::string(argv[i]) == "--play") { gamePath = argv[i + 1]; systemId = argv[i + 2]; }
#endif

    int rc = gamePath.empty() ? runLibrary() : playGame(gamePath, systemId, autoFrames);
    SDL_Quit();
    return rc;
}
