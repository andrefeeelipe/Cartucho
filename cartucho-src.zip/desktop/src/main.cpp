// Cartucho para Windows — biblioteca, ajustes e o modo de jogo (--play).
// Cada jogo roda em um processo próprio: ao sair, o emulador é descarregado por completo.

#include <SDL.h>
#include <glad/gl.h>

#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_sdl2.h"
#include "miniz.h"

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "host.h"
#include "systems.h"

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <shobjidl.h>
#pragma comment(lib, "ole32.lib")
#endif

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Caminhos e texto

static std::string g_prefPath;  // %APPDATA%/Cartucho/Cartucho/
static std::string g_basePath;  // pasta do executável

static fs::path u8path(const std::string& s) { return fs::u8path(s); }
static std::string pathToUtf8(const fs::path& p) {
    auto u = p.u8string();
    return std::string(u.begin(), u.end());
}

#ifdef _WIN32
static std::wstring widen(const std::string& s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}
static std::string narrow(const std::wstring& w) {
    if (w.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}
#endif

/** Os emuladores abrem arquivos com fopen (página de código ANSI): caminhos com acento viram nome curto 8.3. */
static std::string pathForCore(const std::string& utf8) {
#ifdef _WIN32
    bool ascii = std::all_of(utf8.begin(), utf8.end(), [](unsigned char c) { return c < 0x80; });
    if (ascii) return utf8;
    std::wstring w = widen(utf8);
    DWORD n = GetShortPathNameW(w.c_str(), nullptr, 0);
    if (n == 0) return utf8;
    std::wstring shortPath(n, 0);
    GetShortPathNameW(w.c_str(), &shortPath[0], n);
    shortPath.resize(wcslen(shortPath.c_str()));
    return narrow(shortPath);
#else
    return utf8;
#endif
}

// ---------------------------------------------------------------------------
// Configuração (config.ini simples: chave=valor)

struct Config {
    std::vector<std::string> folders;
    int keys[RP_COUNT];
    bool fullscreen = false;
    bool integerScale = false;
    bool smooth = false;
    float volume = 1.0f;
};

static Config g_config;

static void defaultKeys(Config& c) {
    c.keys[RP_B] = SDL_SCANCODE_Z;
    c.keys[RP_A] = SDL_SCANCODE_X;
    c.keys[RP_Y] = SDL_SCANCODE_A;
    c.keys[RP_X] = SDL_SCANCODE_S;
    c.keys[RP_L] = SDL_SCANCODE_Q;
    c.keys[RP_R] = SDL_SCANCODE_W;
    c.keys[RP_L2] = SDL_SCANCODE_E;
    c.keys[RP_R2] = SDL_SCANCODE_R;
    c.keys[RP_L3] = SDL_SCANCODE_D;
    c.keys[RP_R3] = SDL_SCANCODE_F;
    c.keys[RP_START] = SDL_SCANCODE_RETURN;
    c.keys[RP_SELECT] = SDL_SCANCODE_BACKSPACE;
    c.keys[RP_UP] = SDL_SCANCODE_UP;
    c.keys[RP_DOWN] = SDL_SCANCODE_DOWN;
    c.keys[RP_LEFT] = SDL_SCANCODE_LEFT;
    c.keys[RP_RIGHT] = SDL_SCANCODE_RIGHT;
}

static std::string configPath() { return g_prefPath + "config.ini"; }

static void loadConfig() {
    defaultKeys(g_config);
    std::ifstream in(u8path(configPath()));
    std::string line;
    while (std::getline(in, line)) {
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        if (k == "folder") g_config.folders.push_back(v);
        else if (k == "fullscreen") g_config.fullscreen = v == "1";
        else if (k == "integer") g_config.integerScale = v == "1";
        else if (k == "smooth") g_config.smooth = v == "1";
        else if (k == "volume") g_config.volume = (float)atof(v.c_str());
        else if (k.rfind("key", 0) == 0) {
            int id = atoi(k.c_str() + 3);
            if (id >= 0 && id < RP_COUNT) g_config.keys[id] = atoi(v.c_str());
        }
    }
}

static void saveConfig() {
    std::ofstream out(u8path(configPath()), std::ios::trunc);
    for (const auto& f : g_config.folders) out << "folder=" << f << "\n";
    out << "fullscreen=" << (g_config.fullscreen ? 1 : 0) << "\n";
    out << "integer=" << (g_config.integerScale ? 1 : 0) << "\n";
    out << "smooth=" << (g_config.smooth ? 1 : 0) << "\n";
    out << "volume=" << g_config.volume << "\n";
    for (int i = 0; i < RP_COUNT; i++) out << "key" << i << "=" << g_config.keys[i] << "\n";
}

// ---------------------------------------------------------------------------
// Biblioteca

struct Game {
    std::string path;
    std::string title;
    std::string system;
};

static std::vector<Game> g_games;
static std::atomic<bool> g_scanning{false};

static std::string titleFromStem(std::string stem) {
    std::string out;
    int depth = 0;
    for (char ch : stem) {
        if (ch == '(' || ch == '[') depth++;
        else if (ch == ')' || ch == ']') { if (depth > 0) depth--; }
        else if (depth == 0) out.push_back(ch == '_' ? ' ' : ch);
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    while (!out.empty() && out.front() == ' ') out.erase(0, 1);
    return out.empty() ? stem : out;
}

/** Sistema de um .zip pelo que tem dentro; sem ROM de console, é arcade. */
static std::string detectZip(const std::string& path) {
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_file(&zip, pathForCore(path).c_str(), 0)) return "";
    std::string found;
    mz_uint n = mz_zip_reader_get_num_files(&zip);
    for (mz_uint i = 0; i < n && found.empty(); i++) {
        char name[512];
        mz_zip_reader_get_filename(&zip, i, name, sizeof(name));
        std::string ext = lower(fs::path(name).extension().string());
        if (!ext.empty()) ext.erase(0, 1);
        auto c = candidatesFor(ext);
        c.erase(std::remove_if(c.begin(), c.end(), [](const SystemInfo* s) { return std::string(s->id) == "arcade"; }), c.end());
        if (c.size() == 1) found = c[0]->id;
    }
    mz_zip_reader_end(&zip);
    return found.empty() ? "arcade" : found;
}

static void scanFolders() {
    std::vector<Game> found;
    for (const auto& folder : g_config.folders) {
        std::error_code ec;
        fs::recursive_directory_iterator it(u8path(folder), fs::directory_options::skip_permission_denied, ec), end;
        for (; it != end; it.increment(ec)) {
            if (ec) break;
            if (!it->is_regular_file(ec)) continue;
            fs::path p = it->path();
            std::string ext = lower(p.extension().string());
            if (ext.size() < 2) continue;
            ext.erase(0, 1);
            std::string sys;
            if (ext == "zip") {
                sys = detectZip(pathToUtf8(p));
            } else {
                auto c = candidatesFor(ext);
                if (c.empty()) continue;
                // Trilhas .bin ao lado de um .cue não viram jogos.
                if (ext == "bin" || ext == "img") {
                    fs::path cue = p;
                    cue.replace_extension(".cue");
                    if (fs::exists(cue, ec)) continue;
                }
                if (c.size() == 1) {
                    sys = c[0]->id;
                } else {
                    const SystemInfo* hint = nullptr;
                    for (fs::path d = p.parent_path(); !d.empty() && d != d.parent_path() && !hint; d = d.parent_path())
                        hint = hintFromFolder(pathToUtf8(d.filename()));
                    bool ok = hint && std::find(c.begin(), c.end(), hint) != c.end();
                    sys = ok ? hint->id : c[0]->id;
                }
            }
            if (sys.empty()) continue;
            found.push_back({pathToUtf8(p), titleFromStem(pathToUtf8(p.stem())), sys});
        }
    }
    std::sort(found.begin(), found.end(), [](const Game& a, const Game& b) { return lower(a.title) < lower(b.title); });
    g_games = std::move(found);
}

#ifdef _WIN32
static std::string pickFolder() {
    std::string result;
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    IFileOpenDialog* dlg = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_ALL, IID_IFileOpenDialog, (void**)&dlg))) {
        DWORD opts = 0;
        dlg->GetOptions(&opts);
        dlg->SetOptions(opts | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
        dlg->SetTitle(L"Escolha a pasta com seus jogos");
        if (SUCCEEDED(dlg->Show(nullptr))) {
            IShellItem* item = nullptr;
            if (SUCCEEDED(dlg->GetResult(&item))) {
                PWSTR p = nullptr;
                if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &p))) {
                    result = narrow(p);
                    CoTaskMemFree(p);
                }
                item->Release();
            }
        }
        dlg->Release();
    }
    CoUninitialize();
    return result;
}
#else
static std::string pickFolder() { return ""; }
#endif

// ---------------------------------------------------------------------------
// Estilo (minimalista, escuro)

static ImFont* g_fontBody = nullptr;
static ImFont* g_fontTitle = nullptr;
static ImFont* g_fontSmall = nullptr;

static void setupStyle() {
    ImGuiIO& io = ImGui::GetIO();
    std::string regular = g_basePath + "assets/Geist-Regular.ttf";
    std::string semibold = g_basePath + "assets/Geist-SemiBold.ttf";
    if (fs::exists(u8path(regular))) {
        g_fontBody = io.Fonts->AddFontFromFileTTF(regular.c_str(), 18.0f, nullptr, io.Fonts->GetGlyphRangesDefault());
        g_fontSmall = io.Fonts->AddFontFromFileTTF(regular.c_str(), 14.0f);
        g_fontTitle = io.Fonts->AddFontFromFileTTF(semibold.c_str(), 36.0f);
    }
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 0;
    s.ChildRounding = 12;
    s.FrameRounding = 8;
    s.PopupRounding = 12;
    s.GrabRounding = 8;
    s.TabRounding = 8;
    s.FramePadding = ImVec2(14, 10);
    s.ItemSpacing = ImVec2(12, 12);
    s.WindowPadding = ImVec2(32, 28);
    s.FrameBorderSize = 1;
    s.ChildBorderSize = 1;
    ImVec4* c = s.Colors;
    auto rgb = [](int r, int g, int b, float a = 1.0f) { return ImVec4(r / 255.f, g / 255.f, b / 255.f, a); };
    c[ImGuiCol_WindowBg] = rgb(17, 17, 17);
    c[ImGuiCol_ChildBg] = rgb(26, 26, 26);
    c[ImGuiCol_PopupBg] = rgb(26, 26, 26, 0.98f);
    c[ImGuiCol_Border] = rgb(255, 255, 255, 0.08f);
    c[ImGuiCol_Text] = rgb(242, 242, 240);
    c[ImGuiCol_TextDisabled] = rgb(138, 138, 134);
    c[ImGuiCol_FrameBg] = rgb(34, 34, 34);
    c[ImGuiCol_FrameBgHovered] = rgb(44, 44, 44);
    c[ImGuiCol_FrameBgActive] = rgb(52, 52, 52);
    c[ImGuiCol_Button] = rgb(34, 34, 34);
    c[ImGuiCol_ButtonHovered] = rgb(48, 48, 48);
    c[ImGuiCol_ButtonActive] = rgb(60, 60, 60);
    c[ImGuiCol_Header] = rgb(40, 40, 40);
    c[ImGuiCol_HeaderHovered] = rgb(48, 48, 48);
    c[ImGuiCol_HeaderActive] = rgb(60, 60, 60);
    c[ImGuiCol_CheckMark] = rgb(157, 184, 255);
    c[ImGuiCol_SliderGrab] = rgb(242, 242, 240);
    c[ImGuiCol_SliderGrabActive] = rgb(255, 255, 255);
    c[ImGuiCol_NavCursor] = rgb(157, 184, 255);
    c[ImGuiCol_Tab] = rgb(26, 26, 26);
    c[ImGuiCol_TabHovered] = rgb(48, 48, 48);
    c[ImGuiCol_TabSelected] = rgb(242, 242, 240, 0.12f);
    c[ImGuiCol_ScrollbarBg] = rgb(17, 17, 17);
}

static bool primaryButton(const char* label, ImVec2 size = ImVec2(0, 0)) {
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.95f, 0.95f, 0.94f, 1));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1, 1, 1, 1));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.85f, 0.85f, 0.84f, 1));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.07f, 0.07f, 0.07f, 1));
    bool r = ImGui::Button(label, size);
    ImGui::PopStyleColor(4);
    return r;
}

// ---------------------------------------------------------------------------
// Janela e laço comum

struct App {
    SDL_Window* window = nullptr;
    SDL_GLContext gl = nullptr;
};

static bool createWindow(App& app, const char* title, bool fullscreen) {
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
    Uint32 flags = SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI;
    if (fullscreen) flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;
    app.window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 760, flags);
    if (!app.window) return false;
    app.gl = SDL_GL_CreateContext(app.window);
    if (!app.gl) return false;
    SDL_GL_MakeCurrent(app.window, app.gl);
    SDL_GL_SetSwapInterval(1);
    if (!gladLoadGL((GLADloadfunc)SDL_GL_GetProcAddress)) return false;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard | ImGuiConfigFlags_NavEnableGamepad;
    io.IniFilename = nullptr;
    setupStyle();
    ImGui_ImplSDL2_InitForOpenGL(app.window, app.gl);
    ImGui_ImplOpenGL3_Init("#version 330");
    return true;
}

static void destroyWindow(App& app) {
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    if (app.gl) SDL_GL_DeleteContext(app.gl);
    if (app.window) SDL_DestroyWindow(app.window);
}

static void beginFrame() {
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplSDL2_NewFrame();
    ImGui::NewFrame();
}

static void endFrame(App& app, bool clear) {
    ImGui::Render();
    int w, h;
    SDL_GL_GetDrawableSize(app.window, &w, &h);
    glViewport(0, 0, w, h);
    if (clear) {
        glClearColor(0.067f, 0.067f, 0.067f, 1);
        glClear(GL_COLOR_BUFFER_BIT);
    }
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    SDL_GL_SwapWindow(app.window);
}

// ---------------------------------------------------------------------------
// Modo de jogo

static std::string fileStem(const std::string& path) { return pathToUtf8(u8path(path).stem()); }

/** Extrai um .zip de console para uma pasta temporária e devolve o arquivo principal. */
static std::string extractZip(const std::string& zipPath, const SystemInfo& sys) {
    fs::path dir = u8path(g_prefPath + "run");
    std::error_code ec;
    fs::remove_all(dir, ec);
    fs::create_directories(dir, ec);
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_file(&zip, pathForCore(zipPath).c_str(), 0)) return "";
    std::string main;
    mz_uint n = mz_zip_reader_get_num_files(&zip);
    for (mz_uint i = 0; i < n; i++) {
        if (mz_zip_reader_is_file_a_directory(&zip, i)) continue;
        char name[512];
        mz_zip_reader_get_filename(&zip, i, name, sizeof(name));
        std::string base = pathToUtf8(u8path(name).filename());
        fs::path out = dir / u8path(base);
        mz_zip_reader_extract_to_file(&zip, i, pathForCore(pathToUtf8(dir)).append("/").append(base).c_str(), 0);
        std::string ext = lower(u8path(base).extension().string());
        if (!ext.empty()) ext.erase(0, 1);
        bool isSheet = ext == "cue" || ext == "gdi" || ext == "m3u";
        bool matches = std::find(sys.extensions.begin(), sys.extensions.end(), ext) != sys.extensions.end();
        if (isSheet || (main.empty() && matches)) main = pathToUtf8(out);
    }
    mz_zip_reader_end(&zip);
    return main;
}

static int playGame(const std::string& gamePath, const std::string& systemId) {
    const SystemInfo* sys = systemById(systemId);
    if (!sys) return 1;
    App app;
    std::string title = "Cartucho — " + titleFromStem(fileStem(gamePath));
    if (!createWindow(app, title.c_str(), g_config.fullscreen)) return 1;

    std::string corePath = g_basePath + "cores/" + sys->core + "_libretro.dll";
    std::string systemDir = g_prefPath + "system";
    std::string saveDir = g_prefPath + "saves/" + sys->id;
    std::string stateDir = g_prefPath + "states/" + sys->id;
    std::error_code ec;
    fs::create_directories(u8path(systemDir), ec);
    fs::create_directories(u8path(saveDir), ec);
    fs::create_directories(u8path(stateDir), ec);

    std::string actual = gamePath;
    std::string ext = lower(u8path(gamePath).extension().string());
    if (ext == ".zip" && std::string(sys->id) != "arcade") actual = extractZip(gamePath, *sys);

    std::string error;
    bool ok = !actual.empty() &&
              host::start(pathForCore(corePath), pathForCore(actual), pathForCore(systemDir), pathForCore(saveDir), error);
    if (actual.empty()) error = "Não encontrei o jogo dentro do arquivo compactado.";

    std::string stem = fileStem(gamePath);
    std::string sram = saveDir + "/" + stem + ".srm";
    if (ok) host::loadSram(pathForCore(sram));
    host::setVolume(g_config.volume);

    SDL_GameController* pads[4] = {nullptr, nullptr, nullptr, nullptr};
    SDL_JoystickID padIds[4] = {-1, -1, -1, -1};
    auto openPads = [&]() {
        for (int i = 0; i < SDL_NumJoysticks(); i++) {
            if (!SDL_IsGameController(i)) continue;
            SDL_JoystickID id = SDL_JoystickGetDeviceInstanceID(i);
            bool already = false;
            for (int p = 0; p < 4; p++) if (padIds[p] == id) already = true;
            if (already) continue;
            for (int p = 0; p < 4; p++) {
                if (!pads[p]) { pads[p] = SDL_GameControllerOpen(i); padIds[p] = id; break; }
            }
        }
    };
    openPads();

    bool menu = !ok;
    bool running = true;
    bool fastForward = false;
    std::string toast;
    Uint64 toastUntil = 0;
    Uint64 last = SDL_GetPerformanceCounter();
    Uint64 lastSram = SDL_GetTicks64();
    double acc = 0;
    int slot = 1;

    auto showToast = [&](const std::string& t) { toast = t; toastUntil = SDL_GetTicks64() + 2000; };
    auto statePath = [&](int s) { return stateDir + "/" + stem + ".slot" + std::to_string(s); };

    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            ImGui_ImplSDL2_ProcessEvent(&e);
            if (e.type == SDL_QUIT) running = false;
            if (e.type == SDL_CONTROLLERDEVICEADDED) openPads();
            if (e.type == SDL_CONTROLLERDEVICEREMOVED) {
                for (int p = 0; p < 4; p++) {
                    if (padIds[p] == e.cdevice.which) {
                        SDL_GameControllerClose(pads[p]);
                        pads[p] = nullptr;
                        padIds[p] = -1;
                        if (p == 0 && ok) menu = true;
                    }
                }
            }
            if (e.type == SDL_KEYDOWN && !e.key.repeat) {
                SDL_Scancode sc = e.key.keysym.scancode;
                if (sc == SDL_SCANCODE_ESCAPE && ok) menu = !menu;
                if (sc == SDL_SCANCODE_F11) {
                    g_config.fullscreen = !g_config.fullscreen;
                    SDL_SetWindowFullscreen(app.window, g_config.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
                }
                if (sc == SDL_SCANCODE_F2 && ok) showToast(host::saveState(pathForCore(statePath(slot))) ? "Estado salvo" : "Não foi possível salvar");
                if (sc == SDL_SCANCODE_F4 && ok) showToast(host::loadState(pathForCore(statePath(slot))) ? "Estado carregado" : "Nenhum estado neste espaço");
                if (sc == SDL_SCANCODE_TAB) fastForward = true;
            }
            if (e.type == SDL_KEYUP && e.key.keysym.scancode == SDL_SCANCODE_TAB) fastForward = false;
            if (e.type == SDL_CONTROLLERBUTTONDOWN && e.cbutton.button == SDL_CONTROLLER_BUTTON_GUIDE && ok) menu = !menu;
        }
        host::setPaused(menu);

        // Entrada: teclado no jogador 1; controles nos jogadores 1-4.
        uint32_t masks[4] = {0, 0, 0, 0};
        if (!menu) {
            const Uint8* ks = SDL_GetKeyboardState(nullptr);
            for (int i = 0; i < RP_COUNT; i++)
                if (g_config.keys[i] > 0 && ks[g_config.keys[i]]) masks[0] |= 1u << i;
            for (int p = 0; p < 4; p++) {
                SDL_GameController* c = pads[p];
                if (!c) continue;
                struct M { SDL_GameControllerButton b; int id; };
                static const M map[] = {
                    {SDL_CONTROLLER_BUTTON_A, RP_B}, {SDL_CONTROLLER_BUTTON_B, RP_A}, {SDL_CONTROLLER_BUTTON_X, RP_Y},
                    {SDL_CONTROLLER_BUTTON_Y, RP_X}, {SDL_CONTROLLER_BUTTON_LEFTSHOULDER, RP_L},
                    {SDL_CONTROLLER_BUTTON_RIGHTSHOULDER, RP_R}, {SDL_CONTROLLER_BUTTON_LEFTSTICK, RP_L3},
                    {SDL_CONTROLLER_BUTTON_RIGHTSTICK, RP_R3}, {SDL_CONTROLLER_BUTTON_START, RP_START},
                    {SDL_CONTROLLER_BUTTON_BACK, RP_SELECT}, {SDL_CONTROLLER_BUTTON_DPAD_UP, RP_UP},
                    {SDL_CONTROLLER_BUTTON_DPAD_DOWN, RP_DOWN}, {SDL_CONTROLLER_BUTTON_DPAD_LEFT, RP_LEFT},
                    {SDL_CONTROLLER_BUTTON_DPAD_RIGHT, RP_RIGHT},
                };
                for (const auto& m : map)
                    if (SDL_GameControllerGetButton(c, m.b)) masks[p] |= 1u << m.id;
                if (SDL_GameControllerGetAxis(c, SDL_CONTROLLER_AXIS_TRIGGERLEFT) > 12000) masks[p] |= 1u << RP_L2;
                if (SDL_GameControllerGetAxis(c, SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > 12000) masks[p] |= 1u << RP_R2;
                auto axis = [&](SDL_GameControllerAxis a) {
                    int v = SDL_GameControllerGetAxis(c, a);
                    return std::abs(v) < 5000 ? 0 : v;
                };
                host::setAnalog(p, 0, axis(SDL_CONTROLLER_AXIS_LEFTX), axis(SDL_CONTROLLER_AXIS_LEFTY));
                host::setAnalog(p, 1, axis(SDL_CONTROLLER_AXIS_RIGHTX), axis(SDL_CONTROLLER_AXIS_RIGHTY));
            }
        }
        for (int p = 0; p < 4; p++) host::setButtons(p, masks[p]);

        // Ritmo pelo relógio (fps do core), independente da taxa do monitor.
        Uint64 now = SDL_GetPerformanceCounter();
        double dt = (double)(now - last) / SDL_GetPerformanceFrequency();
        last = now;
        if (dt > 0.25) dt = 0.25;
        if (ok && !menu) {
            acc += dt;
            double frame = 1.0 / host::fps();
            int runs = 0;
            while (acc >= frame && runs < 3) {
                host::runFrame(fastForward);
                acc -= frame;
                runs++;
            }
            if (runs == 3) acc = 0;
            if (SDL_GetTicks64() - lastSram > 30000) {
                lastSram = SDL_GetTicks64();
                host::saveSram(pathForCore(sram));
            }
        }

        int w, h;
        SDL_GL_GetDrawableSize(app.window, &w, &h);
        host::draw(w, h, g_config.integerScale, g_config.smooth);

        beginFrame();
        ImGuiIO& io = ImGui::GetIO();
        if (!toast.empty() && SDL_GetTicks64() < toastUntil) {
            ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, 24), ImGuiCond_Always, ImVec2(0.5f, 0));
            ImGui::Begin("##toast", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoNav);
            ImGui::TextUnformatted(toast.c_str());
            ImGui::End();
        }
        if (menu) {
            ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), io.DisplaySize, IM_COL32(0, 0, 0, 150));
            ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
            ImGui::SetNextWindowSize(ImVec2(420, 0));
            ImGui::Begin("##menu", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize);
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted(ok ? titleFromStem(stem).c_str() : "Não deu para abrir o jogo");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::TextDisabled("%s", sys->name);
            ImGui::Spacing();
            ImVec2 full(-1, 0);
            if (!ok) {
                ImGui::TextWrapped("%s", error.c_str());
                ImGui::Spacing();
                if (primaryButton("Voltar à biblioteca", full)) running = false;
            } else {
                if (primaryButton("Continuar", full)) menu = false;
                ImGui::SetNextItemWidth(-1);
                ImGui::SliderInt("##slot", &slot, 1, 3, "Espaço %d");
                if (ImGui::Button("Salvar estado  (F2)", full)) { showToast(host::saveState(pathForCore(statePath(slot))) ? "Estado salvo" : "Não foi possível salvar"); menu = false; }
                if (ImGui::Button("Carregar estado  (F4)", full)) { showToast(host::loadState(pathForCore(statePath(slot))) ? "Estado carregado" : "Nenhum estado neste espaço"); menu = false; }
                if (ImGui::Button("Reiniciar jogo", full)) { host::reset(); menu = false; }
                if (ImGui::Button(g_config.fullscreen ? "Sair da tela cheia  (F11)" : "Tela cheia  (F11)", full)) {
                    g_config.fullscreen = !g_config.fullscreen;
                    SDL_SetWindowFullscreen(app.window, g_config.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
                }
                if (ImGui::SliderFloat("Volume", &g_config.volume, 0.0f, 1.0f, "%.0f%%")) host::setVolume(g_config.volume);
                ImGui::Checkbox("Escala inteira", &g_config.integerScale);
                ImGui::Checkbox("Filtro suave", &g_config.smooth);
                ImGui::Spacing();
                if (ImGui::Button("Sair do jogo", full)) running = false;
                ImGui::TextDisabled("Esc abre e fecha este menu · Tab acelera");
            }
            ImGui::End();
        }
        endFrame(app, false);
    }

    if (ok) host::saveSram(pathForCore(sram));
    saveConfig();
    host::shutdown();
    for (auto* p : pads) if (p) SDL_GameControllerClose(p);
    destroyWindow(app);
    return 0;
}

// ---------------------------------------------------------------------------
// Biblioteca (janela principal)

static void launchGame(const Game& g, SDL_Window* window) {
    saveConfig();
#ifdef _WIN32
    wchar_t exe[MAX_PATH];
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring cmd = L"\"" + std::wstring(exe) + L"\" --play \"" + widen(g.path) + L"\" " + widen(g.system);
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
        SDL_HideWindow(window);
        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        SDL_ShowWindow(window);
        SDL_RaiseWindow(window);
    }
    loadConfig();
#else
    (void)window;
    playGame(g.path, g.system);
#endif
}

static int runLibrary() {
    App app;
    if (!createWindow(app, "Cartucho", false)) return 1;
    scanFolders();

    enum class Screen { Library, Settings };
    Screen screen = Screen::Library;
    char search[128] = "";
    int filter = -1;
    int capturing = -1;
    bool running = true;

    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (capturing >= 0 && e.type == SDL_KEYDOWN) {
                if (e.key.keysym.scancode != SDL_SCANCODE_ESCAPE) g_config.keys[capturing] = e.key.keysym.scancode;
                capturing = -1;
                saveConfig();
                continue;
            }
            ImGui_ImplSDL2_ProcessEvent(&e);
            if (e.type == SDL_QUIT) running = false;
        }

        beginFrame();
        ImGuiIO& io = ImGui::GetIO();
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(io.DisplaySize);
        ImGui::Begin("##main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBringToFrontOnFocus);

        if (screen == Screen::Library) {
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("Biblioteca");
            if (g_fontTitle) ImGui::PopFont();
            ImGui::SameLine(ImGui::GetWindowWidth() - 360);
            if (primaryButton("Adicionar pasta")) {
                std::string folder = pickFolder();
                if (!folder.empty()) {
                    g_config.folders.push_back(folder);
                    saveConfig();
                    scanFolders();
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("Ajustes")) screen = Screen::Settings;

            ImGui::SetNextItemWidth(320);
            ImGui::InputTextWithHint("##search", "Buscar na biblioteca", search, sizeof(search));
            ImGui::SameLine();
            ImGui::SetNextItemWidth(220);
            const char* current = filter < 0 ? "Todos os sistemas" : allSystems()[filter].name;
            if (ImGui::BeginCombo("##filter", current)) {
                if (ImGui::Selectable("Todos os sistemas", filter < 0)) filter = -1;
                for (int i = 0; i < (int)allSystems().size(); i++)
                    if (ImGui::Selectable(allSystems()[i].name, filter == i)) filter = i;
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            ImGui::TextDisabled("%d jogos", (int)g_games.size());

            if (g_games.empty()) {
                ImGui::Dummy(ImVec2(0, 60));
                ImGui::TextUnformatted("Nenhum jogo ainda");
                ImGui::TextDisabled("Clique em \"Adicionar pasta\" e escolha a pasta onde estão os seus jogos.");
                ImGui::TextDisabled("Teclado: setas, Z/X/A/S, Q/W, Enter (Start), Backspace (Select). Joysticks são reconhecidos sozinhos.");
            } else {
                ImGui::BeginChild("##grid", ImVec2(0, 0), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground);
                float tileW = 190, tileH = 120;
                int cols = std::max(1, (int)((ImGui::GetContentRegionAvail().x + 12) / (tileW + 12)));
                int col = 0;
                std::string q = lower(search);
                for (size_t i = 0; i < g_games.size(); i++) {
                    const Game& g = g_games[i];
                    if (filter >= 0 && g.system != allSystems()[filter].id) continue;
                    if (!q.empty() && lower(g.title).find(q) == std::string::npos) continue;
                    if (col > 0) ImGui::SameLine();
                    ImGui::PushID((int)i);
                    ImVec2 pos = ImGui::GetCursorScreenPos();
                    bool clicked = ImGui::InvisibleButton("##tile", ImVec2(tileW, tileH));
                    bool hovered = ImGui::IsItemHovered() || ImGui::IsItemFocused();
                    ImDrawList* dl = ImGui::GetWindowDrawList();
                    dl->AddRectFilled(pos, ImVec2(pos.x + tileW, pos.y + tileH), hovered ? IM_COL32(40, 40, 40, 255) : IM_COL32(26, 26, 26, 255), 12);
                    dl->AddRect(pos, ImVec2(pos.x + tileW, pos.y + tileH), hovered ? IM_COL32(157, 184, 255, 255) : IM_COL32(255, 255, 255, 20), 12, 0, hovered ? 2.0f : 1.0f);
                    const SystemInfo* sys = systemById(g.system);
                    if (g_fontSmall) ImGui::PushFont(g_fontSmall);
                    dl->AddText(ImVec2(pos.x + 14, pos.y + 12), IM_COL32(138, 138, 134, 255), sys ? sys->shortName : "?");
                    if (g_fontSmall) ImGui::PopFont();
                    ImGui::PushClipRect(pos, ImVec2(pos.x + tileW - 12, pos.y + tileH), true);
                    dl->AddText(nullptr, 0, ImVec2(pos.x + 14, pos.y + tileH - 52), IM_COL32(242, 242, 240, 255), g.title.c_str(), nullptr, tileW - 28);
                    ImGui::PopClipRect();
                    if (clicked) launchGame(g, app.window);
                    ImGui::PopID();
                    col = (col + 1) % cols;
                }
                ImGui::EndChild();
            }
        } else {
            if (ImGui::Button("< Voltar")) { screen = Screen::Library; capturing = -1; }
            if (g_fontTitle) ImGui::PushFont(g_fontTitle);
            ImGui::TextUnformatted("Ajustes");
            if (g_fontTitle) ImGui::PopFont();
            if (ImGui::BeginTabBar("##tabs")) {
                if (ImGui::BeginTabItem("Controles")) {
                    ImGui::TextDisabled("Teclado (jogador 1). Clique em uma tecla e aperte a nova. Esc cancela.");
                    ImGui::TextDisabled("Joysticks USB/Bluetooth são configurados automaticamente (até 4 jogadores).");
                    if (ImGui::BeginTable("##keys", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
                        static const int order[] = {RP_UP, RP_DOWN, RP_LEFT, RP_RIGHT, RP_A, RP_B, RP_X, RP_Y, RP_L, RP_R, RP_L2, RP_R2, RP_L3, RP_R3, RP_START, RP_SELECT};
                        for (int id : order) {
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn();
                            ImGui::TextUnformatted(retroPadName(id));
                            ImGui::TableNextColumn();
                            ImGui::PushID(id);
                            const char* label = capturing == id ? "Aperte uma tecla…" : SDL_GetScancodeName((SDL_Scancode)g_config.keys[id]);
                            if (ImGui::Button(label && *label ? label : "—", ImVec2(220, 0))) capturing = id;
                            ImGui::PopID();
                        }
                        ImGui::EndTable();
                    }
                    if (ImGui::Button("Restaurar teclas padrão")) { defaultKeys(g_config); saveConfig(); }
                    ImGui::TextDisabled("Durante o jogo: Esc menu · F2 salvar estado · F4 carregar · F11 tela cheia · Tab acelerar");
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Vídeo e áudio")) {
                    bool changed = false;
                    changed |= ImGui::Checkbox("Abrir os jogos em tela cheia", &g_config.fullscreen);
                    changed |= ImGui::Checkbox("Escala inteira (pixels nítidos)", &g_config.integerScale);
                    changed |= ImGui::Checkbox("Filtro suave", &g_config.smooth);
                    ImGui::SetNextItemWidth(320);
                    changed |= ImGui::SliderFloat("Volume", &g_config.volume, 0.0f, 1.0f, "%.2f");
                    if (changed) saveConfig();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("Pastas")) {
                    for (size_t i = 0; i < g_config.folders.size(); i++) {
                        ImGui::PushID((int)i);
                        ImGui::TextUnformatted(g_config.folders[i].c_str());
                        ImGui::SameLine();
                        if (ImGui::SmallButton("Remover")) {
                            g_config.folders.erase(g_config.folders.begin() + i);
                            saveConfig();
                            scanFolders();
                            ImGui::PopID();
                            break;
                        }
                        ImGui::PopID();
                    }
                    if (ImGui::Button("Procurar jogos de novo")) scanFolders();
                    ImGui::EndTabItem();
                }
                if (ImGui::BeginTabItem("BIOS e sobre")) {
                    ImGui::TextWrapped("Arquivos de BIOS (quando um sistema precisar) vão em:");
                    ImGui::TextUnformatted((g_prefPath + "system").c_str());
                    if (ImGui::Button("Abrir essa pasta")) {
                        std::error_code ec;
                        fs::create_directories(u8path(g_prefPath + "system"), ec);
#ifdef _WIN32
                        ShellExecuteW(nullptr, L"open", widen(g_prefPath + "system").c_str(), nullptr, nullptr, SW_SHOWNORMAL);
#endif
                    }
                    ImGui::Spacing();
                    ImGui::TextWrapped("O Cartucho não inclui jogos nem BIOS. Use apenas arquivos que você possui. Funciona offline.");
                    ImGui::TextDisabled("Emuladores libretro (licenças em LICENSES.md) · github.com/andrefeeelipe/cartucho");
                    ImGui::EndTabItem();
                }
                ImGui::EndTabBar();
            }
        }
        ImGui::End();
        endFrame(app, true);
    }
    saveConfig();
    destroyWindow(app);
    return 0;
}

int main(int argc, char** argv) {
    SDL_SetHint(SDL_HINT_WINDOWS_INTRESOURCE_ICON, "1");  // ícone do Cartucho na janela e na barra de tarefas
    SDL_SetHint(SDL_HINT_WINDOWS_INTRESOURCE_ICON_SMALL, "1");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER | SDL_INIT_TIMER) != 0) return 1;
    char* pref = SDL_GetPrefPath("Cartucho", "Cartucho");
    g_prefPath = pref ? pref : "./";
    SDL_free(pref);
    char* base = SDL_GetBasePath();
    g_basePath = base ? base : "./";
    SDL_free(base);
    for (auto& ch : g_prefPath) if (ch == '\\') ch = '/';
    for (auto& ch : g_basePath) if (ch == '\\') ch = '/';
    loadConfig();

    std::string gamePath, systemId;
#ifdef _WIN32
    // Argumentos em UTF-16 para aceitar nomes com acento.
    int wargc = 0;
    LPWSTR* wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);
    for (int i = 1; i + 2 < wargc + 0 + 1 && i < wargc; i++) {
        if (std::wstring(wargv[i]) == L"--play" && i + 2 < wargc) {
            gamePath = narrow(wargv[i + 1]);
            systemId = narrow(wargv[i + 2]);
        }
    }
    LocalFree(wargv);
    (void)argc;
    (void)argv;
#else
    for (int i = 1; i + 2 < argc; i++)
        if (std::string(argv[i]) == "--play") { gamePath = argv[i + 1]; systemId = argv[i + 2]; }
#endif

    int rc = gamePath.empty() ? runLibrary() : playGame(gamePath, systemId);
    SDL_Quit();
    return rc;
}
