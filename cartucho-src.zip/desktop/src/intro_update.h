// Cartucho no computador e no iPhone: a abertura animada e o aviso de versão nova.
// Incluído pelo main.cpp (usa as cores, as fontes e as pastas de lá).
#pragma once

#include <atomic>
#include <mutex>
#include <thread>

#ifndef CARTUCHO_VERSION
#define CARTUCHO_VERSION "dev"
#endif

// ---------------------------------------------------------------------------
// Abertura: a fita desce, encaixa, os quatro sinais acendem em azul, viram as cores da marca
// e o nome aparece (o mesmo vídeo do celular, desenhado aqui para ficar nítido em qualquer tela).

namespace intro {

static const float kHold = 6.2f;    // o som termina aos 5,6 s
static const ImU32 kBg = IM_COL32(0x4A, 0x3C, 0xB7, 255);
static SDL_AudioDeviceID g_audio = 0;

static float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
static float easeOut(float t) { t = clamp01(t); return 1 - (1 - t) * (1 - t) * (1 - t); }
static ImU32 mix(ImU32 a, ImU32 b, float t) {
    t = clamp01(t);
    auto ch = [&](int s) { return (int)(((a >> s) & 0xFF) * (1 - t) + ((b >> s) & 0xFF) * t); };
    return IM_COL32(ch(IM_COL32_R_SHIFT), ch(IM_COL32_G_SHIFT), ch(IM_COL32_B_SHIFT), 255);
}

// O som da abertura (assets/intro.wav), num dispositivo de áudio só dele.
static void startSound(const std::string& path) {
    SDL_AudioSpec spec{};
    Uint8* buf = nullptr;
    Uint32 len = 0;
    if (!SDL_LoadWAV(path.c_str(), &spec, &buf, &len)) return;
    g_audio = SDL_OpenAudioDevice(nullptr, 0, &spec, nullptr, 0);
    if (g_audio) {
        SDL_QueueAudio(g_audio, buf, len);
        SDL_PauseAudioDevice(g_audio, 0);
    }
    SDL_FreeWAV(buf);
}

static void stopSound() {
    if (g_audio) SDL_CloseAudioDevice(g_audio);
    g_audio = 0;
}

// O símbolo do Cartucho na grade de 100 do Claude Design. o = canto de cima do quadrado de 73 de altura.
static void drawSymbol(ImDrawList* dl, ImVec2 o, float k, const ImU32 dots[4]) {
    auto P = [&](float x, float y) { return ImVec2(o.x + (x - 15) * k, o.y + (y - 14) * k); };
    dl->PathLineTo(P(24, 16));
    dl->PathLineTo(P(76, 16));
    dl->PathBezierQuadraticCurveTo(P(83, 16), P(83, 23), 8);
    dl->PathLineTo(P(83, 33));
    dl->PathLineTo(P(77, 40));
    dl->PathLineTo(P(77, 82));
    dl->PathBezierQuadraticCurveTo(P(77, 85), P(74, 85), 6);
    dl->PathLineTo(P(26, 85));
    dl->PathBezierQuadraticCurveTo(P(23, 85), P(23, 82), 6);
    dl->PathLineTo(P(23, 40));
    dl->PathLineTo(P(17, 33));
    dl->PathLineTo(P(17, 23));
    dl->PathBezierQuadraticCurveTo(P(17, 16), P(24, 16), 8);
    dl->PathFillConcave(IM_COL32(0xD2, 0xD2, 0xDB, 255));
    const float grooves[4] = {24, 29, 69.6f, 74.6f};
    for (float gx : grooves) dl->AddRectFilled(P(gx, 20), P(gx + 2.4f, 28), IM_COL32(0xA9, 0xA9, 0xB8, 255), 1.2f * k);
    dl->AddRectFilled(P(30, 38), P(70, 76), IM_COL32(0x2B, 0x2B, 0x33, 255), 4 * k);
    const float cx[4] = {50, 57.2f, 50, 42.8f}, cy[4] = {49.8f, 57, 64.2f, 57};  // cima, direita, baixo, esquerda
    for (int i = 0; i < 4; i++) dl->AddCircleFilled(P(cx[i], cy[i]), 3.6f * k, dots[i], 24);
}

// Um quadro da abertura no tempo t (segundos).
static void draw(ImDrawList* dl, ImVec2 size, float t, ImFont* nameFont, const char* version, ImFont* small) {
    dl->AddRectFilled(ImVec2(0, 0), size, kBg);
    bool landscape = size.x > size.y;
    float symH = std::min(size.y * (landscape ? 0.33f : 0.285f), size.x * 0.46f);
    float k = symH / 73.0f;
    float nameSize = symH * (landscape ? 0.30f : 0.27f);
    float gap = symH * 0.17f;
    float blockH = symH + gap + nameSize;
    float top = (size.y - blockH) * 0.5f;
    float left = (size.x - 70 * k) * 0.5f;

    // Entrada: cai de cima (0,3 s a 1,0 s), passa um pouco e assenta.
    float y = top;
    if (t < 1.0f) {
        float u = clamp01((t - 0.3f) / 0.7f);
        y = -symH * 1.1f + (top + symH * 1.1f) * (u * u);
    } else if (t < 1.5f) {
        float u = (t - 1.0f) / 0.5f;
        y = top + symH * 0.015f * sinf(u * 3.14159f) ;
    }

    // Sinais: apagados → um a um em azul → as cores da marca, no sentido do relógio.
    const ImU32 off = IM_COL32(0x3B, 0x35, 0x7E, 255), lit = IM_COL32(0x28, 0x64, 0xCD, 255);
    const ImU32 finals[4] = {IM_COL32(0x29, 0x5C, 0xB8, 255), IM_COL32(0xD1, 0x25, 0x2D, 255), IM_COL32(0xEE, 0xBD, 0x1C, 255), IM_COL32(0x22, 0x94, 0x59, 255)};
    const float on[4] = {2.2f, 2.5f, 2.8f, 3.1f};
    const float color[4] = {3.5f, 3.8f, 4.4f, 4.1f};  // azul, vermelho, amarelo, verde
    ImU32 dots[4];
    for (int i = 0; i < 4; i++) {
        ImU32 c = t < 1.0f ? IM_COL32(0x2B, 0x2B, 0x33, 255) : off;
        c = mix(c, lit, (t - on[i]) / 0.1f);
        dots[i] = mix(c, finals[i], (t - color[i]) / 0.12f);
    }
    if (t >= 0.3f) drawSymbol(dl, ImVec2(left, y), k, dots);

    // Nome: aparece aos 5 s (300 ms, sobe 8 px).
    float a = easeOut((t - 5.0f) / 0.3f);
    if (a > 0 && nameFont) {
        const char* name = "Cartucho";
        ImVec2 ts = nameFont->CalcTextSizeA(nameSize, FLT_MAX, 0, name);
        float ny = top + symH + gap + (1 - a) * 8;
        dl->AddText(nameFont, nameSize, ImVec2((size.x - ts.x) * 0.5f, ny), IM_COL32(0xB3, 0xAE, 0xE6, (int)(255 * a)), name);
    }

    // Embaixo: a versão e as três faixas.
    if (small && version) {
        ImVec2 vs = small->CalcTextSizeA(small->FontSize, FLT_MAX, 0, version);
        dl->AddText(small, small->FontSize, ImVec2((size.x - vs.x) * 0.5f, size.y - 48 - vs.y), IM_COL32(0xC9, 0xC6, 0xEE, 255), version);
    }
    float w3 = size.x / 3;
    dl->AddRectFilled(ImVec2(0, size.y - 10), ImVec2(w3, size.y), IM_COL32(0x4F, 0x43, 0xAE, 255));
    dl->AddRectFilled(ImVec2(w3, size.y - 10), ImVec2(2 * w3, size.y), IM_COL32(0x8F, 0x86, 0xD6, 255));
    dl->AddRectFilled(ImVec2(2 * w3, size.y - 10), ImVec2(size.x, size.y), IM_COL32(0xC9, 0xC6, 0xEE, 255));
}

}  // namespace intro

// ---------------------------------------------------------------------------
// Versão nova: confere o GitHub ao abrir, mostra o aviso e, se a pessoa quiser, baixa e instala sozinho.

namespace update {

struct Release {
    std::string version;
    std::vector<std::string> notes;
    std::vector<std::pair<std::string, std::string>> files;  // nome, link
};

enum State { Idle, Checking, Available, Downloading, Ready, Failed };
static std::atomic<int> g_state{Idle};
static std::mutex g_mu;
static Release g_release;
static std::string g_error;
static std::string g_partPath;     // arquivo sendo baixado (para mostrar quanto já veio)
static long long g_expected = 0;
static const char* kSite = "https://cartucho-emulador.netlify.app/#baixar";

static bool newer(const std::string& a, const std::string& b) {
    auto parts = [](const std::string& v) {
        std::vector<int> out;
        int n = 0;
        bool any = false;
        for (char c : v) {
            if (c >= '0' && c <= '9') { n = n * 10 + (c - '0'); any = true; }
            else if (c == '.' || c == '-') { out.push_back(any ? n : 0); n = 0; any = false; }
        }
        out.push_back(any ? n : 0);
        return out;
    };
    std::string x = a, y = b;
    if (!x.empty() && x[0] == 'v') x.erase(0, 1);
    if (!y.empty() && y[0] == 'v') y.erase(0, 1);
    auto p = parts(x), q = parts(y);
    for (size_t i = 0; i < std::max(p.size(), q.size()); i++) {
        int u = i < p.size() ? p[i] : 0, w = i < q.size() ? q[i] : 0;
        if (u != w) return u > w;
    }
    return false;
}

// Texto de um campo "chave": "valor" do JSON do GitHub, com os escapes resolvidos.
static std::string jsonString(const std::string& js, size_t from, const char* key, size_t* end = nullptr) {
    std::string k = std::string("\"") + key + "\"";
    size_t p = js.find(k, from);
    if (p == std::string::npos) return "";
    p = js.find(':', p + k.size());
    if (p == std::string::npos) return "";
    p = js.find('"', p);
    if (p == std::string::npos) return "";
    std::string out;
    for (size_t i = p + 1; i < js.size(); i++) {
        char c = js[i];
        if (c == '"') { if (end) *end = i; return out; }
        if (c != '\\' || i + 1 >= js.size()) { out += c; continue; }
        char e = js[++i];
        if (e == 'n') out += '\n';
        else if (e == 't') out += '\t';
        else if (e == 'r') {}
        else if (e == 'u' && i + 4 < js.size()) {
            unsigned cp = (unsigned)strtoul(js.substr(i + 1, 4).c_str(), nullptr, 16);
            i += 4;
            if (cp < 0x80) out += (char)cp;
            else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F)); }
            else { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
        } else out += e;
    }
    return out;
}

static std::vector<std::string> notesOf(const std::string& body) {
    std::vector<std::string> out;
    size_t p = body.find("Novidades");
    if (p == std::string::npos) return out;
    std::istringstream in(body.substr(p));
    std::string line;
    std::getline(in, line);
    bool started = false;
    while (std::getline(in, line) && out.size() < 4) {
        size_t s = line.find_first_not_of(" \t");
        if (s == std::string::npos) { if (started) break; continue; }
        if (line.compare(s, 2, "- ") != 0 && line.compare(s, 2, "* ") != 0) break;
        started = true;
        std::string t = line.substr(s + 2);
        for (size_t q; (q = t.find("**")) != std::string::npos;) t.erase(q, 2);
        out.push_back(t);
    }
    return out;
}

// Confere em segundo plano (uma vez por abertura).
static void check(const std::string& prefPath) {
    if (std::string(CARTUCHO_VERSION) == "dev") return;  // compilado à mão: sem versão para comparar
    g_state = Checking;
    std::thread([prefPath]() {
        std::string file = prefPath + "versao-nova.json";
        if (!plat::download("https://api.github.com/repos/andrefeeelipe/Cartucho/releases/latest", file)) { g_state = Idle; return; }
        std::string js = readText(file);
        Release r;
        r.version = jsonString(js, 0, "tag_name");
        if (!r.version.empty() && r.version[0] == 'v') r.version.erase(0, 1);
        r.notes = notesOf(jsonString(js, 0, "body"));
        size_t at = 0, end = 0;
        for (;;) {
            std::string url = jsonString(js, at, "browser_download_url", &end);
            if (url.empty()) break;
            r.files.push_back({url.substr(url.rfind('/') + 1), url});
            at = end + 1;
        }
        std::lock_guard<std::mutex> lock(g_mu);
        g_release = r;
        g_state = newer(r.version, CARTUCHO_VERSION) ? Available : Idle;
    }).detach();
}

// O arquivo desta plataforma na versão nova ("" se ainda não foi publicado).
static std::string fileFor(const Release& r, std::string* name = nullptr) {
#if defined(_WIN32)
    const char* suffix = "-windows-instalador.exe";
#elif defined(CARTUCHO_IOS)
    const char* suffix = "-iphone.ipa";
#else
    const char* suffix = "-linux-x86_64.AppImage";
#endif
    for (const auto& f : r.files)
        if (f.first.size() > strlen(suffix) && f.first.compare(f.first.size() - strlen(suffix), strlen(suffix), suffix) == 0) {
            if (name) *name = f.first;
            return f.second;
        }
    return "";
}

static const char* platformName() {
#if defined(_WIN32)
    return "Windows";
#elif defined(CARTUCHO_IOS)
    return "iPhone";
#else
    return "Linux";
#endif
}

// O Cartucho foi instalado pelo instalador (Windows) ou é um AppImage (Linux)? Só assim dá para trocar sozinho.
static bool canSelfUpdate(const std::string& basePath) {
#if defined(_WIN32)
    std::error_code ec;
    return fs::exists(u8path(basePath + "unins000.exe"), ec);
#elif defined(CARTUCHO_IOS)
    (void)basePath;
    return false;
#else
    (void)basePath;
    return getenv("APPIMAGE") != nullptr;
#endif
}

// Baixa e instala. No Windows roda o instalador em modo silencioso (ele fecha e reabre o Cartucho);
// no Linux troca o AppImage e reabre. Saves, jogos e ajustes ficam onde estão.
static void start(const std::string& prefPath) {
    Release r;
    {
        std::lock_guard<std::mutex> lock(g_mu);
        r = g_release;
    }
    std::string name;
    std::string url = fileFor(r, &name);
    if (url.empty()) {
        g_error = "O arquivo desta versão ainda está sendo preparado. Tente de novo em alguns minutos.";
        g_state = Failed;
        return;
    }
    g_state = Downloading;
#if defined(_WIN32)
    std::string target = prefPath + name;
#else
    const char* img = getenv("APPIMAGE");
    std::string target = img ? std::string(img) + ".nova" : prefPath + name;
#endif
    g_partPath = target + ".part";
    g_expected = 0;
    std::thread([url, target]() {
        if (!plat::download(url, target)) {
            g_error = "O download não terminou. Confira a internet e tente de novo.";
            g_state = Failed;
            return;
        }
        g_state = Ready;
    }).detach();
}

// Depois de baixar: abre o instalador ou troca o AppImage. Devolve true se o Cartucho deve fechar agora.
static bool apply(const std::string& prefPath) {
    Release r;
    {
        std::lock_guard<std::mutex> lock(g_mu);
        r = g_release;
    }
    std::string name;
    fileFor(r, &name);
#if defined(_WIN32)
    std::wstring exe = widen(prefPath + name);
    HINSTANCE h = ShellExecuteW(nullptr, L"open", exe.c_str(), L"/SILENT /SUPPRESSMSGBOXES /NOCANCEL /NORESTART /CLOSEAPPLICATIONS", nullptr, SW_SHOWNORMAL);
    if ((INT_PTR)h <= 32) { g_error = "O Windows não abriu o instalador."; g_state = Failed; return false; }
    return true;
#elif defined(CARTUCHO_IOS)
    (void)prefPath;
    return false;
#else
    (void)prefPath;
    const char* img = getenv("APPIMAGE");
    if (!img) return false;
    std::string fresh = std::string(img) + ".nova";
    chmod(fresh.c_str(), 0755);
    if (rename(fresh.c_str(), img) != 0) { g_error = "Não deu para trocar o arquivo do Cartucho (sem permissão na pasta)."; g_state = Failed; return false; }
    std::string path = img;
    char* argv[] = {const_cast<char*>(path.c_str()), nullptr};
    SDL_Quit();
    execv(path.c_str(), argv);
    _exit(0);
#endif
}

// Quanto já veio (para a barra), em MB.
static double downloadedMB() {
    std::error_code ec;
    auto n = fs::file_size(u8path(g_partPath), ec);
    return ec ? 0.0 : (double)n / (1024.0 * 1024.0);
}

}  // namespace update
