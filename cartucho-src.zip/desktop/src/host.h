// Cartucho para Windows — host libretro (carrega o core, vídeo OpenGL, áudio SDL, entrada).
#pragma once

#include <cstdint>
#include <string>

namespace host {

// Carrega o core e o jogo. Retorna false e preenche error em caso de falha.
bool start(const std::string& corePath, const std::string& gamePath, const std::string& systemDir,
           const std::string& saveDir, std::string& error);

// Executa um quadro de emulação (respeitando o ritmo do áudio).
void runFrame(bool fastForward);

// Desenha o último quadro na área (x, y, w, h) da janela.
void draw(int windowW, int windowH, bool integerScale, bool smooth);

double fps();
void setButtons(int port, uint32_t mask);
void setAnalog(int port, int stick, int x, int y);
void setVolume(float volume);
void setPaused(bool paused);

bool saveState(const std::string& path);
bool loadState(const std::string& path);
bool saveSram(const std::string& path);
bool loadSram(const std::string& path);
void reset();
void shutdown();

}  // namespace host
