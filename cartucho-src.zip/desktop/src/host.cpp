// Cartucho para Windows — host libretro.
#include "host.h"

#include <SDL.h>
#include <glad/gl.h>

#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#include "libretro.h"

namespace {

struct Core {
    void* handle = nullptr;
    void (*init)(void);
    void (*deinit)(void);
    void (*get_system_info)(retro_system_info*);
    void (*get_system_av_info)(retro_system_av_info*);
    void (*set_environment)(retro_environment_t);
    void (*set_video_refresh)(retro_video_refresh_t);
    void (*set_audio_sample)(retro_audio_sample_t);
    void (*set_audio_sample_batch)(retro_audio_sample_batch_t);
    void (*set_input_poll)(retro_input_poll_t);
    void (*set_input_state)(retro_input_state_t);
    void (*set_controller_port_device)(unsigned, unsigned);
    void (*reset)(void);
    void (*run)(void);
    size_t (*serialize_size)(void);
    bool (*serialize)(void*, size_t);
    bool (*unserialize)(const void*, size_t);
    bool (*load_game)(const retro_game_info*);
    void (*unload_game)(void);
    void* (*get_memory_data)(unsigned);
    size_t (*get_memory_size)(unsigned);
};

Core core;
bool gameLoaded = false;
std::string systemDir, saveDir, corePathStr, lastError;
std::vector<uint8_t> gameData;
retro_system_av_info av{};
retro_pixel_format pixelFormat = RETRO_PIXEL_FORMAT_0RGB1555;
unsigned rotation = 0;

std::map<std::string, std::string> options;
bool optionsDirty = true;

// Vídeo
GLuint program = 0, vao = 0, vbo = 0, swTexture = 0;
GLint locSwizzle = -1;
int swTexW = 0, swTexH = 0, frameW = 0, frameH = 0;
GLenum swFormat = 0;
std::vector<uint16_t> convert;

bool hwRender = false;
retro_hw_render_callback hw{};
GLuint fbo = 0, fboTex = 0, fboDepth = 0;
int fboW = 0, fboH = 0;
bool lastHw = false;

// Áudio
SDL_AudioDeviceID audioDev = 0;
float volume = 1.0f;
std::vector<int16_t> audioScratch;

// Entrada
uint32_t buttons[4] = {0, 0, 0, 0};
int16_t analog[4][2][2] = {};

void logError(const char* msg) {
    lastError = msg;
    SDL_Log("%s", msg);
}

void RETRO_CALLCONV coreLog(enum retro_log_level level, const char* fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (level >= RETRO_LOG_WARN) {
        std::string s(buf);
        while (!s.empty() && (s.back() == '\n' || s.back() == '\r')) s.pop_back();
        lastError = s;
    }
    SDL_Log("[core] %s", buf);
}

uintptr_t RETRO_CALLCONV hwFramebuffer(void) { return (uintptr_t)fbo; }
retro_proc_address_t RETRO_CALLCONV hwProc(const char* sym) { return (retro_proc_address_t)SDL_GL_GetProcAddress(sym); }

void registerOption(const char* key, const char* def) {
    if (!key) return;
    if (options.find(key) == options.end()) options[key] = def ? def : "";
}

bool RETRO_CALLCONV environment(unsigned cmd, void* data) {
    switch (cmd) {
        case RETRO_ENVIRONMENT_GET_CAN_DUPE: *(bool*)data = true; return true;
        case RETRO_ENVIRONMENT_SET_ROTATION: rotation = (*(const unsigned*)data) % 4; return true;
        case RETRO_ENVIRONMENT_GET_OVERSCAN: *(bool*)data = false; return true;
        case RETRO_ENVIRONMENT_SET_MESSAGE: return true;
        case RETRO_ENVIRONMENT_SHUTDOWN: return true;
        case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL: return true;
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
        case RETRO_ENVIRONMENT_GET_CORE_ASSETS_DIRECTORY: *(const char**)data = systemDir.c_str(); return true;
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char**)data = saveDir.c_str(); return true;
        case RETRO_ENVIRONMENT_GET_LIBRETRO_PATH: *(const char**)data = corePathStr.c_str(); return true;
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
            auto f = *(const retro_pixel_format*)data;
            if (f > RETRO_PIXEL_FORMAT_RGB565) return false;
            pixelFormat = f;
            return true;
        }
        case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
        case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
        case RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO:
        case RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS:
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY:
        case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
        case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
            return true;
        case RETRO_ENVIRONMENT_SET_HW_RENDER: {
            auto* cb = (retro_hw_render_callback*)data;
            if (cb->context_type != RETRO_HW_CONTEXT_OPENGL && cb->context_type != RETRO_HW_CONTEXT_OPENGL_CORE) return false;
            cb->get_current_framebuffer = hwFramebuffer;
            cb->get_proc_address = hwProc;
            hw = *cb;
            hwRender = true;
            return true;
        }
        case RETRO_ENVIRONMENT_GET_PREFERRED_HW_RENDER: *(unsigned*)data = RETRO_HW_CONTEXT_OPENGL; return true;
        case RETRO_ENVIRONMENT_GET_VARIABLE: {
            auto* v = (retro_variable*)data;
            auto it = options.find(v->key ? v->key : "");
            if (it == options.end()) { v->value = nullptr; return false; }
            v->value = it->second.c_str();
            return true;
        }
        case RETRO_ENVIRONMENT_SET_VARIABLES: {
            for (auto* v = (const retro_variable*)data; v && v->key; v++) {
                std::string val = v->value ? v->value : "";
                size_t semi = val.find(';');
                std::string list = semi == std::string::npos ? "" : val.substr(semi + 1);
                while (!list.empty() && list[0] == ' ') list.erase(0, 1);
                registerOption(v->key, list.substr(0, list.find('|')).c_str());
            }
            return true;
        }
        case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool*)data = optionsDirty; optionsDirty = false; return true;
        case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION: *(unsigned*)data = 2; return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS:
            for (auto* d = (const retro_core_option_definition*)data; d && d->key; d++) registerOption(d->key, d->default_value);
            return true;
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL: {
            auto* intl = (const retro_core_options_intl*)data;
            for (auto* d = intl->us; d && d->key; d++) registerOption(d->key, d->default_value);
            return true;
        }
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2: {
            auto* o = (const retro_core_options_v2*)data;
            for (auto* d = o ? o->definitions : nullptr; d && d->key; d++) registerOption(d->key, d->default_value);
            return true;
        }
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL: {
            auto* intl = (const retro_core_options_v2_intl*)data;
            for (auto* d = (intl && intl->us) ? intl->us->definitions : nullptr; d && d->key; d++) registerOption(d->key, d->default_value);
            return true;
        }
        case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: ((retro_log_callback*)data)->log = coreLog; return true;
        case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: av = *(const retro_system_av_info*)data; return true;
        case RETRO_ENVIRONMENT_SET_GEOMETRY: {
            auto* g = (const retro_game_geometry*)data;
            av.geometry.base_width = g->base_width;
            av.geometry.base_height = g->base_height;
            av.geometry.aspect_ratio = g->aspect_ratio;
            return true;
        }
        case RETRO_ENVIRONMENT_GET_USERNAME: *(const char**)data = "Cartucho"; return true;
        case RETRO_ENVIRONMENT_GET_LANGUAGE: *(unsigned*)data = RETRO_LANGUAGE_PORTUGUESE_BRAZIL; return true;
        case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS: return true;
        case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE: *(int*)data = 3; return true;
        case RETRO_ENVIRONMENT_GET_INPUT_MAX_USERS: *(unsigned*)data = 4; return true;
        default: return false;
    }
}

void uploadSoftware(const void* data, unsigned w, unsigned h, size_t pitch) {
    glBindTexture(GL_TEXTURE_2D, swTexture);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    GLenum fmt = pixelFormat == RETRO_PIXEL_FORMAT_XRGB8888 ? GL_BGRA : GL_RGB;
    GLenum type = pixelFormat == RETRO_PIXEL_FORMAT_XRGB8888 ? GL_UNSIGNED_INT_8_8_8_8_REV : GL_UNSIGNED_SHORT_5_6_5;
    GLenum internal = pixelFormat == RETRO_PIXEL_FORMAT_XRGB8888 ? GL_RGBA8 : GL_RGB8;
    if ((int)w != swTexW || (int)h != swTexH || fmt != swFormat) {
        glTexImage2D(GL_TEXTURE_2D, 0, internal, w, h, 0, fmt, type, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        swTexW = w; swTexH = h; swFormat = fmt;
    }
    if (pixelFormat == RETRO_PIXEL_FORMAT_0RGB1555) {
        convert.resize((size_t)w * h);
        for (unsigned y = 0; y < h; y++) {
            const uint16_t* row = (const uint16_t*)((const uint8_t*)data + y * pitch);
            for (unsigned x = 0; x < w; x++) {
                uint16_t p = row[x];
                uint16_t r = (p >> 10) & 0x1f, g = (p >> 5) & 0x1f, b = p & 0x1f;
                convert[(size_t)y * w + x] = (uint16_t)((r << 11) | (((g << 1) | (g >> 4)) << 5) | b);
            }
        }
        glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, fmt, type, convert.data());
    } else {
        int bpp = pixelFormat == RETRO_PIXEL_FORMAT_XRGB8888 ? 4 : 2;
        glPixelStorei(GL_UNPACK_ROW_LENGTH, (GLint)(pitch / bpp));
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, fmt, type, data);
        glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
    }
}

void RETRO_CALLCONV videoRefresh(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!w || !h) return;
    if (data == RETRO_HW_FRAME_BUFFER_VALID) { lastHw = true; frameW = w; frameH = h; return; }
    if (!data) return;
    lastHw = false; frameW = w; frameH = h;
    uploadSoftware(data, w, h, pitch);
}

void RETRO_CALLCONV audioSample(int16_t l, int16_t r) {
    int16_t f[2] = {l, r};
    if (audioDev) SDL_QueueAudio(audioDev, f, sizeof(f));
}

size_t RETRO_CALLCONV audioBatch(const int16_t* data, size_t frames) {
    if (!audioDev) return frames;
    if (volume >= 0.999f) {
        SDL_QueueAudio(audioDev, data, (Uint32)(frames * 4));
    } else {
        audioScratch.assign(data, data + frames * 2);
        for (auto& s : audioScratch) s = (int16_t)(s * volume);
        SDL_QueueAudio(audioDev, audioScratch.data(), (Uint32)(frames * 4));
    }
    return frames;
}

void RETRO_CALLCONV inputPoll(void) {}

int16_t RETRO_CALLCONV inputState(unsigned port, unsigned device, unsigned index, unsigned id) {
    if (port >= 4) return 0;
    unsigned base = device & RETRO_DEVICE_MASK;
    if (base == RETRO_DEVICE_JOYPAD) {
        if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return (int16_t)(buttons[port] & 0xffff);
        return id < 16 && (buttons[port] >> id) & 1 ? 1 : 0;
    }
    if (base == RETRO_DEVICE_ANALOG) {
        if (index == RETRO_DEVICE_INDEX_ANALOG_BUTTON) return id < 16 && (buttons[port] >> id) & 1 ? 0x7fff : 0;
        if (index < 2 && id < 2) return analog[port][index][id];
    }
    return 0;
}

const char* kVs = "#version 330 core\n"
                  "layout(location=0) in vec2 aPos; layout(location=1) in vec2 aTex; out vec2 vTex;\n"
                  "void main(){ vTex=aTex; gl_Position=vec4(aPos,0.0,1.0); }\n";
const char* kFs = "#version 330 core\n"
                  "in vec2 vTex; out vec4 color; uniform sampler2D uTex;\n"
                  "void main(){ color=vec4(texture(uTex,vTex).rgb,1.0); }\n";

GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    return s;
}

void createGl() {
    GLuint vs = compile(GL_VERTEX_SHADER, kVs), fs = compile(GL_FRAGMENT_SHADER, kFs);
    program = glCreateProgram();
    glAttachShader(program, vs);
    glAttachShader(program, fs);
    glLinkProgram(program);
    glDeleteShader(vs);
    glDeleteShader(fs);
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glGenTextures(1, &swTexture);
}

void createFbo() {
    int w = av.geometry.max_width > 0 ? (int)av.geometry.max_width : 640;
    int h = av.geometry.max_height > 0 ? (int)av.geometry.max_height : 480;
    fboW = w; fboH = h;
    glGenTextures(1, &fboTex);
    glBindTexture(GL_TEXTURE_2D, fboTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenFramebuffers(1, &fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, fboTex, 0);
    if (hw.depth) {
        glGenRenderbuffers(1, &fboDepth);
        glBindRenderbuffer(GL_RENDERBUFFER, fboDepth);
        glRenderbufferStorage(GL_RENDERBUFFER, hw.stencil ? GL_DEPTH24_STENCIL8 : GL_DEPTH_COMPONENT24, w, h);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, hw.stencil ? GL_DEPTH_STENCIL_ATTACHMENT : GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, fboDepth);
    }
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

template <typename T>
bool sym(T& out, const char* name) {
    out = (T)SDL_LoadFunction(core.handle, name);
    return out != nullptr;
}

bool readFile(const std::string& path, std::vector<uint8_t>& out) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (size < 0) { fclose(f); return false; }
    out.resize((size_t)size);
    size_t r = size ? fread(out.data(), 1, (size_t)size, f) : 0;
    fclose(f);
    return r == (size_t)size;
}

bool writeFile(const std::string& path, const void* data, size_t size) {
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return false;
    size_t w = fwrite(data, 1, size, f);
    fclose(f);
    return w == size;
}

}  // namespace

namespace host {

bool start(const std::string& corePath, const std::string& gamePath, const std::string& sysDir, const std::string& svDir,
           std::string& error) {
    systemDir = sysDir;
    saveDir = svDir;
    corePathStr = corePath;
    createGl();

    core.handle = SDL_LoadObject(corePath.c_str());
    if (!core.handle) { error = std::string("Não foi possível carregar o emulador: ") + SDL_GetError(); return false; }
    bool ok = sym(core.init, "retro_init") && sym(core.deinit, "retro_deinit") &&
              sym(core.get_system_info, "retro_get_system_info") && sym(core.get_system_av_info, "retro_get_system_av_info") &&
              sym(core.set_environment, "retro_set_environment") && sym(core.set_video_refresh, "retro_set_video_refresh") &&
              sym(core.set_audio_sample, "retro_set_audio_sample") && sym(core.set_audio_sample_batch, "retro_set_audio_sample_batch") &&
              sym(core.set_input_poll, "retro_set_input_poll") && sym(core.set_input_state, "retro_set_input_state") &&
              sym(core.set_controller_port_device, "retro_set_controller_port_device") && sym(core.reset, "retro_reset") &&
              sym(core.run, "retro_run") && sym(core.serialize_size, "retro_serialize_size") &&
              sym(core.serialize, "retro_serialize") && sym(core.unserialize, "retro_unserialize") &&
              sym(core.load_game, "retro_load_game") && sym(core.unload_game, "retro_unload_game") &&
              sym(core.get_memory_data, "retro_get_memory_data") && sym(core.get_memory_size, "retro_get_memory_size");
    if (!ok) { error = "O emulador está incompleto."; return false; }

    core.set_environment(environment);
    core.set_video_refresh(videoRefresh);
    core.set_audio_sample(audioSample);
    core.set_audio_sample_batch(audioBatch);
    core.set_input_poll(inputPoll);
    core.set_input_state(inputState);
    core.init();

    retro_system_info info{};
    core.get_system_info(&info);
    retro_game_info game{};
    game.path = gamePath.c_str();
    if (!info.need_fullpath) {
        if (!readFile(gamePath, gameData)) { error = "Não foi possível ler o arquivo do jogo."; return false; }
        game.data = gameData.data();
        game.size = gameData.size();
    }
    lastError.clear();
    if (!core.load_game(&game)) {
        error = "O emulador não conseguiu abrir este jogo." + (lastError.empty() ? std::string() : "\nDetalhe: " + lastError);
        return false;
    }
    gameLoaded = true;
    core.get_system_av_info(&av);
    for (unsigned p = 0; p < 4; p++) core.set_controller_port_device(p, RETRO_DEVICE_JOYPAD);

    SDL_AudioSpec want{}, have{};
    want.freq = av.timing.sample_rate > 0 ? (int)av.timing.sample_rate : 48000;
    want.format = AUDIO_S16SYS;
    want.channels = 2;
    want.samples = 1024;
    audioDev = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
    if (audioDev) SDL_PauseAudioDevice(audioDev, 0);

    if (hwRender) {
        createFbo();
        if (hw.context_reset) hw.context_reset();
    }
    return true;
}

double fps() { return av.timing.fps > 1 ? av.timing.fps : 60.0; }

void runFrame(bool fastForward) {
    if (!gameLoaded) return;
    // Com o áudio cheio demais, espera; vazio demais, roda um quadro extra.
    if (audioDev && !fastForward) {
        Uint32 queued = SDL_GetQueuedAudioSize(audioDev);
        Uint32 perFrame = (Uint32)(av.timing.sample_rate / fps()) * 4;
        if (queued > perFrame * 6) return;
    }
    int runs = fastForward ? 4 : 1;
    for (int i = 0; i < runs; i++) {
        if (hwRender) glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        if (fastForward && i > 0 && audioDev) {
            SDL_AudioDeviceID saved = audioDev;
            audioDev = 0;
            core.run();
            audioDev = saved;
        } else {
            core.run();
        }
    }
    if (audioDev && !fastForward) {
        Uint32 queued = SDL_GetQueuedAudioSize(audioDev);
        Uint32 perFrame = (Uint32)(av.timing.sample_rate / fps()) * 4;
        if (queued < perFrame * 2) {
            if (hwRender) glBindFramebuffer(GL_FRAMEBUFFER, fbo);
            core.run();
        }
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void draw(int winW, int winH, bool integerScale, bool smooth) {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_BLEND);
    glDisable(GL_CULL_FACE);
    glViewport(0, 0, winW, winH);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    if (frameW <= 0 || frameH <= 0) return;

    GLuint tex = lastHw ? fboTex : swTexture;
    float texW = (float)(lastHw ? fboW : swTexW), texH = (float)(lastHw ? fboH : swTexH);
    if (!tex || texW <= 0) return;
    float aspect = av.geometry.aspect_ratio > 0 ? av.geometry.aspect_ratio : (float)frameW / frameH;
    if (rotation % 2) aspect = 1.0f / aspect;
    int w, h;
    if ((float)winW / winH > aspect) { h = winH; w = (int)(h * aspect); } else { w = winW; h = (int)(w / aspect); }
    if (integerScale) {
        int base = rotation % 2 ? frameW : frameH;
        int scale = h / (base > 0 ? base : 1);
        if (scale >= 1) { h = base * scale; w = (int)(h * aspect); }
    }
    float x0 = (float)(winW - w) / winW - 1.0f, x1 = -x0;
    float y0 = (float)(winH - h) / winH - 1.0f, y1 = -y0;
    float u = frameW / texW, v = frameH / texH;
    bool flip = lastHw && hw.bottom_left_origin;
    float vt = flip ? v : 0.f, vb = flip ? 0.f : v;
    float c[4][2] = {{0, vb}, {u, vb}, {0, vt}, {u, vt}};  // bl, br, tl, tr
    for (unsigned r = 0; r < rotation; r++) {
        float t[4][2];
        memcpy(t, c, sizeof(t));
        memcpy(c[2], t[3], sizeof(c[2])); memcpy(c[3], t[1], sizeof(c[3]));
        memcpy(c[1], t[0], sizeof(c[1])); memcpy(c[0], t[2], sizeof(c[0]));
    }
    float verts[16] = {x0, y0, c[0][0], c[0][1], x1, y0, c[1][0], c[1][1], x0, y1, c[2][0], c[2][1], x1, y1, c[3][0], c[3][1]};
    glUseProgram(program);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 16, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 16, (void*)8);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex);
    GLint filter = smooth ? GL_LINEAR : GL_NEAREST;
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glBindVertexArray(0);
    glUseProgram(0);
}

void setButtons(int port, uint32_t mask) { if (port >= 0 && port < 4) buttons[port] = mask; }
void setAnalog(int port, int stick, int x, int y) {
    if (port < 0 || port >= 4 || stick < 0 || stick > 1) return;
    analog[port][stick][0] = (int16_t)x;
    analog[port][stick][1] = (int16_t)y;
}
void setVolume(float v) { volume = v < 0 ? 0 : (v > 1 ? 1 : v); }
void setPaused(bool p) {
    if (!audioDev) return;
    SDL_PauseAudioDevice(audioDev, p ? 1 : 0);
    if (p) SDL_ClearQueuedAudio(audioDev);
}

bool saveState(const std::string& path) {
    if (!gameLoaded) return false;
    size_t size = core.serialize_size();
    if (!size) return false;
    std::vector<uint8_t> buf(size);
    return core.serialize(buf.data(), size) && writeFile(path, buf.data(), size);
}

bool loadState(const std::string& path) {
    std::vector<uint8_t> buf;
    return gameLoaded && readFile(path, buf) && !buf.empty() && core.unserialize(buf.data(), buf.size());
}

bool saveSram(const std::string& path) {
    if (!gameLoaded) return false;
    void* data = core.get_memory_data(RETRO_MEMORY_SAVE_RAM);
    size_t size = core.get_memory_size(RETRO_MEMORY_SAVE_RAM);
    return data && size && writeFile(path, data, size);
}

bool loadSram(const std::string& path) {
    if (!gameLoaded) return false;
    void* data = core.get_memory_data(RETRO_MEMORY_SAVE_RAM);
    size_t size = core.get_memory_size(RETRO_MEMORY_SAVE_RAM);
    std::vector<uint8_t> buf;
    if (!data || !size || !readFile(path, buf)) return false;
    memcpy(data, buf.data(), buf.size() < size ? buf.size() : size);
    return true;
}

void reset() { if (gameLoaded) core.reset(); }

void shutdown() {
    if (audioDev) { SDL_CloseAudioDevice(audioDev); audioDev = 0; }
    if (gameLoaded) {
        if (hwRender && hw.context_destroy) hw.context_destroy();
        core.unload_game();
        core.deinit();
        gameLoaded = false;
    }
    // O processo do jogo termina em seguida; não descarregamos a DLL de propósito.
}

}  // namespace host
