// Cartucho para Windows — previsão de desempenho: mede o computador e diz, antes de cada jogo,
// se ele deve rodar liso, engasgar, travar ou não rodar. Depois de jogar, usa a velocidade real medida.
#pragma once

#include <glad/gl.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <string>
#include <thread>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <intrin.h>
#endif

namespace perf {

struct Hardware {
    std::string cpu = "?";
    int threads = 0;
    bool avx2 = false;
    bool avx512 = false;
    std::string gpu = "?";
    int vramMB = 0;     // 0 = não deu para saber
    int ramMB = 0;
    int gpuTier = 1;    // 0 integrada fraca · 1 integrada boa / dedicada antiga · 2 dedicada média · 3 dedicada forte
    int cpuTier = 1;    // 0 fraco · 1 médio · 2 bom · 3 forte
};

enum class Level { Smooth, MayStutter, Heavy, CantRun };

struct Verdict {
    Level level = Level::Smooth;
    std::string label;
    std::string reason;
    bool measured = false;
};

inline bool has(const std::string& hay, const char* word) {
    std::string h = hay, w = word;
    std::transform(h.begin(), h.end(), h.begin(), ::tolower);
    std::transform(w.begin(), w.end(), w.begin(), ::tolower);
    return h.find(w) != std::string::npos;
}

/** Número do modelo depois de um prefixo ("RTX 3060" -> 3060). */
inline int modelAfter(const std::string& s, const char* prefix) {
    std::string h = s;
    std::transform(h.begin(), h.end(), h.begin(), ::tolower);
    std::string p = prefix;
    size_t at = h.find(p);
    if (at == std::string::npos) return 0;
    at += p.size();
    while (at < h.size() && (h[at] == ' ' || h[at] == '-')) at++;
    int n = 0;
    while (at < h.size() && h[at] >= '0' && h[at] <= '9') n = n * 10 + (h[at++] - '0');
    return n;
}

inline int classifyGpu(const std::string& gpu, int vram) {
    if (int n = modelAfter(gpu, "rtx")) return n >= 3060 || (n >= 2070 && n < 3000) || n >= 4060 ? 3 : 2;
    if (int n = modelAfter(gpu, "gtx")) return n >= 1070 ? 2 : (n >= 1050 ? 1 : 0) + (n >= 1650 ? 1 : 0);
    if (int n = modelAfter(gpu, "rx")) {
        if (n >= 6600 || (n >= 7600 && n < 8000) || n >= 9000) return 3;
        if (n >= 5500 || n == 590 || n == 580 || n == 570) return 2;
        return 1;
    }
    if (has(gpu, "arc")) return has(gpu, "a3") ? 1 : 2;
    if (has(gpu, "radeon 7") || has(gpu, "radeon 8") || has(gpu, "890m") || has(gpu, "780m") || has(gpu, "680m")) return 2;
    if (has(gpu, "iris xe") || has(gpu, "vega") || has(gpu, "radeon(tm) graphics") || has(gpu, "radeon graphics")) return 1;
    if (has(gpu, "uhd") || has(gpu, "hd graphics")) return 0;
    if (vram >= 8000) return 3;
    if (vram >= 4000) return 2;
    if (vram >= 2000) return 1;
    return 1;
}

inline Hardware detect() {
    Hardware h;
    h.threads = (int)std::thread::hardware_concurrency();
#ifdef _WIN32
    int r[4];
    char brand[49] = {};
    __cpuid(r, 0x80000000);
    if ((unsigned)r[0] >= 0x80000004) {
        for (int i = 0; i < 3; i++) {
            __cpuid(r, 0x80000002 + i);
            memcpy(brand + i * 16, r, 16);
        }
        h.cpu = brand;
        while (!h.cpu.empty() && h.cpu.front() == ' ') h.cpu.erase(0, 1);
    }
    __cpuidex(r, 7, 0);
    h.avx2 = (r[1] & (1 << 5)) != 0;
    h.avx512 = (r[1] & (1 << 16)) != 0;
    MEMORYSTATUSEX ms{};
    ms.dwLength = sizeof(ms);
    if (GlobalMemoryStatusEx(&ms)) h.ramMB = (int)(ms.ullTotalPhys / (1024 * 1024));
#endif
    const char* renderer = (const char*)glGetString(GL_RENDERER);
    if (renderer) h.gpu = renderer;
    GLint kb = 0;
    while (glGetError() != GL_NO_ERROR) {}
    glGetIntegerv(0x9048, &kb);  // GL_NVX_gpu_memory_info: memória dedicada total
    if (glGetError() == GL_NO_ERROR && kb > 0) h.vramMB = kb / 1024;
    else {
        GLint ati[4] = {};
        glGetIntegerv(0x87FC, ati);  // GL_ATI_meminfo: memória livre de texturas
        if (glGetError() == GL_NO_ERROR && ati[0] > 0) h.vramMB = ati[0] / 1024;
    }
    while (glGetError() != GL_NO_ERROR) {}
    h.gpuTier = classifyGpu(h.gpu, h.vramMB);
    // Processador: núcleos lógicos + AVX2 dão uma boa ideia para emulação (Dolphin, PS2, 3DS).
    if (h.threads >= 12 && h.avx2) h.cpuTier = 3;
    else if (h.threads >= 8 && h.avx2) h.cpuTier = 2;
    else if (h.threads >= 4) h.cpuTier = 1;
    else h.cpuTier = 0;
    return h;
}

/** O que cada sistema pede: processador e placa de vídeo mínimos para rodar liso (0..3). */
struct Need { int cpu; int gpu; const char* heavyPart; };

inline Need needFor(const std::string& id) {
    static const std::map<std::string, Need> needs = {
        {"n64", {1, 1, "a placa de vídeo"}},
        {"psp", {1, 1, "a placa de vídeo"}},
        {"saturn", {2, 0, "o processador"}},
        {"dreamcast", {1, 1, "a placa de vídeo"}},
        {"3do", {1, 0, "o processador"}},
        {"jaguar", {1, 0, "o processador"}},
        {"amiga", {1, 0, "o processador"}},
        {"dos", {1, 0, "o processador"}},
        {"pcfx", {1, 0, "o processador"}},
        {"neogeocd", {1, 0, "o processador"}},
        {"nds", {1, 0, "o processador"}},
        {"ps2", {2, 2, "o processador"}},
        {"3ds", {2, 2, "o processador"}},
        {"gamecube", {2, 2, "o processador"}},
        {"wii", {2, 2, "o processador"}},
        {"wiiu", {2, 2, "o processador"}},
        {"xbox360", {3, 2, "o processador"}},
    };
    auto it = needs.find(id);
    return it == needs.end() ? Need{0, 0, ""} : it->second;
}

// ---------------------------------------------------------------- medição real

/** Velocidade medida por jogo (1.0 = velocidade total), salva em perf.ini. */
inline std::map<std::string, float>& measured() {
    static std::map<std::string, float> m;
    return m;
}

inline void loadMeasured(const std::string& file) {
    measured().clear();
    std::ifstream in(file);
    std::string line;
    while (std::getline(in, line)) {
        size_t eq = line.rfind('=');
        if (eq == std::string::npos) continue;
        measured()[line.substr(0, eq)] = (float)atof(line.c_str() + eq + 1);
    }
}

inline void saveMeasured(const std::string& file, const std::string& gamePath, float speed) {
    loadMeasured(file);
    measured()[gamePath] = speed;
    std::ofstream out(file, std::ios::trunc);
    for (const auto& kv : measured()) out << kv.first << "=" << kv.second << "\n";
}

inline Verdict rate(const Hardware& h, const std::string& systemId, const std::string& gamePath) {
    Verdict v;
    auto m = measured().find(gamePath);
    if (m != measured().end()) {
        v.measured = true;
        if (m->second >= 0.97f) { v.level = Level::Smooth; v.label = "Roda liso"; v.reason = "Medido neste computador."; }
        else if (m->second >= 0.85f) { v.level = Level::MayStutter; v.label = "Pode engasgar"; v.reason = "Medido neste computador: às vezes fica abaixo da velocidade total."; }
        else { v.level = Level::Heavy; v.label = "Vai travar bastante"; v.reason = "Medido neste computador: roda bem abaixo da velocidade total."; }
        return v;
    }
    Need n = needFor(systemId);
    int cpuGap = n.cpu - h.cpuTier;
    int gpuGap = n.gpu - h.gpuTier;
    int gap = std::max(cpuGap, gpuGap);
    std::string part = cpuGap >= gpuGap ? "o processador" : "a placa de vídeo";
    if ((systemId == "ps2" || systemId == "gamecube" || systemId == "wii" || systemId == "3ds") && h.threads > 0 && h.threads < 4) gap = 3;
    if (gap <= 0) { v.level = Level::Smooth; v.label = "Roda liso"; v.reason = "Este computador dá conta deste sistema."; }
    else if (gap == 1) { v.level = Level::MayStutter; v.label = "Pode engasgar"; v.reason = "Alguns jogos podem ficar lentos: " + part + " fica no limite para este sistema."; }
    else if (gap == 2) { v.level = Level::Heavy; v.label = "Vai travar bastante"; v.reason = "Deve rodar bem abaixo da velocidade: " + part + " é fraco para este sistema."; }
    else { v.level = Level::CantRun; v.label = "Não roda neste computador"; v.reason = "Este computador não tem o mínimo para este sistema (" + part + ")."; }
    return v;
}

}  // namespace perf
