// Cartucho — baixar arquivos no Windows (no iPhone fica em platform_apple.mm).
#include "platform.h"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <urlmon.h>

static std::wstring wideOf(const std::string& s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}
#endif

namespace plat {

bool download(const std::string& url, const std::string& target) {
#ifdef _WIN32
    std::wstring part = wideOf(target + ".part");
    if (URLDownloadToFileW(nullptr, wideOf(url).c_str(), part.c_str(), 0, nullptr) != S_OK) return false;
    _wremove(wideOf(target).c_str());
    return MoveFileW(part.c_str(), wideOf(target).c_str()) != 0;
#else
    (void)url;
    (void)target;
    return false;
#endif
}

}  // namespace plat
