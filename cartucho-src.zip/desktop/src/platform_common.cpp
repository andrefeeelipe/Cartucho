// Cartucho — baixar arquivos e abrir links no Windows e no Linux (no iPhone fica em platform_apple.mm).
#include "platform.h"

#include <vector>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <urlmon.h>
#include <shellapi.h>

static std::wstring wideOf(const std::string& s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}
#else
#include <cstdio>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>
extern char** environ;

// Roda um programa do sistema (sem shell: nada do endereço vira comando) e espera terminar.
static int runProgram(const std::vector<std::string>& args, bool wait = true) {
    std::vector<char*> argv;
    for (const auto& a : args) argv.push_back(const_cast<char*>(a.c_str()));
    argv.push_back(nullptr);
    pid_t pid = 0;
    if (posix_spawnp(&pid, argv[0], nullptr, nullptr, argv.data(), environ) != 0) return -1;
    if (!wait) return 0;
    int status = 0;
    if (waitpid(pid, &status, 0) < 0) return -1;
    return WIFEXITED(status) ? WEXITSTATUS(status) : -1;
}
#endif

namespace plat {

bool download(const std::string& url, const std::string& target) {
#ifdef _WIN32
    std::wstring part = wideOf(target + ".part");
    if (URLDownloadToFileW(nullptr, wideOf(url).c_str(), part.c_str(), 0, nullptr) != S_OK) return false;
    _wremove(wideOf(target).c_str());
    return MoveFileW(part.c_str(), wideOf(target).c_str()) != 0;
#else
    // Linux: o curl (ou o wget) que todo sistema já tem.
    std::string part = target + ".part";
    std::remove(part.c_str());
    int rc = runProgram({"curl", "-fsSL", "--retry", "2", "--connect-timeout", "20", "-A", "Cartucho-Linux/1.0", "-o", part, url});
    if (rc != 0) rc = runProgram({"wget", "-q", "-U", "Cartucho-Linux/1.0", "-O", part, url});
    if (rc != 0) { std::remove(part.c_str()); return false; }
    std::remove(target.c_str());
    return std::rename(part.c_str(), target.c_str()) == 0;
#endif
}

void openUrl(const std::string& url) {
#ifdef _WIN32
    ShellExecuteW(nullptr, L"open", wideOf(url).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
#else
    runProgram({"xdg-open", url}, false);
#endif
}

}  // namespace plat
