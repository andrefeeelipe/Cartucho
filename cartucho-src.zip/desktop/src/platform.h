// Cartucho — o que muda de um sistema para outro (baixar arquivos, pastas, compartilhar).
#pragma once

#include <string>

namespace plat {

// Baixa url para target (escreve em target.part e renomeia no fim). Bloqueante.
bool download(const std::string& url, const std::string& target);

#if defined(CARTUCHO_IOS)
// Pasta do app no iPhone (onde ficam Documents e Library).
std::string homeDir();
// Margens seguras da tela (entalhe, cantos, barra de início), em pontos.
void safeInsets(float& left, float& top, float& right, float& bottom);
// Abre a folha de compartilhar do iPhone com o arquivo (imagem do card).
void shareFile(const std::string& path);
#endif

}  // namespace plat
