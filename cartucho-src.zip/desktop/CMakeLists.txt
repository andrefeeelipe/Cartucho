cmake_minimum_required(VERSION 3.16)
project(Cartucho CXX C)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Dependências baixadas pelo CI (ou manualmente) em third_party/:
#   imgui/        (github.com/ocornut/imgui)
#   miniz/        (miniz.c + miniz.h da release)
#   libretro.h    (libretro-common)
#   glad/         (gerado: GL 3.3 compat)
set(TP ${CMAKE_CURRENT_SOURCE_DIR}/third_party)

find_package(SDL2 REQUIRED CONFIG)

set(IMGUI ${TP}/imgui)

# ---------------------------------------------------------------- iPhone (OpenGL ES 3, toque)
if(CMAKE_SYSTEM_NAME STREQUAL "iOS")
    enable_language(OBJCXX)
    add_executable(Cartucho
        src/main.cpp
        src/host.cpp
        src/vk_stub.cpp
        src/platform_apple.mm
        ${TP}/miniz/miniz.c
        ${IMGUI}/imgui.cpp
        ${IMGUI}/imgui_draw.cpp
        ${IMGUI}/imgui_tables.cpp
        ${IMGUI}/imgui_widgets.cpp
        ${IMGUI}/backends/imgui_impl_sdl2.cpp
        ${IMGUI}/backends/imgui_impl_opengl3.cpp
    )
    target_include_directories(Cartucho PRIVATE
        src ${TP} ${TP}/miniz ${IMGUI} ${IMGUI}/backends ${CMAKE_CURRENT_SOURCE_DIR}/../app/src/main/cpp)
    target_compile_definitions(Cartucho PRIVATE CARTUCHO_MOBILE CARTUCHO_GLES CARTUCHO_IOS IMGUI_IMPL_OPENGL_ES3 GLES_SILENCE_DEPRECATION)
    if(DEFINED CARTUCHO_VERSION)
        target_compile_definitions(Cartucho PRIVATE CARTUCHO_VERSION="${CARTUCHO_VERSION}")
    endif()
    set_source_files_properties(src/platform_apple.mm PROPERTIES COMPILE_FLAGS "-fobjc-arc")
    if(TARGET SDL2::SDL2main)
        target_link_libraries(Cartucho PRIVATE SDL2::SDL2main)
    endif()
    if(TARGET SDL2::SDL2-static)
        target_link_libraries(Cartucho PRIVATE SDL2::SDL2-static)
    else()
        target_link_libraries(Cartucho PRIVATE SDL2::SDL2)
    endif()
    target_link_libraries(Cartucho PRIVATE
        "-framework Foundation" "-framework UIKit" "-framework OpenGLES" "-framework QuartzCore"
        "-framework CoreGraphics" "-framework CoreAudio" "-framework AudioToolbox" "-framework AVFoundation"
        "-framework GameController" "-framework CoreMotion" "-framework CoreHaptics" "-framework CoreBluetooth"
        "-framework Metal" "-framework CoreFoundation" iconv)
    # Os emuladores (cores) ficam em Cartucho.app/Frameworks.
    set_target_properties(Cartucho PROPERTIES BUILD_RPATH "@executable_path/Frameworks" INSTALL_RPATH "@executable_path/Frameworks")
    return()
endif()

add_executable(Cartucho WIN32
    src/platform_common.cpp
    src/main.cpp
    src/host.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/../app/src/main/cpp/vk_bridge.cpp
    ${TP}/glad/src/gl.c
    ${TP}/miniz/miniz.c
    ${IMGUI}/imgui.cpp
    ${IMGUI}/imgui_draw.cpp
    ${IMGUI}/imgui_tables.cpp
    ${IMGUI}/imgui_widgets.cpp
    ${IMGUI}/backends/imgui_impl_sdl2.cpp
    ${IMGUI}/backends/imgui_impl_opengl3.cpp
)
if(WIN32)
    target_sources(Cartucho PRIVATE cartucho.rc)
endif()
# Versão (o CI passa -DCARTUCHO_VERSION=1.0.N): aparece na abertura, em Ajustes e no aviso de atualização.
if(DEFINED CARTUCHO_VERSION)
    target_compile_definitions(Cartucho PRIVATE CARTUCHO_VERSION="${CARTUCHO_VERSION}")
endif()

target_include_directories(Cartucho PRIVATE
    src ${TP} ${TP}/glad/include ${TP}/miniz ${IMGUI} ${IMGUI}/backends
    ${TP}/vulkan-headers/include ${CMAKE_CURRENT_SOURCE_DIR}/../app/src/main/cpp)

if(TARGET SDL2::SDL2main)
    target_link_libraries(Cartucho PRIVATE SDL2::SDL2main)
endif()
target_link_libraries(Cartucho PRIVATE SDL2::SDL2)
if(WIN32)
    target_link_libraries(Cartucho PRIVATE ole32 shell32 urlmon winhttp ws2_32 bcrypt crypt32)
    # Acesso ao Google Drive (saves na nuvem): ID e chave do cliente OAuth "App para computador".
    if(DEFINED ENV{CARTUCHO_GOOGLE_DESKTOP_ID} AND NOT "$ENV{CARTUCHO_GOOGLE_DESKTOP_ID}" STREQUAL "")
        target_compile_definitions(Cartucho PRIVATE
            CARTUCHO_GOOGLE_ID="$ENV{CARTUCHO_GOOGLE_DESKTOP_ID}"
            CARTUCHO_GOOGLE_SECRET="$ENV{CARTUCHO_GOOGLE_DESKTOP_SECRET}")
    endif()
    target_compile_definitions(Cartucho PRIVATE _CRT_SECURE_NO_WARNINGS UNICODE _UNICODE)
    if(MSVC)
        target_compile_options(Cartucho PRIVATE /utf-8)
    endif()
else()
    # Linux: o SDL2 vai em ../lib, ao lado do programa (AppImage e .tar.gz).
    find_package(Threads REQUIRED)
    target_link_libraries(Cartucho PRIVATE ${CMAKE_DL_LIBS} Threads::Threads)
    set_target_properties(Cartucho PROPERTIES BUILD_RPATH "$ORIGIN/../lib" INSTALL_RPATH "$ORIGIN/../lib")
endif()
