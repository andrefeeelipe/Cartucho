; Instalador do Cartucho para Windows (Inno Setup 6). O CI passa /DAppVersion=1.0.N e /DSrcDir=<pasta pronta>.
#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif
#ifndef SrcDir
  #define SrcDir "dist"
#endif

[Setup]
AppId={{6E1C2B8A-4A55-4F1F-9C0E-CA27C40C0A01}
AppName=Cartucho
AppVersion={#AppVersion}
AppPublisher=Cartucho
AppPublisherURL=https://github.com/andrefeeelipe/cartucho
DefaultDirName={autopf}\Cartucho
DefaultGroupName=Cartucho
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputBaseFilename=Cartucho-{#AppVersion}-windows-instalador
SetupIconFile=assets\cartucho.ico
UninstallDisplayIcon={app}\Cartucho.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "ptbr"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na área de trabalho"; Flags: unchecked

[Files]
Source: "{#SrcDir}\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\Cartucho"; Filename: "{app}\Cartucho.exe"
Name: "{autodesktop}\Cartucho"; Filename: "{app}\Cartucho.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Cartucho.exe"; Description: "Abrir o Cartucho agora"; Flags: nowait postinstall skipifsilent
