#!/usr/bin/env bash
# Instala o APK x86_64 no emulador e roda o autoteste da sala online.
# Falha (e impede a publicação) se a sala não funcionar ou se o app fechar.
set -u
apk=$(ls out/*-x86_64.apk | head -1)
adb install -r "$apk" || exit 1
adb logcat -c
adb shell am start -W -n app.cartucho/.net.SelfTestActivity
for i in $(seq 1 120); do
  log=$(adb logcat -d -s CartuchoAutoteste:*)
  if echo "$log" | grep -q "RESULTADO OK"; then echo "$log"; exit 0; fi
  if echo "$log" | grep -q "RESULTADO FALHA"; then echo "$log"; adb logcat -d | tail -150; exit 1; fi
  if adb logcat -d | grep -qE "Fatal signal.*app.cartucho|Process: app.cartucho"; then
    echo "::error::O app fechou durante o autoteste"
    adb logcat -d | grep -A60 -E "Fatal signal|FATAL EXCEPTION|DEBUG" | tail -200
    exit 1
  fi
  sleep 2
done
echo "::error::Autoteste não terminou em 4 minutos"
adb logcat -d | tail -300
exit 1
