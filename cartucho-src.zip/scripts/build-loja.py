#!/usr/bin/env python3
"""Gera o catálogo da Loja do Cartucho (loja.json) a partir do Homebrew Hub (hh.gbdev.io).

Só entra o que o Homebrew Hub publica abertamente: jogos e demos homebrew de Game Boy, Game Boy Color,
Game Boy Advance e NES, com um arquivo jogável. O app baixa cada jogo direto do servidor do
Homebrew Hub e mostra autor e licença; nenhum jogo é hospedado pelo Cartucho.

Uso: build-loja.py <arquivo-de-saída>
"""
import json
import sys
import time
import urllib.request
from datetime import datetime, timezone

API = "https://hh3.gbdev.io/api"
PLATFORMS = {"GB": "gb", "GBC": "gbc", "GBA": "gba", "NES": "nes"}
TYPES = {"game", "demo", "homebrew"}


def get(url, tries=4):
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Cartucho-loja/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:  # noqa: BLE001
            if attempt == tries - 1:
                raise
            time.sleep(2 + attempt * 3)


def developers(entry):
    dev = entry.get("developer")
    if isinstance(dev, str):
        return dev
    if isinstance(dev, list):
        names = [d.get("name", "") if isinstance(d, dict) else str(d) for d in dev]
        return ", ".join(n for n in names if n)
    return ""


def main():
    out_path = sys.argv[1]
    first = get(f"{API}/all?page=1&page_elements=10&order_by=title&sort=asc")
    pages = int(first.get("page_total", 1))
    entries = list(first.get("entries", []))
    for page in range(2, pages + 1):
        entries += get(f"{API}/all?page={page}&page_elements=10&order_by=title&sort=asc").get("entries", [])
        time.sleep(0.15)

    games = []
    seen = set()
    for e in entries:
        platform = PLATFORMS.get(str(e.get("platform", "")).upper())
        if not platform or e.get("typetag") not in TYPES:
            continue
        files = [f for f in e.get("files", []) if isinstance(f, dict) and f.get("playable")]
        if not files:
            continue
        default = next((f for f in files if f.get("default")), files[0])
        slug = e.get("slug")
        if not slug or slug in seen:
            continue
        seen.add(slug)
        shots = [s for s in e.get("screenshots", []) if isinstance(s, str)]
        desc = (e.get("description") or "").strip().replace("\r", "")
        if len(desc) > 600:
            desc = desc[:597].rsplit(" ", 1)[0] + "…"
        site = e.get("website")
        if isinstance(site, list):
            site = site[0] if site else ""
        games.append({
            "s": slug,
            "t": e.get("title") or slug,
            "p": platform,
            "y": e.get("typetag"),
            "d": developers(e),
            "l": e.get("gameLicense") or "",
            "x": desc,
            "f": default.get("filename"),
            "i": shots[0] if shots else "",
            "g": [t for t in e.get("tags", []) if isinstance(t, str)][:6],
            "w": site or e.get("repository") or "",
            "b": e.get("basepath") or "",
            "a": (e.get("date") or "")[:4],
        })

    data = {
        "v": 1,
        "fonte": "Homebrew Hub (hh.gbdev.io)",
        "gerado": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "jogos": games,
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    print(f"loja: {len(games)} jogos de {len(entries)} entradas")


if __name__ == "__main__":
    main()
