#!/usr/bin/env python3
"""Gera o catálogo da Loja do Cartucho (loja.json e, opcional, loja.tsv para o Windows).

Só entram jogos que os autores ou donos dos direitos liberaram para distribuição gratuita:
  - Homebrew Hub (hh.gbdev.io): homebrew de Game Boy, Game Boy Color, Game Boy Advance e NES.
  - ZXDB / Spectrum Computing: jogos de ZX Spectrum cujos autores ou editoras deram permissão
    de distribuição ("Allowed"), mais os homebrew lançados de 2000 em diante marcados como
    disponíveis (os que ainda estão à venda ficam de fora, como o próprio ZXDB indica).
    Precisa do banco ZXDB carregado num MySQL local (o CI faz isso); sem ele, esta parte é pulada.
  - TIC-80 (tic80.com): jogos publicados de graça pelos autores no site oficial do console.
O app baixa cada arquivo direto do site de origem e mostra o crédito; nada é hospedado pelo Cartucho.

Uso: build-loja.py <saída.json> [saída.tsv]
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from html import unescape

UA = {"User-Agent": "Cartucho-loja/2.0 (+https://github.com/andrefeeelipe/Cartucho)"}

# Gêneros do Cartucho (o app mostra estes nomes nos filtros).
GENRES = ["Ação", "Aventura", "Plataforma", "Tiro", "Corrida", "Esporte", "Luta", "Quebra-cabeça", "RPG",
          "Estratégia", "Simulação", "Labirinto", "Tabuleiro e cartas", "Educativo", "Casual", "Música"]

# Palavras-chave (em inglês, como os autores descrevem) -> gênero.
KEYWORDS = [
    ("RPG", r"\brpg\b|role[- ]?playing|jrpg|roguelike|rogue-like|dungeon"),
    ("Plataforma", r"platform|plataforma|jump ?'?n'? ?run|metroidvania"),
    ("Tiro", r"shoot|shmup|shooter|bullet hell|twin[- ]stick|\bfps\b|gun"),
    ("Corrida", r"racing|\brace\b|racer|kart|driving|corrida"),
    ("Esporte", r"sport|football|soccer|tennis|golf|basketball|baseball|bowling|skate|futebol|hockey|boxing"),
    ("Luta", r"fighting|fighter|beat[- ]?'?em[- ]?up|brawler|martial"),
    ("Quebra-cabeça", r"puzzle|sokoban|tetris|match[- ]?3|logic|brain|picross|nonogram|sudoku|quebra"),
    ("Estratégia", r"strategy|tactic|tower defen|\brts\b|turn[- ]based|war ?game|estrat"),
    ("Simulação", r"simulat|farming|tycoon|management|flight|pet\b"),
    ("Labirinto", r"maze|labyrinth|pac-?man|labirinto"),
    ("Tabuleiro e cartas", r"\bcard\b|cards|board game|chess|checkers|poker|solitaire|domino|xadrez|cartas"),
    ("Educativo", r"educat|learn|math|typing|quiz"),
    ("Música", r"rhythm|music game|dance"),
    ("Aventura", r"adventure|aventura|exploration|explore|quest|point[- ]and[- ]click|story|narrative|zelda"),
    ("Casual", r"casual|arcade|endless|score attack|clicker|idle"),
    ("Ação", r"action|ação|run ?and ?gun|hack ?and ?slash|survival"),
]


def genres_from_text(*texts):
    blob = " ".join(t for t in texts if t).lower()
    found = [g for g, rx in KEYWORDS if re.search(rx, blob)]
    out = []
    for g in found:
        if g not in out:
            out.append(g)
    return out[:3]


def get(url, tries=4, raw=False):
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=40) as r:
                data = r.read()
                return data if raw else data.decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            if attempt == tries - 1:
                raise
            time.sleep(2 + attempt * 3)


def clean_desc(text, limit=600):
    text = re.sub(r"<[^>]+>", " ", unescape(text or "")).replace("\r", "")
    text = re.sub(r"[ \t]+", " ", text).strip()
    if len(text) > limit:
        text = text[: limit - 3].rsplit(" ", 1)[0] + "…"
    return text


# ---------------------------------------------------------------- Homebrew Hub

HH_API = "https://hh3.gbdev.io/api"
HH_PLATFORMS = {"GB": "gb", "GBC": "gbc", "GBA": "gba", "NES": "nes"}


def homebrew_hub():
    first = json.loads(get(f"{HH_API}/search?page=1"))
    pages = int(first.get("page_total", 1))
    entries = list(first.get("entries", []))
    for page in range(2, pages + 1):
        try:
            entries += json.loads(get(f"{HH_API}/search?page={page}")).get("entries", [])
        except Exception as e:  # noqa: BLE001
            print(f"loja: Homebrew Hub página {page} falhou ({e})")
        time.sleep(0.1)
    games, seen = [], set()
    for e in entries:
        platform = HH_PLATFORMS.get(str(e.get("platform", "")).upper())
        if not platform or e.get("typetag") not in {"game", "demo", "homebrew"}:
            continue
        files = [f for f in e.get("files", []) if isinstance(f, dict) and f.get("playable")]
        slug = e.get("slug")
        if not files or not slug or slug in seen:
            continue
        seen.add(slug)
        default = next((f for f in files if f.get("default")), files[0])
        shots = [s for s in e.get("screenshots", []) if isinstance(s, str)]
        dev = e.get("developer")
        if isinstance(dev, list):
            dev = ", ".join((d.get("name", "") if isinstance(d, dict) else str(d)) for d in dev)
        site = e.get("website")
        if isinstance(site, list):
            site = site[0] if site else ""
        tags = [t for t in e.get("tags", []) if isinstance(t, str)]
        desc = clean_desc(e.get("description"))
        g = genres_from_text(" ".join(tags), e.get("title"), desc)
        players = 2 if any(re.search(r"multi|2[- ]?player|two player", t.lower()) for t in tags) else 0
        games.append({
            "s": slug, "t": e.get("title") or slug, "p": platform, "y": e.get("typetag"),
            "d": dev or "", "l": e.get("gameLicense") or "", "x": desc,
            "f": default.get("filename"), "i": shots[0] if shots else "", "g": tags[:6], "k": g,
            "w": site or e.get("repository") or "", "b": e.get("basepath") or "",
            "a": (e.get("date") or "")[:4], "n": "", "j": players, "o": "Homebrew Hub",
        })
    print(f"loja: Homebrew Hub {len(games)} de {len(entries)} entradas")
    return games


# ---------------------------------------------------------------- ZX Spectrum (ZXDB)

ZX_GENRES = {
    1: ["RPG", "Aventura"], 2: ["Aventura"], 4: ["RPG"], 5: ["Aventura"], 6: ["Aventura"],
    7: ["Ação"], 8: ["Aventura", "Ação"], 9: ["Luta"], 10: ["Luta"], 11: ["Labirinto"], 12: ["Casual"],
    13: ["Plataforma"], 14: ["Corrida", "Ação"], 15: ["Tiro"], 16: ["Ação", "Corrida"], 17: ["Tabuleiro e cartas"],
    18: ["Educativo"], 19: ["Simulação"], 20: ["Quebra-cabeça"], 21: ["Quebra-cabeça"], 22: ["Esporte"],
    23: ["Esporte", "Estratégia"], 24: ["Estratégia"], 25: ["Estratégia"], 26: ["Estratégia"],
    27: ["Tabuleiro e cartas"], 28: ["Tabuleiro e cartas"], 29: ["Tabuleiro e cartas"], 30: ["Educativo"],
    31: ["Casual", "Educativo"], 32: ["Casual"], 33: ["Simulação"],
}
ZX_HOST = "https://spectrumcomputing.co.uk"

ZX_SQL = r"""
SELECT e.id, e.title, IFNULL(e.genretype_id,0), IFNULL(e.language_id,''), e.max_players, IFNULL(r.release_year,0),
  IFNULL((SELECT GROUP_CONCAT(DISTINCT l.name ORDER BY a.author_seq SEPARATOR ', ') FROM authors a JOIN labels l ON l.id=a.label_id WHERE a.entry_id=e.id),''),
  IFNULL((SELECT GROUP_CONCAT(DISTINCT l.name SEPARATOR ', ') FROM publishers p JOIN labels l ON l.id=p.label_id WHERE p.entry_id=e.id AND p.release_seq=0),''),
  (SELECT d.file_link FROM downloads d WHERE d.entry_id=e.id AND d.filetype_id IN (8,10) AND d.is_demo=0
     AND (d.file_link LIKE '/pub/%' OR d.file_link LIKE '/zxdb/%')
     AND (d.file_link LIKE '%.tap.zip' OR d.file_link LIKE '%.tzx.zip' OR d.file_link LIKE '%.z80.zip' OR d.file_link LIKE '%.sna.zip' OR d.file_link LIKE '%.szx.zip')
     ORDER BY (d.file_link LIKE '%.tap.zip') DESC, (d.file_link LIKE '%.tzx.zip') DESC, d.release_seq, d.id LIMIT 1),
  IFNULL((SELECT d.file_link FROM downloads d WHERE d.entry_id=e.id AND d.filetype_id=2
     AND (d.file_link LIKE '%.gif' OR d.file_link LIKE '%.png' OR d.file_link LIKE '%.jpg')
     AND (d.file_link LIKE '/pub/%' OR d.file_link LIKE '/zxdb/%') ORDER BY d.id LIMIT 1),''),
  (EXISTS(SELECT 1 FROM permissions pm WHERE pm.permissiontype_id='A' AND pm.label_id IN
      (SELECT a.label_id FROM authors a WHERE a.entry_id=e.id UNION SELECT p.label_id FROM publishers p WHERE p.entry_id=e.id))) AS allowed,
  (EXISTS(SELECT 1 FROM permissions pm WHERE pm.permissiontype_id IN ('D','P','N') AND pm.label_id IN
      (SELECT a.label_id FROM authors a WHERE a.entry_id=e.id UNION SELECT p.label_id FROM publishers p WHERE p.entry_id=e.id))) AS denied
FROM entries e
LEFT JOIN releases r ON r.entry_id=e.id AND r.release_seq=0
LEFT JOIN machinetypes m ON m.id=e.machinetype_id
WHERE e.availabletype_id='A' AND e.is_xrated=0 AND e.genretype_id BETWEEN 1 AND 33
  AND (e.machinetype_id IS NULL OR m.text LIKE 'ZX-Spectrum%')
"""


def zx_spectrum():
    db = os.environ.get("ZXDB_DATABASE", "zxdb")
    cmd = ["mysql", "-uroot", "-p" + os.environ.get("ZXDB_PASSWORD", "root"), db, "-B", "-N", "-e", ZX_SQL]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", timeout=900)
    except Exception as e:  # noqa: BLE001
        print(f"loja: ZXDB indisponível ({e}); ZX Spectrum fica de fora")
        return []
    if out.returncode != 0:
        print(f"loja: ZXDB indisponível ({out.stderr.strip()[:200]}); ZX Spectrum fica de fora")
        return []
    games, allowed_n, modern_n = [], 0, 0
    for line in out.stdout.splitlines():
        c = line.split("\t")
        if len(c) < 12:
            continue
        eid, title, genre, lang, players, year, authors, pubs, link, shot, allowed, denied = c[:12]
        if link in ("", "NULL") or denied == "1":
            continue
        year = int(year or 0)
        if allowed == "1":
            allowed_n += 1
        elif year >= 2000:
            modern_n += 1  # homebrew moderno marcado como disponível (os ainda à venda são 'S' e ficam de fora)
        else:
            continue
        title = unescape(title)
        fname = link.rsplit("/", 1)[-1]
        games.append({
            "s": f"zx-{int(eid)}", "t": title, "p": "zxspectrum", "y": "game",
            "d": authors or pubs, "l": "Distribuição liberada pelo autor/editora" if allowed == "1" else "Homebrew gratuito",
            "x": f"Publicado por {pubs}." if pubs and pubs != authors else "",
            "f": fname, "u": ZX_HOST + urllib.request.quote(link), "c": (ZX_HOST + urllib.request.quote(shot)) if shot and shot != "NULL" else "",
            "i": "", "g": [], "k": ZX_GENRES.get(int(genre or 0), []), "w": f"{ZX_HOST}/entry/{int(eid)}",
            "b": "", "a": str(year) if year else "", "n": lang if len(lang) == 2 else "",
            "j": int(players or 1), "o": "Spectrum Computing (ZXDB)",
        })
    print(f"loja: ZX Spectrum {len(games)} jogos ({allowed_n} com permissão do autor/editora, {modern_n} homebrew de 2000+)")
    return games


# ---------------------------------------------------------------- TIC-80

TIC = "https://tic80.com"
TIC_ROW = re.compile(r'name = "(.*?)", hash = "([0-9a-f]+)", id = (\d+), filename = "(.*?)"')


def tic80_details(cart):
    name, h, cid, fname = cart
    author, desc = "", ""
    try:
        page = get(f"{TIC}/play?cart={cid}", tries=2)
        m = re.search(r'<meta name="author" content="(?:by )?(.*?)">', page)
        author = unescape(m.group(1)).strip() if m else ""
        m = re.search(r'<div>made by (.*?)</div>', page)
        if m:
            author = unescape(re.sub(r"<[^>]+>", "", m.group(1))).strip() or author
        m = re.search(r'<meta property="og:description" content="(.*?)">', page, re.S)
        desc = clean_desc(m.group(1)) if m else ""
    except Exception:  # noqa: BLE001
        pass
    title = re.sub(r"\.tic$", "", name).strip()
    return {
        "s": f"tic-{cid}", "t": title, "p": "tic80", "y": "game", "d": author, "l": "Publicado de graça pelo autor no TIC-80",
        "x": desc, "f": fname, "u": f"{TIC}/cart/{h}/{urllib.request.quote(fname)}", "c": f"{TIC}/cart/{h}/cover.gif",
        "i": "", "g": [], "k": genres_from_text(title, desc), "w": f"{TIC}/play?cart={cid}", "b": "", "a": "",
        "n": "", "j": 0, "o": "TIC-80",
    }


def tic80():
    try:
        text = get(f"{TIC}/api?fn=dir&path=play/Games")
    except Exception as e:  # noqa: BLE001
        print(f"loja: TIC-80 indisponível ({e})")
        return []
    carts, seen = [], set()
    for m in TIC_ROW.finditer(text):
        if m.group(3) not in seen:
            seen.add(m.group(3))
            carts.append((unescape(m.group(1)), m.group(2), m.group(3), m.group(4)))
    with ThreadPoolExecutor(8) as pool:
        games = list(pool.map(tic80_details, carts))
    print(f"loja: TIC-80 {len(games)} jogos")
    return games


# ---------------------------------------------------------------- saída

def main():
    out_path = sys.argv[1]
    games = []
    for source in (homebrew_hub, zx_spectrum, tic80):
        try:
            games += source()
        except Exception as e:  # noqa: BLE001
            print(f"loja: fonte {source.__name__} falhou ({e})")
    if not games:
        sys.exit("loja: nenhum jogo")
    games.sort(key=lambda g: (g["t"].lower(), g["p"]))
    data = {
        "v": 2,
        "fonte": "Homebrew Hub · ZXDB/Spectrum Computing · TIC-80",
        "gerado": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "generos": GENRES,
        "jogos": games,
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    if len(sys.argv) > 2:
        def clean(v):
            if isinstance(v, list):
                v = ",".join(v)
            return str(v if v is not None else "").replace("\t", " ").replace("\r", " ").replace("\n", " ").strip()
        cols = ("s", "t", "p", "y", "d", "l", "f", "i", "b", "a", "x", "u", "c", "k", "n", "j", "o", "w")
        with open(sys.argv[2], "w", encoding="utf-8", newline="\n") as f:
            for g in games:
                f.write("\t".join(clean(g.get(k, "")) for k in cols) + "\n")
    by = {}
    for g in games:
        by[g["p"]] = by.get(g["p"], 0) + 1
    pt = sum(1 for g in games if g.get("n") == "pt")
    print(f"loja: {len(games)} jogos no total {by}; em português: {pt}")


if __name__ == "__main__":
    main()
