#!/usr/bin/env python3
"""Gera as listas de reconhecimento de jogos (assets/ids/<sistema>.tsv.gz) a partir do libretro-database.

Cada linha: "<chave>\t<nome oficial>". Cartuchos usam o CRC32 em hexadecimal minúsculo; discos usam
"s:" + código de série só com letras e números (ex.: s:SLUS00594). Os nomes são os das listas
No-Intro/Redump, os mesmos usados pelo acervo de capas libretro-thumbnails.

Uso: build-ids.py <pasta do libretro-database> <pasta de saída>
"""
import gzip
import os
import re
import sys

# Sistema do Cartucho -> nomes das listas no libretro-database.
DATS = {
    "atari2600": ["Atari - 2600"], "atari5200": ["Atari - 5200"], "atari7800": ["Atari - 7800"],
    "lynx": ["Atari - Lynx"], "jaguar": ["Atari - Jaguar"],
    "nes": ["Nintendo - Nintendo Entertainment System", "Nintendo - Family Computer Disk System"],
    "snes": ["Nintendo - Super Nintendo Entertainment System", "Nintendo - Satellaview"],
    "gb": ["Nintendo - Game Boy"], "gbc": ["Nintendo - Game Boy Color"], "gba": ["Nintendo - Game Boy Advance"],
    "n64": ["Nintendo - Nintendo 64"], "nds": ["Nintendo - Nintendo DS"], "virtualboy": ["Nintendo - Virtual Boy"],
    "pokemini": ["Nintendo - Pokemon Mini"],
    "mastersystem": ["Sega - Master System - Mark III", "Sega - SG-1000"], "gamegear": ["Sega - Game Gear"],
    "megadrive": ["Sega - Mega Drive - Genesis"], "sega32x": ["Sega - 32X"],
    "pce": ["NEC - PC Engine - TurboGrafx 16", "NEC - PC Engine SuperGrafx"],
    "ngp": ["SNK - Neo Geo Pocket Color", "SNK - Neo Geo Pocket"],
    "wswan": ["Bandai - WonderSwan Color", "Bandai - WonderSwan"],
    "colecovision": ["Coleco - ColecoVision"], "intellivision": ["Mattel - Intellivision"],
    "odyssey2": ["Magnavox - Odyssey2"], "channelf": ["Fairchild - Channel F"], "vectrex": ["GCE - Vectrex"],
    "msx": ["Microsoft - MSX", "Microsoft - MSX2"], "supervision": ["Watara - Supervision"],
    "megaduck": ["Welback - Mega Duck"], "arcadia": ["Emerson - Arcadia 2001"], "scv": ["Epoch - Super Cassette Vision"],
    "vic20": ["Commodore - VIC-20"], "plus4": ["Commodore - Plus-4"], "uzebox": ["Uzebox"],
    # Discos: pelo código de série.
    "psx": ["Sony - PlayStation"], "ps2": ["Sony - PlayStation 2"], "psp": ["Sony - PlayStation Portable"],
    "gamecube": ["Nintendo - GameCube"], "wii": ["Nintendo - Wii"],
}
DISC = {"psx", "ps2", "psp", "gamecube", "wii"}

GAME = re.compile(r'^game \($(.*?)^\)', re.M | re.S)
NAME = re.compile(r'^\s*name "(.*?)"', re.M)
CRC = re.compile(r'\bcrc ([0-9A-Fa-f]{8})\b')
SERIAL = re.compile(r'\bserial "(.*?)"')


def find_dats(root):
    found = {}
    for base, _dirs, files in os.walk(root):
        if "/.git" in base:
            continue
        for f in files:
            if f.endswith(".dat"):
                found.setdefault(f[:-4], []).append(os.path.join(base, f))
    return found


def main():
    root, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    dats = find_dats(root)
    total = 0
    for system, names in DATS.items():
        table = {}
        for dat_name in names:
            for path in dats.get(dat_name, []):
                text = open(path, encoding="utf-8", errors="replace").read()
                for block in GAME.finditer(text):
                    body = block.group(1)
                    m = NAME.search(body)
                    if not m:
                        continue
                    name = m.group(1).strip()
                    if system in DISC:
                        for serial in SERIAL.findall(body):
                            for one in re.split(r"[,/]\s*", serial):
                                key = "s:" + re.sub(r"[^A-Za-z0-9]", "", one).upper()
                                if len(key) > 6:
                                    table.setdefault(key, name)
                    else:
                        for crc in CRC.findall(body):
                            table.setdefault(crc.lower(), name)
        if not table:
            print(f"ids: {system} sem lista")
            continue
        with gzip.open(os.path.join(out, f"{system}.tsv.gz"), "wt", encoding="utf-8", compresslevel=9) as f:
            for k in sorted(table):
                f.write(f"{k}\t{table[k]}\n")
        total += len(table)
        print(f"ids: {system} {len(table)}")
    size = sum(os.path.getsize(os.path.join(out, f)) for f in os.listdir(out))
    print(f"ids: {total} jogos reconhecíveis, {size // 1024} KB")


if __name__ == "__main__":
    main()
