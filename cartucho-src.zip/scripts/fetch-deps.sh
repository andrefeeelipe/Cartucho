#!/usr/bin/env bash
# Baixa tudo que o Cartucho precisa para compilar:
#   - libretro.h (cabeçalho oficial da API libretro)
#   - rcheevos (biblioteca oficial do RetroAchievements)
#   - cores libretro pré-compilados para Android (buildbot oficial do libretro)
# Os cores entram no APK; o app nunca baixa nada em tempo de execução.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CPP="$ROOT/app/src/main/cpp/third_party"
JNI="$ROOT/app/src/main/jniLibs"
ASSETS="$ROOT/app/src/main/assets"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

RCHEEVOS_TAG="${RCHEEVOS_TAG:-v11.6.0}"
ABIS="${ABIS:-arm64-v8a armeabi-v7a x86_64}"
BUILDBOT="https://buildbot.libretro.com/nightly/android/latest"

# id do Cartucho  ->  nome do core no buildbot
CORES="
stella:stella
prosystem:prosystem
handy:handy
fceumm:fceumm
snes9x:snes9x
gambatte:gambatte
mgba:mgba
genesis_plus_gx:genesis_plus_gx
picodrive:picodrive
pce_fast:mednafen_pce_fast
ngp:mednafen_ngp
wswan:mednafen_wswan
fbneo:fbneo
mupen64plus:mupen64plus_next_gles3
melonds:melonds
citra:citra
pcsx_rearmed:pcsx_rearmed
ppsspp:ppsspp
flycast:flycast
yabause:yabause
play:play
"

echo "==> libretro.h"
mkdir -p "$CPP/libretro"
curl -fsSL --retry 3 -o "$CPP/libretro/libretro.h" \
  https://raw.githubusercontent.com/libretro/libretro-common/master/include/libretro.h

echo "==> rcheevos ($RCHEEVOS_TAG)"
rm -rf "$CPP/rcheevos"
git clone --depth 1 --branch "$RCHEEVOS_TAG" https://github.com/RetroAchievements/rcheevos.git "$CPP/rcheevos" \
  || git clone --depth 1 https://github.com/RetroAchievements/rcheevos.git "$CPP/rcheevos"
rm -rf "$CPP/rcheevos/.git" "$CPP/rcheevos/test"

echo "==> cores"
MANIFEST="$ASSETS/cores.txt"
mkdir -p "$ASSETS"
: > "$MANIFEST"
for abi in $ABIS; do
  mkdir -p "$JNI/$abi"
  for entry in $CORES; do
    id="${entry%%:*}"
    name="${entry##*:}"
    zip="$WORK/${name}_${abi}.zip"
    url="$BUILDBOT/$abi/${name}_libretro_android.so.zip"
    if curl -fsSL --retry 2 -o "$zip" "$url"; then
      unzip -o -q "$zip" -d "$WORK/$abi"
      if [ -f "$WORK/$abi/${name}_libretro_android.so" ]; then
        mv "$WORK/$abi/${name}_libretro_android.so" "$JNI/$abi/libcore_${id}.so"
        echo "$abi $id ok" | tee -a "$MANIFEST"
      else
        echo "$abi $id ausente-no-zip" | tee -a "$MANIFEST"
      fi
    else
      echo "$abi $id indisponivel" | tee -a "$MANIFEST"
    fi
  done
done

echo "==> arquivos de sistema do PPSSPP (fontes e flash0, opcional)"
if curl -fsSL --retry 2 -o "$WORK/ppsspp.zip" "https://buildbot.libretro.com/assets/system/PPSSPP.zip"; then
  mkdir -p "$ASSETS/system"
  unzip -o -q "$WORK/ppsspp.zip" -d "$ASSETS/system"
  echo "PPSSPP assets ok"
else
  echo "PPSSPP assets indisponíveis (o core ainda funciona, com fontes padrão)"
fi

echo "==> pronto"
